package com.sap.bie.sca.contributionxml.gen.util;

import java.io.File;
import java.io.IOException;

import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.gen.IGeneratorCall;
import com.sap.tc.buildplugin.util.BuildPluginException;
import com.sap.tc.buildplugin.util.IAntToolkit;

public class ScaContribXmlBuildFileCreatorHelper {

	private static final String DEFAULT = "default"; //$NON-NLS-1$
	public static final String OUTPUT_FOLDER = "META-INF"; //$NON-NLS-1$
	public static final String CONVERTER_OUTPUT_FOLDER = "converterOutput";//$NON-NLS-1$
	public static final String TEMP_DIR_SUFFIX = "scdl_gen";
	
	public static void createGeneratorCallPart(IGlobalPluginUtil gpu, IPluginBuildInfo pbi, String generatorId)
			throws BuildPluginException {
		// calls the generator chain defined in .bpfext which generates the MM
		IGeneratorCall gc = gpu.createGeneratorCall(generatorId);
		gc.setOutputPath(DEFAULT, pbi.getTempDir().getAbsolutePath());
		gc.setParameter("outputFolderName", OUTPUT_FOLDER); //$NON-NLS-1$
		gc.invoke();
	}

	public static void createScaContribXmlDeployArchivePreparationPart(IGlobalPluginUtil gpu, IPluginBuildInfo pbi, IAntToolkit antToolKit,
			String chainId, String generatorId) throws IOException {
		antToolKit.taskdef("prepda"); //$NON-NLS-1$
		IAntToolkit.Element entity = antToolKit.createElement("prepda"); //$NON-NLS-1$
		
		//add the "extendmoduletypes" attribute in order to make the implicit include of archives 
		//explicit (required as we add an explicit exclude of "mc~container" later on		
		entity.addAttribute("extendmoduletypes", "true");
		
		//the newly generated sca-contributin.xml file has to be packaged into the ear archive
		IAntToolkit.Element filesetMetaInfChild = entity.createChild("fileset"); //$NON-NLS-1$
		filesetMetaInfChild.addAttribute("dir", pbi.getTempDir().getAbsolutePath()); //$NON-NLS-1$
		IAntToolkit.Element includeChild = filesetMetaInfChild.createChild("include"); //$NON-NLS-1$
		includeChild.addAttribute("name", OUTPUT_FOLDER + "/**"); //$NON-NLS-1$ //$NON-NLS-2$
		
		//the converted cfgar archives have to be included as well
		IAntToolkit.Element filesetCfgArChild = entity.createChild("fileset"); //$NON-NLS-1$
		filesetCfgArChild.addAttribute("dir", pbi.getTempDir().getAbsolutePath() + "/" + CONVERTER_OUTPUT_FOLDER ); //$NON-NLS-1$//$NON-NLS-2$
		IAntToolkit.Element includeChild2 = filesetCfgArChild.createChild("include"); //$NON-NLS-1$
		includeChild2.addAttribute("name", "**/*.*"); //$NON-NLS-1$ //$NON-NLS-2$
				
		//the original cfgar archives which were used in 7.11 have to be excluded.
		//reason: ESB in 7.20 does not support mixture of cfgar files and scdl files within one deploy archive
		IAntToolkit.Element moduleExcludeChild = entity.createChild("moduletype");//$NON-NLS-1$
		moduleExcludeChild.addAttribute("type", "SAP-J2EE-Module[container-type[mc~container]]");//$NON-NLS-1$//$NON-NLS-2$
		moduleExcludeChild.addAttribute("mode", "exclude-immediate");//$NON-NLS-1$//NON-NLS-2$
				
		entity.render();
	}
}
