/**
 * 
 */
package com.sap.bie.sca.contributionxml.gen;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.Map.Entry;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import com.sap.bie.sca.contributionxml.gen.util.ScaContribXmlBuildFileCreatorHelper;
import com.sap.bie.sca.contributionxml.gen.util.XMLSCAConstants;
import com.sap.bie.sca.contributionxml.gen.util.XmlExportService;
import com.sap.bie.sca.scdl.backward.convertor.CfgArchConvertor;
import com.sap.tc.buildplugin.BuildSessionManager;
import com.sap.tc.buildplugin.api.IArchiveDescriptor;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.buildplugin.pp.api.IPublicPartReference;

/**
 * 
 * Generates the sca-contribution.xml on deployable level.
 * 
 * @author d038406
 * 
 */
public class ScaContributionGenerator extends Task {
	private static final String HTTP_WWW_SAP_COM_SCA_CONTENT = "http://www.sap.com/sca/content"; //$NON-NLS-1$
	private static final String LOCATION = "location"; //$NON-NLS-1$
	private static final String NAMESPACE = "namespace"; //$NON-NLS-1$
	private static final String IMPORT = "import"; //$NON-NLS-1$
	private static final String XMLNS_SAP = "xmlns:sap"; //$NON-NLS-1$
	private static final String XMLNS = "xmlns"; //$NON-NLS-1$
	private static final String CONTRIBUTION = "contribution"; //$NON-NLS-1$
	private static final String ASSEMBLY_PP = "assembly"; //$NON-NLS-1$
	private static final String META_INF_FOLDER = "META-INF"; //$NON-NLS-1$

	//module type that is used for cfgar-archives by 7.11 mass configuration 
	private static final String CFGAR_MODULE_TYPE = "SAP-J2EE-Module[container-type[mc~container]]";//$NON-NLS-1$
	//file extension of 7.11 mass configuration archives
	private static final String CFGAR_FILE_EXT = "cfgar";//$NON-NLS-1$
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.tools.ant.Task#execute()
	 */
	@Override
	public void execute() throws BuildException {

		super.execute();
		IPluginBuildInfo pbi = (IPluginBuildInfo) BuildSessionManager.getFromBuildSession(IPluginBuildInfo.class.getName());
		Map<String, Collection<String>> imports = new HashMap<String, Collection<String>>();

		// TODO LIMITATION: Here I only evaluate the direct dependencies for
			// SCDL contributions deeper nesting (i.e. a module assembling
			// another entity providing scdl contributions is not supported).
			// TODO the API reports components depedencies per public part (i.e.
			// if a DC A depends on DC B public part 1 and 2, the dependency
			// between A and B is reported twice. This case is covered by only
			// adding the import location under the condition that is not
			// present but that is inefficient. Fix this to only evaluate a
			// component dependency once.
			
		//we have to search for scdl contributions in jar archives located in any referenced assembly pp
		List<IPublicPartReference> referencedPPs=pbi.getPublicPartReferences(ASSEMBLY_PP);
		List<String> attributes = Arrays.asList("jar"); //$NON-NLS-1$
		
		List<IArchiveDescriptor> ads = pbi.getArchiveDescriptors(referencedPPs, attributes);
		for (IArchiveDescriptor ad : ads) {			
			List<File> files = ad.getFiles();
			
			//check if we are currently handling an 7.11 based mass configuration archive (cfgarch)
			File cfgarOutput = new File(pbi.getTempDir().getAbsolutePath() + "/" + ScaContribXmlBuildFileCreatorHelper.CONVERTER_OUTPUT_FOLDER);//$NON-NLS-1$
			if(!cfgarOutput.exists())
				cfgarOutput.mkdirs();
			
			files = convertCfgArchives(ad, cfgarOutput.getAbsolutePath());
						
			for (File f : files) {
				ZipFile zip=null;
				try {
					zip = new ZipFile(f);
				} catch (IOException e) {
					Log.warn("No zip file");//$NON-NLS-1$
					continue;
				}
				
				//check if the file contains a sca contribution file
				ZipEntry entry = zip.getEntry( META_INF_FOLDER + "/" + XMLSCAConstants.SCA_CONTRIBUTIONFILENAME); //$NON-NLS-1$
				if(entry!=null) {
					//this entry has to be added to the contribution file in the ear archive
					String namespace = getImportNamespace();
					if (imports.containsKey(namespace)) {
						Collection<String> locations = imports.get(namespace);
						
						if (!locations.contains(f.getName())) {
							locations.add(f.getName());
						}
					} else {
						Collection<String> locations = new Vector<String>();
						locations.add(f.getName());
						imports.put(namespace, locations);
					}		
				}
				
			}
		}

		//generate the file only if there are any contributions
		if(imports.keySet().size()>0)
			generateScaContributionsXml(pbi.getTempDir() + "", imports); //$NON-NLS-1$
	}

	/**
	 * 
	 * Creates the XML and stores it.
	 * 
	 * @param genDir
	 *            - the directory to which the XML will be written.
	 * @param namespace
	 *            - the imported namespace.
	 * @param location
	 *            - the import location.
	 * 
	 */
	private void generateScaContributionsXml(final String genDir, Map<String, Collection<String>> imports) {

		// We need a Document
		DocumentBuilderFactory dbfac = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder;

		try {
			docBuilder = dbfac.newDocumentBuilder();
		} catch (ParserConfigurationException e1) {
			throw new RuntimeException(e1);
		}

		Document doc = docBuilder.newDocument();

		// target format: <import
		// namespace="http://www.sap.com/sca/content/test"
		// location="demo.sap.com~test.ws.scdl.ejb.jar" />

		Element contributionTag = doc.createElement(CONTRIBUTION);
		contributionTag.setAttribute(XMLNS, XMLSCAConstants.SCA_NAMESPACE);
		contributionTag.setAttribute(XMLNS_SAP, XMLSCAConstants.SCA_SAP_NAMESPACE);

		Set<Entry<String, Collection<String>>> namespaces = imports.entrySet();
		for (Iterator<Entry<String, Collection<String>>> iterator = namespaces.iterator(); iterator.hasNext();) {
			Entry<String, Collection<String>> entry = iterator.next();
			Collection<String> locations = entry.getValue();

			for (Iterator<String> iterator2 = locations.iterator(); iterator2.hasNext();) {
				Element importTag = doc.createElement(IMPORT);
				importTag.setAttribute(NAMESPACE, entry.getKey());
				String location = iterator2.next();
				importTag.setAttribute(LOCATION, location);
				contributionTag.appendChild(importTag);
			}
		}

		doc.appendChild(contributionTag);

		String path = genDir + File.separator + META_INF_FOLDER;
		String filename = path + File.separator + XMLSCAConstants.SCA_CONTRIBUTIONFILENAME;

		XmlExportService.storeXmlDocument(doc, filename);

		Log.info("			[SCA-CONTRIB-GEN] Sca contribution XML output location: " + filename); //$NON-NLS-1$
	}

	/**
	 * @return
	 */
	private String getImportNamespace() {
		// TODO here we should implement proper support for namespaces in the
		// future.
		return HTTP_WWW_SAP_COM_SCA_CONTENT;
	}
	
	/**
	 * Calls the converter which transforms an 7.11 cfgarch file used by
	 * mass configuration into a scdl based archive that is used in 7.20.
	 * 
	 * The method first checks if the passed archive descriptions refers 
	 * to a cfgarch archive. If yes, the converter will be called for every
	 * file in the archive (normally just one).
	 * 
	 * @param ad {@link IArchiveDescriptor) that should be converted.
	 * 
	 * @return Returns the converted archive files. If the archive descriptor
	 * 		   does not need to be converted, it simply returns 
	 * 		   {@link IArchiveDescriptor#getFiles()}. 
	 */
	private List<File> convertCfgArchives(IArchiveDescriptor ad, String tempDir) {
		boolean isCfgArchive = ad.getAttributes().contains(CFGAR_MODULE_TYPE);
		if(!isCfgArchive)
			return ad.getFiles();
		
		Log.info("			[SCA-CONTRIB-GEN] Mass configuration archive from 7.11 or earlier detected. Conversion will be started.");//$NON-NLS-1$

		File baseFolder = new File(tempDir);
		if(!baseFolder.exists())
			baseFolder.mkdirs();
		
		List<File> filesNew = new ArrayList<File>();
		
		for(File f : ad.getFiles()) {
			if(!f.getName().endsWith(CFGAR_FILE_EXT))
				continue;
				
			String cfgArcName = f.getName();
			String newName = cfgArcName.substring(0, cfgArcName.lastIndexOf('.')+1) + "jar";//$NON-NLS-1$			
				
			File fNew = new File(tempDir + "/" + newName);//$NON-NLS-1$
						
			Log.info("			[SCA-CONTRIB-GEN] Converting file '" + f.getName() + "' to '" + fNew.getName() + "'"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
			
			try {
				CfgArchConvertor.convert(f, fNew, getImportNamespace());
			} catch (IOException e) {
				throw new RuntimeException(e);
			} catch (ParserConfigurationException e) {
				throw new RuntimeException(e);
			} catch (SAXException e) {
				throw new RuntimeException(e);
			} catch (TransformerException e) {
				throw new RuntimeException(e);
			}
			filesNew.add(fNew);
		}
		
		Log.info("			[SCA-CONTRIB-GEN] Conversion completed.");//$NON-NLS-1$
		return filesNew;
	}
}
