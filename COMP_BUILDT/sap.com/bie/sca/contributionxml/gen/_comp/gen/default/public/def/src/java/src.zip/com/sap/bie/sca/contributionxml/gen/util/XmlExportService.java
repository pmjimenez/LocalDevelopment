package com.sap.bie.sca.contributionxml.gen.util;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;

/**
 * 
 * This class contains helper methods for the XML export.
 * 
 * @author D038406
 * 
 */
public class XmlExportService {


	public static DocumentBuilder getDocumentBuilder() {
		// We need a Document
		DocumentBuilderFactory dbfac = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder;

		try {
			docBuilder = dbfac.newDocumentBuilder();
		} catch (ParserConfigurationException e1) {
			throw new RuntimeException(e1);
		}
		
		return docBuilder;
	}
	
	public static void storeXmlDocument(Document doc, String fileName) {

		// Output the XML
		// set up a transformer
		try {

			File file = new File(fileName);
			if (!file.getParentFile().exists()) {
				file.getParentFile().mkdirs();
			}
			file.createNewFile();
			Result result = new StreamResult(file);

			// Write the DOM document to the file
			TransformerFactory transfac = TransformerFactory.newInstance();
			Transformer trans = transfac.newTransformer();
			// trans.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			trans.setOutputProperty(OutputKeys.INDENT, "yes"); //$NON-NLS-1$
			trans.setOutputProperty(OutputKeys.METHOD, "xml"); //$NON-NLS-1$

			Source source = new DOMSource(doc);
			trans.transform(source, result);

			// write the DOM document to String
			StringWriter sw = new StringWriter();
			result = new StreamResult(sw);
			trans.transform(source, result);
		} catch (IOException e) {			
			throw new RuntimeException(e);
		} catch (TransformerConfigurationException e) {
			throw new RuntimeException(e);
		} catch (IllegalArgumentException e) {
			throw new RuntimeException(e);
		} catch (TransformerFactoryConfigurationError e) {
			throw new RuntimeException(e);
		} catch (TransformerException e) {
			throw new RuntimeException(e);
		}
	}
}
