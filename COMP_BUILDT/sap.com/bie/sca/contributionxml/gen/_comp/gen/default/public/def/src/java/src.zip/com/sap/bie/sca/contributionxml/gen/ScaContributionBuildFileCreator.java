/**
 * 
 */
package com.sap.bie.sca.contributionxml.gen;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.sap.tc.buildplugin.api.IDataContext;
import com.sap.tc.buildplugin.gen.AbstractGenerator;
import com.sap.tc.buildplugin.gen.GeneratorException;
import com.sap.tc.buildplugin.util.IAntToolkit;
import com.sap.tc.buildplugin.util.IAntToolkit.Element;

/**
 * 
 * @author d038406
 *
 */
public class ScaContributionBuildFileCreator extends AbstractGenerator {

	private static final String CONTRIB_XML_GENERATOR_ID = "gen_contribution_xml"; //$NON-NLS-1$

	/* (non-Javadoc)
	 * @see com.sap.tc.buildplugin.gen.IGenerator#execute(com.sap.tc.buildplugin.util.IAntToolkit, com.sap.tc.buildplugin.api.IDataContext, java.util.Map, java.util.Map, java.util.Map, java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	public void execute(IAntToolkit antWriter, IDataContext localContext, Map<String, List> inputPaths, Map<String, Object> outputPaths,
			Map<String, List> usedPaths, Map<String, Object> parameters) throws GeneratorException, IOException {
		Element elem = antWriter.createElement(CONTRIB_XML_GENERATOR_ID);
		antWriter.startTimer("Starting sca-contribution.xml generator..."); //$NON-NLS-1$
		elem.render();
		antWriter.showTimer("Starting sca-contribution.xml generator"); //$NON-NLS-1$
	}
}
