package com.sap.bie.sca.scdl.backward.convertor;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * Converter that is able to transform an cfgar archive that was used by mass configuration in 7.11 into a scdl file based 
 * jar file that is used from 7.20 on. The converter has been implemented by the ESB team (Alexander Zubev´s team) and should
 * be maintained by this team in the future. Though it is packaged into the scdl generator due to simplicity reasons.
 * 
 * The converter is required as 7.20 introduces a scdl based deployment format for ESB metadata. The implementation of the ESB
 * does not support deploy archives that mix 7.20 scdl based deployment files and 7.11 cfgar files. Therefore, whenever the
 * scdl generator is triggered for a deployment archives that assembles module archive (ear -> jar case), the converter has 
 * to be called if a cfgar file os recognized.
 * 
 * @author d040882
 *
 */

public class CfgArchConvertor {
	private static final String NS_SCA = "http://www.osoa.org/xmlns/sca/1.0";
	private static final String EL_SCA_COMPOSITE = "composite";
	private static final String ATTR_NAME = "name";
	private static final String ATTR_TARGET_NS = "targetNamespace";
	private static final String EL_SCA_COMPONENT = "component";
	private static final String EL_SCA_IMPL_CLIENT = "implementation.client";
	private static final String EL_SCA_INTERFACE_WSDL = "interface.wsdl";
	private static final String EL_SCA_BINDING_WS = "binding.ws";
	private static final String ATTR_INTERFACE = "interface";
	private static final String NS_CONFIG = "http://www.sap.com/webas/2007/03/esoa/config/system";
	private static final String ATTR_NS_SAPCONFIG = "xmlns:sapconfig";
	private static final String EL_SERVICE_GROUPS = "sapconfig:serviceGroups";
	private static final String EL_SERVICE_GROUP = "sapconfig:serviceGroup";
	private static final String ATTR_SG_NAME_IN_SG_EL = "sgName";
	private static final String ATTR_SG_NAME_IN_REF = "sapconfig:serviceGroup";
	private static final String ATTR_AUTH_PROFILE = "sapconfig:authenticationProfile";
	private static final String EL_SCA_REFERENCE = "reference";

	private static final String EL_CONTRIBUTION = "contribution";
	private static final String EL_DEPLOYABLE = "deployable";
	private static final String ATTR_COMPOSITE = "composite";
	private static final String EL_EXPORT = "export";
	private static final String ATTR_EXPORT_NAMESPACE = "namespace";
	private static final String ATTR_NS_COMPOSITE_DEPLOYABLE_SUFFIX = "comp";
	private static final String ATTR_NS_COMPOSITE_DEPLOYABLE = "xmlns:"
			+ ATTR_NS_COMPOSITE_DEPLOYABLE_SUFFIX;

	private static final String REFERENCES_XML = "META-INF/service-references.servicerefs";

	/**
	 * This method can be used in order to convert a CFGAR file to a module
	 * archive that would contain the configuration metadata represented in SCDL
	 * files
	 * 
	 * @param cfgarFile
	 *            - The location of the CFGAR file that is to be converted
	 * @param moduleFile
	 *            - The location of the modeule file that is about to be
	 *            produced. The produced file will be a ZIP file with the
	 *            specified extension (e.g. JAR)
	 * @param exportNamespace
	 *            - The namespace of the SCDL that can be used in import
	 *            statements in sca-contribution.xml
	 * @throws IOException
	 * @throws TransformerException
	 * @throws SAXException
	 * @throws ParserConfigurationException
	 */
	public static void convert(File cfgarFile, File moduleFile,
			String exportNamespace) throws IOException,
			ParserConfigurationException, SAXException, TransformerException {
		OutputStream module = new FileOutputStream(moduleFile);
		ZipOutputStream out = new ZipOutputStream(module);
		try {
			String compositeName = cfgarFile.getName();
			compositeName = compositeName.substring(0,
					compositeName.length() - 6); // subtract extension .cfgar

			addSCDLFile(cfgarFile, out, exportNamespace, compositeName);
			addSCAContributionFile(out, exportNamespace, compositeName);
		} finally {
			out.close();
			module.close();
		}
	}

	private static void addSCAContributionFile(ZipOutputStream out,
			String exportNamespace, String compositeName)
			throws TransformerException, IOException,
			ParserConfigurationException {
		out.putNextEntry(new ZipEntry("META-INF/sca-contribution.xml"));

		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setNamespaceAware(true);
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document doc = db.newDocument();
		Element contributionEl = doc.createElementNS(NS_SCA, EL_CONTRIBUTION);
		doc.appendChild(contributionEl);
		contributionEl.setAttribute(ATTR_NS_COMPOSITE_DEPLOYABLE,
				exportNamespace);

		Element deployableEl = doc.createElementNS(NS_SCA, EL_DEPLOYABLE);
		contributionEl.appendChild(deployableEl);
		deployableEl.setAttribute(ATTR_COMPOSITE,
				ATTR_NS_COMPOSITE_DEPLOYABLE_SUFFIX + ":" + compositeName);

		Element exportEl = doc.createElementNS(NS_SCA, EL_EXPORT);
		contributionEl.appendChild(exportEl);
		exportEl.setAttribute(ATTR_EXPORT_NAMESPACE, exportNamespace);

		TransformerFactory trf = TransformerFactory.newInstance();
		Transformer tr = trf.newTransformer();
		// tr.setOutputProperty(OutputKeys.INDENT, "yes");
		tr.transform(new DOMSource(doc), new StreamResult(out));

		out.closeEntry();
	}

	private static void addSCDLFile(File cfgarFile, ZipOutputStream out,
			String exportNamespace, String compositeName) throws ZipException,
			ParserConfigurationException, IOException, SAXException,
			TransformerException {
		out.putNextEntry(new ZipEntry("META-INF/cfgar.composite"));

		ByteArrayOutputStream scdl = new ByteArrayOutputStream(2048);
		QName compositeQName = new QName(exportNamespace, compositeName);
		convert(cfgarFile, scdl, compositeQName);

		byte[] scdlBytes = scdl.toByteArray();
		out.write(scdlBytes, 0, scdlBytes.length);

		out.closeEntry();
	}

	public static void convert(File cfgarFile, File scdlFile,
			QName compositeQName) throws ParserConfigurationException,
			ZipException, IOException, SAXException, TransformerException {
		OutputStream out = new FileOutputStream(scdlFile);
		try {
			convert(cfgarFile, out, compositeQName);
		} finally {
			out.close();
		}
	}

	public static void convert(File cfgarFile, OutputStream scdlFile,
			QName compositeQName) throws ParserConfigurationException,
			ZipException, IOException, SAXException, TransformerException {
		Element component = getComponent(compositeQName, cfgarFile.getName());

		ZipFile cfgar = new ZipFile(cfgarFile);
		Enumeration<? extends ZipEntry> zipEntries = cfgar.entries();

		Element serviceGroupsEl = null;

		while (zipEntries.hasMoreElements()) {
			ZipEntry zipEntry = zipEntries.nextElement();
			String fileName = zipEntry.getName();

			if (fileName.equals(REFERENCES_XML)) {
				InputStream refXML = cfgar.getInputStream(zipEntry);
				try {
					addReferences(refXML, component);
				} finally {
					refXML.close();
				}
			} else if (fileName.endsWith(".consgroup")) {
				if (serviceGroupsEl == null) {
					Document doc = component.getOwnerDocument();
					serviceGroupsEl = doc.createElementNS(NS_CONFIG,
							EL_SERVICE_GROUPS);
					doc.getDocumentElement().appendChild(serviceGroupsEl);
				}

				InputStream sgFile = cfgar.getInputStream(zipEntry);
				try {
					addSGtoSCDL(sgFile, fileName, serviceGroupsEl);
				} finally {
					sgFile.close();
				}
			}
		}

		TransformerFactory trf = TransformerFactory.newInstance();
		Transformer tr = trf.newTransformer();
		// tr.setOutputProperty(OutputKeys.INDENT, "yes");
		tr.transform(new DOMSource(component.getOwnerDocument()),
				new StreamResult(scdlFile));
	}

	private static Element getComponent(QName compositeQName,
			String componentName) throws ParserConfigurationException {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setNamespaceAware(true);
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document doc = db.newDocument();

		Element compositeEl = doc.createElementNS(NS_SCA, EL_SCA_COMPOSITE);
		doc.appendChild(compositeEl);
		compositeEl.setAttribute(ATTR_NAME, compositeQName.getLocalPart());
		compositeEl.setAttribute(ATTR_TARGET_NS, compositeQName
				.getNamespaceURI());

		compositeEl.setAttribute(ATTR_NS_SAPCONFIG, NS_CONFIG);

		Element component = doc.createElementNS(NS_SCA, EL_SCA_COMPONENT);
		compositeEl.appendChild(component);
		component.setAttribute(ATTR_NAME, componentName);

		Element implClient = doc.createElementNS(NS_SCA, EL_SCA_IMPL_CLIENT);
		component.appendChild(implClient);

		return component;
	}

	private static void addSGtoSCDL(InputStream sgFile, String sgFileName,
			Element serviceGroupsEl) throws ParserConfigurationException,
			SAXException, IOException {
		Document doc = serviceGroupsEl.getOwnerDocument();
		Element sgEl = doc.createElementNS(NS_CONFIG, EL_SERVICE_GROUP);
		serviceGroupsEl.appendChild(sgEl);
		String sgName = sgFileName.substring(0, sgFileName.length() - 10); // remove
																			// extension
																			// .consgroup
		sgName.replace('/', '.');
		sgEl.setAttribute(ATTR_SG_NAME_IN_SG_EL, sgName);

		// TODO - classified SG
		// DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		// dbf.setNamespaceAware(true);
		// DocumentBuilder db = dbf.newDocumentBuilder();
		// Document sgDoc = db.parse(sgFile);
		//    

	}

	private static void addReferences(InputStream refXML, Element component)
			throws SAXException, IOException, ParserConfigurationException {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setNamespaceAware(true);
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document refDoc = db.parse(refXML);

		HashSet<String> refNames = new HashSet<String>();
		Element serviceReferencesEl = refDoc.getDocumentElement();
		NodeList children = serviceReferencesEl.getChildNodes();
		for (int i = 0; i < children.getLength(); i++) {
			Node childNode = children.item(i);
			if (childNode.getNodeType() == Node.ELEMENT_NODE) {
				Element oldReference = (Element) childNode;
				addReferenceToComponent(oldReference, component, refNames);
			}
		}
	}

	private static void addReferenceToComponent(Element oldReference,
			Element component, HashSet<String> refNames) throws SAXException {
		Document doc = component.getOwnerDocument();
		Element reference = doc.createElementNS(NS_SCA, EL_SCA_REFERENCE);
		component.appendChild(reference);

		String portTypeLocalPart = getReferenceAttribute(oldReference, "name");

		String refName = portTypeLocalPart;
		int count = 2;
		while (refNames.contains(refName)) {
			refName = refName + count;
			count++;
		}
		refNames.add(refName);

		String id = getReferenceAttribute(oldReference, "id");
		reference.setAttribute(ATTR_NAME, id);

		String serviceGroup = getReferenceAttribute(oldReference,
				"logical-system-name");
		reference.setAttributeNS(NS_CONFIG, ATTR_SG_NAME_IN_REF, serviceGroup);

		String authProfile = getReferenceAttribute(oldReference,
				"authentication-profile-name");
		authProfile = toAuthProfileType(authProfile);
		reference.setAttributeNS(NS_CONFIG, ATTR_AUTH_PROFILE, authProfile);

		String portTypeNS = getReferenceAttribute(oldReference, "namespace");
		Element interfaceEl = doc
				.createElementNS(NS_SCA, EL_SCA_INTERFACE_WSDL);
		interfaceEl.setAttribute(ATTR_INTERFACE, portTypeNS
				+ "#wsdl.interface(" + portTypeLocalPart + ')');
		reference.appendChild(interfaceEl);

		Element bindingEl = doc.createElementNS(NS_SCA, EL_SCA_BINDING_WS);
		reference.appendChild(bindingEl);
	}

	private static String toAuthProfileType(String authProfile) {
		if (authProfile.endsWith("Business or Technical User")) { // do not
																	// parse
																	// file, but
																	// assume
																	// IDE
																	// always
																	// generated
																	// in the
																	// past
																	// these 4
																	// authProfiles
			return "businessOrTechnicalUser";
		} else if (authProfile.endsWith("Business User")) {
			return "businessUser";
		} else if (authProfile.endsWith("No Authentication")) {
			return "noAuthentication";
		} else {
			return "technicalUser";
		}
	}

	private static Element getChildElement(Element element, String childElName)
			throws SAXException {
		NodeList children = element.getElementsByTagName(childElName);
		if (children.getLength() == 0) {
			throw new SAXException("Service Reference does not contain "
					+ childElName);
		} else {
			return (Element) children.item(0);
		}
	}

	private static String getReferenceAttribute(Element oldReference,
			String attributeName) throws SAXException {
		Element attribEl = getChildElement(oldReference, attributeName);
		return getElementValue(attribEl);
	}

	private static String getElementValue(Element element) {
		NodeList children = element.getChildNodes();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < children.getLength(); i++) {
			Node child = children.item(i);
			if (child.getNodeType() == Node.TEXT_NODE) {
				sb.append(child.getNodeValue());
			}
		}
		return sb.toString();
	}
}
