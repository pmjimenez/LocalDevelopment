package com.sap.bie.sca.scdl.contributors.wd;


import java.text.MessageFormat;
import java.util.List;

import com.sap.bie.sca.scdl.adapter.IComponent;
import com.sap.bie.sca.scdl.adapter.IComposite;
import com.sap.bie.sca.scdl.adapter.IReference;
import com.sap.bie.sca.scdl.adapter.IScdlContributor;
import com.sap.bie.sca.scdl.adapter.ScdlContributorException;
import com.sap.bie.sca.scdl.adapter.impl.Component;
import com.sap.bie.sca.scdl.adapter.impl.Composite;
import com.sap.bie.sca.scdl.adapter.wd.WDImplementation;
import com.sap.bie.sca.scdl.gen.mc.IMcReferenceGenerator;
import com.sap.bie.sca.scdl.gen.mc.McReferenceGeneratorFactory;
import com.sap.bie.sca.scdl.gen.mc.NoSuchServiceReferenceExistsException;
import com.sap.ide.metamodel.general.exception.MetamodelException;
import com.sap.ide.metamodel.webdynpro.model.Model;
import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.moin.repository.Connection;

/**
 * Contributor that parses all AWS WD Models. For every AWS Model which uses MC 
 * a new SCDL component is created.
 *
 * @author I036201
 */
public class WDScdlContributor implements IScdlContributor
{
	protected static final String LOG_PREFIX = "		[SCDL_GEN-WD]"; //$NON-NLS-1$
	protected static final String LOG_PREFIX_ERROR = LOG_PREFIX + " ERROR:"; //$NON-NLS-1$
	protected static final String LOG_PREFIX_WARN = LOG_PREFIX + " WARNING:"; //$NON-NLS-1$

	private Connection connection;
	private IGlobalPluginUtil globalPluginUtil;
	private IPluginBuildInfo pluginBuildInfo;

	public IComposite getComposite(Connection connection, IGlobalPluginUtil globalPluginUtil, IPluginBuildInfo pluginBuildInfo)
	{
		setParams(connection, globalPluginUtil, pluginBuildInfo);

		final Composite composite = new Composite(pluginBuildInfo.getDCName());
		try {
			List<Model> awsModels = WDMetamodelUtils.getWDAwsModels(globalPluginUtil, pluginBuildInfo);
			for(Model awsModel : awsModels) {
				final IComponent component = createWDComponent(awsModel);
				if (component.getReferences().size() > 0) {
					composite.addComponent(component);
				}
			}
		} catch (NoSuchServiceReferenceExistsException e) {
			final String message = "Generation of component references in project {0} failed"; //$NON-NLS-1$		
			throw new ScdlContributorException(MessageFormat.format(message, pluginBuildInfo.getDCName()), e);
		} catch (MetamodelException e) {
			final String message = "Generation of component references failed as WebDynpro metamodel cannot be loaded due to the following reason"; //$NON-NLS-1$
			throw new ScdlContributorException(message, e);
		}

		return composite;
	}

	private IComponent createWDComponent(Model awsModel) throws NoSuchServiceReferenceExistsException
	{
		final WDImplementation impl = new WDImplementation();

		final Component component = new Component(getComponentName(awsModel), impl);
		addReferences(component, awsModel);

		return component;
	}

	private String getComponentName(Model awsModel) {
		return pluginBuildInfo.getDCVendor()+"~"+pluginBuildInfo.getDCName().replaceAll("/", "~") + "#" + awsModel.getName(); //$NON-NLS-1$
	}

	private void addReferences(final Component component, final Model awsModel) throws NoSuchServiceReferenceExistsException
	{
		final IMcReferenceGenerator generator = createRefGenerator();

		List<IReference> references =null;
		List<String> sRefIds = WDMetamodelUtils.getSRefIds(awsModel);

		references = generator.genReferences(sRefIds.toArray(new String[sRefIds.size()]));

		for (IReference reference : references) {
			component.addReference(reference);
		}
	}

	private IMcReferenceGenerator createRefGenerator() {
		return McReferenceGeneratorFactory.getInstance().newMCReferenceGenerator(connection, globalPluginUtil, pluginBuildInfo);
	}

	private void setParams(Connection connection, IGlobalPluginUtil globalPluginUtil, IPluginBuildInfo pluginBuildInfo)
	{
		WDScdlContributor.nullCheckParam(connection, "connection"); //$NON-NLS-1$
		WDScdlContributor.nullCheckParam(globalPluginUtil, "globalPluginUtil"); //$NON-NLS-1$
		WDScdlContributor.nullCheckParam(pluginBuildInfo, "pluginBuildInfo"); //$NON-NLS-1$

		this.connection = connection;
		this.globalPluginUtil = globalPluginUtil;
		this.pluginBuildInfo = pluginBuildInfo;
	}
	
	public static void nullCheckParam(final Object paramValue, final String paramName)
	{
		if (paramName == null) {
			throw new NullPointerException("paramName must not be null"); //$NON-NLS-1$ 
		}
		
		if (paramValue == null) {
			throw new NullPointerException(paramName + " must not be null"); //$NON-NLS-1$ 
		}
	}
}
