package com.sap.bie.sca.scdl.adapter.wd;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.impl.CustomScdlElement;
import com.sap.bie.sca.scdl.adapter.impl.Implementation;

public class WDImplementation extends Implementation {
	private static final String IMPLEMENTATION_WD = "implementation.wdcomponent"; //$NON-NLS-1$
	private static final String IMPLEMENTATION_WD_NAMESPACE_VALUE = "http://www.sap.com/xmlns/sapsca/wd/1.0"; //$NON-NLS-1$
	private static final String IMPLEMENTATION_WD_NAMESPACE_NAME = "sapimplwd"; //$NON-NLS-1$

	public WDImplementation() {
		super(new QName(IMPLEMENTATION_WD_NAMESPACE_VALUE, IMPLEMENTATION_WD, IMPLEMENTATION_WD_NAMESPACE_NAME));
		
		CustomScdlElement glxImpl = new CustomScdlElement(getName());
		
		addCustomElement(glxImpl);
	}
}
