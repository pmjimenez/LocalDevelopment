package com.sap.bie.sca.scdl.contributors.wd;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.sap.ide.metamodel.Metamodel;
import com.sap.ide.metamodel.general.exception.MetamodelException;
import com.sap.ide.metamodel.webdynpro.WebDynproRoot;
import com.sap.ide.metamodel.webdynpro.model.Model;
import com.sap.ide.mmservices.generation.dc.DCBuildMDOLocator;
import com.sap.tc.buildplugin.BuildSessionManager;
import com.sap.tc.buildplugin.api.IBuildContext;
import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;

public class WDMetamodelUtils {
	@SuppressWarnings("unchecked")
	public static List<Model> getWDAwsModels(final IGlobalPluginUtil globalPluginUtil, final IPluginBuildInfo pluginBuildInfo) throws MetamodelException {
		List<Model> awsModels = new ArrayList<Model>();
		
		List<String> additionalPaths = new ArrayList<String>();

		IBuildContext context = (IBuildContext)BuildSessionManager.getFromBuildSession(IBuildContext.class.getName());
		List modelPath= context.getAsList("webdynpro_model_path"); //$NON-NLS-1$
		List modelPath2 = context.getAsList("dc_depend_compileArchives"); //$NON-NLS-1$
		
		for (int i = 0; i < modelPath.size(); i++) {
			if(modelPath.get(i) instanceof String)
				additionalPaths.add((String)modelPath.get(i));
			else if(modelPath.get(i) instanceof File)
				additionalPaths.add(((File)modelPath.get(i)).getAbsolutePath());
		}
		for (int i = 0; i < modelPath2.size(); i++) {
			if(modelPath2.get(i) instanceof String)
				additionalPaths.add((String)modelPath2.get(i));
			else if(modelPath2.get(i) instanceof File)
				additionalPaths.add(((File)modelPath2.get(i)).getAbsolutePath());
		}

		List<File> sourcePaths = pluginBuildInfo.getPackageDirsAsFiles();
		List<String> sourcePaths2 = new ArrayList<String>();

		for (Iterator iterator = sourcePaths.iterator(); iterator.hasNext();) {
			File path = (File) iterator.next();
			sourcePaths2.add(path.getAbsolutePath());

		}
		
		Metamodel mMetamodel = getOrCreateMetamodel(
				(String[])sourcePaths2.toArray(new String[sourcePaths2.size()]),
				(String[])additionalPaths.toArray(new String[additionalPaths.size()]),
				pluginBuildInfo.getDCOriginalLocale());
		WebDynproRoot webDynproRoot = (WebDynproRoot)mMetamodel.getRoot(WebDynproRoot.class);
        
		Model[] models = webDynproRoot.getModels();
        for (int i = 0; i < models.length; i++) {
        	if(models[i].getModelType().getName().equals("AdaptiveWebservice") &&
        			!(models[i].isExternal())){ //$NON-NLS-1$
        		if(models[i].getModelType().hasModelSettingDefinition("serviceReferenceID") //$NON-NLS-1$
        				&& models[i].getSetting("serviceReferenceID")!=null //$NON-NLS-1$
        				&& models[i].getSetting("serviceReferenceID").getValue()!=null //$NON-NLS-1$
        				&& models[i].getSetting("serviceReferenceID").getValue().trim().length()>0 ){ //$NON-NLS-1$
        			awsModels.add(models[i]);
        		}
        	}
        }
		
		
		return awsModels;
	}
	
	private static Metamodel getOrCreateMetamodel(String[] sourcePaths, String[] additionalArchives, String dcLocale) throws MetamodelException {
		// create Metamodel, WebDynpro and Dictionary root
		Metamodel mMetamodel = new Metamodel("McMetaModelInstanceName" + System.currentTimeMillis(), new DCBuildMDOLocator( //$NON-NLS-1$
				sourcePaths, new String[]{}), dcLocale);
		mMetamodel.createRoot(WebDynproRoot.class);
		mMetamodel.enableDevelopmentObjectCache();

		// add additional archive to metamodel
		for (int i = 0; i < additionalArchives.length; i++) {
			mMetamodel.addArchive(additionalArchives[i]);
		}
		
		return mMetamodel;
	}
	
	public static List<String> getSRefIds(Model awsModel) {
		List<String> sRefIds = new ArrayList<String>();
		
		String sRefIdStr = awsModel.getSetting("serviceReferenceID").getValue(); //$NON-NLS-1$
		
		if(sRefIdStr.contains(" ")) {
			String[] sRefIdsArr = sRefIdStr.split(" ");
			
			for(int ii=0; ii < sRefIdsArr.length; ii++) {
				sRefIds.add(sRefIdsArr[ii]);
			}
		}
		else {
			sRefIds.add(sRefIdStr);
		}
		
		return sRefIds;
	}
}
