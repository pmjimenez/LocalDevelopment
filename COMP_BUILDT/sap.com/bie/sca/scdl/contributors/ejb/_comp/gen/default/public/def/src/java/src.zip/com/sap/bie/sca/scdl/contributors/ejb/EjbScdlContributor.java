package com.sap.bie.sca.scdl.contributors.ejb;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.nullCheckParam;

import java.net.MalformedURLException;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.IComponent;
import com.sap.bie.sca.scdl.adapter.IComposite;
import com.sap.bie.sca.scdl.adapter.IReference;
import com.sap.bie.sca.scdl.adapter.IScdlContributor;
import com.sap.bie.sca.scdl.adapter.ScdlContributorException;
import com.sap.bie.sca.scdl.adapter.impl.Component;
import com.sap.bie.sca.scdl.adapter.impl.Composite;
import com.sap.bie.sca.scdl.gen.mc.IMcReferenceGenerator;
import com.sap.bie.sca.scdl.gen.mc.McReferenceGeneratorFactory;
import com.sap.bie.sca.scdl.gen.mc.NoSuchServiceReferenceExistsException;
import com.sap.bie.sca.scdl.gen.util.ProcessingException;
import com.sap.bie.sca.scdl.gen.util.adapter.impl.EjbImplementation;
import com.sap.bie.sca.scdl.gen.util.clazz.annotations.ejb.EjbUtil;
import com.sap.bie.sca.scdl.gen.util.model.EjbModuleFactory;
import com.sap.bie.sca.scdl.gen.util.model.IModuleFactory;
import com.sap.bie.sca.scdl.gen.util.model.ModelException;
import com.sap.bie.sca.scdl.gen.util.model.ejb.IBean;
import com.sap.bie.sca.scdl.gen.util.model.ejb.IEjbModule;
import com.sap.bie.sca.scdl.gen.util.model.shared.IServiceRef;
import com.sap.bie.sca.scdl.gen.util.model.wsref.IncorrectWsdlLocationException;
import com.sap.bie.sca.scdl.gen.util.model.wsref.WebServiceRefPortTypesExtractor;
import com.sap.bie.sca.scdl.gen.util.project.IResultProvider;
import com.sap.bie.sca.scdl.gen.util.project.ProjectUtilsFactory;
import com.sap.bie.sca.scdl.gen.util.wsdl.WsdlProcessingException;
import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.moin.repository.Connection;

/**
 * Contributor that generates composite for the EJB DC project, parses all EJB's and 
 * creates intermediate EJB model, generates SCDL references for all portTypes defined in WSDL
 * used in web service reference used in EJB's.
 * 
 * @author I036509
 */
public class EjbScdlContributor implements IScdlContributor 
{
	private static final String SLASH = "/"; //$NON-NLS-1$
	private static final String TILDA = "~"; //$NON-NLS-1$

	private Connection connection;
	private IGlobalPluginUtil globalPluginUtil;
	private IPluginBuildInfo pluginBuildInfo;
	private WebServiceRefPortTypesExtractor portTypesExtractor = new WebServiceRefPortTypesExtractor();
	
	public IComposite getComposite(final Connection connection, final IGlobalPluginUtil globalPluginUtil, final IPluginBuildInfo pluginBuildInfo) 
	{
		setParams(connection, globalPluginUtil, pluginBuildInfo);
		
		final Composite composite = new Composite(pluginBuildInfo.getDCName());
		try {			
			final IResultProvider resultProvider = createResultProvider();
			final IEjbModule ejbModule = moduleFactory().createModule(pluginBuildInfo, resultProvider);
			
			for (IBean bean : ejbModule.getBeans()) {
				final IComponent component = createEjbComponent(bean, resultProvider);
				if (component.getReferences().size() > 0) {
					composite.addComponent(component);
				}
			}
			
		} catch (ProcessingException e) {
			final String message = "Error during processing project {0}"; //$NON-NLS-1$
			throw new ScdlContributorException(MessageFormat.format(message, pluginBuildInfo.getDCName()), e);
		} catch (ModelException e) {
			final String message = "Error occured during EJB model preparation for project {0}"; //$NON-NLS-1$
			throw new ScdlContributorException(MessageFormat.format(message, pluginBuildInfo.getDCName()), e);
		} catch (NoSuchServiceReferenceExistsException e) {
			final String message = "Generation of component references in project {0} failed"; //$NON-NLS-1$		
			throw new ScdlContributorException(MessageFormat.format(message, pluginBuildInfo.getDCName()), e);
		} catch (MalformedURLException e) {			
			final String message = "Error occured in creation of class loader for project {0}"; //$NON-NLS-1$
			throw new ScdlContributorException(MessageFormat.format(message, pluginBuildInfo.getDCName()), e);
		}
		
		return composite;
	}

	private IComponent createEjbComponent(final IBean bean, final IResultProvider resultProvider) throws ProcessingException, NoSuchServiceReferenceExistsException
	{
		final EjbImplementation impl = new EjbImplementation(getJarName(), bean.getBeanName());		
		final Component component = new Component(getComponentName(bean.getBeanName()), impl);
		
		final IMcReferenceGenerator generator = createRefGenerator();
		for (IServiceRef serviceRef : bean.getServiceRefs()) 
		{
			final Map<QName, String> portTypesMap = extractPortTypes(bean, serviceRef, resultProvider);
			for (List<IReference> references : generator.genReferences(portTypesMap).values()) {
				for (IReference reference : references) {
					component.addReference(reference);
				}
			}
		}
		
		return component;
	}

	private Map<QName, String> extractPortTypes(final IBean bean, final IServiceRef serviceRef, final IResultProvider resultProvider) throws ProcessingException
	{
		final Map<QName, String> portTypesMap = new HashMap<QName, String>();
		try {
			final List<QName> portTypes = portTypesExtractor.extractPortTypes(serviceRef, resultProvider);
			for (QName qName : portTypes) {
				portTypesMap.put(qName, serviceRef.getWsdlLocation());
			}
		} catch (IncorrectWsdlLocationException e) {
			final String message = "WSDL location for web service reference in bean ''{0}'' is incorrect"; //$NON-NLS-1$
			throw new ScdlContributorException(MessageFormat.format(message, bean.getBeanName()), e);
		} catch (WsdlProcessingException e) {
			final String message = "Extracting port types for service reference used in bean ''{0}'' failed"; //$NON-NLS-1$
			throw new ScdlContributorException(MessageFormat.format(message, bean.getBeanName()), e);
		}
		
		return portTypesMap;
	}

	private IMcReferenceGenerator createRefGenerator() {
		return McReferenceGeneratorFactory.getInstance().newMCReferenceGenerator(connection, globalPluginUtil, pluginBuildInfo);
	}
	
	private String getComponentName(final String beanName) {
		return pluginBuildInfo.getDCVendor() + TILDA + pluginBuildInfo.getDCName().replaceAll(SLASH, TILDA) + "#" + beanName; //$NON-NLS-1$
	}

	private String getJarName() {
		return EjbUtil.getInstance().defineEjbJarName(pluginBuildInfo);
	}
	
	private IModuleFactory<IEjbModule> moduleFactory() {
		return EjbModuleFactory.getInstance();
	}
	
	private IResultProvider createResultProvider() throws MalformedURLException {
		return ProjectUtilsFactory.getInstance().create(globalPluginUtil, pluginBuildInfo);
	}
	
	private void setParams(Connection connection, IGlobalPluginUtil globalPluginUtil, IPluginBuildInfo pluginBuildInfo) 
	{
		nullCheckParam(connection, "connection"); //$NON-NLS-1$
		nullCheckParam(globalPluginUtil, "globalPluginUtil"); //$NON-NLS-1$
		nullCheckParam(pluginBuildInfo, "pluginBuildInfo"); //$NON-NLS-1$
		
		this.connection = connection;
		this.globalPluginUtil = globalPluginUtil;
		this.pluginBuildInfo = pluginBuildInfo;
	}
}
