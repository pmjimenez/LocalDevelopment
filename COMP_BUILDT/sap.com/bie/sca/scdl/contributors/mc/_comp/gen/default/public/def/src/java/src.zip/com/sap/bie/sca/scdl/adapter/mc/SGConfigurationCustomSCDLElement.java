package com.sap.bie.sca.scdl.adapter.mc;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.impl.AttributeValue;
import com.sap.bie.sca.scdl.adapter.impl.CustomScdlAttribute;
import com.sap.bie.sca.scdl.adapter.impl.CustomScdlElement;
import com.sap.bie.sca.scdl.gen.mc.McNamespaceConstants;

public class SGConfigurationCustomSCDLElement extends CustomScdlElement 
{
	public SGConfigurationCustomSCDLElement(String srvGroupName) {
		super(new QName(McNamespaceConstants.SAPCONFIG_NAMESPACE_VALUE, "service-group-configuration", McNamespaceConstants.SAPCONFIG_NAMESPACE_NAME));
		
		addAttribute(new CustomScdlAttribute(new QName("serviceGroup"), new AttributeValue(new QName(srvGroupName))));
	}
	
}
