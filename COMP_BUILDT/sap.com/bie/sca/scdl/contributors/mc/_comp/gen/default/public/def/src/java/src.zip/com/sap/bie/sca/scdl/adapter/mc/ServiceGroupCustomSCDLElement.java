package com.sap.bie.sca.scdl.adapter.mc;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.impl.AttributeValue;
import com.sap.bie.sca.scdl.adapter.impl.CustomScdlAttribute;
import com.sap.bie.sca.scdl.adapter.impl.CustomScdlElement;
import com.sap.bie.sca.scdl.gen.mc.McNamespaceConstants;

public class ServiceGroupCustomSCDLElement extends CustomScdlElement {
	private String srvGroupName;
	
	public ServiceGroupCustomSCDLElement(String srvGroupName, String bundleName) {
		super(new QName(McNamespaceConstants.SAPCONFIG_NAMESPACE_VALUE, "serviceGroup", McNamespaceConstants.SAPCONFIG_NAMESPACE_NAME));
		
		addAttribute(new CustomScdlAttribute(new QName("sgName"), new AttributeValue(new QName(srvGroupName))));
		if(bundleName!=null) {
			addAttribute(new CustomScdlAttribute(new QName("bundle"), new AttributeValue(new QName(bundleName))));
		}
		this.srvGroupName = srvGroupName;
	}
	
	public String getSrvGroupName() {
		return srvGroupName;
	}
}
