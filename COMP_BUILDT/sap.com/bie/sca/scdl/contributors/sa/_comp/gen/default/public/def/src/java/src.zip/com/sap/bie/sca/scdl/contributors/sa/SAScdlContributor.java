/**
 * 
 */
package com.sap.bie.sca.scdl.contributors.sa;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.nullCheckParam;

import java.net.MalformedURLException;
import java.text.MessageFormat;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.IComponent;
import com.sap.bie.sca.scdl.adapter.IComposite;
import com.sap.bie.sca.scdl.adapter.IReference;
import com.sap.bie.sca.scdl.adapter.IScdlContributor;
import com.sap.bie.sca.scdl.adapter.ScdlContributorException;
import com.sap.bie.sca.scdl.adapter.impl.AttributeValue;
import com.sap.bie.sca.scdl.adapter.impl.Component;
import com.sap.bie.sca.scdl.adapter.impl.Composite;
import com.sap.bie.sca.scdl.adapter.impl.CustomScdlAttribute;
import com.sap.bie.sca.scdl.adapter.impl.CustomScdlElement;
import com.sap.bie.sca.scdl.adapter.impl.Service;
import com.sap.bie.sca.scdl.contributors.sa.annotations.sdoservice.SDOServiceExtractor;
import com.sap.bie.sca.scdl.contributors.sa.annotations.sdoservice.SDOServiceFinder;
import com.sap.bie.sca.scdl.contributors.sa.annotations.srpublication.SrPublicationExtractor;
import com.sap.bie.sca.scdl.contributors.sa.annotations.srpublication.SrPublicationFinder;
import com.sap.bie.sca.scdl.contributors.sa.annotations.usedref.UsedReferencesExtractor;
import com.sap.bie.sca.scdl.gen.mc.IMcReferenceGenerator;
import com.sap.bie.sca.scdl.gen.mc.McNamespaceConstants;
import com.sap.bie.sca.scdl.gen.mc.McReferenceGeneratorFactory;
import com.sap.bie.sca.scdl.gen.mc.NoSuchServiceReferenceExistsException;
import com.sap.bie.sca.scdl.gen.util.IProblemsReporter;
import com.sap.bie.sca.scdl.gen.util.ProcessingException;
import com.sap.bie.sca.scdl.gen.util.adapter.impl.EjbImplementation;
import com.sap.bie.sca.scdl.gen.util.clazz.annotations.ClassAnnotationsProcessor;
import com.sap.bie.sca.scdl.gen.util.clazz.annotations.ejb.EjbUtil;
import com.sap.bie.sca.scdl.gen.util.model.EjbModuleFactory;
import com.sap.bie.sca.scdl.gen.util.model.IModuleFactory;
import com.sap.bie.sca.scdl.gen.util.model.ModelException;
import com.sap.bie.sca.scdl.gen.util.model.ejb.IBean;
import com.sap.bie.sca.scdl.gen.util.model.ejb.IEjbModule;
import com.sap.bie.sca.scdl.gen.util.project.IResultProvider;
import com.sap.bie.sca.scdl.gen.util.project.ProjectUtilsFactory;
import com.sap.lib.javalang.element.ClassInfo;
import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.moin.repository.Connection;

/**
 * Contributor for service adaptation use cases by processing SA proprietary annotations.
 * Generates composite instance containing component for every EJB and references for every
 * used service reference. 
 * 
 * @author i036201
 */
public class SAScdlContributor implements IScdlContributor {

	protected static final String LOG_PREFIX = "		[SCDL_GEN-SA]"; //$NON-NLS-1$
	protected static final String LOG_PREFIX_ERROR = LOG_PREFIX + " ERROR:"; //$NON-NLS-1$
	protected static final String LOG_PREFIX_WARN = LOG_PREFIX + " WARNING:"; //$NON-NLS-1$

	private Connection connection;
	private IGlobalPluginUtil globalPluginUtil;
	private IPluginBuildInfo pluginBuildInfo;
	
	public IComposite getComposite(Connection connection, IGlobalPluginUtil globalPluginUtil, IPluginBuildInfo pluginBuildInfo) 
	{
		setParams(connection, globalPluginUtil, pluginBuildInfo);
		
		final Composite composite = new Composite(pluginBuildInfo.getDCName());
		try {			
			final IResultProvider resultProvider = createResultProvider();		
			final IEjbModule ejbModule = moduleFactory(resultProvider).createModule(pluginBuildInfo, resultProvider);
			
			for (IBean bean : ejbModule.getBeans()) {
				final IComponent component = createEjbComponent(bean, resultProvider);
				if (component.getReferences().size() > 0) {
					composite.addComponent(component);
				}
				else if (component.getServices().size() > 0) {
					composite.addComponent(component);
				}
			}
		} catch (ProcessingException e) {
			final String message = "Error during processing project {0}"; //$NON-NLS-1$
			throw new ScdlContributorException(MessageFormat.format(message, pluginBuildInfo.getDCName()), e);
		} catch (NoSuchServiceReferenceExistsException e) {
			final String message = "Generation of component references in project {0} failed"; //$NON-NLS-1$		
			throw new ScdlContributorException(MessageFormat.format(message, pluginBuildInfo.getDCName()), e);
		} catch (MalformedURLException e) {
			final String message = "Error occured in creation of class loader for project {0}"; //$NON-NLS-1$
			throw new ScdlContributorException(MessageFormat.format(message, pluginBuildInfo.getDCName()), e);
		} catch (ModelException e) {
			final String message = "Error occured during EJB model preparation for project {0}"; //$NON-NLS-1$
			throw new ScdlContributorException(MessageFormat.format(message, pluginBuildInfo.getDCName()), e);
		}
		
		return composite;
	}
	
	private IResultProvider createResultProvider() throws MalformedURLException 
	{
		return ProjectUtilsFactory.getInstance().create(globalPluginUtil, pluginBuildInfo);
	}
	
	private IComponent createEjbComponent(final IBean ejb, final IResultProvider resultsProvider) throws ProcessingException, NoSuchServiceReferenceExistsException 
	{
		final String ejbName = ejb.getBeanName();		
		final EjbImplementation impl = new EjbImplementation(getJarName(), ejbName);		
		final Component component = new Component(getComponentName(ejb), impl);
		
		addReferences(ejb, component, resultsProvider);
		addServices(ejb, component, resultsProvider);
		
		return component;
	}
	
	private String getComponentName(final IBean ejb) {
		return pluginBuildInfo.getDCVendor()+"~"+pluginBuildInfo.getDCName().replaceAll("/", "~") + "#" + ejb.getBeanName(); //$NON-NLS-1$
	}

	private String getJarName() {
		return EjbUtil.getInstance().defineEjbJarName(pluginBuildInfo);
	}
	
	private void addServices(final IBean ejb, final Component component, final IResultProvider resultProvider) throws ProcessingException {
		final ClassInfo ejbClassInfo = resultProvider.getReadResult().getClass(ejb.getBeanClass());
		final ClassAnnotationsProcessor processor = new ClassAnnotationsProcessor(resultProvider);
		final Collection<Map<String, String>> sdoServices = processor.collect(ejbClassInfo, new SDOServiceExtractor(reporter()));
		
		if(sdoServices!=null && sdoServices.size()>0) {
			Map<String,String> sdoService = sdoServices.iterator().next();
			
			component.addAttribute(new CustomScdlAttribute(new QName("http://www.sap.com/xmlns/sapsca/1.0", "helperContextManagement", "saphelpctxmngmt"), new AttributeValue(new QName("implementationManaged"))));
			Service saService = new Service(false);
			saService.addAttribute(new CustomScdlAttribute(new QName("name"), new AttributeValue(new QName(sdoService.get(SDOServiceFinder.SERVICE_NAME)))));
			
			final Collection<Map<String, String>> srPublications = processor.collect(ejbClassInfo, new SrPublicationExtractor(reporter()));
			
			if(srPublications!=null && srPublications.size()>0) {
				Map<String,String> srPublication = srPublications.iterator().next();
				
				saService.addAttribute(new CustomScdlAttribute(new QName(McNamespaceConstants.SAPCONFIG_NAMESPACE_VALUE, "classificationLink", McNamespaceConstants.SAPCONFIG_NAMESPACE_NAME), new AttributeValue(new QName(srPublication.get(SrPublicationFinder.LOCATION)))));
			}
			
			CustomScdlElement interfaceDii = new CustomScdlElement(new QName("http://www.sap.com/xmlns/sapsca/ws/1.0", "interface.dii", "sapscaws"));
			interfaceDii.addAttribute(new CustomScdlAttribute(new QName("location"), new AttributeValue(new QName(sdoService.get(SDOServiceFinder.LOCATION)))));
			interfaceDii.addAttribute(new CustomScdlAttribute(new QName("interface"), new AttributeValue(new QName(sdoService.get(SDOServiceFinder.INTERFACE_LOCAL)))));
			
			saService.addCustomElement(interfaceDii);
			saService.addCustomElement(new CustomScdlElement("binding.ws"));
			
			component.addService(saService);
		}
	}
	
	private void addReferences(final IBean ejb, final Component component, final IResultProvider resultProvider) throws ProcessingException, NoSuchServiceReferenceExistsException 
	{
		final IMcReferenceGenerator generator = createRefGenerator();
		final ClassInfo ejbClassInfo = resultProvider.getReadResult().getClass(ejb.getBeanClass());
		final ClassAnnotationsProcessor processor = new ClassAnnotationsProcessor(resultProvider);
		final Collection<Map<String, String>> byUsedRef = processor.collect(ejbClassInfo, new UsedReferencesExtractor(reporter()));
		
		List<IReference> references =null;
		for(Map<String, String> usedRef : byUsedRef) {
			for(String srId : usedRef.keySet()) {
				if(usedRef.get(srId)!=null && usedRef.get(srId).length()>0) {
					references = generator.genReferences(new String[]{ srId }, new String[] { usedRef.get(srId) });
				}
				else {
					references = generator.genReferences(new String[]{ srId } );
				}
				
				for (IReference reference : references) {
					component.addReference(reference);
				}
			}
		}
	}

	private IMcReferenceGenerator createRefGenerator() {
		return McReferenceGeneratorFactory.getInstance().newMCReferenceGenerator(connection, globalPluginUtil, pluginBuildInfo);
	}
	
	protected IModuleFactory<IEjbModule> moduleFactory(final IResultProvider resultProvider) {
		return EjbModuleFactory.getInstance();
	}
	
	private IProblemsReporter reporter() 
	{
		return new IProblemsReporter()
		{
			public void error(Exception e) throws ProcessingException {
				final String message = "Error occured during extraction of values from UsedReferences annotation"; //$NON-NLS-1$
				throw new ScdlContributorException(message, e);
			}

			public void warning(String message, Exception e) throws ProcessingException 
			{
				final String warn = "{0} Warning was reported during extraction of values from UsedReferences annotation: {1}"; //$NON-NLS-1$
				Log.warn(MessageFormat.format(warn, LOG_PREFIX_WARN, message));
			}
			
			public void info(String message) {
				Log.info(MessageFormat.format("{0} {1}", LOG_PREFIX, message)); //$NON-NLS-1$
			}			
		};
	}
	
	private void setParams(Connection connection, IGlobalPluginUtil globalPluginUtil, IPluginBuildInfo pluginBuildInfo) 
	{
		nullCheckParam(connection, "connection"); //$NON-NLS-1$
		nullCheckParam(globalPluginUtil, "globalPluginUtil"); //$NON-NLS-1$
		nullCheckParam(pluginBuildInfo, "pluginBuildInfo"); //$NON-NLS-1$
		
		this.connection = connection;
		this.globalPluginUtil = globalPluginUtil;
		this.pluginBuildInfo = pluginBuildInfo;
	}
}
