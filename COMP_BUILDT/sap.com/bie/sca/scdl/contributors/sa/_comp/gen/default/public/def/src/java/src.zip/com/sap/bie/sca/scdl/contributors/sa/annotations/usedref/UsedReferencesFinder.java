package com.sap.bie.sca.scdl.contributors.sa.annotations.usedref;

import java.util.HashMap;
import java.util.Map;

import com.sap.bie.sca.scdl.gen.util.project.IResultProvider;
import com.sap.lib.javalang.annotation.AnnotationRecord;
import com.sap.lib.javalang.annotation.AnnotationRecord.NamedMember;
import com.sap.lib.javalang.element.ClassInfo;

public class UsedReferencesFinder {
	private static final String SR_IDS_LIST = "srIds"; //$NON-NLS-1$
	private static final String SR_IDS_WSLD_LOCATIONS = "wsdlLocations"; //$NON-NLS-1$
	
	public Map<String, String> extractSrIdsAndWsdlLocations(final ClassInfo clazz, final AnnotationRecord ar, final IResultProvider resultProvider) {
		Map<String, String> srIdWsdlLocation = new HashMap<String, String>();
		
		NamedMember srIds = ar.getMember(SR_IDS_LIST);
		NamedMember wsdlLocations = ar.getMember(SR_IDS_WSLD_LOCATIONS);
		
		if(srIds!=null && srIds.getMemberArrayValue()!=null && srIds.getMemberArrayValue().length > 0) {
			String[] sRefIds = srIds.getMemberArrayValue()[0].getStringValue().split(","); //$NON-NLS-1$
			String[] wsdlLocs = null;
			
			if(wsdlLocations!=null && wsdlLocations.getMemberArrayValue()!=null && wsdlLocations.getMemberArrayValue().length > 0) {
				wsdlLocs = wsdlLocations.getMemberArrayValue()[0].getStringValue().split(","); //$NON-NLS-1$
			}
			
			for(int ii=0; ii < sRefIds.length; ii++) {
				if(wsdlLocs!=null && wsdlLocs.length==sRefIds.length) {
					srIdWsdlLocation.put(sRefIds[ii].trim(), wsdlLocs[ii].trim());
				}
				else {
					srIdWsdlLocation.put(sRefIds[ii].trim(), null);
				}
			}
		}
		
		return srIdWsdlLocation;
	}
}
