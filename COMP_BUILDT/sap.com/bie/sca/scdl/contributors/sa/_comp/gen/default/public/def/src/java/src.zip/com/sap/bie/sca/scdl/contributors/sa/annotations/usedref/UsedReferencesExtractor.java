package com.sap.bie.sca.scdl.contributors.sa.annotations.usedref;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.nullCheckParam;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

import com.sap.bie.sca.scdl.gen.util.IProblemsReporter;
import com.sap.bie.sca.scdl.gen.util.ProcessingException;
import com.sap.bie.sca.scdl.gen.util.clazz.annotations.ClassAnnotationsVisitor;
import com.sap.bie.sca.scdl.gen.util.project.IResultProvider;
import com.sap.lib.javalang.annotation.AnnotationRecord;
import com.sap.lib.javalang.element.ClassInfo;

public class UsedReferencesExtractor extends ClassAnnotationsVisitor<Map<String, String>> {
	private static final String USED_REFERENCES = "com.sap.engine.services.sca.annotations.UsedReferences"; //$NON-NLS-1$
	private static final String CLASS_PROCESSING_MSG = "Processing annotation {0} on class level for class {1}"; //$NON-NLS-1$
	
	private final IProblemsReporter reporter;
	private final UsedReferencesFinder usedReferencesFinder = new UsedReferencesFinder();
	
	public UsedReferencesExtractor(final IProblemsReporter reporter) {
		nullCheckParam(reporter, "reporter"); //$NON-NLS-1$
		this.reporter = reporter;
	}
	
	@Override
	public Map<String, String> processClass(final ClassInfo clazz, final IResultProvider resultProvider) throws ProcessingException {
		return collectUsedReferencesForClass(clazz, clazz.getAnnotation(USED_REFERENCES), resultProvider);
	}
	
	/**
	 * Collects portTypes out of <code>com.sap.engine.services.sca.annotations.UsedReferences<code> annotation 
	 * placed on class level
	 * 
	 * @param clazz the class in which processing is in progress 
	 * @param usedRefAnnotation the annotation extracted from the class or class member
	 * @param resultProvider the project results provider
	 * @return returns list of collected pairs srIds and wsdlLocations
	 * @throws ProcessingException
	 */	
	protected Map<String, String> collectUsedReferencesForClass(final ClassInfo clazz, final AnnotationRecord usedRefAnnotation, final IResultProvider resultProvider) throws ProcessingException
	{
		if (usedRefAnnotation == null) {
			return null;
		}
		
		reporter.info(MessageFormat.format(CLASS_PROCESSING_MSG, usedRefAnnotation.getTypeName(), clazz.getName()));
		
		
		return usedReferencesFinder.extractSrIdsAndWsdlLocations(clazz, usedRefAnnotation, resultProvider); 
	}

	@Override
	public boolean visits(
			com.sap.bie.sca.scdl.gen.util.clazz.annotations.IClassAnnotationsVisitor.VisitType type) {
		return type==VisitType.Class;
	}
}
