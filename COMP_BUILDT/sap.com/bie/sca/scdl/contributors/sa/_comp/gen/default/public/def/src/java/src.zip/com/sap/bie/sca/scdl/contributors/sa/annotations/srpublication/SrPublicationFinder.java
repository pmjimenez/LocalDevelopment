package com.sap.bie.sca.scdl.contributors.sa.annotations.srpublication;

import java.util.HashMap;
import java.util.Map;

import com.sap.bie.sca.scdl.gen.util.project.IResultProvider;
import com.sap.lib.javalang.annotation.AnnotationRecord;
import com.sap.lib.javalang.annotation.AnnotationRecord.NamedMember;
import com.sap.lib.javalang.element.ClassInfo;

public class SrPublicationFinder {
	public static final String LOCATION = "location"; //$NON-NLS-1$
	
	public Map<String, String> extractData(final ClassInfo clazz, final AnnotationRecord ar, final IResultProvider resultProvider) {
		Map<String, String> extractData = new HashMap<String, String>();
		
		NamedMember location = ar.getMember(LOCATION);
		
		extractData.put(LOCATION, location.getStringValue().trim());
		
		return extractData;
	}
}
