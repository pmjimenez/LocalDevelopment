package com.sap.bie.sca.scdl.contributors.sa.annotations.sdoservice;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.nullCheckParam;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

import com.sap.bie.sca.scdl.gen.util.IProblemsReporter;
import com.sap.bie.sca.scdl.gen.util.ProcessingException;
import com.sap.bie.sca.scdl.gen.util.clazz.annotations.ClassAnnotationsVisitor;
import com.sap.bie.sca.scdl.gen.util.project.IResultProvider;
import com.sap.lib.javalang.annotation.AnnotationRecord;
import com.sap.lib.javalang.element.ClassInfo;

public class SDOServiceExtractor extends ClassAnnotationsVisitor<Map<String, String>> {
	private static final String SDO_SERVICE = "com.sap.engine.services.sca.annotations.SDOService"; //$NON-NLS-1$
	private static final String CLASS_PROCESSING_MSG = "Processing annotation {0} on class level for class {1}"; //$NON-NLS-1$
	
	private final IProblemsReporter reporter;
	private final SDOServiceFinder sdoServiceFinder = new SDOServiceFinder();
	
	public SDOServiceExtractor(final IProblemsReporter reporter) {
		nullCheckParam(reporter, "reporter"); //$NON-NLS-1$
		this.reporter = reporter;
	}
	
	@Override
	public Map<String, String> processClass(final ClassInfo clazz, final IResultProvider resultProvider) throws ProcessingException {
		return collectSdoServiceForClass(clazz, clazz.getAnnotation(SDO_SERVICE), resultProvider);
	}
	
	/**
	 * Collects portTypes out of <code>com.sap.engine.services.sca.annotations.UsedReferences<code> annotation 
	 * placed on class level
	 * 
	 * @param clazz the class in which processing is in progress 
	 * @param sdoServiceAnnotation the annotation extracted from the class or class member
	 * @param resultProvider the project results provider
	 * @return returns list of collected pairs srIds and wsdlLocations
	 * @throws ProcessingException
	 */	
	protected Map<String, String> collectSdoServiceForClass(final ClassInfo clazz, final AnnotationRecord sdoServiceAnnotation, final IResultProvider resultProvider) throws ProcessingException
	{
		if (sdoServiceAnnotation == null) {
			return null;
		}
		
		reporter.info(MessageFormat.format(CLASS_PROCESSING_MSG, sdoServiceAnnotation.getTypeName(), clazz.getName()));
		
		
		return sdoServiceFinder.extractData(clazz, sdoServiceAnnotation, resultProvider); 
	}

	@Override
	public boolean visits(
			com.sap.bie.sca.scdl.gen.util.clazz.annotations.IClassAnnotationsVisitor.VisitType type) {
		return type==VisitType.Class;
	}
}
