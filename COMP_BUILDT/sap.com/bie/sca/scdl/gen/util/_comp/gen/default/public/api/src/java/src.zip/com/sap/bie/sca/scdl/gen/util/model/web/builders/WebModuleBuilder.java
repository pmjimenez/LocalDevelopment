package com.sap.bie.sca.scdl.gen.util.model.web.builders;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.emptyStringCheckParam;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import com.sap.bie.sca.scdl.gen.util.ProcessingException;
import com.sap.bie.sca.scdl.gen.util.model.ModelException;
import com.sap.bie.sca.scdl.gen.util.model.shared.IServiceRef;
import com.sap.bie.sca.scdl.gen.util.model.shared.builders.xml.ServiceRefBuilder;
import com.sap.bie.sca.scdl.gen.util.model.shared.builders.xml.XmlUtils;
import com.sap.bie.sca.scdl.gen.util.model.web.IWebModule;
import com.sap.bie.sca.scdl.gen.util.model.web.impl.WebModule;
import com.sap.bie.sca.scdl.gen.util.project.IResultProvider;

public class WebModuleBuilder 
{
	private static final String SERVLET = "servlet"; //$NON-NLS-1$
	private static final String SERVICE_REF = "service-ref"; //$NON-NLS-1$
	
	private final ServiceRefBuilder xmlServiceRefBuilder = new ServiceRefBuilder();
	private final ServletBuilder servletBuilder;
	
	/**
	 * Constructor
	 * @param resultProvider
	 * @throws NullPointerException in case <code>resultProvider</code> is <code>null</code>
	 */
	public WebModuleBuilder(final IResultProvider resultProvider) {
		this.servletBuilder = new ServletBuilder(resultProvider);
	}
	
	/**
	 * Parsers <code>ejbJarXmlFile</code> and creates EJB module out of it
	 * @param webXmlFile - might be <code>null</code>
	 * @param moduleName
	 * @return created module - never returns <code>null</code>
	 * @throws ProcessingException in case of {@link IOException} or parser exception 
	 * @throws ModelException in case some mandatory element is missing
	 */
	public IWebModule process(final File webXmlFile, final String moduleName) throws ProcessingException, ModelException 
	{
		emptyStringCheckParam(moduleName, "moduleName"); //$NON-NLS-1$
		if (webXmlFile == null) {
			return new WebModule(moduleName);
		}
		
		Document document;
		try {
			document = parseXmlSource(webXmlFile);
		} catch (ParserConfigurationException e) {
			throw new ProcessingException(e);
		} catch (SAXException e) {
			throw new ProcessingException(e);
		} catch (IOException e) {
			throw new ProcessingException(e);
		}
		
		return process(document.getDocumentElement(), moduleName);
	}
	
	private IWebModule process(final Element webXmlElement, final String moduleName) throws ModelException, ProcessingException 
	{
		final List<IServiceRef> xmlServiceRefs = processXmlServiceRefs(webXmlElement);
		
		final WebModule webModule = new WebModule(moduleName);
		final List<Element> servlets = XmlUtils.getChildrenByTagName(webXmlElement, SERVLET);
		for (Element servletElement : servlets) {
			webModule.addServlet(servletBuilder.process(servletElement, xmlServiceRefs));
		}

		return webModule;
	}
	
	private List<IServiceRef> processXmlServiceRefs(final Element webXmlElement) throws ModelException {
		final List<IServiceRef> xmlServiceRefs = new ArrayList<IServiceRef>();
		final List<Element> serviceRefElements = XmlUtils.getChildrenByTagName(webXmlElement, SERVICE_REF);
		for (Element serviceRefElement : serviceRefElements) {
			xmlServiceRefs.add(xmlServiceRefBuilder.parse(serviceRefElement));
		}
		
		return xmlServiceRefs;
	}
	
	private Document parseXmlSource(final File webXmlFile) throws ParserConfigurationException, SAXException, IOException 
	{
		final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setIgnoringComments(true);
		factory.setIgnoringElementContentWhitespace(true);
		factory.setNamespaceAware(true);

		final DocumentBuilder docBuilder = factory.newDocumentBuilder();
		return docBuilder.parse(webXmlFile);
	}
}
