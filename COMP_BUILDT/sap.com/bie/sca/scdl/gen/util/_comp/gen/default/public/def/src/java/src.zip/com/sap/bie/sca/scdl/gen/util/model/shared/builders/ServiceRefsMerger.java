package com.sap.bie.sca.scdl.gen.util.model.shared.builders;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.nullCheckParam;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.sap.bie.sca.scdl.gen.util.model.shared.IServiceRef;

/**
 * Merges two {@link IServiceRef} lists 
 * 
 * @author I036509
 */
public class ServiceRefsMerger 
{
	/**
	 * Merges two lists of service references into one containing only unique service
	 * references
	 * @param annServiceRefs
	 * @param xmlServiceRefs
	 * @return list of merges service references - never returns <code>null</code>
	 * @throws NullPointerException in case some of list is <code>null</code>
	 */
	public Collection<IServiceRef> merge(final Collection<IServiceRef> annServiceRefs, final Collection<IServiceRef> xmlServiceRefs) 
	{
		nullCheckParam(annServiceRefs, "annServiceRefs"); //$NON-NLS-1$
		nullCheckParam(xmlServiceRefs, "xmlServiceRefs"); //$NON-NLS-1$
		
		final List<IServiceRef> serviceRefs = new ArrayList<IServiceRef>();
		for (IServiceRef serviceRef : annServiceRefs) {
			if (shouldBeAdded(serviceRefs, serviceRef)) {
				serviceRefs.add(serviceRef);
			}
		}
		
		for (IServiceRef serviceRef : xmlServiceRefs) {
			if (shouldBeAdded(serviceRefs, serviceRef)) {
				serviceRefs.add(serviceRef);
			}
		}
		
		return serviceRefs;
	}
	
	private boolean shouldBeAdded(final List<IServiceRef> serviceRefs, final IServiceRef serviceRef) 
	{
		for (IServiceRef added : serviceRefs) {
			if (added.getServiceInterface().equals(serviceRef.getServiceInterface())) {			
				final String addedWsdlLoc = added.getWsdlLocation();
				final String refWsdlLocation = serviceRef.getWsdlLocation();
				
				if (addedWsdlLoc==null && refWsdlLocation==null) {
					return false;
				}
				
				if (addedWsdlLoc!=null && addedWsdlLoc.equals(refWsdlLocation)) {
					return false;
				}
			}
		}
		
		return true;
	}
}
