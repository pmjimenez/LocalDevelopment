package com.sap.bie.sca.scdl.gen.util.clazz.annotations;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.sap.bie.sca.scdl.gen.util.ProcessingException;
import com.sap.bie.sca.scdl.gen.util.project.IResultProvider;
import com.sap.lib.javalang.element.ClassInfo;

/**
 * Processor that calls {@link IResultProvider#getReadResult()} to retrieve all parsed
 * classes for specific project, traverses through all of them and calls the provided 
 * visitor to process it.
 * 
 * @author I036509
 */
public class ProjectAnnotationsProcessor
{
	private final ClassAnnotationsProcessor classProcessor;
	private final IResultProvider resultsProvider;
	
	/**
	 * Constructor
	 * @param resultsProvider - provides classes available in specific project for processing
	 */
	public ProjectAnnotationsProcessor(final IResultProvider resultsProvider) 
	{
		this.classProcessor = new ClassAnnotationsProcessor(resultsProvider);
		this.resultsProvider = resultsProvider;
	}

	/**
	 * Traverses though classes and for every class calls {@link ClassAnnotationsProcessor} to traverse 
	 * through class members and call the provided visitor in order to process it. As result of processing 
	 * all provided classes by {@link IResultProvider#getReadResult()} are traversed, as second step all
	 * class members are traversed and collection of processing results is returned.
	 * 
	 * @param <E>
	 * @param processor - the visitor that will process annotations per class
	 * @return returns collection of {@link IClassAnnotationsVisitor} processing results
	 * @throws ProcessingException
	 */
	public <E> Collection<E> collect(final IClassAnnotationsVisitor<E> processor) throws ProcessingException
	{
		final Collection<E> results = new ArrayList<E>();
		
		final Map<String, ClassInfo> classes = new HashMap<String, ClassInfo>(resultsProvider.getReadResult().getClasses());
		for (ClassInfo clazz : classes.values()) {
			results.addAll(classProcessor.collect(clazz, processor));
		}		
		
		return results;
	}
}
