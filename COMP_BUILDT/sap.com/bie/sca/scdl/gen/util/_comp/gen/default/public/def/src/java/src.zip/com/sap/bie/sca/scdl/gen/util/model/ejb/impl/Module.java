package com.sap.bie.sca.scdl.gen.util.model.ejb.impl;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.emptyStringCheckParam;
import static com.sap.bie.sca.scdl.gen.util.ParamChecker.nullCheckParam;

import java.text.MessageFormat;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.sap.bie.sca.scdl.gen.util.model.ModelException;
import com.sap.bie.sca.scdl.gen.util.model.ejb.IBean;
import com.sap.bie.sca.scdl.gen.util.model.ejb.IEjbModule;
import com.sap.bie.sca.scdl.gen.util.model.ejb.ModuleVersion;

/**
 * Default implementation of {@link IEjbModule} interface
 * 
 * @author I036509
 */
public class Module implements IEjbModule 
{
	private final Map<String, IBean> beans = new HashMap<String, IBean>();
	private final ModuleVersion version;
	private final String name;

	/**
	 * Constructor
	 * @param name
	 * @param version
	 * @throws NullPointerException in case some of parameters is <code>null</code>
	 * @throws IllegalArgumentException in case <code>name</code> is empty string
	 */
	public Module(final String name, final ModuleVersion version) 
	{
		emptyStringCheckParam(name, "name"); //$NON-NLS-1$
		nullCheckParam(version, "version"); //$NON-NLS-1$
		
		this.name = name;
		this.version = version;
	}
	
	/**
	 * Adds bean to the beans list
	 * @param bean
	 * @throws ModelException in case bean with such name already exists in the model
	 * @throws NullPointerException in case <code>bean</code> is <code>null</code>
	 */
	public void addBean(final IBean bean) throws ModelException {
		nullCheckParam(bean, "bean"); //$NON-NLS-1$
		if (beans.get(bean.getBeanName())!=null) {
			final String message = "Bean with name {0} already exists"; //$NON-NLS-1$
			throw new ModelException(MessageFormat.format(message, bean.getBeanName()));
		}
		beans.put(bean.getBeanName(), bean);
	}
	
	@Override
	public Collection<IBean> getBeans() {
		return beans.values();
	}

	@Override
	public ModuleVersion getVersion() {
		return version;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public IBean getBean(final String beanName) {
		nullCheckParam(beanName, "beanName"); //$NON-NLS-1$
		return beans.get(beanName);
	}
}
