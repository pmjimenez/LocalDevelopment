package com.sap.bie.sca.scdl.gen.util.model.web.impl;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.emptyStringCheckParam;
import static com.sap.bie.sca.scdl.gen.util.ParamChecker.nullCheckParam;

import java.text.MessageFormat;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.sap.bie.sca.scdl.gen.util.model.ModelException;
import com.sap.bie.sca.scdl.gen.util.model.web.IServlet;
import com.sap.bie.sca.scdl.gen.util.model.web.IWebModule;

/**
 * Default implementation of {@link IWebModule} interface 
 * 
 * @author I036509
 */
public class WebModule implements IWebModule 
{
	private final Map<String, IServlet> servlets = new HashMap<String, IServlet>();
	private final String name;
	
	/**
	 * Constructor
	 * @param name - the web module name
	 * @throws NullPointerException in case <code>name</code> is <code>null</code>
	 * @throws IllegalArgumentException in case <code>name</code> is empty string
	 */
	public WebModule(final String name) {
		emptyStringCheckParam(name, "name"); //$NON-NLS-1$
		this.name= name;
	}
	
	@Override
	public String getName() {
		return name;
	}
	
	/**
	 * Adds servlet to the list
	 * @param servlet
	 * @throws ModelException in case servlet with such name already exists in the model
	 * @throws NullPointerException in case <code>servlet</code> is <code>null</code>
	 */
	public void addServlet(final IServlet servlet) throws ModelException {
		nullCheckParam(servlet, "servlet"); //$NON-NLS-1$
		if(servlets.get(servlet.getServletName())!=null) {
			final String message = "Servlet with name {0} already exists"; //$NON-NLS-1$
			throw new ModelException(MessageFormat.format(message, servlet.getServletName()));
		}
		servlets.put(servlet.getServletName(), servlet);
	}
	
	@Override
	public Collection<IServlet> getServlets() {
		return servlets.values();
	}
}
