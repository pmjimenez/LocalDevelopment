package com.sap.bie.sca.scdl.gen.util.model;

import java.io.File;

import com.sap.bie.sca.scdl.gen.util.ProcessingException;
import com.sap.bie.sca.scdl.gen.util.model.web.IWebModule;
import com.sap.bie.sca.scdl.gen.util.model.web.builders.WebModuleBuilder;
import com.sap.bie.sca.scdl.gen.util.project.IResultProvider;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;

public class WebModuleFactory implements IModuleFactory<IWebModule> 
{
	private static final String WEB_INF = "WEB-INF"; //$NON-NLS-1$
	private static final String WEB_XML = "web.xml"; //$NON-NLS-1$
	private static IModuleFactory<IWebModule> instance;
	
	private WebModuleFactory() {
		// singleton
	}
	
	public static IModuleFactory<IWebModule> getInstance() {
		if (instance == null) {
			instance = new WebModuleFactory();
		}
		
		return instance;
	}
	
	@Override
	public IWebModule createModule(final IPluginBuildInfo pluginBuildInfo, final IResultProvider resultProvider) throws ProcessingException, ModelException 
	{
		final WebModuleBuilder webModuleBuilder = new WebModuleBuilder(resultProvider);
		final File webXmlFile = findWebXmlFile(pluginBuildInfo);
		
		return webModuleBuilder.process(webXmlFile, pluginBuildInfo.getDCName());
	}

	public File findWebXmlFile(final IPluginBuildInfo pluginBuildInfo) 
	{
//		for (File packageDir : pluginBuildInfo.getPackageDirsAsFiles()) {
//			File webXmlFile = findWebXmlFile(packageDir);
//			if (webXmlFile != null) {
//				return webXmlFile;
//			}
//		}
		
		for (File packageDir : pluginBuildInfo.getSourceDirsAsFiles()) {
			File webXmlFile = findWebXmlFile(packageDir);
			if (webXmlFile != null) {
				return webXmlFile;
			}
		}
		
		return null;
	}

	private File findWebXmlFile(final File packageDir)
	{
		final File metaInf = findFile(packageDir, WEB_INF, true);
		if (metaInf == null) {
			return null;
		}
		
		return findFile(metaInf, WEB_XML, false);
	}

	private File findFile(final File sourceDir, final String name, boolean isDirectory) 
	{
		for (File file : sourceDir.listFiles()) {
			if (name.equals(file.getName())) {
				if (isDirectory && file.isDirectory()) {
					return file;
				}
				
				if (!isDirectory && file.isFile()) {
					return file;
				}
			}
		}
		
		return null;
	}	
	
}
