package com.sap.bie.sca.scdl.gen.util.clazz.annotations.ejb;

import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.pp.api.IPublicPart;

public class EjbUtil 
{
	public static final String STATELESS = "javax.ejb.Stateless"; //$NON-NLS-1$	
	public static final String STATELESS_NAME_ATTRIBUTE = "name"; //$NON-NLS-1$
	
	private static EjbUtil instance;
	
	private EjbUtil() {
		// singleton
	}
	
	public static EjbUtil getInstance() 
	{
		if (instance == null) {
			instance = new EjbUtil(); 
		}
		
		return instance;
	}
	
	public String defineEjbJarName(final IPluginBuildInfo pbi) 
	{
		final IPublicPart ejbPP = pbi.getPublicPartMap().getPublicPart("ejbjar"); //$NON-NLS-1$
		
		if (pbi.getDCType() != null && pbi.getDCType().equals("Service Composition")) { //$NON-NLS-1$
			return pbi.getDCVendor()+"~"+pbi.getDCName().replaceAll("/", "~") + ".jar"; //$NON-NLS-1$
		}
		else {
			return pbi.getDCVendor()+"~"+pbi.getDCName().replaceAll("/", "~") + (ejbPP!=null ? "~ejbjar" : "")+".jar"; //$NON-NLS-1$
		}
	}
}
