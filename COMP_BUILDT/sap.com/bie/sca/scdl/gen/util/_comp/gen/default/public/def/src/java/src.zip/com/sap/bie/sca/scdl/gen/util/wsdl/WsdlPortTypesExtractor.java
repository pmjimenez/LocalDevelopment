package com.sap.bie.sca.scdl.gen.util.wsdl;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.nullCheckParam;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.namespace.QName;

import org.xml.sax.EntityResolver;

import com.sap.engine.services.webservices.espbase.wsdl.Definitions;
import com.sap.engine.services.webservices.espbase.wsdl.Interface;
import com.sap.engine.services.webservices.espbase.wsdl.ObjectList;
import com.sap.engine.services.webservices.espbase.wsdl.WSDLLoader;
import com.sap.engine.services.webservices.espbase.wsdl.exceptions.WSDLException;
import com.sap.engine.services.webservices.tools.WSDLDownloadResolver;

/**
 * Extracts portTypes defined in WSDL
 * 
 * @author I036509
 */
public class WsdlPortTypesExtractor 
{
	private EntityResolver entityResolver;
	
	/**
	 * Extracts portTypes out of <code>wsdlUrl</code> supplied.
	 * @param wsdlUrl - root WSDL url
	 * @return list of QNames
	 * @throws WsdlProcessingException in case some WSDL processing error happens
	 */
	public List<QName> extract(final URL wsdlFileUrl) throws WsdlProcessingException
	{		
		Definitions definitions;
		try {
			final File wsdlFile = new File(wsdlFileUrl.toURI());
			validateWsdlFile(wsdlFile);
			
			definitions = loadDefinitions(wsdlFileUrl);
		}  
		catch (WSDLException e) {
			throw new WsdlProcessingException(wsdlFileUrl.toExternalForm(), e);
		} 
		catch (IOException e) {
			throw new WsdlProcessingException(wsdlFileUrl.toExternalForm(), e);
		} 
		catch (URISyntaxException e) {
			throw new WsdlProcessingException(wsdlFileUrl.toExternalForm(), e);
		}
		
		final List<QName> portTypes = new ArrayList<QName>();
		final ObjectList interfaces = definitions.getInterfaces();
		for (int i = 0; i < interfaces.getLength(); i++) {
			final Interface sei = (Interface)interfaces.item(i);
			portTypes.add(sei.getName());
		}
		
		return portTypes;			
	}
	
	private void validateWsdlFile(final File wsdlFile) throws IOException, WsdlProcessingException 
	{
		nullCheckParam(wsdlFile, "wsdlFile"); //$NON-NLS-1$
		if (!wsdlFile.exists()) {
			throw new FileNotFoundException(toCannonicalPath(wsdlFile));
		}
	
		if (wsdlFile.isDirectory()) {
			throw new WsdlProcessingException(toCannonicalPath(wsdlFile), "Provided java.io.File is directory"); //$NON-NLS-1$
		}
	}

	/**
	 * Sets the {@link EntityResolver} to be used during WSDL processing 
	 *   
	 * @param entityResolver
	 */
	public void setEntityResolver(EntityResolver entityResolver) 
	{
		nullCheckParam(entityResolver, "entityResolver"); //$NON-NLS-1$
		this.entityResolver = entityResolver;
	}
	
	private Definitions loadDefinitions(final URL wsdlUrl) throws WSDLException, IOException 
	{
		final WSDLLoader loader = new WSDLLoader();
		loader.setWSDLResolver(entityResolver!=null ? entityResolver : new WSDLDownloadResolver());
		
		return loader.load(wsdlUrl.toExternalForm());
	}
	
	private String toCannonicalPath(final File wsdlFile) throws IOException {
		return wsdlFile.getCanonicalPath();
	}
}
