package com.sap.bie.sca.scdl.gen.util.project;

import java.net.URL;

public interface IResourceFinder {
	public URL findResource(String location);
}
