package com.sap.bie.sca.scdl.gen.util.model.shared.impl;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.*;

import com.sap.bie.sca.scdl.gen.util.model.shared.IServiceRef;

/**
 * Default implementation of {@link IServiceRef} interface
 * 
 * @author I036509
 */
public class ServiceRef implements IServiceRef 
{
	private final String name;
	private final String serviceInterface;
	private String serviceRefType;
	private String wsdlLocation;

	/**
	 * Constructor
	 * @param name
	 * @param serviceInterface
	 * @throws NullPointerException in case some of parameters is {@link NullPointerException}
	 * @throws IllegalArgumentException in case some of parameters is empty string
	 */
	public ServiceRef(final String name, final String serviceInterface) 
	{
		nullCheckParam(name, "name"); //$NON-NLS-1$
		emptyStringCheckParam(serviceInterface, "serviceInterface"); //$NON-NLS-1$
		
		this.name = name;
		this.serviceInterface = serviceInterface;
	}
	
	@Override
	public String getName() {
		return name;
	}

	@Override
	public String getServiceInterface() {
		return serviceInterface;
	}
	
	/**
	 * @param serviceRefType - night be null
	 */
	public void setServiceRefType(final String serviceRefType) {
		this.serviceRefType = serviceRefType;
	}

	@Override
	public String getServiceRefType() {
		return serviceRefType;
	}

	/**
	 * @param wsdlLocation - might be <code>null</code>
	 */
	public void setWsdlLocation(final String wsdlLocation) {
		this.wsdlLocation = wsdlLocation;
	}
	
	@Override
	public String getWsdlLocation() {
		return wsdlLocation;
	}
}
