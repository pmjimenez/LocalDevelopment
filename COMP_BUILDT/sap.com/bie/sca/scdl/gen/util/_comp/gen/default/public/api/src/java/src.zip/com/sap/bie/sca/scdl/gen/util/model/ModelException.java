package com.sap.bie.sca.scdl.gen.util.model;

/**
 * Exception thrown when exceptional situation is faced during creation of the model 
 * 
 * @author I036509
 */
public class ModelException extends Exception 
{
	private static final long serialVersionUID = 1L;

	/**
	 * @param message
	 */
	public ModelException(String message) {
		super(message);
	}
}
