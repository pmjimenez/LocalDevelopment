package com.sap.bie.sca.scdl.gen.util.model.shared;

import java.util.Collection;

public interface IServiceRefContainer 
{
	/**
	 * Adds reference to the references list 
	 * @param serviceRef
	 * @throws NullPointerException in case <code>serviceRef</code> is <code>null</code>
	 */
	public void addServiceRef(final IServiceRef serviceRef);
	
	/**
	 * @return collection of web service references for this bean, never returns <code>null</code> instead
	 * returns empty collection
	 */
	public Collection<IServiceRef> getServiceRefs();
}
