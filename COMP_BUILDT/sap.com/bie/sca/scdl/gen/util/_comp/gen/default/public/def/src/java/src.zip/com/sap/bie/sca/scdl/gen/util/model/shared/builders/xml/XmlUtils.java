/*
 * Copyright (c) 2005 by SAP AG, Walldorf.,
 * url: http://www.sap.com
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of SAP AG, Walldorf. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with SAP.
 */
package com.sap.bie.sca.scdl.gen.util.model.shared.builders.xml;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.sap.bie.sca.scdl.gen.util.model.ModelException;

/**
 * @author krasimir.topchiyski@sap.com
 */
public class XmlUtils {
	/**
	 * Returns an iterator over the children with specified name of the given
	 * element.
	 * 
	 * @param element
	 *            The parent element.
	 * @param tagName
	 *            The name of the child to search with.
	 * @return An interator of children.
	 */
	public static List<Element> getChildrenByTagName(Element element, String tagName) {
		final List<Element> childrenList = new ArrayList<Element>();
		if (element != null) {
			NodeList children = element.getChildNodes();
			for (int i = 0; i < children.getLength(); i++) {
				Node currentChild = children.item(i);
				if (currentChild.getNodeType() == Node.ELEMENT_NODE
						&& currentChild.getLocalName().equals(tagName)) {
					childrenList.add((Element) currentChild);
				}
			}
		}
		return childrenList;
	}

	/**
	 * Gets the child with a specified name of the specified element.
	 * 
	 * @param element
	 *            The parent element
	 * @param tagName
	 *            The name of the child to search with
	 * @return The mandatory element.
	 * @throws ModelException if the mandatory element is not specified or more then one occurrences found.
	 */
	public static Element getMandatorySingleChild(Element element, String tagName) throws ModelException {
		final Iterator<Element> children = getChildrenByTagName(element, tagName).iterator();
		if (children.hasNext()) {
			Element child = children.next();
			if (children.hasNext()) {
				throw new ModelException(format("Only one tag with name '{0}' expected in the XML element {1}.", tagName, element)); //$NON-NLS-1$
			}
			return child;
		} else {
			throw new ModelException(format("Mandatory element {0} not found in the XML element {1}." + element, tagName, element)); //$NON-NLS-1$
		}
	}
	
	private static String format(String pattern, Object ... arguments) {
		return MessageFormat.format(pattern, arguments);
	}
	
	/**
	 * Gets the child with a specified name of the specified element. If the
	 * child with this name doesn't exist then the specified default value is
	 * returned.
	 * 
	 * @param element
	 *            The parent element
	 * @param tagName
	 *            The name of the child to search with
	 * @param defaultReturnValue
	 *            The element to return if the child doesn't exist
	 * @return either the named child or the supplied default
	 */
	public static Element getOptionalSingleChild(Element element, String tagName, Element defaultReturnValue) throws ModelException {
		final Iterator<Element> children = getChildrenByTagName(element, tagName).iterator();
		if (children.hasNext()) {
			Element child = children.next();
			if (children.hasNext()) {
				throw new ModelException(format("Only one tag with name '{0}' expected in the XML element {1}.", tagName, element)); //$NON-NLS-1$
			}
			return child;
		} else {
			return defaultReturnValue;
		}
	}

	/**
	 * Gets the child with a specified name of the specified element. If the
	 * child with this name doesn't exist then null is returned.
	 * 
	 * @param element
	 *            The parent element
	 * @param tagName
	 *            The name of the child to search with.
	 * @return either the named child or null
	 */
	public static Element getOptionalSingleChild(Element element, String tagName)
			throws ModelException {
		return getOptionalSingleChild(element, tagName, null);
	}

	/**
	 * Get the text content of the given element.
	 * 
	 * @param element
	 *            The element to get the content off.
	 * @param defaultReturnValue
	 *            The default value which will be returned to when there is no
	 *            content.
	 * @return The content of the element or the specified default value.
	 * @throws ModelException
	 *             If the child node with the given name is not a exactly one or
	 *             the type of the child node is not text.
	 */
	public static String getTextContent(Element element,
			String defaultReturnValue) throws ModelException {
		String result = defaultReturnValue;
		if (element != null) {
			NodeList children = element.getChildNodes();
			if (children.getLength() > 1) {
				throw new ModelException(format("Only one text node expected in element {0}", element.getNodeName())); //$NON-NLS-1$
			} else if (children.getLength() == 1) {
				short nodeType = children.item(0).getNodeType();
				if (nodeType == Node.TEXT_NODE || 
	                    nodeType == Node.CDATA_SECTION_NODE) {
	                result = children.item(0).getNodeValue().trim();
				} else {
	                throw new ModelException(format("Text node or CDATA node expected in element {0} but node type is {1}", element.getNodeName(), nodeType)); //$NON-NLS-1$
	            }
			}
		}
		return result;
	}

	/**
	 * Get the boolean value content of the given element.
	 * 
	 * @param element
	 *            The element to get the content off.
	 * @param defaultReturnValue
	 *            The default value which will be returned to when there is no
	 *            content.
	 * @return The content of the element or the specified default value.
	 * @throws ModelException
	 *             If the child node with the given name is not a exactly one or
	 *             the type of the child node is not text.
	 */
	public static Boolean getBooleanContent(Element element) throws ModelException {
		String strBoolean = getTextContent(element);
		if (strBoolean != null) {
			return Boolean.valueOf(strBoolean);
		} else {
			return null;
		}
	}
	
	
	/**
	 * Get the text content of the given element.
	 * 
	 * @param element
	 *            The element to get the content off.
	 * @return The content of the element or null.
	 * @throws ModelException
	 *             If the child node with the given name is not a exactly one or
	 *             the type of the child node is not text.
	 */
	public static String getTextContent(Element element) throws ModelException {
		return getTextContent(element, null);
	}
	
	public static String getValueContent(Element element) throws ModelException {
			String result = null;
			if (element != null) {
				NodeList children = element.getChildNodes();
				if (children.getLength() > 1) {
					throw new ModelException(format("Only one text node expected in element {0}", element.getNodeName())); //$NON-NLS-1$
				} else if (children.getLength() == 1) {
					short nodeType = children.item(0).getNodeType();
					if (nodeType == Node.TEXT_NODE || 
		                    nodeType == Node.CDATA_SECTION_NODE) {
		                result = children.item(0).getNodeValue();
					} else {
		                throw new ModelException(format("Text node or CDATA node expected in element {0} but node type is {1}", element.getNodeName(), nodeType)); //$NON-NLS-1$
		            }
				}
			}
			return result;
		
	}
	
	/**
	 * Returns an attribute value if any, null otherwise.
	 *
	 * @param element    The element in which the attribute check will be perfomed.
	 * @param attributeName The name of the attrribute.
	 * 
	 * @return           Returns an attribute value if any, null otherwise.
	 */
	public static String getElementAttribute(Element element, String attributeName) {
		String result = null;
		if (element != null) {	
			if (attributeName != null && element.hasAttribute(attributeName)) {
				result = element.getAttribute(attributeName).trim();
			}
		}
		return result;
	}
}
