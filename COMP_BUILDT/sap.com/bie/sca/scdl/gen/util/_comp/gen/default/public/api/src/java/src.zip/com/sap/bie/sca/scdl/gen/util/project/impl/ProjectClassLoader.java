package com.sap.bie.sca.scdl.gen.util.project.impl;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.nullCheckParam;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import com.sap.tc.buildplugin.api.IArchiveDescriptor;
import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.util.Utils;

public class ProjectClassLoader extends URLClassLoader
{	
	/**
	* Constructor
	* Creates {@link ClassLoader} for DC project by collecting all public parts that are referenced for 
	* compilation and the compile directory provided in URL array and creates {@link URLClassLoader} instance
	* @param compileDir
	* @param globalPluginUtil
	* @param pluginBuildInfo
	* @return created class loader
	* @throws MalformedURLException
	*/
	public ProjectClassLoader(final File compileDir, final IGlobalPluginUtil globalPluginUtil, final IPluginBuildInfo pluginBuildInfo) throws MalformedURLException	
	{
		super(new URL[0]);
		
		nullCheckParam(compileDir, "compileDir"); //$NON-NLS-1$
		nullCheckParam(globalPluginUtil, "globalPluginUtil"); //$NON-NLS-1$
		nullCheckParam(pluginBuildInfo, "pluginBuildInfo"); //$NON-NLS-1$
		
		addPublicPartArchives(globalPluginUtil, pluginBuildInfo);
		addURL(compileDir.toURI().toURL());
	}
	
	public ProjectClassLoader(final Collection<File> outFolders, final IGlobalPluginUtil globalPluginUtil, final IPluginBuildInfo pluginBuildInfo) throws MalformedURLException	
	{
		super(new URL[0]);

		nullCheckParam(outFolders, "outFolders"); //$NON-NLS-1$
		nullCheckParam(globalPluginUtil, "globalPluginUtil"); //$NON-NLS-1$
		nullCheckParam(pluginBuildInfo, "pluginBuildInfo"); //$NON-NLS-1$

		addPublicPartArchives(globalPluginUtil, pluginBuildInfo);
		for (File outFolder : outFolders) {
			addURL(outFolder.toURI().toURL());
		}
	}
	
	private void addPublicPartArchives(final IGlobalPluginUtil globalPluginUtil, final IPluginBuildInfo pluginBuildInfo) throws MalformedURLException {
		for (File archive : getPublicPartArchives(globalPluginUtil, pluginBuildInfo)) {
			addURL(archive.toURI().toURL());
		}
	}
	
	private List<File> getPublicPartArchives(IGlobalPluginUtil gpu, IPluginBuildInfo pbi) 
	{
		final List<File> result = new ArrayList<File>();

        final List<File> compilePPs = pbi.getFolderAttributeManager().getFiles("public-part[purpose[compilation]]"); //$NON-NLS-1$
        if (compilePPs != null) {
            for (IArchiveDescriptor descriptor : pbi.getArchiveDescriptors(compilePPs, archiveAtributes())) {
                addFiles(result, descriptor.getFiles());
            }
        }
        
        addFiles(result, gpu.getFoldersByAttribute("java-compile-classpath")); //$NON-NLS-1$
        
        return result;
	}

	private List<String> archiveAtributes() {
		return Arrays.asList("java-library", "jar"); //$NON-NLS-1$ //$NON-NLS-2$
	}
	
	private void addFiles(final List<File> result, final List<File> files) 
	{
        if (files == null) {
        	return;
        }
        
        for (int i = 0; i < files.size(); i++) {
            File file = Utils.asFile(files.get(i));
            if (!result.contains(file)) {
                result.add(file);
            }
        }
    }
}
