package com.sap.bie.sca.scdl.gen.util.model.shared.builders.annotations;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.nullCheckParam;

import java.util.ArrayList;
import java.util.List;

import com.sap.bie.sca.scdl.gen.util.ProcessingException;
import com.sap.bie.sca.scdl.gen.util.clazz.annotations.ClassAnnotationsProcessor;
import com.sap.bie.sca.scdl.gen.util.clazz.annotations.IClassAnnotationsVisitor;
import com.sap.bie.sca.scdl.gen.util.model.ModelException;
import com.sap.bie.sca.scdl.gen.util.model.shared.impl.ServiceRef;
import com.sap.bie.sca.scdl.gen.util.project.IResultProvider;
import com.sap.lib.javalang.annotation.AnnotationRecord;
import com.sap.lib.javalang.annotation.AnnotationRecord.Member;
import com.sap.lib.javalang.annotation.AnnotationRecord.NamedMember;
import com.sap.lib.javalang.element.ClassInfo;
import com.sap.lib.javalang.element.FieldInfo;
import com.sap.lib.javalang.element.MethodInfo;

/**
 * This builder traverses though the class and searches for javax.xml.ws.WebServiceRef and 
 * javax.xml.ws.WebServiceRefs annotation and collects references.
 * 
 * @author I036509
 */
public class ServiceReferencesBuilder 
{
	public static final String WS_REF = "javax.xml.ws.WebServiceRef"; //$NON-NLS-1$
	public static final String WS_REFS = "javax.xml.ws.WebServiceRefs"; //$NON-NLS-1$
	private static final String VALUE = "value"; //$NON-NLS-1$
	private static final String OBJECT = "java.lang.Object"; //$NON-NLS-1$

	private final ServiceRefBuilder refBuilder = new ServiceRefBuilder();
	
	/**
	 * Processes the supplied <code>clazz</code> and extracts a list of web service references defined
	 * in the class using annotations. The processing drills down though hierarchy and collects service references
	 * in super classes.
	 *  
	 * @param clazz
	 * @param resultProvider
	 * @return list of collected references - never returns <code>null</code>
	 * @throws ProcessingException in case the class processing is not possible due to missing classes etc.
	 * @throws ModelException in case of missing or incorrect information
	 * @throws NullPointerException in case some of parameters is <code>null</code>
	 */
	public List<ServiceRef> process(final ClassInfo clazz, final IResultProvider resultProvider) throws ProcessingException, ModelException
	{
		nullCheckParam(clazz, "clazz"); //$NON-NLS-1$
		nullCheckParam(resultProvider, "resultProvider"); //$NON-NLS-1$
		
		final List<ServiceRef> serviceRefs = new ArrayList<ServiceRef>();
		
		ClassInfo currentClass = clazz;
		while(currentClass!=null && !currentClass.getName().equals(OBJECT)) {
			serviceRefs.addAll(processClass(currentClass, resultProvider));
			currentClass = currentClass.getSuperclass();
		}
		
		return serviceRefs;
	}	
	
	private List<ServiceRef> processClass(final ClassInfo clazz, final IResultProvider resultProvider) throws ProcessingException, ModelException
	{
		final List<ServiceRef> refs = new ArrayList<ServiceRef>();
		
		final ClassAnnotationsProcessor processor = new ClassAnnotationsProcessor(resultProvider);
		for (AnnotationRecord ar : processor.collect(clazz, new WebServiceRefVisitor())) {
			refs.add(refBuilder.process(clazz, ar));
		}
		
		for (AnnotationRecord ar : collectFromWsRefsAnnotation(clazz)) {
			refs.add(refBuilder.process(clazz, ar));
		}
		
		return refs;
	}
	
	private List<AnnotationRecord> collectFromWsRefsAnnotation(final ClassInfo clazz) throws ModelException 
	{
		final AnnotationRecord ar = clazz.getAnnotation(WS_REFS);
		if (ar == null) {
			return new ArrayList<AnnotationRecord>(0);
		}

		final NamedMember valueAttribute = ar.getMember(VALUE);
		if (valueAttribute == null) {
			return new ArrayList<AnnotationRecord>(0);
		}

		final List<AnnotationRecord> wsRefAnnotations = new ArrayList<AnnotationRecord>(); 
		for (Member wsRefMemeber : valueAttribute.getMemberArrayValue()) {
			wsRefAnnotations.add(wsRefMemeber.getAnnotationValue());
		}
		
		return wsRefAnnotations;
	}
	
	private class WebServiceRefVisitor implements IClassAnnotationsVisitor<AnnotationRecord>
	{
		@Override
		public AnnotationRecord processClass(ClassInfo clazz, IResultProvider resultProvider) throws ProcessingException {
			return clazz.getAnnotation(WS_REF);
		}

		@Override
		public AnnotationRecord processField(FieldInfo field, IResultProvider resultProvider) throws ProcessingException {
			return field.getAnnotation(WS_REF);
		}

		@Override
		public AnnotationRecord processMethod(MethodInfo method, IResultProvider resultProvider) throws ProcessingException {
			return method.getAnnotation(WS_REF);
		}

		@Override
		public boolean visits(IClassAnnotationsVisitor.VisitType type) {
			return true;
		}
	}
}
