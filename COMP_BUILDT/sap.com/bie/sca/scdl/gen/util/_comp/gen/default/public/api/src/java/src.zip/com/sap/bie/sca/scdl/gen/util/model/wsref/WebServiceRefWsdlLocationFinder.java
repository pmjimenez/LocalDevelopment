package com.sap.bie.sca.scdl.gen.util.model.wsref;

import java.net.MalformedURLException;
import java.net.URL;
import java.text.MessageFormat;

import com.sap.bie.sca.scdl.gen.util.ProcessingException;
import com.sap.bie.sca.scdl.gen.util.model.shared.IServiceRef;
import com.sap.bie.sca.scdl.gen.util.project.IResultProvider;
import com.sap.lib.javalang.annotation.AnnotationRecord;
import com.sap.lib.javalang.annotation.AnnotationRecord.NamedMember;
import com.sap.lib.javalang.element.ClassInfo;

/**
 * This is a utility class extracts the URL for wsdlLocation property of web service reference
 * used in deployment descriptor or annotation
 * 
 * @author I036509
 */
public class WebServiceRefWsdlLocationFinder 
{
	private static final String WEB_SERVICE_CLIENT = "javax.xml.ws.WebServiceClient"; //$NON-NLS-1$
	private static final String WSDL_LOCATION = "wsdlLocation"; //$NON-NLS-1$

	/**
	 * <pre>
	 * Extracts the URL for wsdlLocation property of web service reference
	 * used in deployment descriptor or annotation. The processing order is:
	 * 
	 * 1. If {@link IServiceRef#getWsdlLocation()} is not <code>null</code> tries to define the URL
	 *    for this parameter   
	 * 2. If {@link IServiceRef#getWsdlLocation()} is <code>null</code> searches for WebServiceClient
	 *    annotation in the service class with fully qualified name {@link IServiceRef#getServiceInterface()} 
	 *    and extracts the wsdlLocation out of it, updates the {@link IServiceRef#setWsdlLocation(String)}
	 *    and converts it to URL.
	 * </pre>
	 * @param serviceRef
	 * @param resultProvider
	 * @return defined URL - might return <code>null</code> if wsdlLocation is
	 * not an URL and the underlying resource with such relative name cannot be found
	 * @throws IncorrectWsdlLocationException in case the service class is not annotated with WebServiceClient 
	 * annotation, the wsdlLocation defined in the annotation contains invalid value or the relative WSDL corresponding
	 * to this wsdlLocation cannot be found 
	 * @throws ProcessingException in case of errors in parsing the classes
	 */
	public URL extractWsdlLocation(final IServiceRef serviceRef, final IResultProvider resultProvider) throws IncorrectWsdlLocationException, ProcessingException
	{		
		if (serviceRef.getWsdlLocation() != null) {
			return findWsdlUrl(serviceRef.getWsdlLocation(), resultProvider);
		}
		
		final String foundWsdlLocation = extractWsdlLocationFromServiceClass(serviceRef.getServiceInterface(), resultProvider);
		serviceRef.setWsdlLocation(foundWsdlLocation);
		return findWsdlUrl(foundWsdlLocation, resultProvider);
	}
	
	private URL findWsdlUrl(final String wsdlLocation, final IResultProvider resultProvider) throws IncorrectWsdlLocationException 
	{
		try {
			return new URL(wsdlLocation);
		} 
		catch (MalformedURLException e) { // $JL-EXC$
			final URL wsdlUrl = resultProvider.getResourceFinder().findResource(wsdlLocation);
			if (wsdlUrl == null) {
				final String message = "WSDL with location ''{0}'' cannot be found"; //$NON-NLS-1$
				throw new IncorrectWsdlLocationException(error(message, wsdlLocation));			
			}
			
			return wsdlUrl;
		}
	}

	private String extractWsdlLocationFromServiceClass(final String serviceClassName, final IResultProvider resultProvider) throws IncorrectWsdlLocationException, ProcessingException 
	{
		final ClassInfo cls = resultProvider.getReadResult().getClass(serviceClassName);
		if (cls == null) {
			final String message = "Class {0} used in web service reference cannot be foud"; //$NON-NLS-1$
			throw new IncorrectWsdlLocationException(error(message, serviceClassName));
		}

		final AnnotationRecord wsClientAnnotation = cls.getAnnotation(WEB_SERVICE_CLIENT);
		if (wsClientAnnotation==null) {
			final String message = "Class {0} used in web service reference does not contain @javax.xml.ws.WebServiceClient annotation"; //$NON-NLS-1$
			throw new IncorrectWsdlLocationException(error(message, serviceClassName));
		}

		final NamedMember wsdlLocationAttribute = wsClientAnnotation.getMember(WSDL_LOCATION);  
		if (wsdlLocationAttribute==null) {
			final String message = "The @javax.xml.ws.WebServiceClient annotation on class {0} used in web service reference does not contain ''wsdlLocation'' attribute"; //$NON-NLS-1$
			throw new IncorrectWsdlLocationException(error(message, serviceClassName));
		}

		if (wsdlLocationAttribute.getStringValue().trim().length()==0) {
			final String message = "Invalid ''wsdlLocation'' attribute in @javax.xml.ws.WebServiceClient annotation on class {0} used in web service reference"; //$NON-NLS-1$
			throw new IncorrectWsdlLocationException(error(message, serviceClassName));
		}

		return wsdlLocationAttribute.getStringValue();
	}
	
	private String error(String message, Object ... params) {
		return MessageFormat.format(message, params);
	}
}