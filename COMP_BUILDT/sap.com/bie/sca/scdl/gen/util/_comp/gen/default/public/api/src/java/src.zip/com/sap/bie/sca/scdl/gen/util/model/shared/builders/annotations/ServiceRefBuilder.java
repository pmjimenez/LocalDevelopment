package com.sap.bie.sca.scdl.gen.util.model.shared.builders.annotations;

import java.text.MessageFormat;

import com.sap.bie.sca.scdl.gen.util.model.ModelException;
import com.sap.bie.sca.scdl.gen.util.model.shared.IServiceRef;
import com.sap.bie.sca.scdl.gen.util.model.shared.impl.ServiceRef;
import com.sap.lib.javalang.annotation.AnnotationRecord;
import com.sap.lib.javalang.annotation.AnnotationRecord.NamedMember;
import com.sap.lib.javalang.element.ClassInfo;
import com.sap.lib.javalang.element.FieldInfo;

/**
 * Builder for {@link IServiceRef} out of annotation
 * 
 * @author I036509
 */
public class ServiceRefBuilder 
{
	private static final String EMPTY = ""; //$NON-NLS-1$
	private static final String NAME = "name"; //$NON-NLS-1$
	private static final String VALUE = "value"; //$NON-NLS-1$
	private static final String TYPE = "type"; //$NON-NLS-1$
	private static final String WSDL_LOCATION = "wsdlLocation"; //$NON-NLS-1$

	/**
	 * Processes the bean annotation <code>ar</code> and creates ServiceRef instance
	 * @param clazz
	 * @param ar
	 * @return
	 * @throws ModelException
	 */
	public ServiceRef process(final ClassInfo clazz, final AnnotationRecord ar) throws ModelException 
	{
		final String name = defineName(ar);
		final String serviceInterface = defineServiceClassName(clazz, ar);
		final ServiceRef ref = new ServiceRef(name, serviceInterface);		
		ref.setWsdlLocation(defineWsdlLocation(clazz, ar));
		
		final String type = defineType(ar, serviceInterface); 
		if (type != null) {
			ref.setServiceRefType(type);
		}
		
		return ref;
	}
	
	private String defineServiceClassName(final ClassInfo clazz, final AnnotationRecord ar) throws ModelException 
	{
		final NamedMember pair = ar.getMember(VALUE);
		if (pair != null) {
			return pair.getStringValue();
		}
		
		if (ar.getOwner() instanceof FieldInfo) {
			return ((FieldInfo) ar.getOwner()).getType();
		}
		
		final String message = "''Value'' attribute in @javax.xml.ws.WebServiceRef annotation is missing but it''s required, class {0}"; //$NON-NLS-1$
		throw new ModelException(MessageFormat.format(message, clazz.getName()));
	}

	private String defineName(final AnnotationRecord ar) 
	{
		final NamedMember nameMember = ar.getMember(NAME);
		if (nameMember != null) {
			return nameMember.getStringValue();
		}
		
		return EMPTY;
	}
	
	private String defineType(final AnnotationRecord ar, final String serviceInterface) 
	{
		final NamedMember nameMember = ar.getMember(TYPE);
		if (nameMember != null && nameMember.getStringValue()!=null) {
			return nameMember.getStringValue();
		}
		
		return null;
	}
	
	private String defineWsdlLocation(final ClassInfo clazz, final AnnotationRecord ar) throws ModelException {
		final NamedMember pair = ar.getMember(WSDL_LOCATION);
		if (pair == null) {
			return null;
		}
		
		if (pair.getStringValue().trim().length() == 0) {
			final String message = "Invalid ''wsdlLocation'' attribute in @javax.xml.ws.WebServiceRef annotation, class {0}"; //$NON-NLS-1$
			throw new ModelException(
					MessageFormat.format(message, clazz.getName()));
		}
		return pair.getStringValue();
	}
}
