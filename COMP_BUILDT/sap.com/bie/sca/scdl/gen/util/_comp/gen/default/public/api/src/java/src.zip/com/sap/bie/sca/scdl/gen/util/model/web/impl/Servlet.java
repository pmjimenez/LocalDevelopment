package com.sap.bie.sca.scdl.gen.util.model.web.impl;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.emptyStringCheckParam;

import com.sap.bie.sca.scdl.gen.util.model.shared.impl.ServiceRefContainer;
import com.sap.bie.sca.scdl.gen.util.model.web.IServlet;

/**
 * Default implementation of {@link IServlet} interface
 * 
 * @author I036509
 */
public class Servlet extends ServiceRefContainer implements IServlet 
{
	private final String name;
	private final String servletClass;
	
	/**
	 * Constructor
	 * @param name - the servlet name
	 * @param servletClass - the servlet implementation class
	 * @throws NullPointerException in case some of parameters is <code>null</code>
	 * @throws IllegalArgumentException in case some of parameters is empty string
	 */
	public Servlet(final String name, final String servletClass) {
		emptyStringCheckParam(name, "name"); //$NON-NLS-1$
		emptyStringCheckParam(servletClass, "servletClass"); //$NON-NLS-1$
		this.name= name;
		this.servletClass = servletClass;
	}

	@Override
	public String getServletName() {
		return name;
	}

	@Override
	public String getServletClass() {
		return servletClass;
	}
}
