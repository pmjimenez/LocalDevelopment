package com.sap.bie.sca.scdl.gen.util.model.wsref;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.nullCheckParam;

import java.net.URL;
import java.text.MessageFormat;
import java.util.List;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.gen.util.ProcessingException;
import com.sap.bie.sca.scdl.gen.util.model.shared.IServiceRef;
import com.sap.bie.sca.scdl.gen.util.project.IResultProvider;
import com.sap.bie.sca.scdl.gen.util.wsdl.WsdlPortTypesExtractor;
import com.sap.bie.sca.scdl.gen.util.wsdl.WsdlProcessingException;

public class WebServiceRefPortTypesExtractor 
{
	private static final String FILE = "file"; //$NON-NLS-1$
	
	final WebServiceRefWsdlLocationFinder wsdlLocationFinder = new WebServiceRefWsdlLocationFinder();
	
	public List<QName> extractPortTypes(final IServiceRef serviceRef, final IResultProvider resultProvider) throws IncorrectWsdlLocationException, ProcessingException, WsdlProcessingException
	{
		nullCheckParam(serviceRef, "serviceRef"); //$NON-NLS-1$
		nullCheckParam(resultProvider, "resultProvider"); //$NON-NLS-1$
		
		final URL wsdlUrl = wsdlLocationFinder.extractWsdlLocation(serviceRef, resultProvider);
		
		if (!FILE.equals(wsdlUrl.getProtocol())) {
			final String message = "Unsupported scenario - provided wsdlLocation does not point to file in the file system, {0}"; //$NON-NLS-1$			
			throw new IncorrectWsdlLocationException(MessageFormat.format(message, wsdlUrl)); 
		}
		
		final WsdlPortTypesExtractor portTypeExtractor = new WsdlPortTypesExtractor();		
		return portTypeExtractor.extract(wsdlUrl);
	}
}
