package com.sap.bie.sca.scdl.gen.util.model.shared.builders.xml;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.nullCheckParam;

import org.w3c.dom.Element;

import com.sap.bie.sca.scdl.gen.util.model.ModelException;
import com.sap.bie.sca.scdl.gen.util.model.shared.IServiceRef;
import com.sap.bie.sca.scdl.gen.util.model.shared.impl.ServiceRef;

/**
 * Builder for {@link IServiceRef} instances out of XML element
 * 
 * @author I036509
 */
public class ServiceRefBuilder 
{	
	private static final String SERVICE_REF_TYPE = "service-ref-type"; //$NON-NLS-1$
	private static final String WSDL_FILE = "wsdl-file"; //$NON-NLS-1$
	private static final String SERVICE_INTERFACE = "service-interface"; //$NON-NLS-1$
	private static final String SERVICE_REF_NAME = "service-ref-name"; //$NON-NLS-1$

	/**
	 * Parses the provided XML element and creates {@link IServiceRef} instance
	 * @param serviceRefElement
	 * @return the created instance - never returns <code>null</code>
	 * @throws ModelException in case some mandatory element is missing
	 */
	public IServiceRef parse(final Element serviceRefElement) throws ModelException 	
	{
		nullCheckParam(serviceRefElement, "serviceRefElement"); //$NON-NLS-1$
		
		final String name = XmlUtils.getTextContent(XmlUtils.getMandatorySingleChild(serviceRefElement, SERVICE_REF_NAME));
		final String serviceInterface = XmlUtils.getTextContent(XmlUtils.getMandatorySingleChild(serviceRefElement, SERVICE_INTERFACE));
		
		final ServiceRef reference = new ServiceRef(name, serviceInterface);
		
		final String wsdlFile = XmlUtils.getTextContent(XmlUtils.getOptionalSingleChild(serviceRefElement, WSDL_FILE));
		reference.setWsdlLocation(wsdlFile);		

		final String serviceRefType = XmlUtils.getTextContent(XmlUtils.getOptionalSingleChild(serviceRefElement, SERVICE_REF_TYPE));
		reference.setServiceRefType(serviceRefType);
		
		return reference;
	}
}
