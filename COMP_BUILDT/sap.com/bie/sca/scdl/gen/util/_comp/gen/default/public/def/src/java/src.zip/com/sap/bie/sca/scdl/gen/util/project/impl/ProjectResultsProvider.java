package com.sap.bie.sca.scdl.gen.util.project.impl;


import static com.sap.bie.sca.scdl.gen.util.ParamChecker.nullCheckParam;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.sap.bie.sca.scdl.gen.util.ProcessingException;
import com.sap.bie.sca.scdl.gen.util.clazz.annotations.ProjectAnnotationsProcessor;
import com.sap.bie.sca.scdl.gen.util.project.IResourceFinder;
import com.sap.bie.sca.scdl.gen.util.project.IResultProvider;
import com.sap.lib.javalang.tool.ClassFinder;
import com.sap.lib.javalang.tool.ReadResult;
import com.sap.lib.javalang.tool.ReaderFactory;
import com.sap.lib.javalang.tool.exception.ReadingException;
/**
 * Class that traverse the project's compile directory, collects all files in it
 * and calls {@link ReaderFactory} to parse all class files. Use this class in
 * conjunction with {@link ProjectAnnotationsProcessor} to process classes
 * containing specific annotation.
 * 
 * @author I036509
 */
public class ProjectResultsProvider implements IResultProvider
{
	private static final String CLASS = ".class"; //$NON-NLS-1$
	
	private final Collection<File> compileDirs;
	private final ClassLoader classLoader;
	private final IResourceFinder finder;
	private ReadResult readResult;

	/**
	 * Constructs result provider with only one compile dir
	 * @param compileDir
	 * @param classLoader
	 * @throws NullPointerException in case some of parameters is <code>null</code>
	 */
	public ProjectResultsProvider(final File compileDir, final ClassLoader classLoader, final IResourceFinder finder) 
	{
		nullCheckParam(compileDir, "compileDir"); //$NON-NLS-1$
		nullCheckParam(classLoader, "classLoader"); //$NON-NLS-1$
		nullCheckParam(finder, "finder"); //$NON-NLS-1$
		
		this.compileDirs = new ArrayList<File>(1);
		this.compileDirs.add(compileDir);
		this.classLoader = classLoader;
		this.finder = finder;
	}
	
	/**
	 * Constructs result provider with collection of compile dirs
	 * @param compileDirs
	 * @param classLoader
	 * @param finder
	 * @throws NullPointerException in case some of parameters is <code>null</code>
	 */
	public ProjectResultsProvider(final Collection<File> compileDirs, final ClassLoader classLoader, final IResourceFinder finder) 
	{
		nullCheckParam(compileDirs, "compileDirs"); //$NON-NLS-1$
		nullCheckParam(classLoader, "classLoader"); //$NON-NLS-1$
		nullCheckParam(finder, "finder"); //$NON-NLS-1$
		
		this.compileDirs = compileDirs;
		this.classLoader = classLoader;
		this.finder = finder;
	}

	public ReadResult getReadResult() throws ProcessingException  
	{
		if (readResult == null)
		{
			try {
				readResult = createResult();
			} 
			catch (ReadingException e) {
				throw new ProcessingException(e);
			}
		}
		
		return readResult;
	}
	
	public final ClassLoader getClassLoader() {
		return classLoader;
	}

	private ReadResult createResult() throws ReadingException 
	{
		final List<File> classFiles = new ArrayList<File>();
		for (File compileDir : compileDirs) {
			classFiles.addAll(collectClassesInCompileDir(compileDir));
		}

		return parseClasses(classFiles);
	}

	protected ReadResult parseClasses(final List<File> classFiles) throws ReadingException 
	{
		final ReaderFactory factory = new ReaderFactory(null, null, createFinder());		
		return factory.getReader().read(classFiles.toArray(new File[classFiles.size()]));
	}

	private List<File> collectClassesInCompileDir(final File compileDir) 
	{
		final List<File> classFiles = new ArrayList<File>();
		recursivelyCollectClasses(compileDir, classFiles);
		return classFiles;
	}
	
	private void recursivelyCollectClasses(final File file, final List<File> classFiles) 
	{
		if (file.isDirectory()) {
			String[] children = file.list();
			for (int i = 0; i < children.length; i++) {
				recursivelyCollectClasses(new File(file, children[i]), classFiles);
			}
		} else {
			if (file.getAbsolutePath().endsWith(CLASS)) { 
				classFiles.add(file);
			}
		}
	}

	private ClassFinder createFinder() 
	{
		return new ClassFinder() 
		{
			public InputStream getClassAsStream(String arg0) 
			{
				final String classFileName = arg0.replace('.', '/') + CLASS;
				return classLoader.getResourceAsStream(classFileName);
			}			
		};
	}

	public IResourceFinder getResourceFinder() {
		return finder;
	}
}
