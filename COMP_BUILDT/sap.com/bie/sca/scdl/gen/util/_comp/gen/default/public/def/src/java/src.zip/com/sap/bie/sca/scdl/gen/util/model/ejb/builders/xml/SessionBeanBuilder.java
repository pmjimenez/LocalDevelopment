package com.sap.bie.sca.scdl.gen.util.model.ejb.builders.xml;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.nullCheckParam;

import java.text.MessageFormat;

import org.w3c.dom.Element;

import com.sap.bie.sca.scdl.gen.util.model.ModelException;
import com.sap.bie.sca.scdl.gen.util.model.ejb.BeanType;
import com.sap.bie.sca.scdl.gen.util.model.ejb.IBean;
import com.sap.bie.sca.scdl.gen.util.model.ejb.IEjbModule;
import com.sap.bie.sca.scdl.gen.util.model.shared.builders.xml.XmlUtils;

/**
 * Builder for session type beans, creates stateful and stateless beans
 * 
 * @author I036509
 */
public class SessionBeanBuilder extends BeanBuilder
{
	private static final String TYPE_STATELESS = "Stateless"; //$NON-NLS-1$
	private static final String TYPE_STATEFUL = "Stateful"; //$NON-NLS-1$
	private static final String SESSION_TYPE = "session-type";  //$NON-NLS-1$
	
	/**
	 * Constructor
	 * @param annModule
	 * @throws NullPointerException in case <code>annModule</code> is <code>null</code>
	 */
	public SessionBeanBuilder(final IEjbModule annModule) {
		super(annModule);
	}

	/**
	 * Parses <code>beanElement</code> and creates session bean out of it
	 * @param beanElement
	 * @return the created instance - never returns <code>null</code>
	 * @throws ModelException in case some mandatory bean property cannot be defined
	 */
	public IBean parse(final Element beanElement) throws ModelException 
	{
		nullCheckParam(beanElement, "beanElement"); //$NON-NLS-1$
		
		final BeanType annBeanType = isStatefulByAnnotation(defineBeanName(beanElement)); 
		final String sessionType = XmlUtils.getTextContent(XmlUtils.getOptionalSingleChild(beanElement, SESSION_TYPE));
		
		if (TYPE_STATELESS.equals(sessionType)) {
			return createBean(beanElement, BeanType.stateless);
		} else if (TYPE_STATEFUL.equals(sessionType)) {
			return createBean(beanElement, BeanType.stateful);
		} else if (annBeanType == BeanType.stateless || annBeanType == BeanType.stateful) {
			return createBean(beanElement, annBeanType);
		}
		else {			
			throw new ModelException(MessageFormat.format(
									"Invalid session bean type for bean {0} is specified in the ejb-jar.xml.", //$NON-NLS-1$
									defineBeanName(beanElement)));
		}
	}	
	
	private BeanType isStatefulByAnnotation(final String beanName)
	{
		/*
		 * In the EJB 3.0 <session-type> tag of the session beans is optional.
		 * It must be provided either in the deployment descriptor or metadata
		 * annotation.
		 */
		final IBean annotationBean = getAnnModule().getBean(beanName);
		if (annotationBean == null) {
			return BeanType.unknown;
		}

		final BeanType beanType = annotationBean.getBeanType();
		if (beanType == BeanType.stateful || beanType == BeanType.stateless) {
			return beanType;
		}

		return BeanType.unknown;
	}
}
