package com.sap.bie.sca.scdl.gen.util.model.ejb;

import java.util.Collection;

import com.sap.bie.sca.scdl.gen.util.model.shared.IServiceRef;

/**
 * Represents enterprise bean with its WS relevant properties
 * 
 * @author I036509
 */
public interface IBean 
{
    /**
     * @return the name of the bean, never returns <code>null</code>
     */
    public String getBeanName();
    
    /**
     * @return the bean class name, never returns <code>null</code>
     */
    public String getBeanClass();

	/**
	 * @return the type of the bean, never returns <code>null</code>
	 * @see BeanType
	 */
	public BeanType getBeanType();	
	
	/**
	 * Adds reference to the references list 
	 * @param serviceRef
	 * @throws NullPointerException in case <code>serviceRef</code> is <code>null</code>
	 */
	public void addServiceRef(final IServiceRef serviceRef);
	
	/**
	 * @return collection of web service references for this bean, never returns <code>null</code> instead
	 * returns empty collection
	 */
	public Collection<IServiceRef> getServiceRefs();
}
