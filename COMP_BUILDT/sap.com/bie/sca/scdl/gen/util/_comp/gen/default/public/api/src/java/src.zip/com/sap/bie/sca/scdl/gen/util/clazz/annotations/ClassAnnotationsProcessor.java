package com.sap.bie.sca.scdl.gen.util.clazz.annotations;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.nullCheckParam;

import java.util.ArrayList;
import java.util.Collection;

import com.sap.bie.sca.scdl.gen.util.ProcessingException;
import com.sap.bie.sca.scdl.gen.util.clazz.annotations.IClassAnnotationsVisitor.VisitType;
import com.sap.bie.sca.scdl.gen.util.project.IResultProvider;
import com.sap.lib.javalang.element.ClassInfo;
import com.sap.lib.javalang.element.FieldInfo;
import com.sap.lib.javalang.element.MethodInfo;

/**
 * This class traverses through the class members provided visitor to process it.
 *  
 * @author I036509
 */
public class ClassAnnotationsProcessor 
{
	private IResultProvider resultsProvider;
	
	/**
	 * Constructor
	 * 
	 * @param resultsProvider the provider from where the class that will be processed is
	 * taken - this provider is needed only to be supplied to the visitors in case some
	 * additional class processing is needed in the visitor - for example search for another
	 * class.
	 */
	public ClassAnnotationsProcessor(final IResultProvider resultsProvider) 
	{
		nullCheckParam(resultsProvider, "resultsProvider"); //$NON-NLS-1$
		this.resultsProvider = resultsProvider;
	}

	/**
	 * Traverses though class members and calls the relevant visitor method.
	 * @param <E> collection of single annotation processing results
	 * @param clazz - the class to be processed
	 * @param visitor - the visitor to be called for every annotation
	 * @return collection of all processing results 
	 * @throws ProcessingException
	 */
	public <E> Collection<E> collect(final ClassInfo clazz, final IClassAnnotationsVisitor<E> visitor) throws ProcessingException
	{
		final Collection<E> results = new ArrayList<E>();
		
		E result = null;
		
		if (visitor.visits(VisitType.Class)) {
			result = visitor.processClass(clazz, resultsProvider);
			if (result != null) {
				results.add(result);
			}
		}
		
		if (visitor.visits(VisitType.Field)) {
			for (FieldInfo field : clazz.getFields()) {
				result = visitor.processField(field, resultsProvider);
				if (result != null) {
					results.add(result);
				}
			}
		}

		if (visitor.visits(VisitType.Method)) {
			for (MethodInfo method : clazz.getMethods()) {
				result = visitor.processMethod(method, resultsProvider);
				if (result != null) {
					results.add(result);
				}
			}
		}
		
		return results;
	}
}
