package com.sap.bie.sca.scdl.gen.util.model.ejb;

/**
 * Enumeration of possible bean types
 * 
 * @author I036509
 */
public enum BeanType 
{
    /** for stateful session bean */ stateful,
    /** for stateless session bean */ stateless,
    /** for message driven bean */ msg,
    /** unsupported bean type */ unknown
}
