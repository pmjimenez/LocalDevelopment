package com.sap.bie.sca.scdl.gen.util.wsdl;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.nullCheckParam;

import java.text.MessageFormat;

/**
 * Wraps exceptions thrown during WSDL processing
 * 
 * @author I036509
 */
public class WsdlProcessingException extends Exception 
{
	private static final long serialVersionUID = 1L;
	
	private final String wsdlFile;
	
	/**
	 * Constructs exception with {@link Throwable}
	 * @param t
	 */
	public WsdlProcessingException(final String wsdlFile, final Throwable t) {
		super(t);
		
		nullCheckParam(wsdlFile, "wsdlFile"); //$NON-NLS-1$
		this.wsdlFile = wsdlFile;
	}	
	
	public WsdlProcessingException(final String wsdlFile, final String error) 
	{
		super(error);
		nullCheckParam(wsdlFile, "wsdlFile"); //$NON-NLS-1$
		nullCheckParam(error, "error"); //$NON-NLS-1$
		
		this.wsdlFile = wsdlFile;
	}	
	
	@Override
	public String getMessage() {
		return MessageFormat.format("Unable to parse WSDL {0}: {1}", wsdlFile, super.getMessage()); //$NON-NLS-1$
	}
	
	@Override
	public String getLocalizedMessage() {
		return MessageFormat.format("Unable to parse WSDL {0}: {1}", wsdlFile, super.getMessage()); //$NON-NLS-1$
	}	
}
