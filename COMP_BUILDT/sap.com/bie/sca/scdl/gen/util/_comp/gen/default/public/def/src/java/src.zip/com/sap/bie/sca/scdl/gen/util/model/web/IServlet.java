package com.sap.bie.sca.scdl.gen.util.model.web;

import java.util.Collection;

import com.sap.bie.sca.scdl.gen.util.model.shared.IServiceRefContainer;
import com.sap.bie.sca.scdl.gen.util.model.shared.IServiceRef;

public interface IServlet extends IServiceRefContainer
{
	public String getServletName();

	public String getServletClass();
	
	public Collection<IServiceRef> getServiceRefs();
}
