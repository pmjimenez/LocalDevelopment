package com.sap.bie.sca.scdl.gen.util.model;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.nullCheckParam;

import java.io.File;

import com.sap.bie.sca.scdl.gen.util.ProcessingException;
import com.sap.bie.sca.scdl.gen.util.model.ejb.IEjbModule;
import com.sap.bie.sca.scdl.gen.util.model.ejb.builders.ModulesMerger;
import com.sap.bie.sca.scdl.gen.util.model.ejb.builders.annotations.AnnotationModuleBuilder;
import com.sap.bie.sca.scdl.gen.util.model.ejb.builders.xml.XmlModuleBuilder;
import com.sap.bie.sca.scdl.gen.util.project.IResultProvider;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;

/**
 * This class creates consolidated EJB module model by parsing all relevant
 * annotations and deployment descriptors and merging the results from both.
 * 
 * @author I036509
 */
public class EjbModuleFactory implements IModuleFactory<IEjbModule>
{
	private static final String META_INF = "META-INF"; //$NON-NLS-1$
	private static final String EJB_JAR_XML = "ejb-jar.xml"; //$NON-NLS-1$
	private static IModuleFactory<IEjbModule> instance;
	
	private final AnnotationModuleBuilder annModuleBuilder = new AnnotationModuleBuilder();

	private EjbModuleFactory() {
		// singleton
	}
	
	public static IModuleFactory<IEjbModule> getInstance() {
		if (instance == null) {
			instance = new EjbModuleFactory();
		}
		
		return instance;
	}
	
	public IEjbModule createModule(final IPluginBuildInfo pluginBuildInfo, final IResultProvider resultProvider) throws ProcessingException, ModelException
	{
		nullCheckParam(pluginBuildInfo, "pluginBuildInfo"); //$NON-NLS-1$
		nullCheckParam(resultProvider, "resultProvider"); //$NON-NLS-1$

		final IEjbModule annModule = annModuleBuilder.process(resultProvider, pluginBuildInfo.getDCName());
		
		final File ejbJarXmlFile = findEjbJarXmlFile(pluginBuildInfo);
		if (ejbJarXmlFile != null) {
			final IEjbModule xmlModule = createXmlModule(pluginBuildInfo, annModule, ejbJarXmlFile);
			final ModulesMerger merger = new ModulesMerger(resultProvider);
			return merger.merge(annModule, xmlModule);
		}
	
		return annModule;
	}

	private IEjbModule createXmlModule(final IPluginBuildInfo pluginBuildInfo, final IEjbModule annModule, final File ejbJarXmlFile) throws ProcessingException, ModelException {
		final XmlModuleBuilder xmlModuleBuilder = new XmlModuleBuilder(annModule);
		return xmlModuleBuilder.process(ejbJarXmlFile, pluginBuildInfo.getDCName());
	}

	public File findEjbJarXmlFile(final IPluginBuildInfo pluginBuildInfo) 
	{
		for (File packageDir : pluginBuildInfo.getPackageDirsAsFiles()) {
			File ejbJarXmlFile = findEjbJarXmlFile(packageDir);
			if (ejbJarXmlFile != null) {
				return ejbJarXmlFile;
			}
		}
		
		return null;
	}
	
	private File findEjbJarXmlFile(final File packageDir)
	{
		final File metaInf = findFile(packageDir, META_INF, true);
		if (metaInf == null) {
			return null;
		}
		
		return findFile(metaInf, EJB_JAR_XML, false);
	}

	private File findFile(final File sourceDir, final String name, boolean isDirectory) 
	{
		for (File file : sourceDir.listFiles()) {
			if (name.equals(file.getName())) {
				if (isDirectory && file.isDirectory()) {
					return file;
				}
				
				if (!isDirectory && file.isFile()) {
					return file;
				}
			}
		}
		
		return null;
	}	
}
