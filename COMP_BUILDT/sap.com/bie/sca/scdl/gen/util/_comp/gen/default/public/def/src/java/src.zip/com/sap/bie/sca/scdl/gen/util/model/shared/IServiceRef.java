package com.sap.bie.sca.scdl.gen.util.model.shared;

/**
 * Represents web service reference 
 * 
 * @author I036509
 */
public interface IServiceRef 
{
	/**
	 * @return the service reference name, never returns <code>null</code>, might be empty string
	 */
	public String getName();
	
	/**
	 * @return the wsdlLocation for this reference, might be <code>null</code>
	 */
	public String getWsdlLocation();
	
	/**
	 * Updates the wsdlLocation
	 * @param wsdlLocation - might be <code>null</code>
	 */
	public void setWsdlLocation(final String wsdlLocation);
	
	/**
	 * @return the service class fully qualified name for this reference, never returns <code>null</code> or
	 * empty string
	 */
	public String getServiceInterface();
	
	/**
	 * @return the end-point class fully qualified name, might be <code>null</code>
	 */
	public String getServiceRefType();
}
