package com.sap.bie.sca.scdl.gen.util.project;

import com.sap.bie.sca.scdl.gen.util.ProcessingException;
import com.sap.lib.javalang.tool.ReadResult;

public interface IResultProvider 
{
	public ReadResult getReadResult() throws ProcessingException;
	public ClassLoader getClassLoader(); 
	public IResourceFinder getResourceFinder(); 
}
