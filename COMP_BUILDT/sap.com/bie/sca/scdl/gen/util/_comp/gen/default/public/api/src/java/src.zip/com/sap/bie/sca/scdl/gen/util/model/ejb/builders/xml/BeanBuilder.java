package com.sap.bie.sca.scdl.gen.util.model.ejb.builders.xml;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.nullCheckParam;

import java.text.MessageFormat;

import org.w3c.dom.Element;

import com.sap.bie.sca.scdl.gen.util.model.ModelException;
import com.sap.bie.sca.scdl.gen.util.model.ejb.BeanType;
import com.sap.bie.sca.scdl.gen.util.model.ejb.IBean;
import com.sap.bie.sca.scdl.gen.util.model.ejb.IEjbModule;
import com.sap.bie.sca.scdl.gen.util.model.ejb.impl.Bean;
import com.sap.bie.sca.scdl.gen.util.model.shared.builders.xml.ServiceRefBuilder;
import com.sap.bie.sca.scdl.gen.util.model.shared.builders.xml.XmlUtils;

/**
 * Base class for bean builders. Contains reusable logic for all bean types
 * 
 * @author I036509
 */
public class BeanBuilder 
{
	private static final String EJB_NAME = "ejb-name"; //$NON-NLS-1$
	private static final String EJB_CLASS = "ejb-class"; //$NON-NLS-1$
	private static final String SERVICE_REF = "service-ref"; //$NON-NLS-1$
	
	private final IEjbModule annModule;
	
	/**
	 * Constructor
	 * @param annModule - the created from annotations EJB module
	 */
	public BeanBuilder(final IEjbModule annModule) {
		nullCheckParam(annModule, "annModule"); //$NON-NLS-1$
		this.annModule = annModule;
	}

	protected Bean createBean(final Element beanElement, final BeanType beanType) throws ModelException 
	{
		nullCheckParam(beanElement, "beanElement"); //$NON-NLS-1$
		nullCheckParam(beanType, "beanType"); //$NON-NLS-1$
		
		final String beanName = defineBeanName(beanElement);
		final String beanClass = defineBeanClass(beanElement, beanName);
		final Bean bean = new Bean(beanName, beanClass, beanType);
		
		addServiceRefs(beanElement, bean);
		
		return bean;
	}
	
	protected String defineBeanName(final Element beanElement) throws ModelException {
		return XmlUtils.getTextContent(XmlUtils.getMandatorySingleChild(beanElement, EJB_NAME));
	}
	
	protected String defineBeanClass(final Element beanElement, final String beanName) throws ModelException 
	{
		final String beanClass = XmlUtils.getTextContent(XmlUtils.getOptionalSingleChild(beanElement, EJB_CLASS));        
        if (beanClass != null) {
			if (beanClass.trim().length() == 0) {
				final String message = "Incorrect ''{0}'' value for bean {1} in ejb-jar.xml"; //$NON-NLS-1$
				throw new ModelException(MessageFormat.format(message, EJB_CLASS, beanName));
			}
			return beanClass;
		}
        
        // Bean class name is optional in the related XML element, so will try to find it defined in annotation
        final IBean annBean = annModule.getBean(beanName);
        if (annBean == null) {
        	final String message = "Bean class for bean with name {0} is not defined in annotation or in ejb-jar.xml"; //$NON-NLS-1$
        	throw new ModelException(MessageFormat.format(message, beanName));
        }
        
        return annBean.getBeanClass();
	}

	protected void addServiceRefs(final Element beanElement, final Bean bean) throws ModelException 
	{
		final ServiceRefBuilder srBuilder = new ServiceRefBuilder();
		for (Element serviceRefElement : XmlUtils.getChildrenByTagName(beanElement, SERVICE_REF)) {
			bean.addServiceRef(srBuilder.parse(serviceRefElement));
		}
	}
	
	protected IEjbModule getAnnModule() {
		return annModule;
	}
}
