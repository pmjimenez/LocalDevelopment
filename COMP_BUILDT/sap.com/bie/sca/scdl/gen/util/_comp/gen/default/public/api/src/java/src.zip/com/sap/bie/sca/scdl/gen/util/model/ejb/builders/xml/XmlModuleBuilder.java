package com.sap.bie.sca.scdl.gen.util.model.ejb.builders.xml;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.emptyStringCheckParam;
import static com.sap.bie.sca.scdl.gen.util.ParamChecker.nullCheckParam;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import com.sap.bie.sca.scdl.gen.util.ProcessingException;
import com.sap.bie.sca.scdl.gen.util.model.ModelException;
import com.sap.bie.sca.scdl.gen.util.model.ejb.IEjbModule;
import com.sap.bie.sca.scdl.gen.util.model.ejb.ModuleVersion;
import com.sap.bie.sca.scdl.gen.util.model.ejb.impl.Module;
import com.sap.bie.sca.scdl.gen.util.model.shared.builders.xml.XmlUtils;

/**
 * Builder for {@link IEjbModule} derived from deployment descriptor
 * 
 * @author I036509
 */
public class XmlModuleBuilder 
{	
	private static final String VERSION_3_0 = "3.0"; //$NON-NLS-1$
	private static final String VERSION_2_1 = "2.1"; //$NON-NLS-1$
	private static final String VERSION = "version"; //$NON-NLS-1$
	private static final String MESSAGE_DRIVEN = "message-driven"; //$NON-NLS-1$
	private static final String SESSION = "session"; //$NON-NLS-1$
	private static final String ENTERPRISE_BEANS = "enterprise-beans"; //$NON-NLS-1$
	
	private final SessionBeanBuilder sessBeanBuilder; 
	private final MessageBeanBuilder msgBeanBuilder; 
	
	/**
	 * Constructor
	 * @param annModule
	 * @throws NullPointerException in case <code>annModule</code> is <code>null</code>
	 */
	public XmlModuleBuilder(final IEjbModule annModule) {
		nullCheckParam(annModule, "annModule"); //$NON-NLS-1$
		sessBeanBuilder = new SessionBeanBuilder(annModule);
		msgBeanBuilder = new MessageBeanBuilder(annModule);
	}

	/**
	 * Parsers <code>ejbJarXmlFile</code> and creates EJB module out of it
	 * @param ejbJarXmlFile
	 * @param moduleName
	 * @return created module - never returns <code>null</code>
	 * @throws ProcessingException in case of {@link IOException} or parser exception 
	 * @throws ModelException in case some mandatory element is missing
	 */
	public IEjbModule process(final File ejbJarXmlFile, final String moduleName) throws ProcessingException, ModelException 
	{
		nullCheckParam(ejbJarXmlFile, "ejbJarXmlSource"); //$NON-NLS-1$
		emptyStringCheckParam(moduleName, "moduleName"); //$NON-NLS-1$
		
		Document document;
		try {
			document = parseXmlSource(ejbJarXmlFile);
		} catch (ParserConfigurationException e) {
			throw new ProcessingException(e);
		} catch (SAXException e) {
			throw new ProcessingException(e);
		} catch (IOException e) {
			throw new ProcessingException(e);
		}
		
		return process(document.getDocumentElement(), moduleName);
	}

	private Module process(Element ejbJarElement, final String moduleName) throws ModelException 
	{
		final Module module = new Module(moduleName, defineEjbVersion(ejbJarElement));

		final Element enterpriseBeans = XmlUtils.getOptionalSingleChild(ejbJarElement, ENTERPRISE_BEANS);
		if (enterpriseBeans != null) {
			processEnterpriseBeans(enterpriseBeans, module);
		}
		
		return module;
	}

	private void processEnterpriseBeans(final Element enterpriseBeansElement, final Module module) throws ModelException 
	{
		
		for (Element sessBeanElement : XmlUtils.getChildrenByTagName(enterpriseBeansElement, SESSION)) {
			module.addBean(sessBeanBuilder.parse(sessBeanElement));
		}
		
		for (Element messageBeanElement : XmlUtils.getChildrenByTagName(enterpriseBeansElement, MESSAGE_DRIVEN)) {
			module.addBean(msgBeanBuilder.parse(messageBeanElement));
		}
	}
	
    private ModuleVersion defineEjbVersion(final Element ejbJarElement) throws ModelException 
    {
		final String ejbVersion = XmlUtils.getElementAttribute(ejbJarElement, VERSION);
		if (ejbVersion == null) {
			throw new ModelException("Version attribute of ejb-jar root tag in the ejb-jar.xml is not defined. It is mandatory accorging to ejb-jar scheme."); //$NON-NLS-1$
		}
		
		if (ejbVersion.equals(VERSION_2_1)) {
			return ModuleVersion.version_2_1_or_lower;
		} else if (ejbVersion.equals(VERSION_3_0)) {
			return ModuleVersion.version_3_0;
		}
		
		throw new ModelException("Unsupported version defined in ejb-jar.xml"); //$NON-NLS-1$
	}
    
	private Document parseXmlSource(final File ejbJarXmlFile) throws ParserConfigurationException, SAXException, IOException 
	{
		final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setIgnoringComments(true);
		factory.setIgnoringElementContentWhitespace(true);
		factory.setNamespaceAware(true);

		final DocumentBuilder docBuilder = factory.newDocumentBuilder();
		return docBuilder.parse(ejbJarXmlFile);
	}
}
