package com.sap.bie.sca.scdl.gen.util;

public class ProcessingException extends Exception {

	private static final long serialVersionUID = 1L;

	public ProcessingException(Throwable t) {
		super(t);
	}
	
	public ProcessingException(String message) {
		super(message);
	}
}
