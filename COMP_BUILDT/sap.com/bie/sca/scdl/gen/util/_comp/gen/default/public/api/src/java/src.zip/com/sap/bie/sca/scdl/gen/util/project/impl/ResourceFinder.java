package com.sap.bie.sca.scdl.gen.util.project.impl;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.*;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.HashSet;
import java.util.Set;

import com.sap.bie.sca.scdl.gen.util.project.IResourceFinder;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;

public class ResourceFinder implements IResourceFinder 
{
	// this folders will be added without traversing their subtrees
	private static final Set<String> skippedDirs = new HashSet<String>();
	
	static {
		skippedDirs.add("META-INF"); //$NON-NLS-1$
		skippedDirs.add("WEB-INF"); //$NON-NLS-1$
	}
	
	private final URLClassLoader urlClassLoader;
	public ResourceFinder(final IPluginBuildInfo pluginBuildInfo) throws MalformedURLException 
	{
		nullCheckParam(pluginBuildInfo, "pluginBuildInfo"); //$NON-NLS-1$
		
		final Set<File> dirs = new HashSet<File>();
		for (File packDir : pluginBuildInfo.getPackageDirsAsFiles()) {
			addFolders(dirs, packDir);
		}
		
		for (File packDir : pluginBuildInfo.getSourceDirsAsFiles()) {
			addFolders(dirs, packDir);
		}
		
		final URL [] urls = new URL[dirs.size()];
		int i=0;
		for(File dir: dirs) {
			urls[i++] = dir.toURI().toURL();
		}
		urlClassLoader = new URLClassLoader(urls);
	}

	public URL findResource(final String name) {
		emptyStringCheckParam(name, "name"); //$NON-NLS-1$
		if (name.charAt(0) == '/' || name.charAt(0) == '\\') {
			return urlClassLoader.getResource(name.substring(1)); 
		}
		
		return urlClassLoader.getResource(name);
	}
	
	private void addFolders(final Set<File> result, final File dir) {
		if (dir == null || skippedDirs.contains(dir.getName())) {
			return;
		}

		for (File file : dir.listFiles()) {
			if (file.isDirectory()) {
				addFolders(result, file);
			}
		}	
		result.add(dir);
	}

}
 