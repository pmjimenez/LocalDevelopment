package com.sap.bie.sca.scdl.gen.util.model.ejb.builders.xml;

import org.w3c.dom.Element;

import com.sap.bie.sca.scdl.gen.util.model.ModelException;
import com.sap.bie.sca.scdl.gen.util.model.ejb.BeanType;
import com.sap.bie.sca.scdl.gen.util.model.ejb.IBean;
import com.sap.bie.sca.scdl.gen.util.model.ejb.IEjbModule;

/**
 * Builder for message beans
 * 
 * @author I036509
 */
public class MessageBeanBuilder extends BeanBuilder
{
	/**
	 * Constructor
	 * @param annModule
	 * @throws NullPointerException in case <code>annModule</code> is null
	 */
	public MessageBeanBuilder(final IEjbModule annModule) {
		super(annModule);
	}

	/**
	 * Parses the element and creates bean with beanType {@link BeanType#msg}
	 * @param beanElement
	 * @return created bean - always returns non null instance
	 * @throws ModelException in case some bean property is mandatory but cannot be defined
	 * @throws NullPointerException in case <code>beanElement</code> is <code>null</code>
	 */
	public IBean parse(final Element beanElement) throws ModelException {
		return createBean(beanElement, BeanType.msg);
	}
}
