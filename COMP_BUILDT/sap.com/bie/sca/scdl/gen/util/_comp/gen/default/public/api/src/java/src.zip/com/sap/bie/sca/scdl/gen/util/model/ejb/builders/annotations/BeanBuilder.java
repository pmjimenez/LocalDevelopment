package com.sap.bie.sca.scdl.gen.util.model.ejb.builders.annotations;

import com.sap.bie.sca.scdl.gen.util.ProcessingException;
import com.sap.bie.sca.scdl.gen.util.model.ModelException;
import com.sap.bie.sca.scdl.gen.util.model.ejb.BeanType;
import com.sap.bie.sca.scdl.gen.util.model.ejb.IBean;
import com.sap.bie.sca.scdl.gen.util.model.ejb.impl.Bean;
import com.sap.bie.sca.scdl.gen.util.model.shared.IServiceRef;
import com.sap.bie.sca.scdl.gen.util.model.shared.builders.annotations.ServiceReferencesBuilder;
import com.sap.bie.sca.scdl.gen.util.project.IResultProvider;
import com.sap.lib.javalang.annotation.AnnotationRecord;
import com.sap.lib.javalang.annotation.AnnotationRecord.NamedMember;
import com.sap.lib.javalang.element.ClassInfo;

public class BeanBuilder 
{
	public static final String NAME = "name"; //$NON-NLS-1$

	public IBean process(final AnnotationRecord annotation, final BeanType beanType, final IResultProvider resultProvider) throws ProcessingException, ModelException 
	{
		final String name = defineEjbName(annotation);
		final String className = annotation.getOwner().getName();
		final Bean bean = new Bean(name, className, beanType);
		
		addServiceRefs(bean, (ClassInfo)annotation.getOwner(), resultProvider);
		
		return bean;
	}
	
	private void addServiceRefs(final Bean bean, final ClassInfo clazz, final IResultProvider resultProvider) throws ProcessingException, ModelException 
	{
		final ServiceReferencesBuilder wsRefsBuilder = new ServiceReferencesBuilder();
		for (IServiceRef serviceRef : wsRefsBuilder.process(clazz, resultProvider)) {
			bean.addServiceRef(serviceRef);
		}
	}
	
	private String defineEjbName(final AnnotationRecord annotation) 
	{
		final NamedMember nameAttribute = annotation.getMember(NAME); 
		if (nameAttribute != null) {
			final String nameValue = nameAttribute.getStringValue();
			if (nameValue != null && nameValue.trim().length() > 0) {
				return nameValue;
			}
		}

		return toClassName(annotation.getOwner().getName());
	}
	
	private String toClassName(final String fqName) {
		final int pos = fqName.lastIndexOf('.');
		if (pos == -1) {
			return fqName;
		}
		
		return fqName.substring(pos + 1);		
	}
	

}
