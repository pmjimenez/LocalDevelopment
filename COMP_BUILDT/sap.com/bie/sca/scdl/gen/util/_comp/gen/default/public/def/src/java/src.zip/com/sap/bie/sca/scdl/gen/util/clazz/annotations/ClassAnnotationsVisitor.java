package com.sap.bie.sca.scdl.gen.util.clazz.annotations;

import com.sap.bie.sca.scdl.gen.util.ProcessingException;
import com.sap.bie.sca.scdl.gen.util.project.IResultProvider;
import com.sap.lib.javalang.element.ClassInfo;
import com.sap.lib.javalang.element.FieldInfo;
import com.sap.lib.javalang.element.MethodInfo;

/**
 * Default Implementation of {@link IClassAnnotationsVisitor}. Useful in case your visitor
 * does not need to implement all processing variants but only some of them - in this case
 * just overwrite the relevant method(s) and specify which is the supported case(s) by
 * overwriting {@link ClassAnnotationsVisitor#visits(VisitType)} method.
 * 
 * @author I036509
 *
 * @param <E>
 */
public class ClassAnnotationsVisitor<E> implements IClassAnnotationsVisitor<E>
{
	public E processClass(ClassInfo clazz, IResultProvider resultProvider) throws ProcessingException {
		return null;
	}

	public E processField(FieldInfo field, IResultProvider resultProvider) throws ProcessingException {
		return null;
	}

	public E processMethod(MethodInfo method, IResultProvider resultProvider) throws ProcessingException {
		return null;
	}

	public boolean visits(final VisitType type) {
		return true;
	}
}
