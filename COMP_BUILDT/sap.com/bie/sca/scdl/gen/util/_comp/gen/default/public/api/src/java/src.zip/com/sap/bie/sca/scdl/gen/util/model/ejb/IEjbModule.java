package com.sap.bie.sca.scdl.gen.util.model.ejb;

import java.util.Collection;

/**
 * Represents EJB module with its WS related properties
 * 
 * @author I036509
 */
public interface IEjbModule 
{
	/**
	 * @return the module name, never returns <code>null</code>
	 */
	public String getName();
	
	/**
	 * @return the module version, never returns <code>null</code>
	 */
	public ModuleVersion getVersion();
	
	/**
	 * @return collection of beans in this module, never returns <code>null</code> instead returns empty
	 * collection
	 */
	public Collection<IBean> getBeans();
	
	/**
	 * Finds bean with name <code>beanName</code>
	 * @param beanName
	 * @return found bean or <code>null</code>
	 * @throws NullPointerException in case <code>beanName</code> is <code>null</code>
	 * @throws IllegalArgumentException in case <code>beanName</code> is empty string
	 */
	public IBean getBean(final String beanName);
}
