package com.sap.bie.sca.scdl.gen.util.project;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;

import com.sap.bie.sca.scdl.gen.util.project.impl.ProjectClassLoader;
import com.sap.bie.sca.scdl.gen.util.project.impl.ProjectResultsProvider;
import com.sap.bie.sca.scdl.gen.util.project.impl.ResourceFinder;
import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;

/**
 * Factory that creates utilities needed during SCDL generation 
 * 
 * @author I036509
 */
public class ProjectUtilsFactory 
{
	private static ProjectUtilsFactory instance;
	
	public static ProjectUtilsFactory getInstance() 
	{
		if (instance == null) {
			instance = new ProjectUtilsFactory();
		}
		
		return instance;
	}
	
	/**
	 * Creates {@link ClassLoader} for DC project by collecting all public parts that are referenced for 
	 * compilation and the compile directory provided in URL array and creates {@link URLClassLoader} instance
	 * @param compileDir
	 * @param globalPluginUtil
	 * @param pluginBuildInfo
	 * @return created class loader
	 * @throws MalformedURLException
	 */
	public ClassLoader createClassLoader(final File compileDir, final IGlobalPluginUtil globalPluginUtil, final IPluginBuildInfo pluginBuildInfo) throws MalformedURLException	
	{
		return new ProjectClassLoader(compileDir, globalPluginUtil, pluginBuildInfo);
	}	
	
	/**
	 * Creates {@link IResultProvider} using the supplied compile folder, classLoader and finder
	 * @param compileDir
	 * @param classLoader
	 * @param finder
	 * @return
	 */
	public IResultProvider createResultProvider(final File compileDir, final ClassLoader classLoader, final IResourceFinder finder) {
		return new ProjectResultsProvider(compileDir, classLoader, finder);
	}
	
	/**
	 * Creates {@link IResultProvider} using the supplied compile folder
	 * @param compileDir
	 * @param globalPluginUtil
	 * @param pluginBuildInfo
	 * @return
	 * @throws MalformedURLException
	 * @throws {@link NullPointerException} in case some of parameters is <code>null</code>
	 */
	public IResultProvider create(final File compileDir, final IGlobalPluginUtil globalPluginUtil, final IPluginBuildInfo pluginBuildInfo) throws MalformedURLException 
	{
		final ClassLoader classLoader = createClassLoader(compileDir, globalPluginUtil, pluginBuildInfo);
		final IResourceFinder finder = new ResourceFinder(pluginBuildInfo);
		return new ProjectResultsProvider(compileDir, classLoader, finder);
	}
	
	/**
	 * Creates {@link IResultProvider} using the compile directories found by calling {@link IGlobalPluginUtil#getGeneratorOutputFolders(String, String)}
	 * with parameters "sap.com~javac", "default". In case no directories are found the result is created with empty collection
	 * of output directories
	 * @param globalPluginUtil
	 * @param pluginBuildInfo
	 * @return the created result provider
	 * @throws MalformedURLException
	 */
	public IResultProvider create(final IGlobalPluginUtil globalPluginUtil, final IPluginBuildInfo pluginBuildInfo) throws MalformedURLException 
	{
		final List<String> outFolderLocations = globalPluginUtil.getGeneratorTypeOutputFolders("sap.com~javac", "default"); //$NON-NLS-1$ //$NON-NLS-2$
		final List<File> outFolders = new ArrayList<File>(outFolderLocations.size());
		for (String outFolder: outFolderLocations) {
			outFolders.add(new File(outFolder));
		}
		
		final ClassLoader classLoader = new ProjectClassLoader(outFolders, globalPluginUtil, pluginBuildInfo);
		final IResourceFinder finder = new ResourceFinder(pluginBuildInfo);
		return new ProjectResultsProvider(outFolders, classLoader, finder);
	}
}
