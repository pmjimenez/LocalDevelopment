package com.sap.bie.sca.scdl.gen.util.model.ejb.impl;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.sap.bie.sca.scdl.gen.util.model.ejb.BeanType;
import com.sap.bie.sca.scdl.gen.util.model.ejb.IBean;
import com.sap.bie.sca.scdl.gen.util.model.shared.IServiceRef;

/**
 * Default implementation of {@link IBean} interface
 * 
 * @author I036509
 */
public class Bean implements IBean 
{
	private final String name;
	private final String beanClass;
	private final BeanType type;
	private final List<IServiceRef> serviceRefs = new ArrayList<IServiceRef>();
	
	/**
	 * Constructor
	 * @param beanName
	 * @param beanClass
	 * @param beanType
	 * @throws NullPointerException in case some of parameters is <code>null</code>
	 * @throws IllegalArgumentException in case some of string parameters is empty string
	 */
	public Bean(final String beanName, final String beanClass, final BeanType beanType) 
	{
		emptyStringCheckParam(beanName, "beanName"); //$NON-NLS-1$
		emptyStringCheckParam(beanClass, "beanClass"); //$NON-NLS-1$
		nullCheckParam(beanType, "beanType"); //$NON-NLS-1$
		if (beanType == BeanType.unknown) {
			throw new IllegalArgumentException("Bean type should be of known type"); //$NON-NLS-1$
		}
		
		this.name = beanName;
		this.beanClass = beanClass;
		this.type = beanType;
	}
	
	@Override
	public String getBeanClass() {
		return beanClass;
	}

	@Override
	public String getBeanName() {
		return name;
	}

	@Override
	public BeanType getBeanType() {
		return type;
	}	

	public void addServiceRef(final IServiceRef serviceRef) {
		nullCheckParam(serviceRef, "serviceRef"); //$NON-NLS-1$
		serviceRefs.add(serviceRef);
	}

	@Override
	public Collection<IServiceRef> getServiceRefs() {
		return serviceRefs;
	}
}
