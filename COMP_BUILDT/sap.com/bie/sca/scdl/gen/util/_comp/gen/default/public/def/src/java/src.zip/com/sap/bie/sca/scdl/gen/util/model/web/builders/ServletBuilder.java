package com.sap.bie.sca.scdl.gen.util.model.web.builders;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.nullCheckParam;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Element;

import com.sap.bie.sca.scdl.gen.util.ProcessingException;
import com.sap.bie.sca.scdl.gen.util.model.ModelException;
import com.sap.bie.sca.scdl.gen.util.model.shared.IServiceRef;
import com.sap.bie.sca.scdl.gen.util.model.shared.builders.ServiceRefsMerger;
import com.sap.bie.sca.scdl.gen.util.model.shared.builders.annotations.ServiceReferencesBuilder;
import com.sap.bie.sca.scdl.gen.util.model.shared.builders.xml.XmlUtils;
import com.sap.bie.sca.scdl.gen.util.model.web.IServlet;
import com.sap.bie.sca.scdl.gen.util.model.web.impl.Servlet;
import com.sap.bie.sca.scdl.gen.util.project.IResultProvider;
import com.sap.lib.javalang.element.ClassInfo;

public class ServletBuilder 
{
	private static final String SERVLET_CLASS = "servlet-class"; //$NON-NLS-1$
	private static final String SERVLET_NAME = "servlet-name"; //$NON-NLS-1$
	
	private final ServiceRefsMerger serviceRefMerger = new ServiceRefsMerger();
	private final IResultProvider resultProvider;
	
	/**
	 * Constructor
	 * @param resultProvider
	 * @throws NullPointerException in case <code>resultProvider</code> is <code>null</code>
	 */
	public ServletBuilder(final IResultProvider resultProvider) {
		nullCheckParam(resultProvider, "resultProvider"); //$NON-NLS-1$
		this.resultProvider = resultProvider;
	}

	public IServlet process(final Element servletElement, final List<IServiceRef> xmlServiceRefs) throws ModelException, ProcessingException 
	{
		final Servlet servlet = new Servlet(getServletName(servletElement), getServletClass(servletElement));

		final List<IServiceRef> annServiceRefs = collectAnnotationServiceRefs(servlet);
		for (IServiceRef serviceRef : serviceRefMerger.merge(annServiceRefs, xmlServiceRefs)) {
			servlet.addServiceRef(serviceRef);
		}
		
		return servlet;
	}

	
	private List<IServiceRef> collectAnnotationServiceRefs(final IServlet servlet) throws ModelException, ProcessingException 
	{
		final ClassInfo implClass = resultProvider.getReadResult().getClass(servlet.getServletClass());
		if (implClass== null) {
			final String message = "Servlet with name ''{0}'' is declared to be implemented by ''{1}'' but such class does not exists"; //$NON-NLS-1$
			throw new ModelException(MessageFormat.format(message, servlet.getServletName(), servlet.getServletClass()));
		}
		
		final List<IServiceRef> refs = new ArrayList<IServiceRef>();		
		final ServiceReferencesBuilder refBuilder = new ServiceReferencesBuilder();
		for (IServiceRef serviceRef : refBuilder.process(implClass, resultProvider)) {
			refs.add(serviceRef);
		}		
		
		return refs;
	}

	private String getServletClass(final Element servletElement) throws ModelException {
		return XmlUtils.getTextContent(XmlUtils.getMandatorySingleChild(servletElement, SERVLET_CLASS));
	}

	private String getServletName(final Element servletElement) throws ModelException {
		return XmlUtils.getTextContent(XmlUtils.getMandatorySingleChild(servletElement, SERVLET_NAME));
	}	
}
