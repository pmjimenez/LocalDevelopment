package com.sap.bie.sca.scdl.gen.util.model.shared.impl;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.nullCheckParam;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.sap.bie.sca.scdl.gen.util.model.shared.IServiceRef;
import com.sap.bie.sca.scdl.gen.util.model.shared.IServiceRefContainer;

public class ServiceRefContainer implements IServiceRefContainer
{
	private final List<IServiceRef> serviceRefs = new ArrayList<IServiceRef>();
	
	/**
	 * Adds reference to the references list 
	 * @param serviceRef
	 * @throws NullPointerException in case <code>serviceRef</code> is <code>null</code>
	 */
	public void addServiceRef(final IServiceRef serviceRef) {
		nullCheckParam(serviceRef, "serviceRef"); //$NON-NLS-1$
		serviceRefs.add(serviceRef);
	}

	@Override
	public Collection<IServiceRef> getServiceRefs() {
		return serviceRefs;
	}
}
