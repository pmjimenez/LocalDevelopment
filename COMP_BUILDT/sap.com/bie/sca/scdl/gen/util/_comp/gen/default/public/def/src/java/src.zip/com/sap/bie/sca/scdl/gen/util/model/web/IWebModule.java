package com.sap.bie.sca.scdl.gen.util.model.web;

import java.util.Collection;


public interface IWebModule 
{
	public String getName();
	
	public Collection<IServlet> getServlets();
}
