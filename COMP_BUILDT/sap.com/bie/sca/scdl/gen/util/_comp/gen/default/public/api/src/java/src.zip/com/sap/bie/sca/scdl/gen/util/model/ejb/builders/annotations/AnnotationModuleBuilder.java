package com.sap.bie.sca.scdl.gen.util.model.ejb.builders.annotations;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.emptyStringCheckParam;
import static com.sap.bie.sca.scdl.gen.util.ParamChecker.nullCheckParam;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import com.sap.bie.sca.scdl.gen.util.ProcessingException;
import com.sap.bie.sca.scdl.gen.util.model.ModelException;
import com.sap.bie.sca.scdl.gen.util.model.ejb.BeanType;
import com.sap.bie.sca.scdl.gen.util.model.ejb.IEjbModule;
import com.sap.bie.sca.scdl.gen.util.model.ejb.ModuleVersion;
import com.sap.bie.sca.scdl.gen.util.model.ejb.impl.Module;
import com.sap.bie.sca.scdl.gen.util.project.IResultProvider;
import com.sap.lib.javalang.annotation.AnnotationRecord;
import com.sap.lib.javalang.element.ClassInfo;

/**
 * Builder for {@link IEjbModule} created out of annotations
 * 
 * @author I036509
 */
public class AnnotationModuleBuilder 
{
    public static final String STATELESS = "javax.ejb.Stateless"; //$NON-NLS-1$
    public static final String STATEFUL = "javax.ejb.Stateful"; //$NON-NLS-1$
    public static final String MESSAGE_DRIVEN = "javax.ejb.MessageDriven";  //$NON-NLS-1$
    
	private final BeanBuilder beanBuilder = new BeanBuilder();
	
	/**
	 * Creates {@link IEjbModule} out of annotations. The module version is always 3.0.
	 * Searches classes for bean related annotations and fills the module's bean list
	 * @param resultProvider
	 * @param moduleName
	 * @return created module - never returns <code>null</code>
	 * @throws ProcessingException in case some class processing error occurs
	 * @throws ModelException in case of inconsistent model data
	 */
	public IEjbModule process(final IResultProvider resultProvider, final String moduleName) throws ProcessingException, ModelException 
	{
		nullCheckParam(resultProvider, "resultProvider"); //$NON-NLS-1$
		emptyStringCheckParam(moduleName, "moduleName"); //$NON-NLS-1$
		
		final Module module = new Module(moduleName, ModuleVersion.version_3_0);
		addBeans(module, resultProvider);
		return module;
	}
	
	private void addBeans(final Module module, final IResultProvider resultProvider) throws ProcessingException, ModelException 
	{
		final List<ClassInfo> classes = new ArrayList<ClassInfo>(resultProvider.getReadResult().getClasses().values());
		
		AnnotationRecord annotation = null;
		for (ClassInfo clazz : classes) 
		{
			if (combinesAnnotations(clazz)) {
				throw new ModelException(
						MessageFormat.format("Class {0} contains more than one bean annotation", clazz.getName())); //$NON-NLS-1$
			}
			
			annotation = clazz.getAnnotation(STATELESS);
			if (annotation != null) {
				module.addBean(beanBuilder.process(annotation, BeanType.stateless, resultProvider));
				continue;
			}
			
			annotation = clazz.getAnnotation(STATEFUL);
			if (annotation != null) {
				module.addBean(beanBuilder.process(annotation, BeanType.stateful, resultProvider));
				continue;
			}
			
			annotation = clazz.getAnnotation(MESSAGE_DRIVEN);
			if (annotation != null) {
				module.addBean(beanBuilder.process(annotation, BeanType.msg, resultProvider));
				continue;
			}
		}
	}

	
	private boolean combinesAnnotations(ClassInfo clazz) 
	{		
		int count = 0;
		if (clazz.getAnnotation(STATELESS) != null) {
			count++;
		}
		
		if (clazz.getAnnotation(STATEFUL) != null) {
			count++;
		}
		
		if (clazz.getAnnotation(MESSAGE_DRIVEN) != null) {
			count++;
		}
		
		return count > 1;
	}
	
}
