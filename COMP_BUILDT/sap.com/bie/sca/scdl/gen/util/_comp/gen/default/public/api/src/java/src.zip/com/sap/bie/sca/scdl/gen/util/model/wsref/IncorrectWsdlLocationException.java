package com.sap.bie.sca.scdl.gen.util.model.wsref;

import com.sap.bie.sca.scdl.gen.util.model.ModelException;

public class IncorrectWsdlLocationException extends ModelException 
{
	private static final long serialVersionUID = 1L;

	public IncorrectWsdlLocationException(final String message) {
		super(message);
	}
}
