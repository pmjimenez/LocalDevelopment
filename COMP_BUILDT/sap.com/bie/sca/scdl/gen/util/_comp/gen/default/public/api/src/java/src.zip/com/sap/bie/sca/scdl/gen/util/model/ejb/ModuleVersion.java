package com.sap.bie.sca.scdl.gen.util.model.ejb;

/**
 * Enumeration of posible module versions
 * 
 * @author I036509
 */
public enum ModuleVersion {
	version_3_0,
	version_2_1_or_lower
}
