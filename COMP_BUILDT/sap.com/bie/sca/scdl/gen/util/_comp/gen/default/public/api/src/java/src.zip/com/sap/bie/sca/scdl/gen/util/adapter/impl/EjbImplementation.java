package com.sap.bie.sca.scdl.gen.util.adapter.impl;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.emptyStringCheckParam;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.IAttributeValue;
import com.sap.bie.sca.scdl.adapter.ICustomScdlAttribute;
import com.sap.bie.sca.scdl.adapter.impl.AttributeValue;
import com.sap.bie.sca.scdl.adapter.impl.CustomScdlAttribute;
import com.sap.bie.sca.scdl.adapter.impl.CustomScdlElement;
import com.sap.bie.sca.scdl.adapter.impl.Implementation;

/**
 * Implementation of {@link IScaCustomScdlElement} for EJB case
 * 
 * @author I036509
 */
public class EjbImplementation extends Implementation
{
	private static final String EJB_LINK = "ejb-link"; //$NON-NLS-1$
	private static final String IMPLEMENTATION_EJB = "ejb"; //$NON-NLS-1$

	public EjbImplementation(String jarName, String beanName) {
		super(IMPLEMENTATION_EJB);
		
		setEjbLink(jarName, beanName);
		
		CustomScdlElement ejbImpl = new CustomScdlElement(getName());
		
		for(ICustomScdlAttribute attrib : getCustomAttributes()) {
			ejbImpl.addAttribute(attrib);
		}
		
		addCustomElement(ejbImpl);
	}

	/**
	 * Adds 'ejb-link' attribute to element's attributes  
	 * @param jarName
	 * @param beanName
	 * @throws NullPointerException in case some param is <code>null</code>
	 * @throws IllegalArgumentException in case some param is empty string
	 */
	private void setEjbLink(final String jarName, final String beanName) 
	{
		emptyStringCheckParam(jarName, "jarName"); //$NON-NLS-1$
		emptyStringCheckParam(beanName, "beanName"); //$NON-NLS-1$
		
		final IAttributeValue value = new AttributeValue(new QName(jarName + "#" + beanName)); //$NON-NLS-1$
		
		addAttribute(new CustomScdlAttribute(new QName(EJB_LINK), value));
	}
}