package com.sap.bie.sca.scdl.gen.util;

import java.text.MessageFormat;

public class ParamChecker 
{
	public static void nullCheckParam(final Object paramValue, final String paramName)
	{
		if (paramName == null) {
			throw new NullPointerException("paramName must not be null"); //$NON-NLS-1$ 
		}
		
		if (paramValue == null) {
			throw new NullPointerException(paramName + " must not be null"); //$NON-NLS-1$ 
		}
	}
	
	public static void emptyStringCheckParam(final String param, final String varName) 
	{
		nullCheckParam(param, varName);
		
		if (param.trim().length() == 0) {
			throw new IllegalArgumentException(MessageFormat.format("Parameter {0} is empty string or contains only white spaces", varName)); //$NON-NLS-1$
		}
	}
}
