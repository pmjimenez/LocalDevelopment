package com.sap.bie.sca.scdl.gen.util.model.ejb.builders;

import static com.sap.bie.sca.scdl.gen.util.ParamChecker.nullCheckParam;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import com.sap.bie.sca.scdl.gen.util.ProcessingException;
import com.sap.bie.sca.scdl.gen.util.model.ModelException;
import com.sap.bie.sca.scdl.gen.util.model.ejb.BeanType;
import com.sap.bie.sca.scdl.gen.util.model.ejb.IBean;
import com.sap.bie.sca.scdl.gen.util.model.ejb.IEjbModule;
import com.sap.bie.sca.scdl.gen.util.model.ejb.impl.Bean;
import com.sap.bie.sca.scdl.gen.util.model.ejb.impl.Module;
import com.sap.bie.sca.scdl.gen.util.model.shared.IServiceRef;
import com.sap.bie.sca.scdl.gen.util.model.shared.builders.ServiceRefsMerger;
import com.sap.bie.sca.scdl.gen.util.model.shared.builders.annotations.ServiceReferencesBuilder;
import com.sap.bie.sca.scdl.gen.util.project.IResultProvider;
import com.sap.lib.javalang.element.ClassInfo;

/**
 * Merges modules generated from annotations and deployment descriptor
 * 
 * @author I036509
 */
public class ModulesMerger 
{
	private final ServiceRefsMerger serviceRefsMerger = new ServiceRefsMerger();
	private final IResultProvider resultProvider;
	
	public ModulesMerger(final IResultProvider resultProvider) {
		nullCheckParam(resultProvider, "resultProvider"); //$NON-NLS-1$
		this.resultProvider = resultProvider;
	}
	
	/**
	 * Merges modules generated from annotations and deployment descriptor by 
	 * applying the rule that the deployment descriptor is with higher priority
	 * @param annModule the annotation generated module
	 * @param xmlModule the XML generated module
	 * @return merged module
	 * @throws ModelException in case model inconsistencies were found
	 * @throws ProcessingException in case 
	 * @throws NullPointerException in case some of params is <code>null</code>
	 */
	public IEjbModule merge(final IEjbModule annModule, final IEjbModule xmlModule) throws ModelException, ProcessingException 
	{
		nullCheckParam(annModule, "annModule"); //$NON-NLS-1$
		nullCheckParam(xmlModule, "xmlModule"); //$NON-NLS-1$
		
		final Module mergedModule = new Module(annModule.getName(), annModule.getVersion());
		for (IBean bean : mergeBeans(annModule, xmlModule)) {
			mergedModule.addBean(bean);
		}
		
		return mergedModule;
	}
	
	private List<IBean> mergeBeans(final IEjbModule annModule, final IEjbModule xmlModule) throws ModelException, ProcessingException 
	{
		final List<IBean> mergedBeans = new ArrayList<IBean>();		
		for (IBean annBean : annModule.getBeans()) 
		{
			final IBean xmlBean = xmlModule.getBean(annBean.getBeanName());
			if (xmlBean != null) {
				mergedBeans.add(mergeBean(annBean, xmlBean));
			} else {
				mergedBeans.add(annBean);
			}
		}
		
		for (IBean xmlBean : xmlModule.getBeans()) {			
			if (annModule.getBean(xmlBean.getBeanName()) == null) {
				fillXmlBeanAnnotationRefs(xmlBean);
				mergedBeans.add(xmlBean);
			}
		}
		
		return mergedBeans;
	}
	
	private void fillXmlBeanAnnotationRefs(final IBean xmlBean) throws ModelException, ProcessingException 
	{
		final ClassInfo implClass = resultProvider.getReadResult().getClass(xmlBean.getBeanClass());
		if (implClass== null) {
			final String message = "Bean with name ''{0}'' is declared to be implemented by ''{1}'' but such class does not exists"; //$NON-NLS-1$
			throw new ModelException(MessageFormat.format(message, xmlBean.getBeanName(), xmlBean.getBeanClass()));
		}
		
		final ServiceReferencesBuilder refBuilder = new ServiceReferencesBuilder();
		for (IServiceRef serviceRef : refBuilder.process(implClass, resultProvider)) {
			xmlBean.addServiceRef(serviceRef);
		}		
	}

	private IBean mergeBean(final IBean annBean, final IBean xmlBean) throws ModelException 
	{
		if (!annBean.getBeanClass().equals(xmlBean.getBeanClass())) {
			final String message = "Bean with name {0} is declared to be implemented by {1} in annotation, " + //$NON-NLS-1$
					"but also is declared to be imlemented by {2} in the ejb-jar.xml"; //$NON-NLS-1$
			throw new ModelException(
					MessageFormat.format(message, annBean.getBeanName(), annBean.getBeanClass(), xmlBean.getBeanClass()));
		}
		
		final BeanType beanType = defineBeanType(annBean, xmlBean);
		final Bean bean = new Bean(annBean.getBeanName(), annBean.getBeanClass(), beanType);
		
		for (IServiceRef serviceRef : serviceRefsMerger.merge(annBean.getServiceRefs(), xmlBean.getServiceRefs())) {
			bean.addServiceRef(serviceRef);
		}
		
		return bean;
	}

	private BeanType defineBeanType(final IBean annBean, final IBean xmlBean) throws ModelException 
	{
		final BeanType annBeanType = annBean.getBeanType();
		final BeanType xmlBeanType = xmlBean.getBeanType();
		if (annBeanType == xmlBeanType) {
			return annBeanType;
		}
		
		if ((annBeanType != BeanType.msg && xmlBeanType == BeanType.msg)) {
			final String message = "Bean {0} is defined as session bean in annotation, but also is defined as message driven in ejb-jar.xml"; //$NON-NLS-1$
			throw new ModelException(MessageFormat.format(message, annBean.getBeanName()));
		}
		
		if ((xmlBeanType != BeanType.msg && annBeanType == BeanType.msg)) {
			final String message = "Bean {0} is defined as session bean in ejb-jar.xml, but also is defined as message driven in annotation"; //$NON-NLS-1$
			throw new ModelException(MessageFormat.format(message, annBean.getBeanName()));
		}
		
		return xmlBeanType;
	}
}