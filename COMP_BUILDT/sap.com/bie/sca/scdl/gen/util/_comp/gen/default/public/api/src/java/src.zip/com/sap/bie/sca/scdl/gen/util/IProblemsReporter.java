package com.sap.bie.sca.scdl.gen.util;

/**
 * The interface is used to report problems during processing, instead of throwing
 * exception. The benefit is that the processor reports error though this interface
 * but the caller have the chance to decide if exception should be thrown or
 * just logged. 
 * 
 * @author I036509
 */
public interface IProblemsReporter 
{
	/**
	 * Reports fatal error in processing - means that the processing cannot continue.
	 * @param e the exception thrown
	 * @throws ProcessingException - can be used to re-throw the provided exception
	 */
	public void error(Exception e) throws ProcessingException;
	
	/**
	 * Reports warning with some explanation message
	 * @param message warning text 
	 * @param e the thrown exception if any - might be <code>null</code>
	 * @throws ProcessingException
	 */
	public void warning(String message, Exception e) throws ProcessingException;
	
	/**
	 * Provides some information about the processing status
	 * @param message info text
	 */
	public void info(String message);
}
