package com.sap.bie.sca.scdl.gen.util.model;

import java.io.IOException;

import com.sap.bie.sca.scdl.gen.util.ProcessingException;
import com.sap.bie.sca.scdl.gen.util.project.IResultProvider;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;

/**
 * Module factory interface. Specific factories should implement this module factory
 * interface with specific module type. 
 * 
 * @author I036509
 *
 * @param <T>
 */
public interface IModuleFactory<T> 
{
	/**
	 * Creates specified module type
	 * @param pluginBuildInfo
	 * @param resultProvider
	 * @return
	 * @throws ProcessingException in case some general problem like {@link IOException} occures 
	 * @throws ModelException in case of model inconsistency - i.e. some required properties cannot be defined
	 * out of annotations and deployment descriptors
	 */
	public T createModule(final IPluginBuildInfo pluginBuildInfo, final IResultProvider resultProvider) throws ProcessingException, ModelException;
}
