package com.sap.bie.sca.scdl.gen.util.clazz.annotations;

import com.sap.bie.sca.scdl.gen.util.ProcessingException;
import com.sap.bie.sca.scdl.gen.util.project.IResultProvider;
import com.sap.lib.javalang.element.ClassInfo;
import com.sap.lib.javalang.element.FieldInfo;
import com.sap.lib.javalang.element.MethodInfo;

/**
 * This interface should be implemented by clients in order to be able
 * to contribute to the class processing framework. This framework consists
 * of class traverse utilities that extract class members for set of classes 
 * or single class and call visitors in order to process it.
 * 
 * @author I036509
 *
 * @param <E> the specific visitor result type that will be returned as result of member 
 * processing
 * @see ClassAnnotationsProcessor
 * @see ProjectAnnotationsProcessor
 */
public interface IClassAnnotationsVisitor<E> 
{
	public enum VisitType {Class, Field, Method};
	
	/**
	 * Called when the visitor supports class processing 
	 * 
	 * @param clazz the class to be processed
	 * @param resultProvider the provider of the class
	 * @return concrete processing result
	 * @throws ProcessingException
	 */
	public E processClass(ClassInfo clazz, IResultProvider resultProvider) throws ProcessingException;
	
	/**
	 * Called when the visitor supports class field processing 
	 * 
	 * @param field the field to be processed
	 * @param resultProvider the provider of the class
	 * @return concrete processing result
	 * @throws ProcessingException
	 */
	public E processField(FieldInfo field, IResultProvider resultProvider) throws ProcessingException;
	
	/**
	 * Called when the visitor supports class method processing 
	 * 
	 * @param method the method to be processed
	 * @param resultProvider the provider of the class
	 * @return concrete processing result
	 * @throws ProcessingException
	 */
	public E processMethod(MethodInfo method, IResultProvider resultProvider) throws ProcessingException;
	
	/**
	 * Defines which member types this visitor is capable to process
	 * @param type
	 * @return <code>true</code> if this visit <code>type</code> is supporder by the visitor
	 */
	public boolean visits(VisitType type);
}
