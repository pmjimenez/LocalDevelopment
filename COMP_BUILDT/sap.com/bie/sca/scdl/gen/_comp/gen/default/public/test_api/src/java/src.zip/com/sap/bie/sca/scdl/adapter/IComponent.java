/**
 * 
 */
package com.sap.bie.sca.scdl.adapter;

import java.util.Collection;

/**
 * 
 * Represents the component in the SCA assembly model.
 * 
 * @author d038406
 *
 */
public interface IComponent extends ICustomizableElement {
	
	/**
	 * 
	 * Return the references required by this component. If there are no
	 * element to be returned, an implementor SHOULD return an empty
	 * {@link Collection} rather than <code>null</code>..
	 * 
	 * @return
	 */
	public Collection<IReference> getReferences();
	
	/**
	 * 
	 * Return the services provided by this component. If there are no
	 * element to be returned, an implementor SHOULD return an empty
	 * {@link Collection} rather than <code>null</code>..
	 * 
	 * @return
	 */
	public Collection<IService> getServices();
	
	/**
	 * 
	 * Return the object representing the implementation element in the SCDL.
	 * Implementors MAY return <code>null</code>.
	 * 
	 * @return
	 * 
	 */
	public IImplementation getImplementation();
	

	/**
	 * 
	 * Return the component name here. This name has to be unique across all
	 * {@link IComponent} of the associated {@link IComposite}. Implementors 
	 * MUST NOT return <code>null</code>.
	 * 
	 * @return
	 */
	public String getName();
}
