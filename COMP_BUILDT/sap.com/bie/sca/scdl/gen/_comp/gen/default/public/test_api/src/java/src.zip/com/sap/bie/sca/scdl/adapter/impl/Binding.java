package com.sap.bie.sca.scdl.adapter.impl;

import static com.sap.bie.sca.scdl.gen.util.ContractChecker.emptyStringCheckParam;
import static com.sap.bie.sca.scdl.gen.util.ContractChecker.nullCheckParam;

import java.text.MessageFormat;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.IBinding;

/**
 * Default implementation of {@link IBinding}
 * 
 * @author I036509
 */
public class Binding extends CustomizableElement implements IBinding 
{
	private final String BINDING = "binding"; //$NON-NLS-1$
	private final QName qName; 
	
	/**
	 * Constructor
	 * @param qName binding tag qualified name
	 * @throws NullPointerException in case <code>qName</code> is <code>null</code>
	 */
	public Binding(final QName qName) 
	{
		nullCheckParam(qName, "qName");  //$NON-NLS-1$
		this.qName = qName;
	}
	
	/**
	 * Constructor
	 * @param customScdlElement
	 * @throws NullPointerException in case <code>customScdlElement</code> is <code>null</code>
	 */
	public Binding(final String type) {
		
		emptyStringCheckParam(type, "type"); //$NON-NLS-1$
		this.qName = new QName(BINDING + '.' + type);
	}

	public QName getName() {
		return qName;
	}
	
	@Override
	public String toString() {
		return MessageFormat.format("Binding[{0}]\n\t{1}", qName, super.toString()); //$NON-NLS-1$
	}
}
