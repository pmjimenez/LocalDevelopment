package com.sap.bie.sca.scdl.gen.util;


/**
 * The XML Constants of the relevant SCA Schemas, 
 * 
 * @see <link>http://www.osoa.org/display/Main/Service+Component+Architecture+Specifications</link> 
 * SCA Assembly Model V1.00 
 * 
 * @author SAP AG
 *
 */
public class XMLSCAConstants {
	public static final String SCA_NAMESPACE = "http://www.osoa.org/xmlns/sca/1.0";  //$NON-NLS-1$
	public static final String SCA_SAP_NAMESPACE = "http://www.sap.com";  //$NON-NLS-1$
	public static final String XML_FILE_EXTENSION = ".xml"; //$NON-NLS-1$
}
