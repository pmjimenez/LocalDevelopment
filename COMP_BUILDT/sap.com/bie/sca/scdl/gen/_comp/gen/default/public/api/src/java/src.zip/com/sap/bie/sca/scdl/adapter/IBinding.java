/**
 * 
 */
package com.sap.bie.sca.scdl.adapter;


/**
 * 
 * Represents the binding element in the SCA assembly model.
 * The SCA specification does not define any structure for this
 * element. Rather the binding element has to be completely 
 * defined by the technology implementation.
 * 
 * @author d038406
 *
 */
public interface IBinding extends ICustomizableElement {
}
