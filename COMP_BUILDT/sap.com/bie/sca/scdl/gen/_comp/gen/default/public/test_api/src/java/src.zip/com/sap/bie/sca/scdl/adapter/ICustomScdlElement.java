/**
 * 
 */
package com.sap.bie.sca.scdl.adapter;

import java.util.List;

/**
 * Defines a custom element inside the scdl file. A custom element has to be defined
 * in its own namespace. Otherwise the generated scdl file will not be compatible with
 * the SCA specification.
 * 
 * @author d038406
 * 
 */
public interface ICustomScdlElement extends ICustomizableAttributes {

	/**
	 * 
	 * Return the namespace to which this SCDL element belongs. Implementors
	 * MUST NOT return <code>null</code>.
	 * 
	 * @return
	 * 
	 */
	String getNamespace();

	/**
	 * 
	 * Return the namespace prefix for the namespace returned in {@link
	 * getScdlNamespace()}. Implementors MUST NOT return <code>null</code>.
	 * 
	 * @return
	 * 
	 */
	String getNamespacePrefix();

	/**
	 * 
	 * Return the XML element name of the tag. Implementors MUST NOT return
	 * <code>null</code>.
	 * 
	 * @return
	 * 
	 */
	String getElementName();

	/**
	 * 
	 * Returns any children of this custom element. Implementors MAY return
	 * <code>null</code>.
	 * 
	 * @return
	 */
	List<ICustomScdlElement> getChildren();

}
