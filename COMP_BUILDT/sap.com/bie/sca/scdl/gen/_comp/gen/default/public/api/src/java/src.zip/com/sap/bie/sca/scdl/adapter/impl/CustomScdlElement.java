package com.sap.bie.sca.scdl.adapter.impl;

import static com.sap.bie.sca.scdl.gen.util.ContractChecker.emptyStringCheckParam;
import static com.sap.bie.sca.scdl.gen.util.ContractChecker.nullCheckParam;

import java.util.List;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.ICustomScdlAttribute;
import com.sap.bie.sca.scdl.adapter.ICustomScdlElement;

/**
 * Default {@link ICustomScdlElement} implementation. Can be used in order not to develop new
 * implementor every time we need {@link ICustomScdlElement} instance. 
 * 
 * @author I036509
 */
public class CustomScdlElement extends CustomizableAttributes implements ICustomScdlElement 
{
	private final NoNullsList<ICustomScdlElement> children = new NoNullsList<ICustomScdlElement>(); 

	private final QName qName;
	
	/**
	 * Constructor - constructs {@link ICustomScdlElement} instance with element name - the supplied 
	 * <code>elementName</code> and empty name-space and prefix
	 * @param elementName
	 * @throws NullPointerException in case <code>elementName</code> is <code>null</code>
	 * @throws IllegalArgumentException in case <code>elementName</code> is empty string
	 */
	public CustomScdlElement(final String elementName) 
	{
		emptyStringCheckParam(elementName, "elementName"); //$NON-NLS-1$
		this.qName = new QName(elementName);
	}
	
	/**
	 * Constructor - constructs {@link ICustomScdlElement} instance with element name 
	 * {@link QName#getLocalPart()}, name-space {@link QName#getNamespaceURI()} and prefix
	 * {@link QName#getPrefix()}.	 
	 * @param qName
	 * @throws NullPointerException in case <code>qName</code> is <code>null</code>s
	 */
	public CustomScdlElement(final QName qName) 
	{
		nullCheckParam(qName, "qName"); //$NON-NLS-1$
		this.qName = qName;
	}
	
	public boolean addChild(final ICustomScdlElement customScdlElement) {
		return children.add(customScdlElement);
	}
	
	public List<ICustomScdlElement> getChildren() {
		return children.unmodifiable();
	}
	
	public String getElementName() {
		return qName.getLocalPart();
	}

	public String getNamespace() {
		return qName.getNamespaceURI();
	}
	
	public String getNamespacePrefix() {
		return qName.getPrefix();
	}
	
	@Override
	public String toString() 
	{
		final StringBuilder sb = new StringBuilder();
		sb.append("CustomScdlElement [").append(qName).append(']'); //$NON-NLS-1$
		
		for (ICustomScdlAttribute attribute : getCustomAttributes()) {
			sb.append("\n\t").append(attribute.toString()); //$NON-NLS-1$
		}
		for (ICustomScdlElement element : children) {
			sb.append("\n\t").append(element.toString()); //$NON-NLS-1$
		}
		
		return sb.toString();
	}
}
