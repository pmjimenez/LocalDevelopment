/**
 * 
 */
package com.sap.bie.sca.scdl.adapter;

/**
 * Represents the wire element in the SCA assembly model.
 * 
 * @author d038406
 *
 */
public interface IWire extends ICustomizableElement {

	/**
	 * Returns the name of the reference that is used as source
	 * for the wire. The method DOES NOT return the {@link IReference}
	 * instance, but only their name. Implementors MAY NOT return 
	 * <code>null</code>
	 * 
	 * @return
	 */
	String getSource();

	/**
	 * Returns the name of the service that is used as target
	 * for the wire. The method DOES NOT return the {@link IService}
	 * instance, but only their name. Implementors MAY NOT return 
	 * <code>null</code>
	 * 
	 * @return
	 */
	String getTarget();
}
