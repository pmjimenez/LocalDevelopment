package com.sap.bie.sca.scdl.adapter;

import java.util.Collection;

/**
 * 
 * Interface represents SCA composites.
 * 
 * @author d038406
 *
 */
public interface IComposite extends ICustomizableElement {

	/**
	 * Name of the composite element. This SHOULD be the name of the DC.
	 * MAY NOT be <code>null</code>.
	 * 
	 * @return
	 */
	String getName();

	/**
	 * @return
	 */
	String getTargetnamespace();

	/**
	 * Returns the components provided by this composite.
	 * 
	 * @return
	 */
	Collection<IComponent> getComponents();

	/**
	 * Returns the wires defined within this composite.
	 * 
	 * @return
	 */
	Collection<IWire> getWires();
}
