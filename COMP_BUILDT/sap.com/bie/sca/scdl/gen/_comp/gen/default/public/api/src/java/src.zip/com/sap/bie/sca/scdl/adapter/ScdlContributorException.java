package com.sap.bie.sca.scdl.adapter;

/**
 * Standard exception that should be used by all contributors to notify
 * the scdl generator about an error. Throwing this kind of exception
 * will stop the generation process and automatically leads to a failed 
 * DC build. There is no need to print the error into the log yourself,
 * this will be done by the scdl generator based on the thrown exception.
 * 
 * If a contributor just wants to print out a warning, please use the 
 * standard logging capabilities.
 *   
 * @author d040882
 *
 */
public class ScdlContributorException extends RuntimeException {

	private static final long serialVersionUID = 6058050032051283820L;

	public ScdlContributorException(String description) {
		super(description);
	}
	
	public ScdlContributorException(String descr, Throwable cause) {
		super(descr, cause);
	}
}
