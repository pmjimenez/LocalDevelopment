/**
 * 
 */
package com.sap.bie.sca.scdl.classifications;

import java.io.File;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.sap.bie.sca.scdl.adapter.IAttributeValue;
import com.sap.bie.sca.scdl.gen.util.ContractChecker;
import com.sap.bie.sca.scdl.gen.util.ScdlExportService;
import com.sap.bie.sca.scdl.gen.util.XmlExportService;
import com.sap.tc.buildplugin.log.Log;

/**
 * 
 * @author d038406
 * 
 */
public class ClassificationsProcessor {

	private static final String META_INF = "META-INF";  //$NON-NLS-1$
	private static final String CLASSIFICATIONS_FILE_EXT = ".classifications";  //$NON-NLS-1$
	private static final String TAG_CODE = "code"; //$NON-NLS-1$
	private static final String TAG_QNAME = "qname"; //$NON-NLS-1$
 	private static final String TAG_CLASSIFICATION = "Classification"; //$NON-NLS-1$
	private static final String TAG_SAP_CLASSIFICATIONS = "sapClassifications"; //$NON-NLS-1$
	private static final String TAG_CLASSIFICATIONS = "Classifications"; //$NON-NLS-1$
	private static final String ATTRIBUTE_VERSION = "version"; //$NON-NLS-1$
	private static final String ATTRIBUTE_XMLNS = "xmlns"; //$NON-NLS-1$
	private static final String TAG_SR_PUBLICATION_DATA = "SrPublicationData"; //$NON-NLS-1$
	private static final String NS_SAP_CLASSIFICATION = "http://www.sap.com/webas/2006/11/sr/classifications"; //$NON-NLS-1$
	
	private final Map<Map<IAttributeValue, SortedSet<IAttributeValue>>, String> keyToClassFileMap = new HashMap<Map<IAttributeValue, SortedSet<IAttributeValue>>, String>();
	private final String outputDir;
	
	/**
	 * @param outputDir
	 */
	private ClassificationsProcessor(final String outputDir) {
		ContractChecker.nullCheckParam(outputDir);
		this.outputDir = outputDir;
	}

	/**
	 * @param outputDir
	 * @return
	 */
	public static synchronized ClassificationsProcessor getInstance(final String outputDir) {
		return new ClassificationsProcessor(outputDir);
	}

	/**
	 * 
	 * @param scdlContributionClassifications
	 * @return
	 */
	public String process(final Map<IAttributeValue, SortedSet<IAttributeValue>> scdlContributionClassifications) {
		
		if (keyToClassFileMap.containsKey(scdlContributionClassifications)) {
			return keyToClassFileMap.get(scdlContributionClassifications);
		}
		
		return createClassificationFile(scdlContributionClassifications);		
	}

	/**
	 * @param scdlContributionClassifications
	 * @return
	 */
	private String createClassificationFile(final Map<IAttributeValue, SortedSet<IAttributeValue>> scdlContributionClassifications) {
		
		Document doc = XmlExportService.getDocumentBuilder().newDocument();
		
		Element root = doc.createElement(TAG_SR_PUBLICATION_DATA); 
		root.setAttribute(ATTRIBUTE_XMLNS, NS_SAP_CLASSIFICATION);
		root.setAttribute(ATTRIBUTE_VERSION, "1.0"); //$NON-NLS-1$
		Element classifications = doc.createElement(TAG_CLASSIFICATIONS);
		classifications.setAttribute(TAG_SAP_CLASSIFICATIONS, Boolean.TRUE.toString());
		Set<IAttributeValue> keys = scdlContributionClassifications.keySet();
		for (Iterator<IAttributeValue> iterator = keys.iterator(); iterator.hasNext();) {
			IAttributeValue key = iterator.next();
			Collection<IAttributeValue> values = scdlContributionClassifications.get(key);
			for (Iterator<IAttributeValue> iterator2 = values.iterator(); iterator2.hasNext();) {
				IAttributeValue value = iterator2.next();
				Element classification = doc.createElement(TAG_CLASSIFICATION);
				
				Element qName = doc.createElement(TAG_QNAME);
				
				String newValue = ScdlExportService.handleNamespaceForAttribute(root, key.getValue(), 
						key.getNamespace(), key.getNamespacePrefix());
				qName.setTextContent(newValue);
	
				Element code = doc.createElement(TAG_CODE); // this is the value
				
				newValue = ScdlExportService.handleNamespaceForAttribute(root, value.getValue(), 
									value.getNamespace(), value.getNamespacePrefix());
				code.setTextContent(newValue);
				
				classification.appendChild(qName);
				classification.appendChild(code);
				classifications.appendChild(classification);
			}
		}
		root.appendChild(classifications);
		doc.appendChild(root);

		
		String fileName = createFileName();
		
		XmlExportService.storeXmlDocument(doc, createAbsoluteFileName(fileName));

		Log.info("			[SCDL-EXPORT] Classification file output location: " + fileName); //$NON-NLS-1$

		
		keyToClassFileMap.put(scdlContributionClassifications, createRelativeFileName(fileName));
		return fileName;
	}

	/**
	 * @return
	 */
	private String createFileName() {
		return  System.currentTimeMillis() + CLASSIFICATIONS_FILE_EXT;
	}
	
	private String createAbsoluteFileName(String fileName) {
		return outputDir + File.separator + META_INF + File.separator + fileName;
	}
	
	private String createRelativeFileName(String fileName) {
		return "." + File.separator + fileName; //$NON-NLS-1$
	}
}
