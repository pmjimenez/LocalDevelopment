package com.sap.bie.sca.scdl.adapter.impl;

import static com.sap.bie.sca.scdl.gen.util.ContractChecker.nullCheckParam;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * {@link List} that does not allows adding <code>null</code> object 
 * 
 * @author I036509
 *
 * @param <T>
 */
public class NoNullsList<T> extends ArrayList<T>
{
	static final long serialVersionUID = -7626230406072799165L;

	@Override
    public boolean add(T object) 
    {
    	nullCheckParam(object, "added object"); //$NON-NLS-1$
    	return super.add(object);
    }
	
	/**
	 * @return unmodifiable collection
	 */
	public List<T> unmodifiable() {
		return Collections.unmodifiableList(this);
	}	
}
