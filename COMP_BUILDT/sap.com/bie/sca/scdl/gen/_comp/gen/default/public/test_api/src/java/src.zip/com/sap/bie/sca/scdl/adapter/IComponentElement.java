package com.sap.bie.sca.scdl.adapter;


/**
 * 
 * A base interface for entities used to define a components interface ( see
 * {@link IReference} and {@link IService}.
 * 
 * @author d038406
 * 
 */
public interface IComponentElement extends IClassifiedScdlContribution, ICustomizableElement {

	/**
	 * 
	 * The value of the name attribute. Implementors MUST NOT return
	 * <code>null</code>.
	 * 
	 * @return
	 */
	String getName();


	/**
	 * 
	 * Return the element representing the component interface elements
	 * interface. Implementors MUST NOT return <code>null</code>.
	 * 
	 * @return
	 */
	IInterface getScainterface();

	/**
	 * 
	 * Optionally you can specify a custom binding, if not needed you MAY return
	 * <code>null</code> here.
	 * 
	 * @return your binding or null.
	 */
	IBinding getBinding();
}
