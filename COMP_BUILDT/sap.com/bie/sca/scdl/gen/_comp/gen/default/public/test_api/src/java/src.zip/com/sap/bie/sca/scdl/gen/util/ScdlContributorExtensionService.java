/**
 * 
 */
package com.sap.bie.sca.scdl.gen.util;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.tools.ant.BuildException;

import com.sap.bie.sca.scdl.adapter.IComposite;
import com.sap.bie.sca.scdl.adapter.IScdlContributor;
import com.sap.bie.sca.scdl.adapter.ScdlContributorException;
import com.sap.tc.buildplugin.BuildSessionManager;
import com.sap.tc.buildplugin.api.IAttributeManager;
import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.moin.repository.Connection;

/**
 * @author d038406
 * 
 */
public class ScdlContributorExtensionService {

	public static final String EXT_POINT_IDE_EXT_CFG_BIE = "ext-point[bie.sca.scdl.gen]"; //$NON-NLS-1$
	public static final String JAVA_LANG_STRING = "java.lang.String"; //$NON-NLS-1$

	private static IGlobalPluginUtil gpu = null;
	private static IPluginBuildInfo pluginBuildInfo = null;
	private static Connection con=null;
	
	/**
	 * 
	 * Retrieve the SCDL contributors and instantiate the implementation class.
	 * 
	 * @return the collection of contributor, will never return null.
	 * 
	 * @throws InvocationTargetException
	 *             - In case loading/instantiating the adapter implementation
	 *             fails.
	 * @throws {@link IllegalStateException} - In case there is no adapter impl
	 *         registered --> this is a hint for a missing dc reference.
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, IScdlContributor> getContributors() throws InvocationTargetException {
		IPluginBuildInfo pbi = getPluginBuildInfo();
		
		IAttributeManager am = pbi.getAttributeManager();
		Collection<Object> impl = am.getObjects(JAVA_LANG_STRING, EXT_POINT_IDE_EXT_CFG_BIE);
		Map<String, IScdlContributor> scdlContributors = new HashMap<String, IScdlContributor>();
		for (Iterator iterator = impl.iterator(); iterator.hasNext();) {
			String adapter = (String) iterator.next();
			try {
				Class clazz = Class.forName(adapter);
				try {
					IScdlContributor extCfgAdapter = (IScdlContributor) clazz.newInstance();
					scdlContributors.put(adapter, extCfgAdapter);
				} catch (InstantiationException e) {
					throw new InvocationTargetException(e);
				} catch (IllegalAccessException e) {
					throw new InvocationTargetException(e);
				}
			} catch (ClassNotFoundException e) {
				throw new InvocationTargetException(e);
			}
		}
		return scdlContributors;
	}
	
	public static Collection<IComposite> getContributions() {
		if(getCon()==null) {
			Log.error("ScdlGenerator: No moin connection is available"); //$NON-NLS-1$
			throw new RuntimeException("ScdlGenerator: No moin connection is availalable"); //$NON-NLS-1$
		}
			
		Map<String,IScdlContributor> scdlContributors = new HashMap<String,IScdlContributor>();
		try {
			scdlContributors = getContributors();
		} catch (InvocationTargetException e) {
			Log.error(e);
			throw new BuildException("ScdlGenerator: Not able to get contributors."); //$NON-NLS-1$
		}
		if (scdlContributors.size() < 1) {
			Log.info("ScdlGenerator is skipped: no scdl contributors were found! " //$NON-NLS-1$
					+ "Is a contributor BIE available in the list of DC refs?"); //$NON-NLS-1$
			return Collections.emptyList();
		}
		
		Collection<IComposite> contributedComposites = new ArrayList<IComposite>();
		for (Iterator<String> iterator = scdlContributors.keySet().iterator(); iterator.hasNext();) {
			String contributorName=iterator.next();
			IScdlContributor scdlContributor = scdlContributors.get(contributorName);
			
			try {
				IComposite composite = scdlContributor.getComposite(getCon(), getGpu(), getPluginBuildInfo());
			
				if (composite != null) {
					contributedComposites.add(composite);
				}
			}
			catch(ScdlContributorException e) {
				Log.error("Contributor '" + contributorName + "' failed: ");  //$NON-NLS-1$//$NON-NLS-2$
				throw new BuildException(e);
			}
		}
		return contributedComposites;
	}
	
	public static IPluginBuildInfo getPluginBuildInfo() {
		if(pluginBuildInfo==null)
			return (IPluginBuildInfo) BuildSessionManager.
					getFromBuildSession(IPluginBuildInfo.class.getName());
		else
			return pluginBuildInfo;
	}
	
	public static void setPluginBuildInfo(IPluginBuildInfo info) {
		pluginBuildInfo = info;
	}

	public static IGlobalPluginUtil getGpu() {
		if(gpu==null)
			return (IGlobalPluginUtil) BuildSessionManager.
					getFromBuildSession(IGlobalPluginUtil.class.getName());
		else
			return gpu;
	}

	public static void setGpu(IGlobalPluginUtil gpu) {
		ScdlContributorExtensionService.gpu = gpu;
	}

	public static Connection getCon() {
		return con;
	}

	public static void setCon(Connection con) {
		ScdlContributorExtensionService.con = con;
	}
}
