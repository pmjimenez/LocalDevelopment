package com.sap.bie.sca.scdl.adapter.impl;

import static com.sap.bie.sca.scdl.gen.util.ContractChecker.emptyStringCheckParam;
import static com.sap.bie.sca.scdl.gen.util.ContractChecker.nullCheckParam;

import java.util.Collection;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.IComponent;
import com.sap.bie.sca.scdl.adapter.IComposite;
import com.sap.bie.sca.scdl.adapter.IWire;

/**
 * Default {@link IComposite} implementation. Can be used in order not to develop new
 * implementor every time we need {@link IComposite} instance. 
 * 
 * @author I036509
 */
public class Composite extends CustomizableElement implements IComposite 
{
	public static final String DEFAULT_NS = "http://www.sap.com"; //$NON-NLS-1$
	
	private final NoNullsList<IComponent> components = new NoNullsList<IComponent>();
	private final NoNullsList<IWire> wires = new NoNullsList<IWire>();
	
	private final QName qName;	

	/**
	 * Constructor - creates {@link IComposite} instance with name - the supplied <code>name</code> parameter
	 * and name-space {@link Composite#DEFAULT_NS}
	 * @param name
	 * @throws NullPointerException in case <code>name</code> is <code>null</code>
	 */
	public Composite(final String name) {
		emptyStringCheckParam(name, "name"); //$NON-NLS-1$
		this.qName = new QName(DEFAULT_NS, name);
	}
	
	/**
	 * Constructor - creates {@link IComposite} instance with name {@link QName#getLocalPart()} and
	 * name-space {@link QName#getNamespaceURI()}
	 * @param qName
	 * @throws NullPointerException in case <code>qName</code> is <code>null</code>
	 */
	public Composite(final QName qName) {
		nullCheckParam(qName, "qName"); //$NON-NLS-1$
		this.qName = qName;
	}

	public String getName() {
		return qName.getLocalPart();
	}

	public String getTargetnamespace() {
		return qName.getNamespaceURI();
	}

	public void addComponent(final IComponent component) {
		components.add(component);
	}
	
	public Collection<IComponent> getComponents() {
		return components.unmodifiable();
	}
	
	public boolean addWire(final IWire wire) {
		return wires.add(wire);
	}
	
	public Collection<IWire> getWires() {
		return wires.unmodifiable();
	}
	
	@SuppressWarnings("nls")
	@Override
	public String toString() 
	{
		final StringBuilder sb = new StringBuilder();
		sb.append("Composite [").append(qName.toString()).append(']') //$NON-NLS-1$
		  .append("\n\tcomponents[").append(components.toString()).append(']') //$NON-NLS-1$
		  .append("\n\twires[").append(wires.toString()).append(']') //$NON-NLS-1$
		  .append("\n\tcustom[").append(super.toString()).append(']'); //$NON-NLS-1$
		
		return sb.toString();
	}
}
