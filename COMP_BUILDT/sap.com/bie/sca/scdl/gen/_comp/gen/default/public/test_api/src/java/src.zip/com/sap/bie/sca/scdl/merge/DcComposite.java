package com.sap.bie.sca.scdl.merge;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.sap.bie.sca.scdl.adapter.IComponent;
import com.sap.bie.sca.scdl.adapter.IComposite;
import com.sap.bie.sca.scdl.adapter.ICustomScdlAttribute;
import com.sap.bie.sca.scdl.adapter.ICustomScdlElement;
import com.sap.bie.sca.scdl.adapter.IWire;
import com.sap.bie.sca.scdl.gen.util.XMLSCAConstants;

public class DcComposite implements IComposite {
	private String name;
	private Collection<IComponent> components = new ArrayList<IComponent>();
	private Collection<ICustomScdlElement> customElements = new ArrayList<ICustomScdlElement>();
	private Collection<ICustomScdlAttribute> customAttributes = new ArrayList<ICustomScdlAttribute>();
	private Collection<IWire> wires = new ArrayList<IWire>();
	private Map<String, Collection<String>> scdlContributionClassifications = new HashMap<String, Collection<String>>();

	public void setName(String name) {
		this.name = name;
	}
	
	public String getTargetnamespace() {
		return XMLSCAConstants.SCA_SAP_NAMESPACE;
	}

	public String getName() {
		return name;
	}

	public Collection<IComponent> getComponents() {
		return components;
	}

	public Collection<IWire> getWires() {
		return wires;
	}

	public Collection<ICustomScdlElement> getCustomElements() {
		return customElements;
	}
	
	public Collection<ICustomScdlAttribute> getCustomAttributes() {
		return customAttributes;
	}
	
	public Map<String, Collection<String>> getScdlContributionClassifications() {
		return scdlContributionClassifications;
	}
}

