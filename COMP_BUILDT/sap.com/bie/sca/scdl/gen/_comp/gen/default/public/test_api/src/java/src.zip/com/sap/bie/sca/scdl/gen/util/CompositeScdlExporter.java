package com.sap.bie.sca.scdl.gen.util;

import java.io.File;
import java.util.Collection;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.sap.bie.sca.scdl.adapter.IComposite;
import com.sap.tc.buildplugin.log.Log;

/**
 * All Components are treated alike, there is no primary component Components
 * differ with respect to their content
 * 
 * A file component is to be called <componentname>.composite
 * 
 * @author d038406
 * 
 */
public final class CompositeScdlExporter {

	private static final String META_INF = "META-INF"; //$NON-NLS-1$
	private static final String SCA_CONTRIBUTION = "sca-contribution"; //$NON-NLS-1$
	public static final String COMP_FILE_EXTENSION = ".composite"; //$NON-NLS-1$

	private final String genDir;
	private final Collection<IComposite> composites;
	private boolean isExportedScdlContribution;

	/**
	 * 
	 * Constructor of exporter.
	 * 
	 * 
	 * @param baseOutputPath
	 *            - the outputpath to which the scdl exporter writes its files,
	 *            must not be <code>null</code>.
	 * @param composites
	 *            - the set of composites to be exported, must not be
	 *            <code>null</code>.
	 * 
	 * @param isExportedScdlContribution
	 *            - specify whether this is an exported scdl or a directly
	 *            deployable composite. This parameter controls how the
	 *            sca-contribution.xml is generated. In the ejb case an
	 *            sca-contribution.xml with an export has to be generated (call
	 *            this constructor with this parameter set to <code>true</code>)
	 *            which is then imported into the sca-contribution.xml on
	 *            application level (i.e. the META-INF of the EAR). In the
	 *            propriatary SAP DCs such as WD, an sca-contribution with
	 *            deployable tag is generated (call this constructor with this
	 *            parameter set to <code>false</code>).
	 * 
	 * @throws IllegalArgumentException
	 *             in case <code>null</code> is passed for parameter
	 *             baseOutputPath (arg 0) or parameter composites (arg 1).
	 */
	public CompositeScdlExporter(final String baseOutputPath, final Collection<IComposite> composites,
			final boolean isExportedScdlContribution) {
		ContractChecker.nullCheckParam(baseOutputPath);
		ContractChecker.nullCheckParam(composites);
		this.genDir = baseOutputPath;
		this.composites = composites;
		this.isExportedScdlContribution = isExportedScdlContribution;
	}

	/**
	 * 
	 */
	// TODO think about returning collection of created filenames and handle
	// logging outside of this class.
	public final void run() {

		// We need a Document
		DocumentBuilderFactory dbfac = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder;

		try {
			docBuilder = dbfac.newDocumentBuilder();
		} catch (ParserConfigurationException e1) {
			throw new RuntimeException(e1);
		}

		for (IComposite mmComposite : composites) {
			genereateScdl(docBuilder, mmComposite);
			if (isExportedScdlContribution) {
				generateScaContributionXmlWithExport(docBuilder, mmComposite.getName());
			} else {
				generateScaContributionXmlWithDeployable(docBuilder, mmComposite.getName());
			}
		}
	}

	/**
	 * 
	 * Generate the .composite (i.e. SCDL) file.
	 * 
	 * @param docBuilder
	 * @param composite
	 * 
	 * @throws IllegalArgumentException
	 *             in case <code>null</code> is passed for either parameter.
	 * @return
	 */
	private void genereateScdl(final DocumentBuilder docBuilder, final IComposite composite) {
		ContractChecker.nullCheckParam(docBuilder);
		ContractChecker.nullCheckParam(composite);
		Document doc = docBuilder.newDocument();

		Element root = createRootScdlElement(composite, doc);

		doc.appendChild(root);

		// Add components.
		if (composite.getComponents() != null && composite.getComponents().size() > 0) {
			new ConvertComponents(composite.getComponents(), root, genDir).run();
		}
		// Add wires.
		if (composite.getWires() != null && composite.getWires().size() > 0) {
			new ConvertWires(composite.getWires(), root).run();
		}
		// Add custom xml content
		if (composite.getCustomElements() != null && composite.getCustomElements().size() > 0) {
			new ConvertCustomElements(composite.getCustomElements(), root).run();
		}

		// Serialize the document
		String path = this.genDir + File.separator + META_INF;
		String filename = path + File.separator + convertCompositeName(composite.getName()) + COMP_FILE_EXTENSION;

		XmlExportService.storeXmlDocument(doc, filename);

		Log.info("			[SCDL-EXPORT] Scdl file output location: " + filename); //$NON-NLS-1$
	}

	/**
	 * @param composite
	 * @param doc
	 * @return
	 */
	private Element createRootScdlElement(final IComposite composite, final Document doc) {
		// Create the root element and add it to the document
		Element root = doc.createElement("composite"); //$NON-NLS-1$
		root.setAttribute("name", convertCompositeName(composite.getName())); //$NON-NLS-1$
		root.setAttribute("xmlns:sap", XMLSCAConstants.SCA_SAP_NAMESPACE); //$NON-NLS-1$
		root.setAttribute("xmlns", XMLSCAConstants.SCA_NAMESPACE); //$NON-NLS-1$
		root.setAttribute("targetNamespace", composite.getTargetnamespace()); //$NON-NLS-1$

		//ScdlExportService.handleScaCustomElements(root, composite.getCustomElements(), root);
		ScdlExportService.handleAttributes(root, composite.getCustomAttributes(), root);
		
		return root;
	}

	/**
	 * @param docBuilder
	 * @param name
	 */
	private void generateScaContributionXmlWithDeployable(final DocumentBuilder docBuilder, final String compositeName) {
		Document doc = docBuilder.newDocument();

		Element root = createScaContributionRootElement(doc);
		Element deployable = createScaContributionDeployableElement(compositeName, doc);
		root.appendChild(deployable);
		doc.appendChild(root);

		storeScaContributionFile(doc);
	}

	/**
	 * 
	 * One shot operation to generate the sca-contribution.xml in the DC build.
	 * Currently the assumption is that there is only one contribution per DC.
	 * 
	 * @param docBuilder
	 *            - Doc Builder to create the in memory xml representation.
	 * @param compositeName
	 *            - The composite name.
	 * 
	 */
	private void generateScaContributionXmlWithExport(final DocumentBuilder docBuilder, final String compositeName) {

		Document doc = docBuilder.newDocument();

		Element root = createScaContributionRootElement(doc);

		Element deployable = createScaContributionDeployableElement(compositeName, doc);

		Element export = doc.createElement("export"); //$//$NON-NLS-1$
		export.setAttribute("namespace", "http://www.sap.com/sca/content"); //$NON-NLS-1$ //$NON-NLS-2$
		root.appendChild(deployable);
		root.appendChild(export);
		doc.appendChild(root);

		storeScaContributionFile(doc);
	}

	/**
	 * @param doc
	 * @return
	 */
	private void storeScaContributionFile(Document doc) {
		String path = this.genDir + File.separator + META_INF;
		String filename = path + File.separator + SCA_CONTRIBUTION + XMLSCAConstants.XML_FILE_EXTENSION;

		XmlExportService.storeXmlDocument(doc, filename);

		Log.info("			[SCDL-EXPORT] sca contribution XML output location: " + filename); //$NON-NLS-1$
	}

	/**
	 * @param compositeName
	 * @param doc
	 * @return
	 */
	private Element createScaContributionDeployableElement(final String compositeName, Document doc) {
		Element deployable = doc.createElement("deployable"); //$NON-NLS-1$
		deployable.setAttribute("composite", "sap:" + convertCompositeName(compositeName)); //$NON-NLS-1$ //$NON-NLS-2$
		return deployable;
	}

	/**
	 * @param doc
	 * @return
	 */
	private Element createScaContributionRootElement(Document doc) {
		Element root = doc.createElement("contribution"); //$NON-NLS-1$
		root.setAttribute("xmlns", XMLSCAConstants.SCA_NAMESPACE); //$NON-NLS-1$
		root.setAttribute("xmlns:sap", XMLSCAConstants.SCA_SAP_NAMESPACE); //$NON-NLS-1$
		return root;
	}

	/**
	 * Converts the name of the composite into a valid format. By default, the DC name is 
	 * used, but the DC name could contain illegal characters. '/' and '\' are used in sca
	 * as a sepatator inside attribute values. Therefore, attribute values should not use
	 * these characters unless they explicitly need such a separator. 
	 * 
	 * @param name
	 * @return
	 */
	private String convertCompositeName(String name) {
		return name.replace('\\', '~').replace('/', '~');
	}
}