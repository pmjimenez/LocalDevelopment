/**
 * 
 */
package com.sap.bie.sca.scdl.adapter;


/**
 * Represents the service element in the SCA assembly model.
 * 
 * @author d038406
 *
 */
public interface IService extends IComponentElement 
{
	/**
	 * Specify whether a component interface element is promoted to composite level or not.
	 * 
	 * @return true or false
	 */
	boolean isPromoted();
}
