package com.sap.bie.sca.scdl.gen.util;

import java.io.File;
import java.io.IOException;

import com.sap.bie.sca.scdl.gen.ScdlGeneratorBuildFileCreator;
import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.gen.IGeneratorCall;
import com.sap.tc.buildplugin.util.BuildPluginException;
import com.sap.tc.buildplugin.util.IAntToolkit;

public class EcBuildFileCreatorHelper {

	private static final String DEFAULT = "default"; //$NON-NLS-1$
	public static final String MOIN_OUTPUT_FOLDER = "gensrc/extcfg"; //$NON-NLS-1$
	
	public static void createGeneratorCallPart(IGlobalPluginUtil gpu, IPluginBuildInfo pbi, String chainId)
			throws BuildPluginException {
		// calls the generator chain defined in .bpfext which generates the MM
		IGeneratorCall gc = gpu.createGeneratorCall(chainId);
		// the following parameter is necessary for moininit
		gc.setOutputPath(DEFAULT, pbi.getTempDir().getAbsolutePath());
		gc.setParameter("outputFolderName", MOIN_OUTPUT_FOLDER); //$NON-NLS-1$
		gc.invoke();
	}

	public static void createScdlDeployArchivePreparationPart(IGlobalPluginUtil gpu, IPluginBuildInfo pbi, IAntToolkit antToolKit,
			String chainId, String generatorId) throws IOException {
		
		String scdlOutputFolder = pbi.getTempDir().getAbsolutePath() + "/" + ScdlGeneratorBuildFileCreator.SCDL_OUTPUT;//$NON-NLS-1$
		//create the folder for the scdl files as we don´t know if the generator will create it later(due to empty metadata)
		File outputFolder = new File(scdlOutputFolder);
		if(!outputFolder.exists()) {
			outputFolder.mkdirs();
		}
		

		antToolKit.taskdef("prepda"); //$NON-NLS-1$
		IAntToolkit.Element entity = antToolKit.createElement("prepda"); //$NON-NLS-1$
		IAntToolkit.Element filesetChild = entity.createChild("fileset"); //$NON-NLS-1$
		filesetChild.addAttribute("dir", scdlOutputFolder); //$NON-NLS-1$
		IAntToolkit.Element includeChild = filesetChild.createChild("include"); //$NON-NLS-1$
		includeChild.addAttribute("name", "META-INF/**"); //$NON-NLS-1$ //$NON-NLS-2$
		entity.render();
	}
}
