package com.sap.bie.sca.scdl.mc.gen.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.IReference;
import com.sap.bie.sca.scdl.gen.mc.IMcMetamodelInteraction;
import com.sap.bie.sca.scdl.gen.mc.IMcReferenceExtensionContribution;
import com.sap.bie.sca.scdl.gen.mc.IMcReferenceGenerator;
import com.sap.bie.sca.scdl.gen.mc.NoSuchServiceReferenceExistsException;
import com.sap.bie.sca.scdl.mc.adapter.McRefInterface;
import com.sap.bie.sca.scdl.mc.adapter.McReference;
import com.sap.bie.sca.scdl.mc.build.extension.McScdlReferenceBuildExtensionService;
import com.sap.ide.es.config.mc.model.mc.authentication.AuthenticationType;
import com.sap.ide.es.config.mc.model.mc.authentication.AuthenticationTypeEnum;
import com.sap.ide.es.config.mc.model.mc.servicereferences.ServiceReference;

public class McReferenceGeneratorImpl implements IMcReferenceGenerator {
	private final String SCDL_TYPE_NO_AUTHENTICATION = "noAuthentication"; //$NON-NLS-1$
	private final String SCDL_TYPE_BUSINESS_USER = "businessUser"; //$NON-NLS-1$
	private final String SCDL_TYPE_TECHNICAL_USER = "technicalUser"; //$NON-NLS-1$
	private final String SCDL_TYPE_BUSINESS_OR_TECHNICAL_USER = "businessOrTechnicalUser"; //$NON-NLS-1$

	private IMcMetamodelInteraction mcMetamodelInteractor;

	public McReferenceGeneratorImpl(IMcMetamodelInteraction mcMetamodelInteractor) {
		this.mcMetamodelInteractor = mcMetamodelInteractor;
	}

	protected IMcMetamodelInteraction getMcMetamodelInteractor() {
		return this.mcMetamodelInteractor;
	}

	private String getScdlApId(AuthenticationType type) {
		if (type.equals(AuthenticationTypeEnum.NO_AUTHENTICATION)) {
			return SCDL_TYPE_NO_AUTHENTICATION;
		}
		else if (type.equals(AuthenticationTypeEnum.BUSINESS_USER)) {
			return SCDL_TYPE_BUSINESS_USER;
		}
		else if (type.equals(AuthenticationTypeEnum.TECHNICAL_USER)) {
			return SCDL_TYPE_TECHNICAL_USER;
		}
		else if (type.equals(AuthenticationTypeEnum.BUSINESS_OR_TECHNICAL_USER)) {
			return SCDL_TYPE_BUSINESS_OR_TECHNICAL_USER;
		}
		else {
			throw new IllegalArgumentException("Unrecognized authentication type: " + type); //$NON-NLS-1$
		}
	}

	public List<IReference> genReferences(String[] srIds, String[] wsdlLocations)
			throws NoSuchServiceReferenceExistsException {
		final Set<IReference> refs = new HashSet<IReference>();

		for (int jj = 0; jj < srIds.length; jj++) {
			refs.add(createReference(srIds[jj], wsdlLocations[jj]));
		}

		return new ArrayList<IReference>(refs);
	}

	private IReference createReference(final String srId, final String wsdlLocation) throws NoSuchServiceReferenceExistsException
	{
		final McReference ref = new McReference(srId);

		final ServiceReference sRef = getMcMetamodelInteractor().getServiceReference(srId);
		ref.setAuthProfileName(getScdlApId(sRef.getAuthenticationProfile().getType()));
		ref.setSrvGroupName(getMcMetamodelInteractor().getServiceGroupName(sRef.getLogicalSystem()));

		final String refType;
		if (sRef.getScdlBindingType() == null) {
			refType = sRef.getType().toString().toLowerCase(Locale.ENGLISH);
		}
		else {
			refType = sRef.getScdlBindingType();
		}


		McRefInterface mcRefInterface = new McRefInterface(
				new QName(sRef.getPorttype().getNamespace(), sRef.getPorttype().getName()),
				wsdlLocation);
		ref.setScainterface(mcRefInterface);
		Map<String, IMcReferenceExtensionContribution> scdlRefContributors = McScdlReferenceBuildExtensionService.getContributors();
		for(String scdlRefContributerKey : scdlRefContributors.keySet()) {
			IMcReferenceExtensionContribution scdlRefContributor = scdlRefContributors.get(scdlRefContributerKey);
			if(scdlRefContributor.getSupportedServiceReferenceType()==null ||
					scdlRefContributor.getSupportedServiceReferenceType().equalsIgnoreCase(refType)) {
				scdlRefContributor.applyCustomization(McScdlReferenceBuildExtensionService.getCon(), McScdlReferenceBuildExtensionService.getPluginBuildInfo(), sRef, ref);
			}
		}
		if(ref.getBinding()==null) {
			throw new IllegalArgumentException("No binding type support contributed at build time for binding type: " + refType); //$NON-NLS-1$
		}

		return ref;
	}

	public List<IReference> genReferences(String[] srIds) throws NoSuchServiceReferenceExistsException {
		return genReferences(srIds, new String[srIds.length]);
	}

	public List<IReference> genReferences(String srvGroupName,
			Map<String, String> portTypeQualifiedName) throws NoSuchServiceReferenceExistsException {
		return genReferences(srvGroupName, portTypeQualifiedName, null);
	}

	public List<IReference> genReferences(String srvGroupName,
			Map<String, String> portTypeQualifiedName,
			Map<String, String> wsdlLocations)	throws NoSuchServiceReferenceExistsException {
		Set<String> srIds = new HashSet<String>();
		List<String> identifiedWsdlLocations = new ArrayList<String>();

		for(String key : portTypeQualifiedName.keySet()) {
			if(portTypeQualifiedName.get(key)!=null && portTypeQualifiedName.get(key).length() > 0) {
				srIds.add(getMcMetamodelInteractor().getServiceReferenceId(srvGroupName, key, portTypeQualifiedName.get(key)));
				if(wsdlLocations.containsKey(key+portTypeQualifiedName.get(key))) {
					identifiedWsdlLocations.add(wsdlLocations.get(key+portTypeQualifiedName.get(key)));
				}
			}
		}

		return genReferences(srIds.toArray(new String[srIds.size()]), identifiedWsdlLocations.toArray(new String[identifiedWsdlLocations.size()]));
	}

	public List<IReference> genReferences(String srvGroupName,
			String portTypeName, String portTypeNamespace) throws NoSuchServiceReferenceExistsException {
		Map<String, String> portTypeQualifiedName = new HashMap<String, String>();
		portTypeQualifiedName.put(portTypeNamespace, portTypeName);

		return genReferences(srvGroupName, portTypeQualifiedName);
	}

	public List<IReference> genReferences(String srvGroupName,
			String portTypeName, String portTypeNamespace, String wsdlLocation) throws NoSuchServiceReferenceExistsException {
		Map<String, String> portTypeQualifiedName = new HashMap<String, String>();
		portTypeQualifiedName.put(portTypeNamespace, portTypeName);
		Map<String, String> wsdlLocations = new HashMap<String, String>();
		wsdlLocations.put(portTypeNamespace+portTypeName, wsdlLocation);

		return genReferences(srvGroupName, portTypeQualifiedName, wsdlLocations);
	}

	public List<IReference> genReferences(String srvGroupName) throws NoSuchServiceReferenceExistsException {
		return genReferences(srvGroupName, ""); //$NON-NLS-1$
	}

	public List<IReference> genReferences(String srvGroupName,
			String wsdlLocation) throws NoSuchServiceReferenceExistsException {
		List<String> identifiedWsdlLocations = new ArrayList<String>();
		List<String> srIdsFound = getMcMetamodelInteractor().getServiceReferenceIds(srvGroupName);

		for(@SuppressWarnings("unused") String srId : srIdsFound) {
			identifiedWsdlLocations.add(wsdlLocation);
		}

		return genReferences(srIdsFound.toArray(new String[srIdsFound.size()]), identifiedWsdlLocations.toArray(new String[identifiedWsdlLocations.size()]));
	}

	public Map<QName, List<IReference>> genReferences(final Map<QName, String> portTypesMap) throws NoSuchServiceReferenceExistsException
	{
		final Map<QName, List<IReference>> scaReferences = new HashMap<QName, List<IReference>>(portTypesMap.size());
		for (QName portTypeName : portTypesMap.keySet()) {
			scaReferences.put(portTypeName, new ArrayList<IReference>());
		}

		final Map<QName, List<ServiceReference>> serviceReferences = getMcMetamodelInteractor().getServiceReferences(portTypesMap.keySet());
		for (QName qName : serviceReferences.keySet()) {
			for(ServiceReference serviceRef : serviceReferences.get(qName)) {
				IReference reference = createReference(serviceRef.getId(), portTypesMap.get(qName));
				scaReferences.get(qName).add(reference);
			}
		}

		return scaReferences;
	}
}
