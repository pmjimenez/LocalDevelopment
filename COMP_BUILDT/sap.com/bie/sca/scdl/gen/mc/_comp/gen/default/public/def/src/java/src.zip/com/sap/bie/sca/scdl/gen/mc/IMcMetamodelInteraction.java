package com.sap.bie.sca.scdl.gen.mc;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;

import com.sap.ide.es.config.mc.model.mc.logicalsystem.LogicalSystem;
import com.sap.ide.es.config.mc.model.mc.servicereferences.ServiceReference;

public interface IMcMetamodelInteraction {
	/**
	 * @param srId - the service reference id which will be searched in MC metamodel scoped by
	 * the currently built dc
	 * @return the service reference instance
	 * @throws NoSuchServiceReferenceExistsException if such service reference is not found
	 * in the MC metamodel
	 */
	public ServiceReference getServiceReference(String srId) throws NoSuchServiceReferenceExistsException;
	
	/**
	 * Based on a service group name and port type name and port type namespace finds a 
	 * service reference in MC metamodel. The service reference is unique based on these search
	 * criteria. 
	 * 
	 * @param srvGroupName - a name of a service group
	 * @param portTypeNamespace - a port type namespace
	 * @param portTypeName - a port type name
	 * @return the service reference id found
	 * @throws NoSuchServiceReferenceExistsException if such service reference is not found
	 * in the MC metamodel
	 */
	public String getServiceReferenceId(String srvGroupName, String portTypeNamespace, String portTypeName) throws NoSuchServiceReferenceExistsException;
	
	/**
	 * 
	 * @return The list of all service references found within the scope of the currently built
	 * dc. If no services references are found and empty list is returned.
	 */
	public List<ServiceReference> getAllServiceReferences();
	
	/**
	 * @param srvGroupName - a name of a service group 
	 * @return The list of ids of all service references found within the scope of the currently 
	 * built dc which belong to the given service group. If no services references are found and 
	 * empty list is returned.
	 */
	public List<String> getServiceReferenceIds(final String srvGroupName);
	
	/**
	 * 
	 * @param portTypeNames - a list of qualified port types (port type name and port type namespace)
	 * @return a list of service references representing a port type in the portTypeNames collection
	 * and belonging to different service groups. Will return an empty list if such does not 
	 * exist in the currently built dc.
	 */
	public Map<QName, List<ServiceReference>> getServiceReferences(final Collection<QName> portTypeNames);
	
	/**
	 * Based on the service group instance this method will return its fully qualified name
	 * as a string, which will contain the service group package, if any, and the service group
	 * name itself at the end. The package and service group name will be concatenated with
	 * '.' symbol.
	 * 
	 * @param srvGroup - the service group instance for which the fully qualified name of the
	 * service group will be returned
	 * @return the fully qualified name of the service group which means the package and the
	 * service group name altogether like this 'package1.package2.srvgrpname'
	 */
	public String getServiceGroupName(LogicalSystem srvGroup);
	
	/**
	 * 
	 * @return all service groups hosted in the currently built dc
	 */
	public List<LogicalSystem> getLogicalSystems();
}
