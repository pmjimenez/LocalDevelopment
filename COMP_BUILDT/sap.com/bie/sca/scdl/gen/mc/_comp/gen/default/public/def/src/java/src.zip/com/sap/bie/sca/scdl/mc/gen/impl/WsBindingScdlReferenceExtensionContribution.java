package com.sap.bie.sca.scdl.mc.gen.impl;

import java.util.Locale;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.gen.mc.IMcReferenceExtensionContribution;
import com.sap.bie.sca.scdl.gen.mc.IMcScdlReference;
import com.sap.bie.sca.scdl.mc.adapter.McBinding;
import com.sap.ide.es.config.mc.model.mc.servicereferences.ServiceReference;
import com.sap.ide.es.config.mc.model.mc.servicereferences.ServiceReferenceTypeEnum;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.moin.repository.Connection;

public class WsBindingScdlReferenceExtensionContribution implements
		IMcReferenceExtensionContribution {
	@Override
	public void applyCustomization(Connection conn, IPluginBuildInfo pbi,
			ServiceReference serviceRef, IMcScdlReference scdlReference) {
		scdlReference.setBinding(new McBinding(new QName(null, ServiceReferenceTypeEnum.WS.toString().toLowerCase(Locale.ENGLISH), "")));
	}

	@Override
	public String getSupportedServiceReferenceType() {
		return ServiceReferenceTypeEnum.WS.toString();
	}
}
