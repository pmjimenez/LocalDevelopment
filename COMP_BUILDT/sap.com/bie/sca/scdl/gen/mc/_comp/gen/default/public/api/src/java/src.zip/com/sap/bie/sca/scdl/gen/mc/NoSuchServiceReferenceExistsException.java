package com.sap.bie.sca.scdl.gen.mc;

public class NoSuchServiceReferenceExistsException extends Exception {
	private static final long serialVersionUID = 1L;

	public NoSuchServiceReferenceExistsException(String message) {
		super(message);
	}
}
