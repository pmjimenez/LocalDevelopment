package com.sap.bie.sca.scdl.gen.mc;

import com.sap.bie.sca.scdl.adapter.IBinding;
import com.sap.bie.sca.scdl.adapter.ICustomScdlElement;
import com.sap.bie.sca.scdl.adapter.ICustomizableElement;
import com.sap.bie.sca.scdl.adapter.IInterface;
import com.sap.bie.sca.scdl.adapter.IReference;

/**
 * Representation of Mass Configuration scdl reference. Contributors to MC scdl reference generation will receive as
 * a context an instance of this interface. 
 * 
 * @author I036201
 *
 */
public interface IMcScdlReference extends IReference, ICustomizableElement {
	/**
	 * Sets the scdl binding for a scdl reference.
	 * 
	 * @param binding - the binding instance to be stored in the generated scdl file
	 */
	public void setBinding(IBinding binding);
	
	/**
	 * Sets the service group name of the scdl reference.
	 * 
	 * @param srvGroupName - service group name to be stored in the generated scdl file
	 */
	public void setSrvGroupName(String srvGroupName);
	
	/**
	 * Sets the authentication profile name for a scdl reference.
	 * 
	 * @param authProfileName - the authentication profile name to be stored in the generated scdl file
	 */
	public void setAuthProfileName(final String authProfileName);
	
	/**
	 * Sets the SCA interface element for a scdl reference.
	 * 
	 * @param scdlInterface - the sca interface element to be stored in the generated scdl file
	 */
	public void setScainterface(final IInterface scdlInterface);
	
	/**
	 * Sets a custom element as child to the scdl reference.
	 * 
	 * @param customScdlElement - a custom element to be stored in the generated scdl file
	 * @return <code>true</code> if the custom element is not <code>null</code> and vice versa
	 */
	public boolean addCustomElement(final ICustomScdlElement customScdlElement);
}
