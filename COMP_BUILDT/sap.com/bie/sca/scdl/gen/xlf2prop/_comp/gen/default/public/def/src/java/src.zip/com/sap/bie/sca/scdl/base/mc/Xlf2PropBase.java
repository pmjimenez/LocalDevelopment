/**
 *
 */
package com.sap.bie.sca.scdl.base.mc;

import java.io.IOException;

import com.sap.tc.buildplugin.AbstractBuildFileCreatorLibrary;
import com.sap.tc.buildplugin.BuildSessionManager;
import com.sap.tc.buildplugin.api.IBuildFileCreator;
import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.util.BuildPluginException;
import com.sap.tc.buildplugin.util.IAntToolkit;

/**
 *
 * @author i036201
 *
 */
public class Xlf2PropBase extends AbstractBuildFileCreatorLibrary implements IBuildFileCreator {

	private static final String GENERATOR_ID = "sap.com~xlf2prop_gen_chain"; //$NON-NLS-1$
	private static final String ANT_BASE = "antBase"; //$NON-NLS-1$

	/* (non-Javadoc)
	 * @see com.sap.tc.buildplugin.api.IBuildFileCreator#render(com.sap.tc.buildplugin.util.IAntToolkit)
	 */
	public void render(IAntToolkit arg0) throws BuildPluginException,
			IOException {
		IPluginBuildInfo pbi = (IPluginBuildInfo) BuildSessionManager.getFromBuildSession(IPluginBuildInfo.class.getName());
		IGlobalPluginUtil gpu = (IGlobalPluginUtil) BuildSessionManager.getFromBuildSession(IGlobalPluginUtil.class.getName());
		IAntToolkit kit = (IAntToolkit) getToolkit(ANT_BASE);

		Xlf2PropBuildFileCreatorHelper.createGeneratorCallPart(gpu, pbi, GENERATOR_ID);
		Xlf2PropBuildFileCreatorHelper.createScdlDeployArchivePreparationPart(gpu, pbi, kit, "", "");	//$NON-NLS-1$  //$NON-NLS-2$
	}
}
