package com.sap.bie.sca.scdl.pp.mc;

import com.sap.tc.buildplugin.pp.AbstractEntityHandler;
import com.sap.tc.buildplugin.pp.EntityDataProvider;
import com.sap.tc.buildplugin.pp.IEntityFileSet;
import com.sap.tc.buildplugin.pp.PackException;
import com.sap.tc.buildplugin.pp.PackerDestination;
import com.sap.tc.buildplugin.pp.api.IEntity;
import com.sap.tc.buildplugin.pp.util.FileSet;
import com.sap.tc.buildplugin.pp.util.PathIdentifier;

public class Xlf2PropEntityHandler extends AbstractEntityHandler {
	public void determineFileList(IEntityFileSet entityFileSet, IEntity entity, EntityDataProvider entityDataProvider) throws PackException {
		PathIdentifier path = new PathIdentifier(PathIdentifier.BASE_GEN, "xlf_out");
		FileSet fs = entityDataProvider.createFileSet(path);
		entityFileSet.addFlatFileSet(PackerDestination.JAVALIB, fs, "META-INF/sca-resources/");
		fs.dispose();
	}
}
