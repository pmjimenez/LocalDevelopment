package com.sap.caf.core.services.bi;

/**
 * This enumeration represents possible operators that can be used in
 * a BI selection.
 * @author Trendafil Madarov 
 */
public enum BIOperator {

	/**
	 * Constant representing the operator 'EQUALS'
	 */
	EQ,
	
	/**
	 * Constant representing the operator 'BETWEEN'
	 */	
	BW	
}