
package com.sap.caf.core.services.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for RelatedObject complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RelatedObject">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="key" type="{http://www.sap.com/caf/sap.com/caf.core/services}Id" minOccurs="0"/>
 *         &lt;element name="createdBy" type="{http://www.sap.com/caf/sap.com/caf.core/services}UserId" minOccurs="0"/>
 *         &lt;element name="createdAt" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="modifiedAt" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="modifiedBy" type="{http://www.sap.com/caf/sap.com/caf.core/services}UserId" minOccurs="0"/>
 *         &lt;element name="refObjectKey" type="{http://www.sap.com/caf/sap.com/caf.core/services}Id" minOccurs="0"/>
 *         &lt;element name="refObjectType" type="{http://www.sap.com/caf/sap.com/caf.core/services}LongText" minOccurs="0"/>
 *         &lt;element name="refObjectRid" type="{http://www.sap.com/caf/sap.com/caf.core/services}Rid" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RelatedObject", propOrder = {
    "key",
    "createdBy",
    "createdAt",
    "modifiedAt",
    "modifiedBy",
    "refObjectKey",
    "refObjectType",
    "refObjectRid"
})
public class RelatedObject implements com.sap.caf.rt.bol.IBusinessObjectNodeBase, java.io.Serializable {

    protected String key;
    protected String createdBy;
    protected XMLGregorianCalendar createdAt;
    protected XMLGregorianCalendar modifiedAt;
    protected String modifiedBy;
    protected String refObjectKey;
    protected String refObjectType;
    protected String refObjectRid;

    /**
     * Gets the value of the key property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKey() {
        return key;
    }

    /**
     * Sets the value of the key property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKey(String value) {
        this.key = value;
    }

    /**
     * Gets the value of the createdBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the value of the createdBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatedBy(String value) {
        this.createdBy = value;
    }

    /**
     * Gets the value of the createdAt property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCreatedAt() {
        return createdAt;
    }

    /**
     * Sets the value of the createdAt property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCreatedAt(XMLGregorianCalendar value) {
        this.createdAt = value;
    }

    /**
     * Gets the value of the modifiedAt property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getModifiedAt() {
        return modifiedAt;
    }

    /**
     * Sets the value of the modifiedAt property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setModifiedAt(XMLGregorianCalendar value) {
        this.modifiedAt = value;
    }

    /**
     * Gets the value of the modifiedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModifiedBy() {
        return modifiedBy;
    }

    /**
     * Sets the value of the modifiedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModifiedBy(String value) {
        this.modifiedBy = value;
    }

    /**
     * Gets the value of the refObjectKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefObjectKey() {
        return refObjectKey;
    }

    /**
     * Sets the value of the refObjectKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefObjectKey(String value) {
        this.refObjectKey = value;
    }

    /**
     * Gets the value of the refObjectType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefObjectType() {
        return refObjectType;
    }

    /**
     * Sets the value of the refObjectType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefObjectType(String value) {
        this.refObjectType = value;
    }

    /**
     * Gets the value of the refObjectRid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefObjectRid() {
        return refObjectRid;
    }

    /**
     * Sets the value of the refObjectRid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefObjectRid(String value) {
        this.refObjectRid = value;
    }

	private static final transient java.lang.String[] _CAF_PROPERTY_NAMES = new java.lang.String[] {
			"key", "createdBy", "createdAt", "modifiedAt", "modifiedBy",
			"refObjectKey", "refObjectType", "refObjectRid" };
	@javax.xml.bind.annotation.XmlTransient
	private java.lang.String __caf_object_type;

	@javax.xml.bind.annotation.XmlTransient
	public java.lang.String getObjectType() {
		return __caf_object_type;
	}

	/**
	 * Specifies the object type.
	 * @param objectType  - the object type value.
	 * @see #getObjectType
	 */
	public void setObjectType(java.lang.String objectType) {
		this.__caf_object_type = objectType;
	}

	/**
	 * Returns structure properties' names
	 * @return  properties names
	 */
	@javax.xml.bind.annotation.XmlTransient
	public java.lang.String[] getPropertyList() {
		return _CAF_PROPERTY_NAMES;
	}

	@java.lang.SuppressWarnings("unchecked")
	public java.lang.Object getProperty(java.lang.String _propertyName) {
		if (_propertyName.equals("key"))
			return getKey();
		if (_propertyName.equals("createdBy"))
			return getCreatedBy();
		if (_propertyName.equals("createdAt"))
			return getCreatedAt();
		if (_propertyName.equals("modifiedAt"))
			return getModifiedAt();
		if (_propertyName.equals("modifiedBy"))
			return getModifiedBy();
		if (_propertyName.equals("refObjectKey"))
			return getRefObjectKey();
		if (_propertyName.equals("refObjectType"))
			return getRefObjectType();
		if (_propertyName.equals("refObjectRid"))
			return getRefObjectRid();
		return null;
	}

	@java.lang.SuppressWarnings("unchecked")
	public void setProperty(java.lang.String _propertyName,
			java.lang.Object _value) {
		if (_propertyName.equals("key"))
			setKey((java.lang.String) _value);
		else if (_propertyName.equals("createdBy"))
			setCreatedBy((java.lang.String) _value);
		else if (_propertyName.equals("createdAt"))
			setCreatedAt((javax.xml.datatype.XMLGregorianCalendar) _value);
		else if (_propertyName.equals("modifiedAt"))
			setModifiedAt((javax.xml.datatype.XMLGregorianCalendar) _value);
		else if (_propertyName.equals("modifiedBy"))
			setModifiedBy((java.lang.String) _value);
		else if (_propertyName.equals("refObjectKey"))
			setRefObjectKey((java.lang.String) _value);
		else if (_propertyName.equals("refObjectType"))
			setRefObjectType((java.lang.String) _value);
		else if (_propertyName.equals("refObjectRid"))
			setRefObjectRid((java.lang.String) _value);
	}

	public boolean equals(java.lang.Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final com.sap.caf.core.services.types.RelatedObject other = (com.sap.caf.core.services.types.RelatedObject) obj;
		if (getKey() == null) {
			if (other.getKey() != null)
				return false;
		} else if (!getKey().equals(other.getKey()))
			return false;
		return true;
	}

	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result
				+ ((getKey() == null) ? 0 : getKey().hashCode());
		return result;
	}

}
