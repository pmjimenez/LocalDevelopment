
package com.sap.caf.core.services.appsrv.doccontent;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.sap.caf.core.services.appsrv.doccontent package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.sap.caf.core.services.appsrv.doccontent
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetLockInfoResponse }
     * 
     */
    public GetLockInfoResponse createGetLockInfoResponse() {
        return new GetLockInfoResponse();
    }

    /**
     * Create an instance of {@link GetCurrentVersionResponse }
     * 
     */
    public GetCurrentVersionResponse createGetCurrentVersionResponse() {
        return new GetCurrentVersionResponse();
    }

    /**
     * Create an instance of {@link ReadDocumentContent }
     * 
     */
    public ReadDocumentContent createReadDocumentContent() {
        return new ReadDocumentContent();
    }

    /**
     * Create an instance of {@link RelateDocumentResponse }
     * 
     */
    public RelateDocumentResponse createRelateDocumentResponse() {
        return new RelateDocumentResponse();
    }

    /**
     * Create an instance of {@link GetVersionHistory }
     * 
     */
    public GetVersionHistory createGetVersionHistory() {
        return new GetVersionHistory();
    }

    /**
     * Create an instance of {@link UploadDocumentWithType }
     * 
     */
    public UploadDocumentWithType createUploadDocumentWithType() {
        return new UploadDocumentWithType();
    }

    /**
     * Create an instance of {@link UnLockDocumentResponse }
     * 
     */
    public UnLockDocumentResponse createUnLockDocumentResponse() {
        return new UnLockDocumentResponse();
    }

    /**
     * Create an instance of {@link IsDocumentVersioned }
     * 
     */
    public IsDocumentVersioned createIsDocumentVersioned() {
        return new IsDocumentVersioned();
    }

    /**
     * Create an instance of {@link IsDocumentLockedResponse }
     * 
     */
    public IsDocumentLockedResponse createIsDocumentLockedResponse() {
        return new IsDocumentLockedResponse();
    }

    /**
     * Create an instance of {@link ReadDocumentContentResponse }
     * 
     */
    public ReadDocumentContentResponse createReadDocumentContentResponse() {
        return new ReadDocumentContentResponse();
    }

    /**
     * Create an instance of {@link GetVersionHistoryResponse }
     * 
     */
    public GetVersionHistoryResponse createGetVersionHistoryResponse() {
        return new GetVersionHistoryResponse();
    }

    /**
     * Create an instance of {@link Checkout }
     * 
     */
    public Checkout createCheckout() {
        return new Checkout();
    }

    /**
     * Create an instance of {@link DisableDocumentVersioningResponse }
     * 
     */
    public DisableDocumentVersioningResponse createDisableDocumentVersioningResponse() {
        return new DisableDocumentVersioningResponse();
    }

    /**
     * Create an instance of {@link UploadExtLink }
     * 
     */
    public UploadExtLink createUploadExtLink() {
        return new UploadExtLink();
    }

    /**
     * Create an instance of {@link UploadDocumentWithTypeResponse }
     * 
     */
    public UploadDocumentWithTypeResponse createUploadDocumentWithTypeResponse() {
        return new UploadDocumentWithTypeResponse();
    }

    /**
     * Create an instance of {@link EnableDocumentVersioningResponse }
     * 
     */
    public EnableDocumentVersioningResponse createEnableDocumentVersioningResponse() {
        return new EnableDocumentVersioningResponse();
    }

    /**
     * Create an instance of {@link CopyDocumentResponse }
     * 
     */
    public CopyDocumentResponse createCopyDocumentResponse() {
        return new CopyDocumentResponse();
    }

    /**
     * Create an instance of {@link GetRelatedObjectRidsResponse }
     * 
     */
    public GetRelatedObjectRidsResponse createGetRelatedObjectRidsResponse() {
        return new GetRelatedObjectRidsResponse();
    }

    /**
     * Create an instance of {@link AddRelatedObjectRid }
     * 
     */
    public AddRelatedObjectRid createAddRelatedObjectRid() {
        return new AddRelatedObjectRid();
    }

    /**
     * Create an instance of {@link IsDocumentVersionedResponse }
     * 
     */
    public IsDocumentVersionedResponse createIsDocumentVersionedResponse() {
        return new IsDocumentVersionedResponse();
    }

    /**
     * Create an instance of {@link RelateDocument }
     * 
     */
    public RelateDocument createRelateDocument() {
        return new RelateDocument();
    }

    /**
     * Create an instance of {@link CheckinResponse }
     * 
     */
    public CheckinResponse createCheckinResponse() {
        return new CheckinResponse();
    }

    /**
     * Create an instance of {@link UnlockDocumentWithToken }
     * 
     */
    public UnlockDocumentWithToken createUnlockDocumentWithToken() {
        return new UnlockDocumentWithToken();
    }

    /**
     * Create an instance of {@link LockDocument }
     * 
     */
    public LockDocument createLockDocument() {
        return new LockDocument();
    }

    /**
     * Create an instance of {@link SetAsCurrentVersionResponse }
     * 
     */
    public SetAsCurrentVersionResponse createSetAsCurrentVersionResponse() {
        return new SetAsCurrentVersionResponse();
    }

    /**
     * Create an instance of {@link DeleteVersion }
     * 
     */
    public DeleteVersion createDeleteVersion() {
        return new DeleteVersion();
    }

    /**
     * Create an instance of {@link CopyDocument }
     * 
     */
    public CopyDocument createCopyDocument() {
        return new CopyDocument();
    }

    /**
     * Create an instance of {@link DeleteVersionResponse }
     * 
     */
    public DeleteVersionResponse createDeleteVersionResponse() {
        return new DeleteVersionResponse();
    }

    /**
     * Create an instance of {@link GetRelatedObjectRids }
     * 
     */
    public GetRelatedObjectRids createGetRelatedObjectRids() {
        return new GetRelatedObjectRids();
    }

    /**
     * Create an instance of {@link EnableDocumentVersioning }
     * 
     */
    public EnableDocumentVersioning createEnableDocumentVersioning() {
        return new EnableDocumentVersioning();
    }

    /**
     * Create an instance of {@link SetAsCurrentVersion }
     * 
     */
    public SetAsCurrentVersion createSetAsCurrentVersion() {
        return new SetAsCurrentVersion();
    }

    /**
     * Create an instance of {@link AddRelatedObjectRidResponse }
     * 
     */
    public AddRelatedObjectRidResponse createAddRelatedObjectRidResponse() {
        return new AddRelatedObjectRidResponse();
    }

    /**
     * Create an instance of {@link GetLockInfo }
     * 
     */
    public GetLockInfo createGetLockInfo() {
        return new GetLockInfo();
    }

    /**
     * Create an instance of {@link RemoveRelatedObjectRid }
     * 
     */
    public RemoveRelatedObjectRid createRemoveRelatedObjectRid() {
        return new RemoveRelatedObjectRid();
    }

    /**
     * Create an instance of {@link UploadExtLinkResponse }
     * 
     */
    public UploadExtLinkResponse createUploadExtLinkResponse() {
        return new UploadExtLinkResponse();
    }

    /**
     * Create an instance of {@link GetDocumentVersionResponse }
     * 
     */
    public GetDocumentVersionResponse createGetDocumentVersionResponse() {
        return new GetDocumentVersionResponse();
    }

    /**
     * Create an instance of {@link IsAttachedResponse }
     * 
     */
    public IsAttachedResponse createIsAttachedResponse() {
        return new IsAttachedResponse();
    }

    /**
     * Create an instance of {@link RemoveRelatedObjectRidResponse }
     * 
     */
    public RemoveRelatedObjectRidResponse createRemoveRelatedObjectRidResponse() {
        return new RemoveRelatedObjectRidResponse();
    }

    /**
     * Create an instance of {@link DisableDocumentVersioning }
     * 
     */
    public DisableDocumentVersioning createDisableDocumentVersioning() {
        return new DisableDocumentVersioning();
    }

    /**
     * Create an instance of {@link Checkin }
     * 
     */
    public Checkin createCheckin() {
        return new Checkin();
    }

    /**
     * Create an instance of {@link IsDocumentLocked }
     * 
     */
    public IsDocumentLocked createIsDocumentLocked() {
        return new IsDocumentLocked();
    }

    /**
     * Create an instance of {@link UploadDocumentResponse }
     * 
     */
    public UploadDocumentResponse createUploadDocumentResponse() {
        return new UploadDocumentResponse();
    }

    /**
     * Create an instance of {@link CheckoutResponse }
     * 
     */
    public CheckoutResponse createCheckoutResponse() {
        return new CheckoutResponse();
    }

    /**
     * Create an instance of {@link GetDocumentVersion }
     * 
     */
    public GetDocumentVersion createGetDocumentVersion() {
        return new GetDocumentVersion();
    }

    /**
     * Create an instance of {@link GetCurrentVersion }
     * 
     */
    public GetCurrentVersion createGetCurrentVersion() {
        return new GetCurrentVersion();
    }

    /**
     * Create an instance of {@link IsAttached }
     * 
     */
    public IsAttached createIsAttached() {
        return new IsAttached();
    }

    /**
     * Create an instance of {@link UnlockDocumentWithTokenResponse }
     * 
     */
    public UnlockDocumentWithTokenResponse createUnlockDocumentWithTokenResponse() {
        return new UnlockDocumentWithTokenResponse();
    }

    /**
     * Create an instance of {@link LockDocumentResponse }
     * 
     */
    public LockDocumentResponse createLockDocumentResponse() {
        return new LockDocumentResponse();
    }

    /**
     * Create an instance of {@link UploadDocument }
     * 
     */
    public UploadDocument createUploadDocument() {
        return new UploadDocument();
    }

    /**
     * Create an instance of {@link UnLockDocument }
     * 
     */
    public UnLockDocument createUnLockDocument() {
        return new UnLockDocument();
    }

}
