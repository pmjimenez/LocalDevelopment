
package com.sap.caf.core.services.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for Document complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Document">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="createdBy" type="{http://www.sap.com/caf/sap.com/caf.core/services}UserId" minOccurs="0"/>
 *         &lt;element name="createdAt" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="modifiedAt" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="modifiedBy" type="{http://www.sap.com/caf/sap.com/caf.core/services}UserId" minOccurs="0"/>
 *         &lt;element name="title" type="{http://www.sap.com/caf/sap.com/caf.core/services}LongText" minOccurs="0"/>
 *         &lt;element name="link" type="{http://www.sap.com/caf/sap.com/caf.core/services}Rid" minOccurs="0"/>
 *         &lt;element name="description" type="{http://www.sap.com/caf/sap.com/caf.core/services}LongText" minOccurs="0"/>
 *         &lt;element name="contentLength" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="contentType" type="{http://www.sap.com/caf/sap.com/caf.core/services}ShortText" minOccurs="0"/>
 *         &lt;element name="parentFolder" type="{http://www.sap.com/caf/sap.com/caf.core/services}Rid"/>
 *         &lt;element name="documentId" type="{http://www.sap.com/caf/sap.com/caf.core/services}Rid"/>
 *         &lt;element name="key" type="{http://www.sap.com/caf/sap.com/caf.core/services}Id" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Document", propOrder = {
    "createdBy",
    "createdAt",
    "modifiedAt",
    "modifiedBy",
    "title",
    "link",
    "description",
    "contentLength",
    "contentType",
    "parentFolder",
    "documentId",
    "key"
})
public class Document implements com.sap.caf.rt.bol.IBusinessObjectNodeBase, java.io.Serializable {

    protected String createdBy;
    protected XMLGregorianCalendar createdAt;
    protected XMLGregorianCalendar modifiedAt;
    protected String modifiedBy;
    protected String title;
    protected String link;
    protected String description;
    protected Long contentLength;
    protected String contentType;
    @XmlElement(required = true, nillable = true)
    protected String parentFolder;
    @XmlElement(required = true, nillable = true)
    protected String documentId;
    protected String key;

    /**
     * Gets the value of the createdBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the value of the createdBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatedBy(String value) {
        this.createdBy = value;
    }

    /**
     * Gets the value of the createdAt property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCreatedAt() {
        return createdAt;
    }

    /**
     * Sets the value of the createdAt property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCreatedAt(XMLGregorianCalendar value) {
        this.createdAt = value;
    }

    /**
     * Gets the value of the modifiedAt property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getModifiedAt() {
        return modifiedAt;
    }

    /**
     * Sets the value of the modifiedAt property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setModifiedAt(XMLGregorianCalendar value) {
        this.modifiedAt = value;
    }

    /**
     * Gets the value of the modifiedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModifiedBy() {
        return modifiedBy;
    }

    /**
     * Sets the value of the modifiedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModifiedBy(String value) {
        this.modifiedBy = value;
    }

    /**
     * Gets the value of the title property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the value of the title property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitle(String value) {
        this.title = value;
    }

    /**
     * Gets the value of the link property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLink() {
        return link;
    }

    /**
     * Sets the value of the link property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLink(String value) {
        this.link = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the contentLength property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getContentLength() {
        return contentLength;
    }

    /**
     * Sets the value of the contentLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setContentLength(Long value) {
        this.contentLength = value;
    }

    /**
     * Gets the value of the contentType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContentType() {
        return contentType;
    }

    /**
     * Sets the value of the contentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContentType(String value) {
        this.contentType = value;
    }

    /**
     * Gets the value of the parentFolder property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentFolder() {
        return parentFolder;
    }

    /**
     * Sets the value of the parentFolder property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentFolder(String value) {
        this.parentFolder = value;
    }

    /**
     * Gets the value of the documentId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentId() {
        return documentId;
    }

    /**
     * Sets the value of the documentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentId(String value) {
        this.documentId = value;
    }

    /**
     * Gets the value of the key property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKey() {
        return key;
    }

    /**
     * Sets the value of the key property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKey(String value) {
        this.key = value;
    }

	private static final transient java.lang.String[] _CAF_PROPERTY_NAMES = new java.lang.String[] {
			"createdBy", "createdAt", "modifiedAt", "modifiedBy", "title",
			"link", "description", "contentLength", "contentType",
			"parentFolder", "documentId", "key" };
	@javax.xml.bind.annotation.XmlTransient
	private java.lang.String __caf_object_type;

	@javax.xml.bind.annotation.XmlTransient
	public java.lang.String getObjectType() {
		return __caf_object_type;
	}

	/**
	 * Specifies the object type.
	 * @param objectType  - the object type value.
	 * @see #getObjectType
	 */
	public void setObjectType(java.lang.String objectType) {
		this.__caf_object_type = objectType;
	}

	/**
	 * Returns structure properties' names
	 * @return  properties names
	 */
	@javax.xml.bind.annotation.XmlTransient
	public java.lang.String[] getPropertyList() {
		return _CAF_PROPERTY_NAMES;
	}

	@java.lang.SuppressWarnings("unchecked")
	public java.lang.Object getProperty(java.lang.String _propertyName) {
		if (_propertyName.equals("createdBy"))
			return getCreatedBy();
		if (_propertyName.equals("createdAt"))
			return getCreatedAt();
		if (_propertyName.equals("modifiedAt"))
			return getModifiedAt();
		if (_propertyName.equals("modifiedBy"))
			return getModifiedBy();
		if (_propertyName.equals("title"))
			return getTitle();
		if (_propertyName.equals("link"))
			return getLink();
		if (_propertyName.equals("description"))
			return getDescription();
		if (_propertyName.equals("contentLength"))
			return getContentLength();
		if (_propertyName.equals("contentType"))
			return getContentType();
		if (_propertyName.equals("parentFolder"))
			return getParentFolder();
		if (_propertyName.equals("documentId"))
			return getDocumentId();
		if (_propertyName.equals("key"))
			return getKey();
		return null;
	}

	@java.lang.SuppressWarnings("unchecked")
	public void setProperty(java.lang.String _propertyName,
			java.lang.Object _value) {
		if (_propertyName.equals("createdBy"))
			setCreatedBy((java.lang.String) _value);
		else if (_propertyName.equals("createdAt"))
			setCreatedAt((javax.xml.datatype.XMLGregorianCalendar) _value);
		else if (_propertyName.equals("modifiedAt"))
			setModifiedAt((javax.xml.datatype.XMLGregorianCalendar) _value);
		else if (_propertyName.equals("modifiedBy"))
			setModifiedBy((java.lang.String) _value);
		else if (_propertyName.equals("title"))
			setTitle((java.lang.String) _value);
		else if (_propertyName.equals("link"))
			setLink((java.lang.String) _value);
		else if (_propertyName.equals("description"))
			setDescription((java.lang.String) _value);
		else if (_propertyName.equals("contentLength"))
			setContentLength((java.lang.Long) _value);
		else if (_propertyName.equals("contentType"))
			setContentType((java.lang.String) _value);
		else if (_propertyName.equals("parentFolder"))
			setParentFolder((java.lang.String) _value);
		else if (_propertyName.equals("documentId"))
			setDocumentId((java.lang.String) _value);
		else if (_propertyName.equals("key"))
			setKey((java.lang.String) _value);
	}

	public boolean equals(java.lang.Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final com.sap.caf.core.services.types.Document other = (com.sap.caf.core.services.types.Document) obj;
		if (getKey() == null) {
			if (other.getKey() != null)
				return false;
		} else if (!getKey().equals(other.getKey()))
			return false;
		return true;
	}

	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result
				+ ((getKey() == null) ? 0 : getKey().hashCode());
		return result;
	}

}
