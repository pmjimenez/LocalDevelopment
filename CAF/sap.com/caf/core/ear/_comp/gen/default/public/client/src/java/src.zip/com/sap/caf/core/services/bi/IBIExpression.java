package com.sap.caf.core.services.bi;

import java.io.Serializable;

/**
 * Interface representing a BI expression - it could be a BI Composite expression
 * or a BI Selection
 * @author Trendafil Madarov 
 */
public interface IBIExpression extends Serializable {
}