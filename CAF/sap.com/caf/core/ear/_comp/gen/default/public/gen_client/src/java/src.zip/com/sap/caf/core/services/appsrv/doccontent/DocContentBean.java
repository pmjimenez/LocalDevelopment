package com.sap.caf.core.services.appsrv.doccontent;

public abstract class DocContentBean implements com.sap.caf.core.services.appsrv.doccontent.DocContentServiceLocal { //$JL-SER$ - static final long serialVersionUID is not declared

    public static final java.lang.String _PROVIDER = "sap.com";
    public static final java.lang.String _APPLICATION = "caf.core";
    public static final java.lang.String _APP_SRV_NAME = "DocContent";
    public static final java.lang.String _OBJECT_NAME = _PROVIDER + "/" + _APPLICATION + "/" + _APP_SRV_NAME;
    public static final java.lang.String _JARM_REQUEST = "XAP:APPSERV:" + _OBJECT_NAME;

    protected static final com.sap.tc.logging.Location _location = com.sap.tc.logging.Location.getLocation(DocContentBean.class);

	@javax.ejb.EJB (beanName="com.sap.caf.core.services.bonode.document.document.Document")
    private com.sap.caf.core.services.bonode.document.document.DocumentServiceLocal _dep_to_Document;

	@javax.ejb.EJB (beanName="com.sap.caf.core.services.bonode.document.document.relatedobject.RelatedObject")
    private com.sap.caf.core.services.bonode.document.document.relatedobject.RelatedObjectServiceLocal _dep_to_RelatedObject;    
    
    public DocContentBean() {
    
    }
    
	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	abstract public java.lang.String copyDocument(java.lang.String srcRid,java.lang.String dstBOGuid,java.lang.String dstBOName) throws com.sap.caf.rt.exception.CAFUpdateException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	abstract public java.lang.String uploadDocument(java.lang.String key,byte[] content) throws com.sap.caf.rt.exception.CAFCreateException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	abstract public java.lang.String uploadExtLink(java.lang.String url,java.lang.String key) throws com.sap.caf.rt.exception.CAFCreateException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	abstract public java.lang.Boolean isAttached(java.lang.String rid) throws com.sap.caf.rt.exception.CAFBaseException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	abstract public java.lang.String addRelatedObjectRid(java.lang.String boRid,java.lang.String documentKey,java.lang.String boGuid,java.lang.String boName) throws com.sap.caf.rt.exception.CAFUpdateException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	abstract public java.lang.String relateDocument(java.lang.String srcRid,java.lang.String dstBOGuid,java.lang.String dstBOName) throws com.sap.caf.rt.exception.CAFUpdateException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	abstract public java.lang.String removeRelatedObjectRid(java.lang.String boInstanceGuid,java.lang.String documentKey,java.lang.String boName) throws com.sap.caf.rt.exception.CAFUpdateException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	abstract public byte[] readDocumentContent(java.lang.String documentKey) throws com.sap.caf.rt.exception.CAFRetrieveException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	abstract public java.lang.Boolean isDocumentLocked(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	abstract public java.lang.Boolean unLockDocument(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	abstract public java.lang.Boolean isDocumentVersioned(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	abstract public void disableDocumentVersioning(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	abstract public void enableDocumentVersioning(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	abstract public void setAsCurrentVersion(java.lang.String historyRid,java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	abstract public void deleteVersion(java.lang.String historyRid) throws com.sap.caf.rt.exception.CAFServiceException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	abstract public java.util.List<java.lang.String> getVersionHistory(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	abstract public java.lang.String getCurrentVersion(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.SUPPORTS)
	abstract public com.sap.caf.core.services.types.DocumentLockInfo getLockInfo(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	abstract public com.sap.caf.core.services.types.Document getDocumentVersion(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	abstract public java.util.List<java.lang.String> getRelatedObjectRids(java.lang.String documentKey) throws com.sap.caf.rt.exception.CAFUpdateException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	abstract public java.lang.String uploadDocumentWithType(java.lang.String key,byte[] content,java.lang.String contentType,java.lang.String encoding) throws com.sap.caf.rt.exception.CAFCreateException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.MANDATORY)
	abstract public void checkout(java.lang.String rid) throws com.sap.caf.rt.exception.CAFUpdateException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.MANDATORY)
	abstract public void checkin(java.lang.String rid,byte[] docContent) throws com.sap.caf.rt.exception.CAFUpdateException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.MANDATORY)
	abstract public java.lang.String lockDocument(java.lang.String rid,java.lang.Integer lockType,java.lang.Integer lockScope,java.lang.Integer timeout) throws com.sap.caf.rt.exception.CAFUpdateException;

	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	abstract public java.lang.Boolean unlockDocumentWithToken(java.lang.String rid,java.lang.String lockToken) throws com.sap.caf.rt.exception.CAFUpdateException;


    protected com.sap.caf.core.services.bonode.document.document.DocumentServiceLocal getDocumentService() {
    	return _dep_to_Document;
    }
    
    protected com.sap.caf.core.services.bonode.document.document.relatedobject.RelatedObjectServiceLocal getRelatedObjectService() {
    	return _dep_to_RelatedObject;
    }
    
}