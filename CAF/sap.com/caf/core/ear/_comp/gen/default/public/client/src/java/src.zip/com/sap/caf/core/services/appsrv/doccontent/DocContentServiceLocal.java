package com.sap.caf.core.services.appsrv.doccontent;
 
public interface DocContentServiceLocal {

	public java.lang.String copyDocument(java.lang.String srcRid,java.lang.String dstBOGuid,java.lang.String dstBOName) throws com.sap.caf.rt.exception.CAFUpdateException;

	public java.lang.String uploadDocument(java.lang.String key,byte[] content) throws com.sap.caf.rt.exception.CAFCreateException;

	public java.lang.String uploadExtLink(java.lang.String url,java.lang.String key) throws com.sap.caf.rt.exception.CAFCreateException;

	public java.lang.Boolean isAttached(java.lang.String rid) throws com.sap.caf.rt.exception.CAFBaseException;

	public java.lang.String addRelatedObjectRid(java.lang.String boRid,java.lang.String documentKey,java.lang.String boGuid,java.lang.String boName) throws com.sap.caf.rt.exception.CAFUpdateException;

	public java.lang.String relateDocument(java.lang.String srcRid,java.lang.String dstBOGuid,java.lang.String dstBOName) throws com.sap.caf.rt.exception.CAFUpdateException;

	public java.lang.String removeRelatedObjectRid(java.lang.String boInstanceGuid,java.lang.String documentKey,java.lang.String boName) throws com.sap.caf.rt.exception.CAFUpdateException;

	public byte[] readDocumentContent(java.lang.String documentKey) throws com.sap.caf.rt.exception.CAFRetrieveException;

	public java.lang.Boolean isDocumentLocked(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException;

	public java.lang.Boolean unLockDocument(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException;

	public java.lang.Boolean isDocumentVersioned(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException;

	public void disableDocumentVersioning(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException;

	public void enableDocumentVersioning(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException;

	public void setAsCurrentVersion(java.lang.String historyRid,java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException;

	public void deleteVersion(java.lang.String historyRid) throws com.sap.caf.rt.exception.CAFServiceException;

	public java.util.List<java.lang.String> getVersionHistory(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException;

	public java.lang.String getCurrentVersion(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException;

	public com.sap.caf.core.services.types.DocumentLockInfo getLockInfo(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException;

	public com.sap.caf.core.services.types.Document getDocumentVersion(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException;

	public java.util.List<java.lang.String> getRelatedObjectRids(java.lang.String documentKey) throws com.sap.caf.rt.exception.CAFUpdateException;

	public java.lang.String uploadDocumentWithType(java.lang.String key,byte[] content,java.lang.String contentType,java.lang.String encoding) throws com.sap.caf.rt.exception.CAFCreateException;

	public void checkout(java.lang.String rid) throws com.sap.caf.rt.exception.CAFUpdateException;

	public void checkin(java.lang.String rid,byte[] docContent) throws com.sap.caf.rt.exception.CAFUpdateException;

	public java.lang.String lockDocument(java.lang.String rid,java.lang.Integer lockType,java.lang.Integer lockScope,java.lang.Integer timeout) throws com.sap.caf.rt.exception.CAFUpdateException;

	public java.lang.Boolean unlockDocumentWithToken(java.lang.String rid,java.lang.String lockToken) throws com.sap.caf.rt.exception.CAFUpdateException;

}
