package com.sap.caf.core.services.appsrv.doccontent;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.ejb.EJBException;

import com.sap.caf.core.services.bonode.document.document.DocumentBO;
import com.sap.caf.core.services.bonode.document.document.DocumentBean;
import com.sap.caf.core.services.bonode.document.document.DocumentService;
import com.sap.caf.core.services.types.Document;
import com.sap.caf.core.services.types.DocumentLockInfo;
import com.sap.caf.core.services.types.RelatedObject;
import com.sap.caf.km.da.RidUtils;
import com.sap.caf.km.ejb.data.document.DocumentProxyEJBLocal;
import com.sap.caf.km.ejb.data.util.INodeContent;
import com.sap.caf.km.ejb.data.util.INodeHeader;
import com.sap.caf.km.ejb.data.util.KMNodeException;
import com.sap.caf.resources.CAFApplicationProperties;
import com.sap.caf.rt.bol.da.km.DocumentDataAccessService;
import com.sap.caf.rt.bol.da.km.internal.KMDataAccess;
import com.sap.caf.rt.exception.CAFCreateException;
import com.sap.caf.rt.exception.CAFDataAccessException;
import com.sap.caf.rt.exception.CAFRetrieveException;
import com.sap.caf.rt.exception.CAFServiceException;
import com.sap.caf.rt.exception.CAFUpdateException;
import com.sap.caf.rt.util.DateUtils;
import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;


@javax.ejb.Stateless(name = "com.sap.caf.core.services.appsrv.doccontent.DocContent")
@javax.ejb.Local({ com.sap.caf.core.services.appsrv.doccontent.DocContentServiceLocal.class })
@javax.interceptor.Interceptors({ com.sap.caf.rt.interceptors.LogInterceptor.class })
public class DocContentBeanImpl extends DocContentBean {
	
	private static final Location location = Location.getLocation(DocContentBeanImpl.class);

	@com.sap.caf.dt.CAFOperation(name = "isDocumentLocked")
	public java.lang.Boolean isDocumentLocked(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException {
		try {
			return KMDataAccess.getDocumentProxyService().isDocumentLocked(rid);
		}
		catch (Exception e) {
			location.throwing(e);
			throw new CAFServiceException(location, e);
		}
	}

	@com.sap.caf.dt.CAFOperation(name = "getDocumentVersion")
	public com.sap.caf.core.services.types.Document getDocumentVersion(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException {
	    String parentFolder = RidUtils.getPath(rid);
	    String documentId = RidUtils.getName(rid);
	
	    try {
	    	INodeHeader header = KMDataAccess.getDocumentProxyService()
	    		.readDocumentHeader(documentId, parentFolder);
	
	    	//load document atributes
	      Document doc = new Document();
	      doc.setProperty("parentFolder", header.getParentRid());
	      doc.setProperty("documentId", header.getName());
	      doc.setProperty("title", header.getDisplayName());
	      doc.setProperty("description", header.getDescription());
	      doc.setProperty("createdBy", header.getCreatedBy());
	      doc.setProperty("createdAt", DateUtils.fromDate(header.getCreationdate().getTime()));
	      doc.setProperty("modifiedBy", header.getLastmodifiedBy());
	      doc.setProperty("modifiedAt", DateUtils.fromDate(header.getLastmodifieddate().getTime()));
	      doc.setProperty("link", header.getLink());
	      doc.setProperty("contentLength", header.getSize());
	      return (Document)doc;
	    }
	    catch (Exception e) {
		  location.throwing(e);
	      throw new CAFServiceException(location, e);
	    }
	}

	@com.sap.caf.dt.CAFOperation(name = "uploadDocument")
	public java.lang.String uploadDocument(java.lang.String key, byte[] content) throws com.sap.caf.rt.exception.CAFCreateException {
		return uploadDocumentWithType(key, content, null, null);
	}

	@com.sap.caf.dt.CAFOperation(name = "isDocumentVersioned")
	public java.lang.Boolean isDocumentVersioned(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException {
		try {
			return KMDataAccess.getDocumentProxyService().isDocumentVersioned(rid);
		}
		catch (Exception e) {
			throw new CAFServiceException(location, e);
		}
	}

	@com.sap.caf.dt.CAFOperation(name = "getCurrentVersion")
	public java.lang.String getCurrentVersion(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException {
		try {
			return KMDataAccess.getDocumentProxyService().getCurrentVersion(rid);
		}
		catch (Exception e) {
			throw new CAFServiceException(location, e);
		}
	}

	@com.sap.caf.dt.CAFOperation(name = "unLockDocument")
	public java.lang.Boolean unLockDocument(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException {
		try {
			return KMDataAccess.getDocumentProxyService().unlockDocument(rid);
		}
		catch (Exception e) {
			throw new CAFServiceException(location, e);
		}
	}

	@com.sap.caf.dt.CAFOperation(name = "copyDocument")
	public java.lang.String copyDocument(java.lang.String srcRid, java.lang.String dstBOGuid, java.lang.String dstBOName) throws com.sap.caf.rt.exception.CAFUpdateException {
		try {
				return KMDataAccess.getDocumentProxyService().copyBODocument(dstBOName, dstBOGuid, srcRid);
		} catch (Exception e) {
			throw new CAFUpdateException(location, e);
		}
	}

	@com.sap.caf.dt.CAFOperation(name = "removeRelatedObjectRid")
	public java.lang.String removeRelatedObjectRid(java.lang.String boInstanceGuid, java.lang.String documentKey, java.lang.String boName) throws com.sap.caf.rt.exception.CAFUpdateException {
		try {
			Document doc = getDocumentService().read(documentKey);
			if (doc==null) {
				return null;
			}
			String[] relObjKeys = getDocumentService().getRelatedObjectRefs(documentKey);
			if (relObjKeys==null || relObjKeys.length==0) {
				return null;
			}
			String relObjKey; 
			RelatedObject relObj;
			for(int i=0; i<relObjKeys.length; i++) {
				relObjKey = relObjKeys[i];
				relObj = getRelatedObjectService().read(relObjKey);
				if (boName.equals(relObj.getRefObjectType()) && boInstanceGuid.equals(relObj.getRefObjectKey())) {
					getDocumentService().removeRelatedObjectRefs(documentKey, relObjKey);
					getRelatedObjectService().delete(relObj);
					break;
				}
			}
			getDocumentService().update(doc);
			return documentKey;
		} catch (Exception e) {
			throw new CAFUpdateException(location, e);
		}
	}

	@com.sap.caf.dt.CAFOperation(name = "getRelatedObjectRids")
	public java.util.List<java.lang.String> getRelatedObjectRids(java.lang.String documentKey) throws com.sap.caf.rt.exception.CAFUpdateException {
		try {
			String[] refObjKeys = getDocumentService().getRelatedObjectRefs(documentKey);
			if (refObjKeys==null || refObjKeys.length==0) {
				return new ArrayList<String>();
			}
			List<String> relObjRids = new ArrayList<String>(refObjKeys.length);
			RelatedObject relObj;
			for(int i=0; i<refObjKeys.length; i++) {
				try {
					relObj = getRelatedObjectService().read((String)refObjKeys[i]);
					relObjRids.add(relObj.getRefObjectRid());
				}
				catch(CAFRetrieveException e) {
        			location.traceThrowableT(Severity.INFO, e.getMessage(), e);
				}
			}
			return relObjRids;
		} catch (Exception e) {
			throw new CAFUpdateException(location, e);
		}
	}

	@com.sap.caf.dt.CAFOperation(name = "addRelatedObjectRid")
	public java.lang.String addRelatedObjectRid(java.lang.String boRid, java.lang.String documentKey, java.lang.String boGuid, java.lang.String boName) throws com.sap.caf.rt.exception.CAFUpdateException {
		try {
			DocumentService documentService = getDocumentService();
			Document doc = getDocumentService().read(documentKey);
				
			String sOldRid = doc.getParentFolder()+'/'+doc.getDocumentId();			
			Collection<String> docRids = new ArrayList<String>(1);
			docRids.add(sOldRid);

			//copy document into BO folder
			Collection newDocRids = KMDataAccess.getDocumentProxyService()
				.copyAttachedKMDocuments(boName, boGuid, docRids);

			//get new RID for document							 
			String newDocRid = (String) newDocRids.iterator().next();
			
			//store new KM parentFolder and documentId into JPA 
			doc.setParentFolder(RidUtils.getPath(newDocRid));
			doc.setDocumentId(RidUtils.getName(newDocRid));			
			getDocumentDataAccessService().store(doc);
			
			//re-read document from new _location (in order to get modifiedAt from KM)
			doc = documentService.read(documentKey);

			RelatedObject relObj = getRelatedObjectService().create();
			relObj.setRefObjectKey(boGuid);
			relObj.setRefObjectRid(newDocRid);
			relObj.setRefObjectType(boName);
			getRelatedObjectService().update(relObj);
			documentService.addRelatedObjectRefs(documentKey, relObj.getKey());

			//store changes and rise notification
			documentService.update(doc);		

			//delete doc if it was uploaded into temp folder
			if (!newDocRid.equals(sOldRid)) { 				
				try  {
					KMDataAccess.getDocumentProxyService()
						.deleteDocument(RidUtils.getName(sOldRid), RidUtils.getPath(sOldRid));
				}
				catch (Exception e) { // $JL-EXC$
					location.traceThrowableT(Severity.INFO, e.getMessage(), e);
				}
			}			
						
			return doc.getKey();
		} catch (Exception e) {
			throw new CAFUpdateException(location, e);
		}
	}

	@com.sap.caf.dt.CAFOperation(name = "relateDocument")
	public java.lang.String relateDocument(java.lang.String srcRid, java.lang.String dstBOGuid, java.lang.String dstBOName) throws com.sap.caf.rt.exception.CAFUpdateException {
		try {
			return KMDataAccess.getDocumentProxyService().relateKMDocument(dstBOName, dstBOGuid, srcRid); //getUploadService().relateKMDocument(dstBOName, dstBOGuid, srcRid);
		} catch (Exception e) {
			throw new CAFUpdateException(location, e);
		}
	}

	@com.sap.caf.dt.CAFOperation(name = "uploadExtLink")
	public java.lang.String uploadExtLink(java.lang.String url, java.lang.String key) throws com.sap.caf.rt.exception.CAFCreateException {
		try {
			DocumentDataAccessService das = getDocumentDataAccessService();
			Document doc = (Document) das.load(key);
			doc.setLink(url);
			das.store(doc);
			return doc.getKey();
		}
		catch (Exception e) {
			throw new CAFCreateException(location, e);
		}
	}

	@com.sap.caf.dt.CAFOperation(name = "disableDocumentVersioning")
	public void disableDocumentVersioning(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException {
		try {
			KMDataAccess.getDocumentProxyService().disableDocumentVersioning(rid);
		}
		catch (Exception e) {
			throw new CAFServiceException(location, e);
		}		
	}

	@com.sap.caf.dt.CAFOperation(name = "deleteVersion")
	public void deleteVersion(java.lang.String historyRid) throws com.sap.caf.rt.exception.CAFServiceException {
		try {
			KMDataAccess.getDocumentProxyService().deleteVersion(historyRid);
		}
		catch (Exception e) {
			throw new CAFServiceException(location, e);
		}
	}

	@com.sap.caf.dt.CAFOperation(name = "isAttached")
	public java.lang.Boolean isAttached(java.lang.String rid) throws com.sap.caf.rt.exception.CAFBaseException {
		return rid.startsWith(CAFApplicationProperties.getKMTmpRepositoryFolder());			
	}

	@com.sap.caf.dt.CAFOperation(name = "readDocumentContent")
	public byte[] readDocumentContent(java.lang.String documentKey) throws com.sap.caf.rt.exception.CAFRetrieveException {
		try {
			DocumentDataAccessService service = getDocumentDataAccessService();

			Document doc = 
				(Document)service
							.load(documentKey);							
			
			INodeContent data = KMDataAccess
									.getDocumentProxyService() 
										.readDocumentContent(doc.getDocumentId(), 
															 doc.getParentFolder());
			byte[] content = data.getContent();
			return content;
		} catch (Exception e) {
			throw new CAFRetrieveException(location, e);
		}		
	}

	@com.sap.caf.dt.CAFOperation(name = "enableDocumentVersioning")
	public void enableDocumentVersioning(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException {
		try {
			KMDataAccess.getDocumentProxyService().enableDocumentVersioning(rid);
		}
		catch (Exception e) {
			throw new CAFServiceException(location, e);
		}
	}

	@com.sap.caf.dt.CAFOperation(name = "getLockInfo")
	public com.sap.caf.core.services.types.DocumentLockInfo getLockInfo(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException {
		try {
			DocumentProxyEJBLocal docProxy = KMDataAccess.getDocumentProxyService();
			String lockOwnwer = docProxy.getLockOwner(rid);
			boolean allowUnlock = docProxy.authorizationCheck(rid);
			DocumentLockInfo docLockInfo = new DocumentLockInfo();
			docLockInfo.setLockOwner(lockOwnwer);
			docLockInfo.setAllowUnlock(allowUnlock);
			return docLockInfo;
		}
		catch (Exception e) {
			throw new CAFServiceException(location, e);
		}
	}

	@com.sap.caf.dt.CAFOperation(name = "setAsCurrentVersion")
	public void setAsCurrentVersion(java.lang.String historyRid, java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException {
		try {
			KMDataAccess.getDocumentProxyService().setAsCurrentVersion(historyRid, rid);
		}
		catch (Exception e) {
			throw new CAFServiceException(location, e);
		}
	}

	@com.sap.caf.dt.CAFOperation(name = "getVersionHistory")
	public java.util.List<java.lang.String> getVersionHistory(java.lang.String rid) throws com.sap.caf.rt.exception.CAFServiceException {
		try {
			String[] versions = KMDataAccess.getDocumentProxyService().getVersionHistory(rid);
			if (versions==null || versions.length==0) {
				return null;
			}
			ArrayList<String> infos = new ArrayList<String>(versions.length);
			for(int i=versions.length; --i>=0; ) {
				infos.add(versions[i]);
			};
			return infos;
		}
		catch (Exception e) {
			throw new CAFServiceException(location, e);
		}
	}

	// Private stuff.
	
	@javax.persistence.PersistenceContext(unitName="sap.com.caf.core")
	private javax.persistence.EntityManager _entityManager;
	
    @javax.annotation.Resource
    protected javax.ejb.SessionContext _sessionContext;
	
	private DocumentDataAccessService getDocumentDataAccessService() {
		try {
			java.util.Map<String, Object> _properties = new java.util.HashMap<String, Object>();
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.ENTITY_MANAGER_PROPERTY, _entityManager);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.SESSION_CONTEXT_PROPERTY, _sessionContext);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_PERSISTENT_CLASS_PROPERTY, DocumentBO.class);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_PROVIDER_PROPERTY, DocumentBean._PROVIDER);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_APPLICATION_PROPERTY, DocumentBean._APPLICATION);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_SERVICE_NAME_PROPERTY, DocumentBean._BO_SRV_NAME);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_NAMESPACE_PROPERTY, DocumentBean._NAMESPACE);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_FULLY_QUALIFIED_NAME, DocumentBean._FULLY_QUALIFIED_NAME);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_OBJECT_NAME_PROPERTY, DocumentBean._OBJECT_NAME);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_OBJECT_TYPE_PROPERTY, DocumentBean._OBJECT_TYPE);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_MAIN_STRUCT_CLASS_PROPERTY, com.sap.caf.core.services.types.Document.class);
			
			DocumentDataAccessService das = (DocumentDataAccessService) com.sap.caf.rt.bol.da.DataAccessFactory.getDataAccessService(com.sap.caf.rt.bol.da.DataAccessFactory.DATASOURCE_KM, _properties);
			return das;
		} catch (CAFDataAccessException e) {
			throw new EJBException(e);
		}
	}

	@com.sap.caf.dt.CAFOperation(name = "uploadDocumentWithType")
	public java.lang.String uploadDocumentWithType(java.lang.String key, byte[] content, java.lang.String contentType, java.lang.String encoding) throws com.sap.caf.rt.exception.CAFCreateException {
		try {
			DocumentDataAccessService service = getDocumentDataAccessService();

			Document doc = (Document)service.load(key);			

			if (content==null) {
				content = new byte[0];
			}

			KMDataAccess.getDocumentProxyService()
				.saveDocumentContent(doc.getDocumentId(),
						 doc.getParentFolder(),
						 content.length,
						 contentType,
						 encoding,
						 content);

			return doc.getKey();
		}
		catch (Exception e) {
			throw new CAFCreateException(location, e);
		}
	}

	/**
	 * Check out a KM document for versioning.
	 * @since 04s SP13. this method will throw an exception if used with earlear versions of 04s KM backend.
	 * @throws  CAFUpdateException if the operation fails for some reason.
	 */
	@com.sap.caf.dt.CAFOperation(name = "checkout")
	public void checkout(java.lang.String rid) throws com.sap.caf.rt.exception.CAFUpdateException {
		try {
			KMDataAccess.getDocumentProxyService().checkoutDocument(rid);
		} catch (KMNodeException e) {
			throw new CAFUpdateException(location, e);
		}
	}

	/**
	 * Check in given KM document with given content.
	 * @since 04s SP13. this method will throw an exception if used with earlear versions of 04s KM backend.
	 * @param docContent Content of the document to be checked in.
	 * @throws  CAFUpdateException if the operation fails for some reason.
	 */
	@com.sap.caf.dt.CAFOperation(name = "checkin")
	public void checkin(java.lang.String rid, byte[] docContent) throws com.sap.caf.rt.exception.CAFUpdateException {
		try {
			KMDataAccess.getDocumentProxyService().checkinDocument(rid, docContent);
		} catch (KMNodeException e) {
			throw new CAFUpdateException(location, e);
		}
	}

	@com.sap.caf.dt.CAFOperation(name="lockDocument")
	public java.lang.String lockDocument(java.lang.String rid, java.lang.Integer lockType, java.lang.Integer lockScope, java.lang.Integer timeout) throws com.sap.caf.rt.exception.CAFUpdateException {
		String res = null; 
		try {
			res = KMDataAccess.getDocumentProxyService().lockDocument(rid, lockType, lockScope, timeout);
		} catch (KMNodeException e) {
			throw new CAFUpdateException(location, e);
		}
		return res;
	}

	@com.sap.caf.dt.CAFOperation(name = "unlockDocumentWithToken")
	public java.lang.Boolean unlockDocumentWithToken(java.lang.String rid, java.lang.String lockToken) throws com.sap.caf.rt.exception.CAFUpdateException {
		try {
			return new java.lang.Boolean (KMDataAccess.getDocumentProxyService().unlockDocument(rid, lockToken));
		}
		catch (Exception e) {
			location.throwing(e);
			throw new CAFUpdateException(location, e);
		}
	}
}