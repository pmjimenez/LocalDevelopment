package com.sap.caf.core.services.bonode.document.document;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.xml.datatype.XMLGregorianCalendar;

import com.sap.caf.core.services.types.Document;
import com.sap.caf.km.da.RidUtils;
import com.sap.caf.resources.CAFApplicationProperties;
import com.sap.caf.rt.bol.da.km.internal.KMHelper;
import com.sap.caf.rt.bol.pk.PrimaryKeyFactory;
import com.sap.caf.rt.bol.util.QueryFilter;
import com.sap.caf.rt.bol.util.QueryFilterFactory;
import com.sap.caf.rt.exception.CAFCreateException;
import com.sap.caf.rt.exception.CAFDataAccessException;
import com.sap.caf.rt.exception.CAFDeleteException;
import com.sap.caf.rt.exception.CAFFindException;
import com.sap.caf.rt.exception.CAFPermissionException;
import com.sap.caf.rt.exception.CAFRetrieveException;
import com.sap.caf.rt.exception.CAFUpdateException;
import com.sap.caf.rt.security.acl.CAFPermission;
import com.sap.caf.rt.security.util.CAFPermissionName;
import com.sap.caf.rt.services.eventing.EventCache;
import com.sap.caf.rt.services.eventing.EventException;
import com.sap.caf.rt.util.DateUtils;


@javax.ejb.Stateless(name = "com.sap.caf.core.services.bonode.document.document.Document")
@javax.ejb.Local({ com.sap.caf.core.services.bonode.document.document.DocumentServiceLocal.class })
@javax.interceptor.Interceptors({ com.sap.caf.rt.interceptors.LogInterceptor.class })
public class DocumentBeanImpl extends DocumentBean {

	public void delete(Document document) throws com.sap.caf.rt.exception.CAFDeleteException {
		final String user = sessionContext.getCallerPrincipal().getName();
		if (!checkPermission(CAFPermissionName.delete, document, user, _OBJECT_TYPE)) {
			Object[] permissionExceptionArgs = {user, CAFPermissionName.delete, null, _OBJECT_TYPE};
			throw new CAFDeleteException("BO_PERMISSION", permissionExceptionArgs);
		} 			
		try {
			_dataAccessService.remove(document);
//			if(CAFApplicationProperties.getPublishEnabled()){
//				// document index has the rid as a key unlike caf which uses guid.
//				// after doc being removed we don't have other way how to map guid to rid.
//				// so we have to change the doc key in the event
//				EventCache cache = EventCache.getInstance();
//				IEntityChangedEvent event = cache.getRecentEvent(document.getKey());
//				if (event!=null) {
//					event.setObjectKey(document.getParentFolder()+'/'+document.getDocumentId());
//				}
//			}
		} catch (CAFDataAccessException e) {
			throw new CAFDeleteException("BO_DELETE", e);
		} catch (EventException e) {
			throw new CAFDeleteException(e);
		}
 	}
	
	public void update(com.sap.caf.core.services.types.Document document) throws com.sap.caf.rt.exception.CAFUpdateException{
		final String user = sessionContext.getCallerPrincipal().getName();
		if (!checkPermission(CAFPermissionName.update, document, user, _OBJECT_TYPE)) {
			Object[] permissionExceptionArgs = {user, CAFPermissionName.update, null, _OBJECT_TYPE};
			throw new CAFUpdateException("BO_PERMISSION", permissionExceptionArgs);
		}			

		// optimistic locking
		Document oldDocument;
		try {
			oldDocument = read(document.getKey());			
		} catch (CAFRetrieveException e) {
			throw new CAFUpdateException("BO_UPDATE", e);
		}

		// check if document has already been updated by other thread
		Date dOldChanged = DateUtils.toDate(oldDocument.getModifiedAt());
		Date dChanged = DateUtils.toDate(document.getModifiedAt());
	
		if ((dOldChanged!=null && !dOldChanged.equals(dChanged)) || (dOldChanged==null && dChanged!=null))
		{
			CAFUpdateException e = new CAFUpdateException("BO_UPDATE");
			throw e;
		}

		// Set the administrational attributes
		document.setModifiedBy(user);
		document.setModifiedAt(DateUtils.fromDate(new Date()));		

		try {
			_dataAccessService.store(document);
		} catch (CAFDataAccessException e) {
			throw new CAFUpdateException("BO_UPDATE", e);
		}
 	}

	@TransactionAttribute(value=TransactionAttributeType.SUPPORTS)
	public java.util.List<Document> findAll() throws com.sap.caf.rt.exception.CAFFindException{
 		return new ArrayList<Document>();
	}
	
	/**
	 * The method gets document by its CAF key.
	 * 
	 * @param key	A key of a document
	 * @return document instance
	 * @throws CAFRetrieveException
	 */
	@TransactionAttribute(value=TransactionAttributeType.SUPPORTS)
	public com.sap.caf.core.services.types.Document read(java.lang.String key) throws com.sap.caf.rt.exception.CAFRetrieveException {
		final String user = sessionContext.getCallerPrincipal().getName();
		try {
			Document doc = (Document)_dataAccessService.load(key);
			if (!checkPermission(CAFPermissionName.read, doc, user, _OBJECT_TYPE)) {
				Object[] permissionExceptionArgs = { user, CAFPermissionName.read, null, _OBJECT_TYPE };
				throw new CAFRetrieveException("BO_PERMISSION",	permissionExceptionArgs);
			}
			return doc;
		} catch (CAFDataAccessException e) {
			throw new CAFRetrieveException("BO_READ", e);
		}
	}
	
	/**
	 * Create a new document instance by given parentFolder and documentId. 
	 * If parentFolder is null, temporary folder will be used.
	 * 
	 * @param parentFolder	KM parent folder RID, if null temp folder will be used
	 * @param documentId	An id of the document, it's used as a default title. If parentFolder is null, i.e.
	 * 										document is uploaded to the temp folder, the document key is used as a perfix for real document id,
	 * 										It means the whole rid will be: /<temp-folder-path>/<caf-doc-key>-documentId, if parentFolder is null
	 * 										and /parentFolder/documentId otherwise.
	 * @return	The new document instance
	 * @throws CAFCreateException
	 */
//	public com.sap.caf.core.services.types.Document create(String parentFolder, String key, String documentId) throws com.sap.caf.rt.exception.CAFCreateException{
	public com.sap.caf.core.services.types.Document create(String documentId, String parentFolder) throws com.sap.caf.rt.exception.CAFCreateException{
		String user = sessionContext.getCallerPrincipal().getName();
		if (!checkPermission(CAFPermissionName.create, null, user, _OBJECT_TYPE)) {
			Object[] permissionExceptionArgs = {user, CAFPermissionName.create, null, _OBJECT_TYPE};
			throw new CAFCreateException("BO_PERMISSION", permissionExceptionArgs);
		}
		Document document = new Document();
		document.setTitle(documentId); // documentId is a default title		

		// Set the administrational attributes
		Date changeDate = new Date();
		XMLGregorianCalendar changeCal = DateUtils.fromDate(changeDate);
		document.setCreatedBy(user);
		document.setCreatedAt(changeCal);
		document.setModifiedBy(user);
		document.setModifiedAt(changeCal);		
		
		try {
			document.setParentFolder(parentFolder==null || parentFolder.length()==0? 
					KMHelper.getTempFolderRid(): parentFolder);
		
			document.setKey(PrimaryKeyFactory.getInstance().getPrimaryKey());
			//For new documents set KM DocumentID equal to CAF Document KEY 
			document.setDocumentId(parentFolder==null || parentFolder.length()==0? 
					document.getKey()+'-'+documentId: documentId);						

//			Next line was added as workaround due to description is mandatory attribute for createResource operation in EP6SP6
			document.setDescription("CAF Document");
			
			_dataAccessService.create(document);
			Document newDoc = read(document.getKey());
			document.setCreatedAt(newDoc.getCreatedAt());
			document.setModifiedAt(newDoc.getModifiedAt());
			
			CAFPermission.createOwnerPermission(user, document.getKey());
			
			return document;		
		} catch (CAFDataAccessException e) {						
			throw new CAFCreateException("BO_CREATE", e);
		} catch (CAFRetrieveException e) {						
			throw new CAFCreateException("BO_CREATE", e);
		} catch (CAFPermissionException e) {						
			throw new CAFCreateException("BO_CREATE", e);
		}
	}
	

	public java.lang.String[] getRelatedObjectRefs(java.lang.String sourceKey) throws CAFRetrieveException {
		java.lang.String[] targetKeys = null;
		try {
			targetKeys = _dataAccessService.getCardinalityManyAssociationTargetKeys(sourceKey, "relatedObjectRefs");
		} catch (com.sap.caf.rt.exception.CAFDataAccessException e) {
			com.sap.caf.rt.exception.CAFRetrieveException e1 = new com.sap.caf.rt.exception.CAFRetrieveException("BO_READ", e);
			throw e1;
		}
		return targetKeys;
	}
	
	public void addRelatedObjectRefs(java.lang.String sourceKey, java.lang.String targetKey) throws CAFUpdateException {
		try {
			_dataAccessService.addCardinalityManyAssociationTargetKeys(sourceKey, new String[] {targetKey}, "relatedObjectRefs");
		} catch (com.sap.caf.rt.exception.CAFDataAccessException e) {
			com.sap.caf.rt.exception.CAFUpdateException _caf_ex = new com.sap.caf.rt.exception.CAFUpdateException("BO_UPDATE", e);
			throw _caf_ex;
		}
	}
	
	public void removeRelatedObjectRefs(java.lang.String sourceKey, java.lang.String targetKey) throws CAFUpdateException {
		final boolean isComposition = false;
		try {
			_dataAccessService.removeCardinalityManyAssociationTargetKeys(sourceKey, new String[] {targetKey}, "relatedObjectRefs", isComposition);
		} catch (com.sap.caf.rt.exception.CAFDataAccessException e) {
			com.sap.caf.rt.exception.CAFUpdateException _caf_ex = new com.sap.caf.rt.exception.CAFUpdateException("BO_UPDATE", e);
			throw _caf_ex;
		}
	}

	/**
	 * @see DocumentLocal#findByDocumentKey(com.sap.caf.rt.bol.util.QueryFilter) 
	 */
	public java.util.Collection<com.sap.caf.core.services.types.Document> findByDocumentKey(com.sap.caf.rt.bol.util.QueryFilter key) throws com.sap.caf.rt.exception.CAFFindException{
		String user = sessionContext.getCallerPrincipal().getName();
		try {
			String documentKey = (String)key.getValue();
			Document doc = (Document)_dataAccessService.load(documentKey);
			
			if (doc==null || !checkPermission(CAFPermissionName.read, doc, user, _OBJECT_TYPE)) {
				return new HashSet<Document>();
			}								
			HashSet<Document> retValue = new HashSet<Document>();
			retValue.add(doc);
			return retValue;
		} catch (Exception ex) {
			_location.throwing(ex);
			throw new CAFFindException(ex);
		}
	}
	
	/**
	 * @see DocumentLocal#findByTitle(com.sap.caf.rt.bol.util.QueryFilter, com.sap.caf.rt.bol.util.QueryFilter)
	 */
	public java.util.List<com.sap.caf.core.services.types.Document> findByTitle(com.sap.caf.rt.bol.util.QueryFilter title, com.sap.caf.rt.bol.util.QueryFilter parentFolder) throws com.sap.caf.rt.exception.CAFFindException{
		final String user = sessionContext.getCallerPrincipal().getName();
		try {			
			Collection resultQuery = _dataAccessService.query(new QueryFilter[] {title, parentFolder}, null);					
			return checkPermissions(resultQuery, CAFPermissionName.read, user, _OBJECT_TYPE);
		} catch (Exception ex) {
			throw new CAFFindException(ex);
		}
	}

	/**
	 * @see DocumentLocal#findByDocumentId(com.sap.caf.rt.bol.util.QueryFilter, com.sap.caf.rt.bol.util.QueryFilter)
	 */	
	public java.util.List<com.sap.caf.core.services.types.Document> findByDocumentId(String parentFolder, String documentId) throws com.sap.caf.rt.exception.CAFFindException{
		final String user = sessionContext.getCallerPrincipal().getName();
		try {
//			String docId = (String) documentId.getValue();
//			String pFolder = (String) parentFolder.getValue();
			String docId = (String) documentId;
			String pFolder = (String) parentFolder;
			
			QueryFilter[] qf = new QueryFilter[3];
			qf[0] = QueryFilterFactory.createFilter(docId);
			qf[0].setAttribute("documentId");
			qf[1] = QueryFilterFactory.createBoolOperator(QueryFilter.OPERATION_AND);
			qf[2] = QueryFilterFactory.createFilter(pFolder);
			qf[2].setAttribute("parentFolder");
			Collection result = _dataAccessService.query(qf, "");
			
//---			Collection result = _dataAccessService.query(_dataAccessContext, Document.class, new QueryFilter[] {documentId, parentFolder}, null); 
			return checkPermissions(result, CAFPermissionName.read, user, _OBJECT_TYPE);
		} catch (Exception ex) {
			throw new CAFFindException(ex);
		}
	}

	/**
	 * @see DocumentLocal#findByRid(com.sap.caf.rt.bol.util.QueryFilter)
	 */	
	public java.util.List<com.sap.caf.core.services.types.Document> findByRid(String rid) throws com.sap.caf.rt.exception.CAFFindException{
		try {
//			String rid = (String)parentFolder.getValue();
//			QueryFilter parentFolderFilter = QueryFilterFactory.createStringFilter(
//					QueryFilter.ACTION_EXACT, RidUtils.getPath(rid), "parentFolder", true);
//			parentFolderFilter.setCondition(Condition.EQ);
//				
//			QueryFilter docIdFilter = QueryFilterFactory.createStringFilter(
//					QueryFilter.ACTION_EXACT, RidUtils.getName(rid), "documentId", true);
//			docIdFilter.setCondition(Condition.EQ);
//			return findByDocumentId(parentFolderFilter, docIdFilter);
			return findByDocumentId(RidUtils.getPath(rid), RidUtils.getName(rid));
		} catch (CAFFindException ex) {
			throw ex;
		}
	}


	public java.util.Collection<com.sap.caf.core.services.types.Document> findByMultipleParameters(com.sap.caf.rt.bol.util.QueryFilter[] queryFilters, boolean implCheck, java.lang.String findByName) throws com.sap.caf.rt.exception.CAFFindException {
		java.lang.String user = sessionContext.getCallerPrincipal().getName();
    
		java.util.ArrayList<com.sap.caf.core.services.types.Document> result = new java.util.ArrayList<com.sap.caf.core.services.types.Document>();
	
		try {
			java.util.Collection resultSet = _dataAccessService.query(queryFilters, findByName);
			   
			XMLGregorianCalendar time = DateUtils.fromDate(new java.util.Date());     
			java.util.Iterator iter = resultSet.iterator();     
			while (iter.hasNext()) {      
				com.sap.caf.core.services.types.Document bo = (com.sap.caf.core.services.types.Document) iter.next();
			    
				if (bo.getCreatedBy() == null) {
					bo.setCreatedBy(user);
				}
				if (bo.getCreatedAt() == null) {
					bo.setCreatedAt(time);
				}
				if (bo.getModifiedBy() == null) {
					bo.setModifiedBy(user);
				}
				if (bo.getModifiedAt() == null) {
					bo.setModifiedAt(time);
				}       

			}
		} catch (Exception e) {
			com.sap.caf.rt.exception.CAFFindException _caf_ex = new com.sap.caf.rt.exception.CAFFindException("BO_FIND", e);
			throw _caf_ex;
		} 
		return result;
	} 

	/**
	 * Check permissions for each object of collection
	 * 
	 * @param objectList	Objects to check
	 * @param permission	Permission to check
	 * @param user			User to check permissions for
	 * @param objectName	
	 * @return filtered array of objects
	 */	
	private List<Document> checkPermissions(Collection objectList, String permission, String user, String objectName) {
		List<Document> filteredResult = new ArrayList<Document>(objectList.size());
		for (Iterator i = objectList.iterator(); i.hasNext(); ) {
			Document doc = (Document) i.next();
			if (checkPermission(permission, doc, user, _OBJECT_TYPE)) {
				filteredResult.add(doc);
			}
		}
		return filteredResult;
	}

	/*
	private boolean checkPermission(java.lang.String permission, com.sap.caf.rt.bol.IBusinessObjectNodeBase object, java.lang.String user, java.lang.String objectName) {
		boolean allowAccess = true;
		try {
			if (!com.sap.caf.rt.security.acl.CAFPermission.checkAclPermission(object, user, permission, objectName)) {
				allowAccess = false;
			}
		} catch (com.sap.caf.rt.exception.CAFPermissionException e) {
			allowAccess = false;
		}
		return allowAccess;
	}*/
}