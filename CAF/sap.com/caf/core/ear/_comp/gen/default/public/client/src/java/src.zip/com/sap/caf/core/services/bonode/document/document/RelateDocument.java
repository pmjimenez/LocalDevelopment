
package com.sap.caf.core.services.bonode.document.document;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.sap.caf.rt.bol.util.QueryFilter;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="srcRid" type="{http://www.sap.com/caf/query_filter}QueryFilter" minOccurs="0"/>
 *         &lt;element name="dstBOGuid" type="{http://www.sap.com/caf/query_filter}QueryFilter" minOccurs="0"/>
 *         &lt;element name="dstBOName" type="{http://www.sap.com/caf/query_filter}QueryFilter" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "srcRid",
    "dstBOGuid",
    "dstBOName"
})
@XmlRootElement(name = "relateDocument")
public class RelateDocument implements java.io.Serializable {

    protected QueryFilter srcRid;
    protected QueryFilter dstBOGuid;
    protected QueryFilter dstBOName;

    /**
     * Gets the value of the srcRid property.
     * 
     * @return
     *     possible object is
     *     {@link QueryFilter }
     *     
     */
    public QueryFilter getSrcRid() {
        return srcRid;
    }

    /**
     * Sets the value of the srcRid property.
     * 
     * @param value
     *     allowed object is
     *     {@link QueryFilter }
     *     
     */
    public void setSrcRid(QueryFilter value) {
        this.srcRid = value;
    }

    /**
     * Gets the value of the dstBOGuid property.
     * 
     * @return
     *     possible object is
     *     {@link QueryFilter }
     *     
     */
    public QueryFilter getDstBOGuid() {
        return dstBOGuid;
    }

    /**
     * Sets the value of the dstBOGuid property.
     * 
     * @param value
     *     allowed object is
     *     {@link QueryFilter }
     *     
     */
    public void setDstBOGuid(QueryFilter value) {
        this.dstBOGuid = value;
    }

    /**
     * Gets the value of the dstBOName property.
     * 
     * @return
     *     possible object is
     *     {@link QueryFilter }
     *     
     */
    public QueryFilter getDstBOName() {
        return dstBOName;
    }

    /**
     * Sets the value of the dstBOName property.
     * 
     * @param value
     *     allowed object is
     *     {@link QueryFilter }
     *     
     */
    public void setDstBOName(QueryFilter value) {
        this.dstBOName = value;
    }

}
