package com.sap.caf.core.services.bonode.document.document.relatedobject;
 
public abstract class RelatedObjectBean extends com.sap.caf.rt.bol.BusinessObjectNodeServiceBase implements RelatedObjectServiceLocal { //$JL-SER$ - static final long serialVersionUID is not declared

	public static final java.lang.String _objectGuid = "2006303D-2E5E-45F1-3941-B2DA520C";
	public static final java.lang.String _PROVIDER = "sap.com";
	public static final java.lang.String _APPLICATION = "caf.core";
	public static final java.lang.String _BO_SRV_NAME = "RelatedObject";
	public static final java.lang.String _NAMESPACE = "http://www.sap.com/caf/sap.com/caf.core";
	public static final java.lang.String _FULLY_QUALIFIED_NAME = "caf.core.services.RelatedObject";	
	public static final java.lang.String _OBJECT_NAME = "sap.com/http://www.sap.com/caf/sap.com/caf.core:caf.core/RelatedObject";
	public static final java.lang.String _OBJECT_TYPE = "sap.com/http://www.sap.com/caf/sap.com/caf.core:caf.core/caf.core.services.RelatedObject";
	protected static final java.lang.String _JARM_REQUEST = "XAP:BO:" + _OBJECT_NAME;
	
    protected static final com.sap.tc.logging.Location _location = com.sap.tc.logging.Location.getLocation(com.sap.caf.core.services.bonode.document.document.relatedobject.RelatedObjectBean.class);    

	protected com.sap.caf.rt.bol.da.IDataAccessService _dataAccessService;
	
	@javax.persistence.PersistenceContext(unitName="sap.com.caf.core")
	protected javax.persistence.EntityManager _entityManager;


	public RelatedObjectBean(){
	}
    
	@javax.annotation.PostConstruct
    protected void _init() {
    	_objectName = _OBJECT_NAME;
        try {
			java.util.Map<String, Object> _properties = new java.util.HashMap<String, Object>();
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.ENTITY_MANAGER_PROPERTY, _entityManager);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.SESSION_CONTEXT_PROPERTY, sessionContext);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_PERSISTENT_CLASS_PROPERTY, com.sap.caf.core.services.bonode.document.document.relatedobject.RelatedObjectBO.class);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_PROVIDER_PROPERTY, _PROVIDER);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_APPLICATION_PROPERTY, _APPLICATION);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_SERVICE_NAME_PROPERTY, _BO_SRV_NAME);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_NAMESPACE_PROPERTY, _NAMESPACE);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_FULLY_QUALIFIED_NAME, _FULLY_QUALIFIED_NAME);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_OBJECT_NAME_PROPERTY, _OBJECT_NAME);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_OBJECT_TYPE_PROPERTY, _OBJECT_TYPE);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_GUID_PROPERTY, _objectGuid);
			_properties.put(com.sap.caf.rt.bol.da.DataAccessFactory.BO_NODE_MAIN_STRUCT_CLASS_PROPERTY, com.sap.caf.core.services.types.RelatedObject.class);

			_dataAccessService = com.sap.caf.rt.bol.da.DataAccessFactory.getDataAccessService(com.sap.caf.rt.bol.da.DataAccessFactory.DATASOURCE_JPA, _properties);
        } catch (com.sap.caf.rt.exception.CAFDataAccessException _e) {
            _location.traceThrowableT(com.sap.tc.logging.Severity.ERROR, "Error in PostConstruct", _e);
            throw new javax.ejb.EJBException(_e);
        }
    }
    
    @javax.annotation.PreDestroy
    protected void _destroy() {
		_dataAccessService.destroy();
    }
    
	public com.sap.caf.core.services.types.RelatedObject create() throws com.sap.caf.rt.exception.CAFCreateException{
		java.lang.String method = _JARM_REQUEST + ":create()";
		java.lang.String user = sessionContext.getCallerPrincipal().getName();
		com.sap.caf.core.services.types.RelatedObject _boNodeStructure = null;
        
		try {
			com.sap.caf.core.services.types.ObjectFactory _objectFactory = new com.sap.caf.core.services.types.ObjectFactory();
	        _boNodeStructure = _objectFactory.createRelatedObject();
	        _boNodeStructure.setObjectType(_OBJECT_TYPE);


			_dataAccessService.create(_boNodeStructure);
			return _boNodeStructure;
		}
		catch (com.sap.caf.rt.exception.CAFDataAccessException _e) {
			sessionContext.setRollbackOnly();
	        _location.traceThrowableT(com.sap.tc.logging.Severity.ERROR, "Error in {0}. Error message is: {1}", new Object[] {method, _e.getMessage()}, _e);
            throw new com.sap.caf.rt.exception.CAFCreateException(_location, _e);
        }

	}

	public com.sap.caf.core.services.types.RelatedObject read(java.lang.String key) throws com.sap.caf.rt.exception.CAFRetrieveException{
		if (key == null) {
			throw new com.sap.caf.rt.exception.CAFRetrieveException(_location, "BO_CRUD_NULL_ARGUMENT", new String[]{"key"});
		}
		java.lang.String method = _JARM_REQUEST + ":read(java.lang.String,)";
		java.lang.String user = sessionContext.getCallerPrincipal().getName();
		try {
		    com.sap.caf.core.services.types.RelatedObject _boNodeStructure;
	      	_boNodeStructure = (com.sap.caf.core.services.types.RelatedObject) _dataAccessService.load(key);
	      	if (_boNodeStructure == null) {
	      		throw new com.sap.caf.rt.exception.CAFRetrieveException(_location, "BO_NOT_EXIST",  new Object[] {key});
	      	}
	      	_boNodeStructure.setObjectType(_OBJECT_TYPE);

			return _boNodeStructure;
		}
		catch (com.sap.caf.rt.exception.CAFDataAccessException _e) {
	        _location.traceThrowableT(com.sap.tc.logging.Severity.ERROR, "Error in {0}. Error message is: {1}", new Object[] {method, _e.getMessage()}, _e);		
            throw new com.sap.caf.rt.exception.CAFRetrieveException(_location, _e);
        }
        
	}

	public void update(com.sap.caf.core.services.types.RelatedObject input) throws com.sap.caf.rt.exception.CAFUpdateException,com.sap.caf.rt.exception.CAFOptimisticLockException,com.sap.caf.rt.exception.CAFPessimisticLockException{
		if (input == null) {
			throw new com.sap.caf.rt.exception.CAFUpdateException(_location, "BO_CRUD_NULL_ARGUMENT", new String[]{"input"});
		}
		java.lang.String method = _JARM_REQUEST + ":update(com.sap.caf.core.services.types.RelatedObject)";
		java.lang.String user = sessionContext.getCallerPrincipal().getName();
		 


		lock(input.getKey(), com.sap.caf.rt.bol.IBusinessObjectNodeServiceBase.MODE_WRITE);

		try {
			com.sap.caf.core.services.types.RelatedObject currentlyInStore = read(input.getKey());
			
			if (!almostEqual(currentlyInStore.getModifiedAt(), input.getModifiedAt())) {
				throw new com.sap.caf.rt.exception.CAFOptimisticLockException(_location, "EXCEPTION_OPTIMISTIC_LOCK_FAILED", new Object[]{_OBJECT_TYPE, input.getKey(), currentlyInStore.getModifiedAt(), input.getModifiedAt()});
			}
			input.setObjectType(_OBJECT_TYPE);
			_dataAccessService.store(input);
		} catch (com.sap.caf.rt.exception.CAFRetrieveException _e) {
		    throw new com.sap.caf.rt.exception.CAFUpdateException(_location, "BO_UPDATE", _e);
		} catch (com.sap.caf.rt.exception.CAFDataAccessException _e) {
			sessionContext.setRollbackOnly();
			_location.traceThrowableT(com.sap.tc.logging.Severity.ERROR, "Error in {0}. Error message is: {1}", new Object[] {method, _e.getMessage()}, _e);
			throw new com.sap.caf.rt.exception.CAFUpdateException(_location, "BO_UPDATE", _e);
		} finally {
			unlock(input.getKey(), com.sap.caf.rt.bol.IBusinessObjectNodeServiceBase.MODE_WRITE);
		}
	}

	public void delete(com.sap.caf.core.services.types.RelatedObject input) throws com.sap.caf.rt.exception.CAFDeleteException,com.sap.caf.rt.exception.CAFOptimisticLockException,com.sap.caf.rt.exception.CAFPessimisticLockException{
		if (input == null) {
			throw new com.sap.caf.rt.exception.CAFDeleteException(_location, "BO_CRUD_NULL_ARGUMENT", new String[]{"input"});
		}
		java.lang.String method = _JARM_REQUEST + ":delete(void)";
		java.lang.String user = sessionContext.getCallerPrincipal().getName();

		lock(input.getKey(), com.sap.caf.rt.bol.IBusinessObjectNodeServiceBase.MODE_WRITE);

		try {		
			input.setObjectType(_OBJECT_TYPE);
			 _dataAccessService.remove(input);
			com.sap.caf.rt.security.acl.CAFPermission.removeInheritedPermissionByInheriting(input.getKey());				 
        } catch (com.sap.caf.rt.exception.CAFDataAccessException _e) {
	        sessionContext.setRollbackOnly();
        	_location.traceThrowableT(com.sap.tc.logging.Severity.ERROR, "Error in {0}. Error message is: {1}", new Object[] {method, _e.getMessage()}, _e);
            throw new com.sap.caf.rt.exception.CAFDeleteException(_location, "BO_DELETE", _e);
        } catch (com.sap.caf.rt.exception.CAFPermissionException _e) {
	        sessionContext.setRollbackOnly();
            throw new com.sap.caf.rt.exception.CAFDeleteException(_location, "BO_DELETE", _e);
		} finally {
			unlock(input.getKey(), com.sap.caf.rt.bol.IBusinessObjectNodeServiceBase.MODE_WRITE);
		}
	}


	@java.lang.SuppressWarnings("unchecked")
	public java.util.List<com.sap.caf.core.services.types.RelatedObject> findAll() throws com.sap.caf.rt.exception.CAFFindException{
		java.lang.String method = _JARM_REQUEST + ":findAll(void)";
		java.lang.String user = sessionContext.getCallerPrincipal().getName();
		
        try {
            java.util.List<com.sap.caf.core.services.types.RelatedObject> _retval = (java.util.List<com.sap.caf.core.services.types.RelatedObject>) _dataAccessService.query(new com.sap.caf.rt.bol.util.QueryFilter[0], "findAll" );
			for (com.sap.caf.core.services.types.RelatedObject _item : _retval) {
				_item.setObjectType(_OBJECT_TYPE);
			}
			return _retval;
        } catch (com.sap.caf.rt.exception.CAFDataAccessException _e) {
        	_location.traceThrowableT(com.sap.tc.logging.Severity.ERROR, "Error in {0}. Error message is: {1}", new Object[] {method, _e.getMessage()}, _e);
            throw new com.sap.caf.rt.exception.CAFFindException(_location, "BO_FIND", _e);
        }
	}








	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	@java.lang.SuppressWarnings("unchecked")
	public java.util.List<com.sap.caf.core.services.types.RelatedObject> findByMultipleParameters(java.util.List<com.sap.caf.rt.bol.util.QueryFilter> queryFilters, java.lang.Boolean implCheck, java.lang.String findByName) throws com.sap.caf.rt.exception.CAFFindException {
		java.lang.String method = _JARM_REQUEST + ":findByMultipleParameters(java.util.List<com.sap.caf.rt.bol.util.QueryFilter>, boolean, String)";
		java.lang.String user = sessionContext.getCallerPrincipal().getName();

		com.sap.caf.rt.bol.util.QueryFilter[] queryFiltersArray = null;
		if (queryFilters != null) {
			queryFiltersArray = new com.sap.caf.rt.bol.util.QueryFilter[queryFilters.size()];
			queryFilters.toArray(queryFiltersArray);
		}

		try {
    	    java.util.List<com.sap.caf.core.services.types.RelatedObject> _retval = (java.util.List<com.sap.caf.core.services.types.RelatedObject>) _dataAccessService.query(queryFiltersArray, findByName );
			for (com.sap.caf.core.services.types.RelatedObject _item : _retval) {
				_item.setObjectType(_OBJECT_TYPE);
			}
        	return  _retval;
        } catch (com.sap.caf.rt.exception.CAFDataAccessException _e) {
        	_location.traceThrowableT(com.sap.tc.logging.Severity.ERROR, "Error in {0}. Error message is: {1}", new Object[] {method, _e.getMessage()}, _e);
            throw new com.sap.caf.rt.exception.CAFFindException(_location, "BO_FIND", _e);
        }
	} 
	
	
	@javax.ejb.TransactionAttribute (javax.ejb.TransactionAttributeType.REQUIRED)
	@java.lang.SuppressWarnings("unchecked")
	public java.util.List<com.sap.caf.core.services.types.RelatedObject> findByMultipleParameters(java.util.List<com.sap.caf.rt.bol.util.QueryFilter> queryFilters, com.sap.caf.rt.bol.util.OrderBy orderBy, com.sap.caf.rt.bol.util.Paging paging, java.lang.String findByName) throws com.sap.caf.rt.exception.CAFFindException {
		java.lang.String method = _JARM_REQUEST + ":findByMultipleParameters(java.util.List<com.sap.caf.rt.bol.util.QueryFilter>, boolean, String)";
		java.lang.String user = sessionContext.getCallerPrincipal().getName();

		com.sap.caf.rt.bol.util.QueryFilter[] queryFiltersArray = null;
		if (queryFilters != null) {
			queryFiltersArray = new com.sap.caf.rt.bol.util.QueryFilter[queryFilters.size()];
			queryFilters.toArray(queryFiltersArray);
		}

		try {
    	    java.util.List<com.sap.caf.core.services.types.RelatedObject> _retval = (java.util.List<com.sap.caf.core.services.types.RelatedObject>) _dataAccessService.query(queryFiltersArray, orderBy, paging, findByName );   	    
			for (com.sap.caf.core.services.types.RelatedObject _item : _retval) {
				_item.setObjectType(_OBJECT_TYPE);
			}
        	return  _retval;
        } catch (com.sap.caf.rt.exception.CAFDataAccessException _e) {
			_location.traceThrowableT(com.sap.tc.logging.Severity.ERROR, "Error in {0}. Error message is: {1}", new Object[] {method, _e.getMessage()}, _e);
            throw new com.sap.caf.rt.exception.CAFFindException(_location, "BO_FIND", _e);
        }
	} 
	
	public java.util.List<com.sap.caf.core.services.types.RelatedObject> findByMultipleParameters(com.sap.caf.rt.bol.util.QueryFilter[] queryFilters, com.sap.caf.rt.bol.util.OrderBy orderBy, com.sap.caf.rt.bol.util.Paging paging, java.lang.String findByName) throws com.sap.caf.rt.exception.CAFFindException {
		java.util.List<com.sap.caf.rt.bol.util.QueryFilter> _queryFiltersList = null;
		if (queryFilters != null) {
			_queryFiltersList = java.util.Arrays.asList(queryFilters);
		}
		return findByMultipleParameters(_queryFiltersList, orderBy, paging, findByName);
	}
	
	public java.util.List<com.sap.caf.core.services.types.RelatedObject> findByMultipleParameters(com.sap.caf.rt.bol.util.QueryFilter[] queryFilters, java.lang.Boolean implCheck, java.lang.String findByName) throws com.sap.caf.rt.exception.CAFFindException {
		java.util.List<com.sap.caf.rt.bol.util.QueryFilter> _queryFiltersList = null;
		if (queryFilters != null) {
			_queryFiltersList = java.util.Arrays.asList(queryFilters);
		}
		return findByMultipleParameters(_queryFiltersList, implCheck, findByName);
	}

}