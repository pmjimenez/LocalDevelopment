
package com.sap.caf.core.services.appsrv.doccontent;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.sap.caf.core.services.types.DocumentLockInfo;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DocumentLockInfo" type="{http://www.sap.com/caf/sap.com/caf.core/services}DocumentLockInfo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "documentLockInfo"
})
@XmlRootElement(name = "getLockInfoResponse")
public class GetLockInfoResponse implements java.io.Serializable {

    @XmlElement(name = "DocumentLockInfo")
    protected DocumentLockInfo documentLockInfo;

    /**
     * Gets the value of the documentLockInfo property.
     * 
     * @return
     *     possible object is
     *     {@link DocumentLockInfo }
     *     
     */
    public DocumentLockInfo getDocumentLockInfo() {
        return documentLockInfo;
    }

    /**
     * Sets the value of the documentLockInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocumentLockInfo }
     *     
     */
    public void setDocumentLockInfo(DocumentLockInfo value) {
        this.documentLockInfo = value;
    }

}
