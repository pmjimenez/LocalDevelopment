	
package com.sap.caf.core.services.bonode.document.document.relatedobject;

import static com.sap.caf.rt.util.JPAValuesConvertor.*;

@javax.persistence.Entity(name="com_sap_caf_core_services_bonode_document_document_relatedobject_RelatedObjectBO")
@javax.persistence.Table(name="XAP_CAF_SER_RELATF")

@com.sap.caf.rt.bol.da.jpa.annotations.CAFStructure(mainStructure=true, pojoClass=com.sap.caf.core.services.types.RelatedObject.class, version="1.1.0" )
public class RelatedObjectBO implements com.sap.caf.rt.bol.da.jpa.IPersistableBONode {


	private java.lang.String _key;
	private java.lang.String _createdBy;
	private java.sql.Timestamp _createdAt;
	private java.sql.Timestamp _modifiedAt;
	private java.lang.String _modifiedBy;
	private java.lang.String _refObjectRid;
	private java.lang.String _refObjectKey;
	private java.lang.String _refObjectType;



	public RelatedObjectBO() {
	
	}
	
	@Deprecated
	public void setCreatedAt(java.util.Date _createdAt) {
		this._createdAt = new java.sql.Timestamp(_createdAt.getTime());
	}
	
	@Deprecated
	public void setModifiedAt(java.util.Date _modifiedAt){
		this._modifiedAt = new java.sql.Timestamp(_modifiedAt.getTime());
	}



	@javax.persistence.Id
	@javax.persistence.Column(name="OBJECTKEY")

	@com.sap.caf.rt.bol.da.jpa.annotations.CAFAttribute(name="key", properties={@com.sap.caf.rt.bol.da.jpa.annotations.CAFProperty(key="length", value="36")})
	public java.lang.String getKey() {
		return this._key;
	}
	
	
	
	public void setKey(java.lang.String _key) {
		if (_key != null && _key.trim().length() == 0) {
			this._key = null;
		} else {
			this._key = _key;
		}
	}
	
	@javax.persistence.Column(name="CREATEDBY0")

	@com.sap.caf.rt.bol.da.jpa.annotations.CAFAttribute(name="createdBy", properties={@com.sap.caf.rt.bol.da.jpa.annotations.CAFProperty(key="length", value="32")})
	public java.lang.String getCreatedBy() {
		return this._createdBy;
	}
	
	
	
	public void setCreatedBy(java.lang.String _createdBy) {
		if (_createdBy != null && _createdBy.trim().length() == 0) {
			this._createdBy = null;
		} else {
			this._createdBy = _createdBy;
		}
	}
	
	@javax.persistence.Column(name="CREATEDAT0")
	@javax.persistence.Temporal(javax.persistence.TemporalType.TIMESTAMP)

	@com.sap.caf.rt.bol.da.jpa.annotations.CAFAttribute(name="createdAt", properties={})
	public java.sql.Timestamp getCreatedAt() {
		return this._createdAt;
	}
	
	
	
	public void setCreatedAt(java.sql.Timestamp _createdAt) {
		this._createdAt = _createdAt;
	}
	
	@javax.persistence.Column(name="MODIFIEDAT0")
	@javax.persistence.Temporal(javax.persistence.TemporalType.TIMESTAMP)

	@com.sap.caf.rt.bol.da.jpa.annotations.CAFAttribute(name="modifiedAt", properties={})
	public java.sql.Timestamp getModifiedAt() {
		return this._modifiedAt;
	}
	
	
	
	public void setModifiedAt(java.sql.Timestamp _modifiedAt) {
		this._modifiedAt = _modifiedAt;
	}
	
	@javax.persistence.Column(name="MODIFIEDBY0")

	@com.sap.caf.rt.bol.da.jpa.annotations.CAFAttribute(name="modifiedBy", properties={@com.sap.caf.rt.bol.da.jpa.annotations.CAFProperty(key="length", value="32")})
	public java.lang.String getModifiedBy() {
		return this._modifiedBy;
	}
	
	
	
	public void setModifiedBy(java.lang.String _modifiedBy) {
		if (_modifiedBy != null && _modifiedBy.trim().length() == 0) {
			this._modifiedBy = null;
		} else {
			this._modifiedBy = _modifiedBy;
		}
	}
	
	@javax.persistence.Column(name="REFOBJECTRID")

	@com.sap.caf.rt.bol.da.jpa.annotations.CAFAttribute(name="refObjectRid", properties={@com.sap.caf.rt.bol.da.jpa.annotations.CAFProperty(key="length", value="1024")})
	public java.lang.String getRefObjectRid() {
		return this._refObjectRid;
	}
	
	
	
	public void setRefObjectRid(java.lang.String _refObjectRid) {
		if (_refObjectRid != null && _refObjectRid.trim().length() == 0) {
			this._refObjectRid = null;
		} else {
			this._refObjectRid = _refObjectRid;
		}
	}
	
	@javax.persistence.Column(name="REFOBJECTKEY")

	@com.sap.caf.rt.bol.da.jpa.annotations.CAFAttribute(name="refObjectKey", properties={@com.sap.caf.rt.bol.da.jpa.annotations.CAFProperty(key="length", value="36")})
	public java.lang.String getRefObjectKey() {
		return this._refObjectKey;
	}
	
	
	
	public void setRefObjectKey(java.lang.String _refObjectKey) {
		if (_refObjectKey != null && _refObjectKey.trim().length() == 0) {
			this._refObjectKey = null;
		} else {
			this._refObjectKey = _refObjectKey;
		}
	}
	
	@javax.persistence.Column(name="REFOBJECTTYPE")

	@com.sap.caf.rt.bol.da.jpa.annotations.CAFAttribute(name="refObjectType", properties={@com.sap.caf.rt.bol.da.jpa.annotations.CAFProperty(key="length", value="256")})
	public java.lang.String getRefObjectType() {
		return this._refObjectType;
	}
	
	
	
	public void setRefObjectType(java.lang.String _refObjectType) {
		if (_refObjectType != null && _refObjectType.trim().length() == 0) {
			this._refObjectType = null;
		} else {
			this._refObjectType = _refObjectType;
		}
	}
	

	public Object getAttribute(java.lang.String name) {
		if ("key".equals(name))
			return getKey();
		if ("createdBy".equals(name))
			return getCreatedBy();
		if ("createdAt".equals(name))
			return getCreatedAt();
		if ("modifiedAt".equals(name))
			return getModifiedAt();
		if ("modifiedBy".equals(name))
			return getModifiedBy();
		if ("refObjectRid".equals(name))
			return getRefObjectRid();
		if ("refObjectKey".equals(name))
			return getRefObjectKey();
		if ("refObjectType".equals(name))
			return getRefObjectType();
		return null;
	}
	
	public void setAttribute(java.lang.String name, java.lang.Object value) {
		if ("key".equals(name)) {
	
			setKey( convertToJPAValue(value,java.lang.String.class,"key") );
		} else if ("createdBy".equals(name)) {
	
			setCreatedBy( convertToJPAValue(value,java.lang.String.class,"createdBy") );
		} else if ("createdAt".equals(name)) {
	
			setCreatedAt( convertToJPAValue(value,java.sql.Timestamp.class,"createdAt") );
		} else if ("modifiedAt".equals(name)) {
	
			setModifiedAt( convertToJPAValue(value,java.sql.Timestamp.class,"modifiedAt") );
		} else if ("modifiedBy".equals(name)) {
	
			setModifiedBy( convertToJPAValue(value,java.lang.String.class,"modifiedBy") );
		} else if ("refObjectRid".equals(name)) {
	
			setRefObjectRid( convertToJPAValue(value,java.lang.String.class,"refObjectRid") );
		} else if ("refObjectKey".equals(name)) {
	
			setRefObjectKey( convertToJPAValue(value,java.lang.String.class,"refObjectKey") );
		} else if ("refObjectType".equals(name)) {
	
			setRefObjectType( convertToJPAValue(value,java.lang.String.class,"refObjectType") );
		}
	}
	
	public Object getAttribute(Object structure, String name) {
		com.sap.caf.core.services.types.RelatedObject struct = (com.sap.caf.core.services.types.RelatedObject) structure;
		
		if ("key".equals(name))
			return struct.getKey();
		
		if ("createdBy".equals(name))
			return struct.getCreatedBy();
		
		if ("createdAt".equals(name))
			return struct.getCreatedAt();
		
		if ("modifiedAt".equals(name))
			return struct.getModifiedAt();
		
		if ("modifiedBy".equals(name))
			return struct.getModifiedBy();
		
		if ("refObjectRid".equals(name))
			return struct.getRefObjectRid();
		
		if ("refObjectKey".equals(name))
			return struct.getRefObjectKey();
		
		if ("refObjectType".equals(name))
			return struct.getRefObjectType();
		

		return null;
	}
	
	public void setAttribute(Object structure, String name, Object value) {
		com.sap.caf.core.services.types.RelatedObject struct = (com.sap.caf.core.services.types.RelatedObject) structure;
		if ("key".equals(name)) {
	
	
			struct.setKey(convertFromJPAValue(value, java.lang.String.class) );
	
		} else if ("createdBy".equals(name)) {
	
	
			struct.setCreatedBy(convertFromJPAValue(value, java.lang.String.class) );
	
		} else if ("createdAt".equals(name)) {
	
	
			struct.setCreatedAt(convertFromJPAValue(value, javax.xml.datatype.XMLGregorianCalendar.class) );
	
		} else if ("modifiedAt".equals(name)) {
	
	
			struct.setModifiedAt(convertFromJPAValue(value, javax.xml.datatype.XMLGregorianCalendar.class) );
	
		} else if ("modifiedBy".equals(name)) {
	
	
			struct.setModifiedBy(convertFromJPAValue(value, java.lang.String.class) );
	
		} else if ("refObjectRid".equals(name)) {
	
	
			struct.setRefObjectRid(convertFromJPAValue(value, java.lang.String.class) );
	
		} else if ("refObjectKey".equals(name)) {
	
	
			struct.setRefObjectKey(convertFromJPAValue(value, java.lang.String.class) );
	
		} else if ("refObjectType".equals(name)) {
	
	
			struct.setRefObjectType(convertFromJPAValue(value, java.lang.String.class) );
	
		}
	}

	@javax.persistence.Transient
	@java.lang.SuppressWarnings("unchecked")
	public java.util.Map getLanguageDependentAttributes() {	
		return java.util.Collections.EMPTY_MAP;
	}
}