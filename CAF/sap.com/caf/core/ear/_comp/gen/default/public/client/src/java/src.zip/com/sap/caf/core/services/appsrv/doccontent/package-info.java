@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.sap.com/caf/sap.com/caf.core/DocContent")
package com.sap.caf.core.services.appsrv.doccontent;
