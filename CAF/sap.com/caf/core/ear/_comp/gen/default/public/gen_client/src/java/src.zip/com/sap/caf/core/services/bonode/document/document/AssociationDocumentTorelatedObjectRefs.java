	
package com.sap.caf.core.services.bonode.document.document;

@javax.persistence.NamedQueries({
	@javax.persistence.NamedQuery(
			name="AssociationDocumentTorelatedObjectRefs_getTargetKeys",
			query="SELECT assoc.targetKey FROM com_sap_caf_core_services_bonode_document_document_AssociationDocumentTorelatedObjectRefs AS assoc,com_sap_caf_core_services_bonode_document_document_relatedobject_RelatedObjectBO target WHERE assoc.targetKey=target.key AND assoc.sourceKey=:sourceKey"),

	@javax.persistence.NamedQuery(
			name="AssociationDocumentTorelatedObjectRefs_countByTargetKey",
			query="SELECT COUNT(assoc) FROM com_sap_caf_core_services_bonode_document_document_AssociationDocumentTorelatedObjectRefs AS assoc WHERE assoc.sourceKey=:sourceKey AND assoc.targetKey=:targetKey"),

	@javax.persistence.NamedQuery(
			name="AssociationDocumentTorelatedObjectRefs_remove",
			query="DELETE FROM com_sap_caf_core_services_bonode_document_document_AssociationDocumentTorelatedObjectRefs AS assoc WHERE assoc.sourceKey=:sourceKey AND assoc.targetKey=:targetKey"),
			
	@javax.persistence.NamedQuery(
			name="AssociationDocumentTorelatedObjectRefs_removeAll",
			query="DELETE FROM com_sap_caf_core_services_bonode_document_document_AssociationDocumentTorelatedObjectRefs AS assoc WHERE assoc.sourceKey=:sourceKey")
})

@javax.persistence.Entity(name="com_sap_caf_core_services_bonode_document_document_AssociationDocumentTorelatedObjectRefs")
@javax.persistence.Table(name="XAP_CAF_SER_DOCREM")
public class AssociationDocumentTorelatedObjectRefs implements com.sap.caf.rt.bol.da.jpa.IAssociation {
	
	private String id;
	
	private String sourceKey;
	
	private String targetKey;
	
	public AssociationDocumentTorelatedObjectRefs() {
		
	}

	@javax.persistence.Id
	@javax.persistence.Column(name="OBJECTKEY")
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	@javax.persistence.Column(name="SOURCE_FK")
	public String getSourceKey() {
		return sourceKey;
	}

	public void setSourceKey(String sourceKey) {
		this.sourceKey = sourceKey;
	}
	@javax.persistence.Column(name="TARGET_FK")
	public String getTargetKey() {
		return targetKey;
	}

	public void setTargetKey(String targetKey) {
		this.targetKey = targetKey;
	}

	
}
