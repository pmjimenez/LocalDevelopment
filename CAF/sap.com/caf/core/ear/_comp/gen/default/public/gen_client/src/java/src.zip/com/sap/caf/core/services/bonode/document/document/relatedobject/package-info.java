@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.sap.com/caf/sap.com/caf.core/RelatedObject")
package com.sap.caf.core.services.bonode.document.document.relatedobject;
