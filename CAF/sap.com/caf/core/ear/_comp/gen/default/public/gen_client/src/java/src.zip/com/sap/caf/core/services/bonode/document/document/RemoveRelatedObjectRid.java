
package com.sap.caf.core.services.bonode.document.document;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.sap.caf.rt.bol.util.QueryFilter;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="boRid" type="{http://www.sap.com/caf/query_filter}QueryFilter" minOccurs="0"/>
 *         &lt;element name="documentKey" type="{http://www.sap.com/caf/query_filter}QueryFilter" minOccurs="0"/>
 *         &lt;element name="boName" type="{http://www.sap.com/caf/query_filter}QueryFilter" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "boRid",
    "documentKey",
    "boName"
})
@XmlRootElement(name = "removeRelatedObjectRid")
public class RemoveRelatedObjectRid implements java.io.Serializable {

    protected QueryFilter boRid;
    protected QueryFilter documentKey;
    protected QueryFilter boName;

    /**
     * Gets the value of the boRid property.
     * 
     * @return
     *     possible object is
     *     {@link QueryFilter }
     *     
     */
    public QueryFilter getBoRid() {
        return boRid;
    }

    /**
     * Sets the value of the boRid property.
     * 
     * @param value
     *     allowed object is
     *     {@link QueryFilter }
     *     
     */
    public void setBoRid(QueryFilter value) {
        this.boRid = value;
    }

    /**
     * Gets the value of the documentKey property.
     * 
     * @return
     *     possible object is
     *     {@link QueryFilter }
     *     
     */
    public QueryFilter getDocumentKey() {
        return documentKey;
    }

    /**
     * Sets the value of the documentKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link QueryFilter }
     *     
     */
    public void setDocumentKey(QueryFilter value) {
        this.documentKey = value;
    }

    /**
     * Gets the value of the boName property.
     * 
     * @return
     *     possible object is
     *     {@link QueryFilter }
     *     
     */
    public QueryFilter getBoName() {
        return boName;
    }

    /**
     * Sets the value of the boName property.
     * 
     * @param value
     *     allowed object is
     *     {@link QueryFilter }
     *     
     */
    public void setBoName(QueryFilter value) {
        this.boName = value;
    }

}
