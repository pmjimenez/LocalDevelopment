/**
 * 
 */
package com.sap.caf.core.utils;

import javax.annotation.Resource;
import javax.ejb.Local;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.sap.caf.core.services.bonode.document.document.DocumentBO;
import com.sap.caf.rt.bol.da.km.internal.IDataAccessHelper;

/**
 * This class is used to provide the EntityManger for caf.core.
 * @author i034234
 *
 */
@Stateless
@Local(value=IDataAccessHelper.class)
public class DocumentDataAccessHelper implements IDataAccessHelper {
	@PersistenceContext 
	EntityManager em;

	@Resource 
	SessionContext sc;
	
	public EntityManager getEntityManger() {
		return em;
	}

	public Class getPersistentClass() {
		return DocumentBO.class;
	}

	public SessionContext getSessionContext() {
		return sc;
	}
	
}
