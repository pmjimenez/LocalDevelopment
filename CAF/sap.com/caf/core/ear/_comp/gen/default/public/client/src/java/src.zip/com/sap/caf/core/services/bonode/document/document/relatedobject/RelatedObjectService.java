package com.sap.caf.core.services.bonode.document.document.relatedobject;

public interface RelatedObjectService {

	public com.sap.caf.core.services.types.RelatedObject create() throws com.sap.caf.rt.exception.CAFCreateException;

	public com.sap.caf.core.services.types.RelatedObject read(java.lang.String key) throws com.sap.caf.rt.exception.CAFRetrieveException;

	public void update(com.sap.caf.core.services.types.RelatedObject input) throws com.sap.caf.rt.exception.CAFUpdateException,com.sap.caf.rt.exception.CAFOptimisticLockException,com.sap.caf.rt.exception.CAFPessimisticLockException;

	public void delete(com.sap.caf.core.services.types.RelatedObject input) throws com.sap.caf.rt.exception.CAFDeleteException,com.sap.caf.rt.exception.CAFOptimisticLockException,com.sap.caf.rt.exception.CAFPessimisticLockException;

	public java.util.List<com.sap.caf.core.services.types.RelatedObject> findByMultipleParameters(java.util.List<com.sap.caf.rt.bol.util.QueryFilter> mapNameToFilter,java.lang.Boolean implCheck,java.lang.String findByName) throws com.sap.caf.rt.exception.CAFFindException;

	public java.util.List<com.sap.caf.core.services.types.RelatedObject> findAll() throws com.sap.caf.rt.exception.CAFFindException;


	public java.util.List<com.sap.caf.core.services.types.RelatedObject> findByMultipleParameters(java.util.List<com.sap.caf.rt.bol.util.QueryFilter> queryFilters, com.sap.caf.rt.bol.util.OrderBy orderBy, com.sap.caf.rt.bol.util.Paging paging, java.lang.String findByName) throws com.sap.caf.rt.exception.CAFFindException;
	

	public java.util.List<com.sap.caf.core.services.types.RelatedObject> findByMultipleParameters(com.sap.caf.rt.bol.util.QueryFilter[] queryFilters, com.sap.caf.rt.bol.util.OrderBy orderBy, com.sap.caf.rt.bol.util.Paging paging, java.lang.String findByName) throws com.sap.caf.rt.exception.CAFFindException;
	
	public java.util.List<com.sap.caf.core.services.types.RelatedObject> findByMultipleParameters(com.sap.caf.rt.bol.util.QueryFilter[] queryFilters, java.lang.Boolean implCheck, java.lang.String findByName) throws com.sap.caf.rt.exception.CAFFindException;



}