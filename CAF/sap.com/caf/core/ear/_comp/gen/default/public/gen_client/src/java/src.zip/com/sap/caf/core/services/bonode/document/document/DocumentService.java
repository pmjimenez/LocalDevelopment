package com.sap.caf.core.services.bonode.document.document;

public interface DocumentService {

	public com.sap.caf.core.services.types.Document create(java.lang.String documentId,java.lang.String parentFolder) throws com.sap.caf.rt.exception.CAFCreateException;

	public com.sap.caf.core.services.types.Document read(java.lang.String key) throws com.sap.caf.rt.exception.CAFRetrieveException;

	public void update(com.sap.caf.core.services.types.Document input) throws com.sap.caf.rt.exception.CAFUpdateException,com.sap.caf.rt.exception.CAFOptimisticLockException,com.sap.caf.rt.exception.CAFPessimisticLockException;

	public void delete(com.sap.caf.core.services.types.Document input) throws com.sap.caf.rt.exception.CAFDeleteException,com.sap.caf.rt.exception.CAFOptimisticLockException,com.sap.caf.rt.exception.CAFPessimisticLockException;

	public java.util.List<com.sap.caf.core.services.types.Document> findByMultipleParameters(java.util.List<com.sap.caf.rt.bol.util.QueryFilter> mapNameToFilter,java.lang.Boolean implCheck,java.lang.String findByName) throws com.sap.caf.rt.exception.CAFFindException;

	public java.util.List<com.sap.caf.core.services.types.Document> findAll() throws com.sap.caf.rt.exception.CAFFindException;

	public void addAuthUser(String permission,String primaryKey,String userId) throws com.sap.caf.rt.exception.CAFBONodeException;

	public void removeAuthUser(String permission,String primaryKey,String userId) throws com.sap.caf.rt.exception.CAFBONodeException;

	public com.sap.caf.core.services.types.Document getAuthUser(String permission,String primaryKey) throws com.sap.caf.rt.exception.CAFBONodeException;

	public java.lang.String addRelatedObjectRid(String boRid,String documentKey,String boGuid,String boName) throws com.sap.caf.rt.exception.CAFUpdateException;

	public void removeRelatedObjectRid(String boRid,String documentKey,String boName) throws com.sap.caf.rt.exception.CAFUpdateException;

	public java.lang.String relateDocument(String srcRid,String dstBOGuid,String dstBOName) throws com.sap.caf.rt.exception.CAFUpdateException;

	public java.util.List<com.sap.caf.core.services.types.Document> findByTitle(String parentFolder,String title) throws com.sap.caf.rt.exception.CAFFindException;

	public java.util.List<com.sap.caf.core.services.types.Document> findByDocumentId(String parentFolder,String documentId) throws com.sap.caf.rt.exception.CAFFindException;

	public java.util.List<com.sap.caf.core.services.types.Document> findByRid(String rid) throws com.sap.caf.rt.exception.CAFFindException;


	public java.util.List<com.sap.caf.core.services.types.Document> findByMultipleParameters(java.util.List<com.sap.caf.rt.bol.util.QueryFilter> queryFilters, com.sap.caf.rt.bol.util.OrderBy orderBy, com.sap.caf.rt.bol.util.Paging paging, java.lang.String findByName) throws com.sap.caf.rt.exception.CAFFindException;
	

	public java.util.List<com.sap.caf.core.services.types.Document> findByMultipleParameters(com.sap.caf.rt.bol.util.QueryFilter[] queryFilters, com.sap.caf.rt.bol.util.OrderBy orderBy, com.sap.caf.rt.bol.util.Paging paging, java.lang.String findByName) throws com.sap.caf.rt.exception.CAFFindException;
	
	public java.util.List<com.sap.caf.core.services.types.Document> findByMultipleParameters(com.sap.caf.rt.bol.util.QueryFilter[] queryFilters, java.lang.Boolean implCheck, java.lang.String findByName) throws com.sap.caf.rt.exception.CAFFindException;

	/**
	 * @param documentKey Identifier of a <code>Document</code> instance.
	 * @return The identifiers of the associated <code>RelatedObject</code> nodes.
	 */
	public java.lang.String[] getRelatedObjectRefs(java.lang.String documentKey) throws com.sap.caf.rt.exception.CAFRetrieveException;
	
	/**
	 * @param documentKey Identifier of a <code>Document</code> instance.
	 * @param relatedObjectKeys Identifiers of the <code>RelatedObject</code> instances that are to be associated. 
	 */
	public void setRelatedObjectRefs(java.lang.String documentKey, java.lang.String[] relatedObjectKeys) throws com.sap.caf.rt.exception.CAFUpdateException;
	
	/**
	 * Adds an association to a <code>RelatedObject</code> instance with the given identifier
	 * @param documentKey Identifier of a <code>Document</code> instance.
	 * @param relatedObjectKey Identifier of a <code>RelatedObject</code> instance that is to be associated 
	 */	
	public void addRelatedObjectRefs(java.lang.String documentKey, java.lang.String relatedObjectKey) throws com.sap.caf.rt.exception.CAFUpdateException;
	
	/**
	 * Removes the association to the <code>RelatedObject</code> instance with the given identifier
	 * @param documentKey Identifier of a <code>Document</code> instance.
	 * @param relatedObjectKey Identifier of the associated <code>RelatedObject</code> instance. 
	 */
	public void removeRelatedObjectRefs(java.lang.String documentKey, java.lang.String relatedObjectKey) throws com.sap.caf.rt.exception.CAFUpdateException;
	


}