package com.sap.caf.core.services.bonode.document.document.relatedobject;

public interface RelatedObjectServiceLocal extends com.sap.caf.core.services.bonode.document.document.relatedobject.RelatedObjectService, com.sap.caf.rt.bol.IBusinessObjectNodeServiceBase{
}