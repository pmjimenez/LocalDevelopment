/*
 * Created on May 10, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.sap.caf.rt.bol;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.LinkedList;


import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.jws.WebMethod;
import javax.xml.datatype.XMLGregorianCalendar;

import com.sap.caf.rt.bol.util.QueryFilter;
import com.sap.caf.rt.bol.util.QueryFilterFactory;
import com.sap.caf.rt.bol.util.internal.CAFLogicalLocking;
import com.sap.caf.rt.exception.CAFBaseException;
import com.sap.caf.rt.exception.CAFCreateException;
import com.sap.caf.rt.exception.CAFDeleteException;
import com.sap.caf.rt.exception.CAFFindException;
import com.sap.caf.rt.exception.CAFPermissionException;
import com.sap.caf.rt.exception.CAFPessimisticLockException;
import com.sap.caf.rt.exception.CAFRetrieveException;
import com.sap.caf.rt.exception.CAFUpdateException;
import com.sap.caf.rt.security.acl.CAFPermission;
import com.sap.caf.rt.security.util.CAFPermissionName;
import com.sap.caf.rt.util.DateUtils;
import com.sap.ejb.annotations.ExcludeFromImport;
import com.sap.engine.services.applocking.LogicalLocking;
import com.sap.security.api.IUser;
import com.sap.security.api.UMException;
import com.sap.security.api.UMFactory;
import com.sap.tc.logging.Category;
import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;
import com.sap.tc.logging.SimpleLogger;

/**
 * @author trendafil-m
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public abstract class BusinessObjectNodeServiceBase implements IBusinessObjectNodeServiceBase {
	                  
	private static final Location location = Location.getLocation(BusinessObjectNodeServiceBase.class);
	private static final int MS_DELTA = 3;

	@Resource
	protected SessionContext sessionContext;
	
	protected String _objectName;
	
	@WebMethod(exclude=true)
	@ExcludeFromImport
	public IBusinessObjectNodeBase createGeneric(List attributes) throws CAFCreateException {
		int size = attributes.size();
		Class[] parameterTypes = new Class[size];
		Object[] args = new Object[size];
		Iterator iter = attributes.iterator();
		for (int i = 0; i < size; i++) {
			Object attribute = iter.next();
			parameterTypes[i] = attribute.getClass();
			args[i] = attribute;
		}
		IBusinessObjectNodeBase result;
		try {
			Method createMethod = this.getClass().getMethod("create", parameterTypes);
			result = (IBusinessObjectNodeBase) createMethod.invoke(this, args);
		} catch (Exception e) {
			location.traceThrowableT(Severity.ERROR, e.getMessage(), e);
			throw new CAFCreateException(location, e);
		}
		return result;
	}
	
	@SuppressWarnings({ "unchecked", "deprecation"})
	@Deprecated	
	@WebMethod(exclude=true)
	@ExcludeFromImport
	public IBusinessObjectNodeBase createWithKeyGeneric(String key, List attributes)
	throws CAFCreateException {
		int size = attributes.size();
		Class[] parameterTypes = new Class[size + 1];
		parameterTypes[0] = String.class;
		Object[] args = new Object[size + 1];
		args[0] = key;
		Iterator iter = attributes.iterator();
		for (int i = 1; i < size+1; i++) {
			Object attribute = iter.next();
			parameterTypes[i] = attribute.getClass();
			args[i] = attribute;
		}
		IBusinessObjectNodeBase result;
		try {
			Method createMethod =
				this.getClass().getMethod("createWithKey", parameterTypes);
			result = (IBusinessObjectNodeBase) createMethod.invoke(this, args);
		} catch (Exception e) {
			location.traceThrowableT(Severity.ERROR, e.getMessage(), e);
			throw new CAFCreateException(location, e);
		}
		return result;
	}
	
	@WebMethod(exclude=true)
	@ExcludeFromImport
	public void deleteGeneric(IBusinessObjectNodeBase object) throws CAFDeleteException {
		try {
			Method deleteMethod = this.getClass().getMethod("delete", new Class[] { object.getClass() });
			deleteMethod.invoke(this, new Object[] { object });
		} catch (Exception e) {
			location.traceThrowableT(Severity.ERROR, e.getMessage(), e);
			throw new CAFDeleteException(location, e);
		}
	}
	
	@WebMethod(exclude=true)
	@ExcludeFromImport
	public Object[] findGeneric(String operationName, List attributes) throws CAFFindException {
		int size = attributes.size();
		Class[] parameterTypes = new Class[size];
		Object[] args = new Object[size];
		Iterator iter = attributes.iterator();
		for (int i = 0; i < size; i++) {
			Object attribute = iter.next();
			parameterTypes[i] = attribute.getClass();
			args[i] = attribute;
		}
		Object[] result;
		try {
			Method findMethod = this.getClass().getMethod(operationName, parameterTypes);
			result = ((List) findMethod.invoke(this, args)).toArray();
		} catch (Exception e) {
			location.traceThrowableT(Severity.ERROR, e.getMessage(), e);
			throw new CAFFindException(location, e);
		}
		return result;
	}

//	/**
//	 * Implementation will be in the generated code. 
//	 * @param mapNameToFilter
//	 * @param implCheck
//	 * @param findByName
//	 * @return
//	 * @throws CAFFindException
//	 */
//	public abstract java.util.List findByMultipleParameters(Map mapNameToFilter, boolean implCheck, java.lang.String findByName) 
//		throws CAFFindException;

	@WebMethod(exclude=true)
	@ExcludeFromImport
	public IBusinessObjectNodeBase readGeneric(String key) throws CAFRetrieveException {
	IBusinessObjectNodeBase result;
		try {
			Method readMethod = this.getClass().getMethod("read", new Class[] { String.class });
			result = (IBusinessObjectNodeBase) readMethod.invoke(this, new Object[] { key });
		} catch (Exception e) {
			location.traceThrowableT(Severity.ERROR, e.getMessage(), e);
			throw new CAFRetrieveException(location, e);
		}
		return result;
	}
	
	@WebMethod(exclude=true)
	@ExcludeFromImport
	public void updateGeneric(IBusinessObjectNodeBase object) throws CAFUpdateException {
		try {
			Method updateMethod = this.getClass().getMethod("update", new Class[] { object.getClass() });
			updateMethod.invoke(this, new Object[] { object });
		} catch (Exception e) {
			location.traceThrowableT(Severity.ERROR, e.getMessage(), e);
			throw new CAFUpdateException(location, e);
		}
	}

	/**
	 * Performs full text search by BO properties in KM index
	 * @param collectionFilters	A collection of filters
	 * @return A collection of BO keys
	 * @throws CAFFindException
	 */
	@WebMethod(exclude=true)
	public String[] findByKMPropertySearch(QueryFilter[] collectionFilters) throws CAFFindException {
		throw new CAFFindException(location, "Operation not supported.");
	}

	/* ======================================================================
	 * 																LOCK
	 * ======================================================================*/

	/**
	 *   Locks an argument, which belongs to a name.
	 * 
	 * @param argument The argument which to lock. The maximum size is MAX_ARGUMENT_LENGTH characters.
	 * @param mode The mode can be MODE_SHARED or MODE_EXCLUSIVE_CUMULATIVE or MODE_EXCLUSIVE_NONCUMULATIVE.
	 * 
	 * @exception LockException if the argument is already locked
	 */
	@WebMethod(exclude=true)
	@ExcludeFromImport
	public void lock(String argument, char mode) throws CAFPessimisticLockException {

		if (mode != IBusinessObjectNodeServiceBase.MODE_WRITE && mode != IBusinessObjectNodeServiceBase.MODE_READ) {
			CAFPessimisticLockException ex = new CAFPessimisticLockException(location, "LOCK_KEY_LOCK_NOT_SUPPORTED");
			ex.setType(CAFPessimisticLockException.TYPE_LOCK_NOT_SUPPORTED);
			throw ex;
		}

		String lockName = constructLockName();
		CAFLogicalLocking.lock(LogicalLocking.LIFETIME_USERSESSION, lockName, argument, mode);
	}

	@WebMethod(exclude=true)
	@ExcludeFromImport
	public void lock(String arguments[], char mode) throws CAFPessimisticLockException {

		if (mode != IBusinessObjectNodeServiceBase.MODE_WRITE && mode != IBusinessObjectNodeServiceBase.MODE_READ) {
			CAFPessimisticLockException ex = new CAFPessimisticLockException(location, "LOCK_KEY_LOCK_NOT_SUPPORTED");
			ex.setType(CAFPessimisticLockException.TYPE_LOCK_NOT_SUPPORTED);
			throw ex;
		}

		String lockName = constructLockName();
		CAFLogicalLocking.lock(LogicalLocking.LIFETIME_USERSESSION, lockName, arguments, mode);
	}

	/**
	 * Locks an argument, which belongs to a name.
	 * 
	 * @param argument The argument which to lock. The maximum size is MAX_ARGUMENT_LENGTH characters.
	 * @param mode The mode can be MODE_SHARED or MODE_EXCLUSIVE_CUMULATIVE or MODE_EXCLUSIVE_NONCUMULATIVE.
	 * @param timeout time period in milliseconds within this the lock will be requested several times if there is a lock collision
	 * 
	 * @exception LockException if the argument is already locked
	 */
	@WebMethod(exclude=true)
	@ExcludeFromImport
	public void lock(String argument, char mode, int timeout) throws CAFPessimisticLockException {

		if (mode != IBusinessObjectNodeServiceBase.MODE_WRITE && mode != IBusinessObjectNodeServiceBase.MODE_READ) {
			CAFPessimisticLockException ex = new CAFPessimisticLockException(location, "LOCK_KEY_LOCK_NOT_SUPPORTED");
			ex.setType(CAFPessimisticLockException.TYPE_LOCK_NOT_SUPPORTED);
			throw ex;
		}

		String lockName = constructLockName();
		CAFLogicalLocking.lock(LogicalLocking.LIFETIME_USERSESSION, lockName, argument, mode, timeout);
	}

	@WebMethod(exclude=true)
	@ExcludeFromImport
	public void lock(String arguments[], char mode, int timeout) throws CAFPessimisticLockException {

		if (mode != IBusinessObjectNodeServiceBase.MODE_WRITE && mode != IBusinessObjectNodeServiceBase.MODE_READ) {
			CAFPessimisticLockException ex = new CAFPessimisticLockException(location, "LOCK_KEY_LOCK_NOT_SUPPORTED");
			ex.setType(CAFPessimisticLockException.TYPE_LOCK_NOT_SUPPORTED);
			throw ex;
		}

		String lockName = constructLockName();
		CAFLogicalLocking.lock(LogicalLocking.LIFETIME_USERSESSION, lockName, arguments, mode, timeout);
	}

	/* ======================================================================
	 * 																UNLOCK
	 * ======================================================================*/

	/**
	 * Unlocks an argument, which belongs to a name.
	 * By default the unlock may be done asynchronously.
	 * 
	 * @param argument The argument which to unlock. The maximum size is MAX_ARGUMENT_LENGTH characters.
	 * @param mode The mode can be MODE_SHARED or MODE_EXCLUSIVE_CUMULATIVE or MODE_EXCLUSIVE_NONCUMULATIVE.
	 */
	@WebMethod(exclude=true)
	@ExcludeFromImport
	public void unlock(String argument, char mode) throws CAFPessimisticLockException {

		if (mode != IBusinessObjectNodeServiceBase.MODE_WRITE && mode != IBusinessObjectNodeServiceBase.MODE_READ) {
			CAFPessimisticLockException ex = new CAFPessimisticLockException(location, "LOCK_KEY_LOCK_NOT_SUPPORTED");
			ex.setType(CAFPessimisticLockException.TYPE_LOCK_NOT_SUPPORTED);
			throw ex;
		}

		String lockName = constructLockName();
		CAFLogicalLocking.unlock(LogicalLocking.LIFETIME_USERSESSION, lockName, argument, mode);
	}

	@WebMethod(exclude=true)
	@ExcludeFromImport
	public void unlock(String arguments[], char mode) throws CAFPessimisticLockException {

		if (mode != IBusinessObjectNodeServiceBase.MODE_WRITE && mode != IBusinessObjectNodeServiceBase.MODE_READ) {
			CAFPessimisticLockException ex = new CAFPessimisticLockException(location, "LOCK_KEY_LOCK_NOT_SUPPORTED");
			ex.setType(CAFPessimisticLockException.TYPE_LOCK_NOT_SUPPORTED);
			throw ex;
		}

		String lockName = constructLockName();
		CAFLogicalLocking.unlock(LogicalLocking.LIFETIME_USERSESSION, lockName, arguments, mode);
	}

	/**
	 * Unlocks an argument, which belongs to a name.
	 * 
	 * @param argument The argument which to unlock. The maximum size is MAX_ARGUMENT_LENGTH characters.
	 * @param mode The mode can be MODE_SHARED or MODE_EXCLUSIVE_CUMULATIVE or MODE_EXCLUSIVE_NONCUMULATIVE.
	 * @param asynchronous If true, then the unlock may be done asynchronously, otherwise it is guaranteed to be done synchronously.
	 */
	@WebMethod(exclude=true)
	@ExcludeFromImport
	public void unlock(String argument, char mode, boolean asynchronous) throws CAFPessimisticLockException {

		if (mode != IBusinessObjectNodeServiceBase.MODE_WRITE && mode != IBusinessObjectNodeServiceBase.MODE_READ) {
			CAFPessimisticLockException ex = new CAFPessimisticLockException(location, "LOCK_KEY_LOCK_NOT_SUPPORTED");
			ex.setType(CAFPessimisticLockException.TYPE_LOCK_NOT_SUPPORTED);
			throw ex;
		}

		String lockName = constructLockName();
		CAFLogicalLocking.unlock(LogicalLocking.LIFETIME_USERSESSION, lockName, argument, mode, asynchronous);
	}

	@WebMethod(exclude=true)
	@ExcludeFromImport
	public void unlock(String arguments[], char mode, boolean asynchronous) throws CAFPessimisticLockException {

		if (mode != IBusinessObjectNodeServiceBase.MODE_WRITE && mode != IBusinessObjectNodeServiceBase.MODE_READ) {
			CAFPessimisticLockException ex = new CAFPessimisticLockException(location, "LOCK_KEY_LOCK_NOT_SUPPORTED");
			ex.setType(CAFPessimisticLockException.TYPE_LOCK_NOT_SUPPORTED);
			throw ex;
		}

		String lockName = constructLockName();
		CAFLogicalLocking.unlock(LogicalLocking.LIFETIME_USERSESSION, lockName, arguments, mode, asynchronous);
	}

	/**
	 * Returns if locking is currently allowed.
	 * <p>
	 * This method is typically not needed to use the locking. 
	 * It is meant mainly for debugging-purposes and to support better tracing.
	 * 
	 *
	 * @exception TechnicalLockException if the lifetime is currently not allowed.
	 */
	@WebMethod(exclude=true)
	@ExcludeFromImport
	public void assertLocking() throws CAFPessimisticLockException {

		CAFLogicalLocking.assertLifetime(LogicalLocking.LIFETIME_USERSESSION);
	}

	/**
	 * Returns the current owner-id, to which all locks belong.
	 * It is dependent on the current session or the current transaction.
	 * <p>
	 * This method is not needed to use the locking.
	 * It is meant mainly for debugging-purposes and to support better tracing.
	 */
	@WebMethod(exclude=true)
	@ExcludeFromImport
	public String getCurrentOwner() throws CAFPessimisticLockException {
		return CAFLogicalLocking.getCurrentOwner(LogicalLocking.LIFETIME_USERSESSION);
	}

	/**
	 * Constructs name for the lock in the format: <CAF lock namespace>.<name of the current service>
	 * @return constructed name for the current service
	 * @author nikolay-k (i030736)
	 */
	
	private String constructLockName() {
		String className = this.getClass().getName();
		String lockName = CAFLogicalLocking.ENQ_SRV_NAMESPACE + "." + className.substring(className.lastIndexOf('.') + 1);
		lockName = lockName.substring(0, Math.min(LogicalLocking.MAX_NAME_LENGTH, lockName.length()));
		return lockName;
	}

	/**
	 * Workaround: Compares two dates with MS_DELTA = 3ms 
	 * to avoid problems with MS SQL Server 2000
	 * @return True if dates are equal with delta
	 * @param date1 Date to compare
	 * @param date2 Date to compare
	 */
	@WebMethod(exclude=true)
	public static boolean almostEqual(Date date1, Date date2) {
		return 
			Math.abs(date1.getTime() - date2.getTime()) <= MS_DELTA; 		
	}
	
	@WebMethod(exclude=true)
	protected static boolean almostEqual(XMLGregorianCalendar cal1, XMLGregorianCalendar cal2) {
		return almostEqual(DateUtils.toDate(cal1), DateUtils.toDate(cal2));
	}
	
	@WebMethod(exclude=true)
	protected String getLogonLanguage() throws CAFBaseException {
		
		String user = sessionContext.getCallerPrincipal().getName();
		String logonLanguage = null;
		
		try {
			IUser us = UMFactory.getUserFactory().getUserByLogonID(user);
			Locale loc = us.getLocale();
			if (loc == null) {
				loc = Locale.getDefault();
			}
			if (loc != null) {
				logonLanguage = loc.getLanguage();
			} else {
				logonLanguage = "EN";
			}
		} catch (UMException ue) {
			location.traceThrowableT(Severity.ERROR, ue.getMessage(), ue);
			CAFBaseException _caf_ex = new CAFBaseException(location, "BO_USER_NOT_FOUND", new Object[] {user}, ue);
			throw _caf_ex;
		}
		
		return logonLanguage;
	}
	
	/**
	 * Transforms arrays of QueryFilter coming from findByXXX operations in form suitable for
	 * findByMultipleParameters invocation
	 * @param filters - filters array coming from findByXXX method
	 * @return array to be used in the invocation of "findByMultiplePatra
	 */
	@WebMethod(exclude=true)
	public static QueryFilter[] transformForFindByMultipleParams(QueryFilter[] filters) {
		if (filters.length < 2) {
			return filters;
		}
		
		final QueryFilter openBracket = QueryFilterFactory.createBracket(QueryFilter.OPERATION_BRACKET_OPEN);
		final QueryFilter closeBracket = QueryFilterFactory.createBracket(QueryFilter.OPERATION_BRACKET_CLOSE);
		
		class SequenceInfo {
			boolean mayRequireBrackats = false;
			LinkedList<QueryFilter> elements = new LinkedList<QueryFilter>();
			LinkedList<QueryFilter> getFilters() {
				if (elements.size()>1 && mayRequireBrackats){
					elements.addFirst(openBracket);
					elements.addLast(closeBracket);
				}
				return elements;
			}
		}
		List<SequenceInfo> lsSequences = new ArrayList<SequenceInfo>(10);
		SequenceInfo sequenceInfo = new SequenceInfo();
		lsSequences.add(sequenceInfo);
		sequenceInfo.elements.add(filters[0]);
		
		QueryFilter filterAND = QueryFilterFactory.createBoolOperator(QueryFilter.OPERATION_AND);
		QueryFilter filterOR= QueryFilterFactory.createBoolOperator(QueryFilter.OPERATION_OR);
		for (int i=1; i<filters.length;i++){
			if (filters[i].getAttribute().equals(filters[i-1].getAttribute())){
				sequenceInfo.elements.add(filterOR);
			}else{
				sequenceInfo.mayRequireBrackats = true;
				sequenceInfo = new SequenceInfo();
				lsSequences.add(sequenceInfo);
			}
			
			sequenceInfo.elements.add(filters[i]);
		}
		
		
		if (lsSequences.size()>1){
			sequenceInfo.mayRequireBrackats = true;
		}
		
		LinkedList<QueryFilter> finalQFList = new LinkedList<QueryFilter>(lsSequences.get(0).getFilters());
		for (int i=1;i<lsSequences.size();i++){
			finalQFList.addLast(filterAND);
			finalQFList.addAll(lsSequences.get(i).getFilters());
		}
		
		
		return finalQFList.toArray(new QueryFilter[0]);
	}

	protected boolean checkPermission(String permission, IBusinessObjectNodeBase object, String user, String objectName, int mode) {
		boolean allowAccess = true;
		try {
			if (!CAFPermission.checkAclPermission(object, user, permission, objectName, mode)) {
				allowAccess = false;
				if (permission.equals(CAFPermissionName.create)) {
					SimpleLogger.log(Severity.INFO, Category.APPS_COMMON_SECURITY, location, "CAF.core.000001", "User {0} does not have a {1} permission for BO node with object ID \"{2}\".", (Object)user, (Object)permission, (Object)objectName);
				} else {
					SimpleLogger.log(Severity.INFO, Category.APPS_COMMON_SECURITY, location, "CAF.core.000002", "User {0} does not have a {1} permission for BO node with object ID \"{2}\" and key \"{3}\".", (Object)user, (Object)permission, (Object)objectName, (Object)object.getKey());
				}
			}
		} catch (CAFPermissionException e) {
			allowAccess = false;
			location.traceThrowableT(Severity.WARNING, "Permissions check for user {0} for objectId {1} failed! Will continue with no permissions!", new Object[] {user, objectName}, e);			
		}
		return allowAccess;
	}

	protected boolean checkPermission(String permission, IBusinessObjectNodeBase object, String user, String objectName) {
		return this.checkPermission(permission, object, user, objectName, CAFPermission.MODE_CHECK_ALL - CAFPermission.MODE_CHECK_ONLY_FOR_INSTANCE);
	}
}
