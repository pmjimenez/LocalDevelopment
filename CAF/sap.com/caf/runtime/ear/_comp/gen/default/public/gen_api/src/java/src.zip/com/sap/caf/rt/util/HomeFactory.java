package com.sap.caf.rt.util;

import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;

public class HomeFactory {
	private static final Location location = Location.getLocation(HomeFactory.class);
	private javax.naming.InitialContext context;
	private java.util.Map cache;
	private static HomeFactory factory;

	static {
		try {
			factory = new HomeFactory();
		} catch(com.sap.caf.rt.exception.CAFServiceException se) {
			location.traceThrowableT(Severity.ERROR, se.getMessage(), se);
			com.sap.caf.rt.exception.CAFBaseRuntimeException _caf_ex = new com.sap.caf.rt.exception.CAFBaseRuntimeException(se);
			throw _caf_ex;
		}
	}

	private HomeFactory() throws com.sap.caf.rt.exception.CAFServiceException  {
		try {
			context = new javax.naming.InitialContext();
			cache = java.util.Collections.synchronizedMap(new java.util.HashMap());
		} catch (javax.naming.NamingException ne) {
			location.traceThrowableT(Severity.ERROR, ne.getMessage(), ne);
			com.sap.caf.rt.exception.CAFServiceException _caf_ex = new com.sap.caf.rt.exception.CAFServiceException(ne);
			throw _caf_ex;
		} catch (Exception e) {
			location.traceThrowableT(Severity.ERROR, e.getMessage(), e);
			com.sap.caf.rt.exception.CAFServiceException _caf_ex = new com.sap.caf.rt.exception.CAFServiceException(e);
			throw _caf_ex;
		}
	}

	static public HomeFactory getInstance() {
		return factory;
	}
    
	public Object getLocalHome(String jndiHomeName) throws com.sap.caf.rt.exception.CAFServiceException {
		Object home = null;
		try { 
			if (cache.containsKey(jndiHomeName)) {
				home = cache.get(jndiHomeName);
			} else {         
				home = context.lookup(jndiHomeName);
				cache.put(jndiHomeName, home);
			}
		} catch (javax.naming.NamingException ne) {
			location.traceThrowableT(Severity.ERROR, ne.getMessage(), ne);
			com.sap.caf.rt.exception.CAFServiceException _caf_ex = new com.sap.caf.rt.exception.CAFServiceException(ne);
			throw _caf_ex;
		} catch (Exception e) {
			location.traceThrowableT(Severity.ERROR, e.getMessage(), e);
			com.sap.caf.rt.exception.CAFServiceException _caf_ex = new com.sap.caf.rt.exception.CAFServiceException(e);
			throw _caf_ex;
		}
		return home;
	}
}
