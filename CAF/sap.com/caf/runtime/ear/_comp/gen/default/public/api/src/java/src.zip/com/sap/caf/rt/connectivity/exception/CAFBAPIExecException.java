/*
 * Created on 2005-3-22
 *
 * Copyright 2005 SAP AG, All rights reserved.
 * SAP AG PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.sap.caf.rt.connectivity.exception;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.sap.caf.rt.util.CAFResourceAccessor;
import com.sap.exception.BaseExceptionInfo;
import com.sap.localization.LocalizableText;
import com.sap.localization.LocalizableTextFormatter;
import com.sap.localization.ResourceAccessor;
import com.sap.localization.LocalizableText.Msg;
import com.sap.tc.logging.Category;
import com.sap.tc.logging.Location;

/**
 * This exception is thrown when a problem with executing a BAPI external service occurs.
 * It contains extra info which is returned by BAPIs.
 */
public class CAFBAPIExecException extends CAFRFCExecException
{
	private static final long serialVersionUID = 3760125271255927962L;

	/**
	 * Error type.
	 * @see BAPIErrorMessageDescription#getType()
	 */
	public static final String TYPE_E = "E";

	/**
	 * Abort type.
	 * @see BAPIErrorMessageDescription#getType()
	 */
	public static final String TYPE_A = "A";

	private transient List<BAPIErrorMessageDescription> allBAPIErrors; 
	
	private void init(BAPIErrorMessageDescription bapiErr)
	{
		this.allBAPIErrors = new ArrayList<BAPIErrorMessageDescription>();
		this.addBAPIErrorMessage(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param location logging location
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Location location)
	{
		super(location);
		this.init(bapiErr);
	}
	
	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location)} instead.
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr)
	{
		super();
		this.init(bapiErr);
	}
	
	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param baseExcInfo information about the throwable which caused this exception
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, BaseExceptionInfo baseExcInfo)
	{
		super(baseExcInfo);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param baseExcInfo information about the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, BaseExceptionInfo baseExcInfo, boolean isRealCause)
	{
		super(baseExcInfo, isRealCause);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param location logging location
	 * @param cause the throwable which caused this exception
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Location location, Throwable cause)
	{
		super(location, cause);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location, Throwable)} instead.
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Throwable cause)
	{
		super(cause);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param location logging location
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Location location, Throwable cause, boolean isRealCause)
	{
		super(location, cause, isRealCause);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location, Throwable, boolean)} instead.
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Throwable cause, boolean isRealCause)
	{
		super(cause, isRealCause);
		this.init(bapiErr);
	}
	
	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Location location, ResourceAccessor ra, String key)
	{
		super(location, ra, key);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location, ResourceAccessor, String)} instead.
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, ResourceAccessor ra, String key)
	{
		super(ra, key);
		this.init(bapiErr);
	}
	
	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Location location, ResourceAccessor ra, String key, Throwable cause)
	{
		super(location, ra, key, cause);
		this.init(bapiErr);
	}
	
	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location, ResourceAccessor, String, Throwable)} instead.
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, ResourceAccessor ra, String key, Throwable cause)
	{
		super(ra, key, cause);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Location location, ResourceAccessor ra, String key, Throwable cause, boolean isRealCause)
	{
		super(location, ra, key, cause, isRealCause);
		this.init(bapiErr);
	}
	
	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location, ResourceAccessor, String, Throwable, boolean)} instead.
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, ResourceAccessor ra, String key, Throwable cause, boolean isRealCause)
	{
		super(ra, key, cause, isRealCause);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Location location, ResourceAccessor ra, String key, Object[] args)
	{
		super(location, ra, key, args);
		this.init(bapiErr);
	}
	
	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location, ResourceAccessor, String, Object[])} instead.
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, ResourceAccessor ra, String key, Object[] args)
	{
		super(ra, key, args);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause)
	{
		super(location, ra, key, args, cause);
		this.init(bapiErr);
	}
	
	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location, ResourceAccessor, String, Object[], Throwable)} instead. 
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, ResourceAccessor ra, String key, Object[] args, Throwable cause)
	{
		super(ra, key, args, cause);
		this.init(bapiErr);
	}
	
	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		super(location, ra, key, args, cause, isRealCause);
		this.init(bapiErr);
	}
	
	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location, ResourceAccessor, String, Object[], Throwable, boolean)} instead.
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, ResourceAccessor ra, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		super(ra, key, args, cause, isRealCause);
		this.init(bapiErr);
	}
	
	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param location logging location
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Location location, ResourceAccessor ra, Msg msg)
	{
		super(location, ra, msg);
		this.init(bapiErr);
	}
	
	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location, ResourceAccessor, LocalizableText.Msg)} instead.
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, ResourceAccessor ra, Msg msg)
	{
		super(ra, msg);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param location logging location
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception 
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Location location, ResourceAccessor ra, Msg msg, Throwable cause)
	{
		super(location, ra, msg, cause);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location, ResourceAccessor, LocalizableText.Msg, Throwable)} instead. 
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, ResourceAccessor ra, Msg msg, Throwable cause)
	{
		super(ra, msg, cause);
		this.init(bapiErr);
	}
	
	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param location logging location
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Location location, ResourceAccessor ra, Msg msg, Throwable cause, boolean isRealCause)
	{
		super(location, ra, msg, cause, isRealCause);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location, ResourceAccessor, LocalizableText.Msg, Throwable, boolean)} instead. 
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, ResourceAccessor ra, Msg msg, Throwable cause, boolean isRealCause)
	{
		super(ra, msg, cause, isRealCause);
		this.init(bapiErr);
	}
	
	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param location logging location
	 * @param localizableText localizable message
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Location location, LocalizableText localizableText)
	{
		super(location, localizableText);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param localizableText localizable message
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location, LocalizableText)} instead. 
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, LocalizableText localizableText)
	{
		super(localizableText);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Location location, LocalizableText localizableText, Throwable cause)
	{
		super(location, localizableText, cause);
		this.init(bapiErr);
	}
	
	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location, LocalizableText, Throwable)} instead.
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, LocalizableText localizableText, Throwable cause)
	{
		super(localizableText, cause);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Location location, LocalizableText localizableText, Throwable cause, boolean isRealCause)
	{
		super(location, localizableText, cause, isRealCause);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location, LocalizableText, Throwable, boolean)} instead.
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, LocalizableText localizableText, Throwable cause, boolean isRealCause)
	{
		super(localizableText, cause, isRealCause);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @deprecated
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Category category, int severity, Location location, LocalizableText localizableText, Throwable cause)
	{
		super(category, severity, location, localizableText, cause);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Category category, int severity, Location location, LocalizableText localizableText, Throwable cause, boolean isRealCause)
	{
		super(category, severity, location, localizableText, cause, isRealCause);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @deprecated
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Category category, int severity, Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause)
	{
		super(category, severity, location, ra, key, args, cause);
		this.init(bapiErr);
	}
	
	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Category category, int severity, Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		super(category, severity, location, ra, key, args, cause, isRealCause);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param textFormatter localizable message
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location, LocalizableText)} instead.
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, LocalizableTextFormatter textFormatter)
	{
		this(bapiErr, (LocalizableText)textFormatter);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param textFormatter localizable message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location, LocalizableText, Throwable)} instead.
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, LocalizableTextFormatter textFormatter, Throwable cause)
	{
		this(bapiErr, (LocalizableText)textFormatter, cause);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException.
	 * @param bapiErr description of the BAPI error
	 * @param textFormatter localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location, LocalizableText, Throwable, boolean)} instead.
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, LocalizableTextFormatter textFormatter, Throwable cause, boolean isRealCause)
	{
		this(bapiErr, (LocalizableText)textFormatter, cause, isRealCause);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException with the default CAF resource accessor.
	 * @param bapiErr description of the BAPI error
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Location location, String key)
	{
		this(bapiErr, location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key));
		this.init(bapiErr);
	}
	
	/**
	 * Constructs a new CAFBAPIExecException with the default CAF resource accessor.
	 * @param bapiErr description of the BAPI error
	 * @param key the key of the message in the resource bundle
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location, String)} instead.
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, String key)
	{
		this(bapiErr, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key));
		this.init(bapiErr);
	}
	
	/**
	 * Constructs a new CAFBAPIExecException with the default CAF resource accessor.
	 * @param bapiErr description of the BAPI error
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Location location, String key, Throwable cause)
	{
		this(bapiErr, location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException with the default CAF resource accessor.
	 * @param bapiErr description of the BAPI error
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location, String, Throwable)} instead.
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, String key, Throwable cause)
	{
		this(bapiErr, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException with the default CAF resource accessor.
	 * @param bapiErr description of the BAPI error
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Location location, String key, Throwable cause, boolean isRealCause)
	{
		this(bapiErr, location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause, isRealCause);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException with the default CAF resource accessor.
	 * @param bapiErr description of the BAPI error
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location, String, Throwable, boolean)} instead.
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, String key, Throwable cause, boolean isRealCause)
	{
		this(bapiErr, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause, isRealCause);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException with the default CAF resource accessor.
	 * @param bapiErr description of the BAPI error
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Location location, String key, Object[] args)
	{
		this(bapiErr, location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args));
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException with the default CAF resource accessor.
	 * @param bapiErr description of the BAPI error
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location, String, Object[])} instead.
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, String key, Object[] args)
	{
		this(bapiErr, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args));
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException with the default CAF resource accessor.
	 * @param bapiErr description of the BAPI error
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Location location, String key, Object[] args, Throwable cause)
	{
		this(bapiErr, location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException with the default CAF resource accessor.
	 * @param bapiErr description of the BAPI error
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location, String, Object[], Throwable)} instead.
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, String key, Object[] args, Throwable cause)
	{
		this(bapiErr, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException with the default CAF resource accessor.
	 * @param bapiErr description of the BAPI error
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, Location location, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		this(bapiErr, location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause, isRealCause);
		this.init(bapiErr);
	}

	/**
	 * Constructs a new CAFBAPIExecException with the default CAF resource accessor.
	 * @param bapiErr description of the BAPI error
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBAPIExecException#CAFBAPIExecException(BAPIErrorMessageDescription, Location, String, Object[], Throwable, boolean)} instead.
	 */
	public CAFBAPIExecException(BAPIErrorMessageDescription bapiErr, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		this(bapiErr, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause, isRealCause);
		this.init(bapiErr);
	}

	/**
	 * Returns all the BAPI error messages of this exception.
	 * @return an array containing the BAPI error messages
	 */
	public BAPIErrorMessageDescription[] getAllBAPIErrorMessages()
	{
		BAPIErrorMessageDescription[] res = new BAPIErrorMessageDescription[ allBAPIErrors.size() ];
		int i = 0;
		for (Iterator<BAPIErrorMessageDescription> iter = this.allBAPIErrors.iterator(); iter.hasNext(); i++ )
		{
			res[i] = (BAPIErrorMessageDescription) iter.next();
		}
		return res;
	}
	
	/**
	 * Adds a new BAPI error message to this exception.
	 * @param el the new BAPI error message
	 */
	public void addBAPIErrorMessage(BAPIErrorMessageDescription el)
	{
		this.allBAPIErrors.add(el);
	}
		
	/**
	 *  Returns the localized message of this BAPI exception.
	 *  @return message string
	 */
	public String getMessage()
	{
		return getLocalizedMessage();
	}
	
	/**
	 *  Returns the localized message of this BAPI exception.
	 *  @return message string
	 */
	public String getLocalizedMessage()
	{
		StringBuffer buff = new StringBuffer();
		for (Iterator<BAPIErrorMessageDescription> iter = allBAPIErrors.iterator(); iter.hasNext();)
		{
			BAPIErrorMessageDescription err = (BAPIErrorMessageDescription) iter.next();
			if (err != null) buff.append(err.getMessage() + "\n");
		}
		return buff.toString();
	}
	
	/**
	 * This is the type of the error messages of a BAPI exception.
	 * Each BAPI exception may contain one or more error messages.
	 */
	public static class BAPIErrorMessageDescription implements Serializable
	{
		private static final long serialVersionUID = 3365525613392638276L;
		
		private String message;
		private String type;
		private String id;
		private int number;
		private String[] messageVar;
		private String parameter;
		private String system;

		public BAPIErrorMessageDescription()
		{
			this.init();
		}

		private void init()
		{
			this.setType(TYPE_A);
			this.messageVar = new String[4];
		}

        /**
         * Sets the message for this error.
         * @param message the value of the MESSAGE field of this return structure
         */
		public void setMessage(String message){
			this.message = message; 
		}

		/**
		 * Returns the message of this error.
		 * @return the value of the MESSAGE field of this return structure
		 */
		public String getMessage(){
			return this.message; 
		}

		/**
		 * Sets the type of this error.
		 * @param type one of {@link CAFBAPIExecException#TYPE_A} and {@link CAFBAPIExecException#TYPE_E} 
		 */
		public void setType(String type)
		{
			this.type = type;
		}

		/**
		 * Returns the type of this error.
		 * @return one of {@link CAFBAPIExecException#TYPE_A} and {@link CAFBAPIExecException#TYPE_E} 
		 */
		public String getType()
		{
			return this.type;
		}

        /**
         * Sets the ID for this error.
         * @param id the value of the ID field of this return structure
         */
		public void setId(String id)
		{
			this.id = id;
		}

		/**
		 * Returns the ID of this error.
		 * @return the value of the ID field of this return structure
		 */
		public String getId()
		{
			return this.id;
		}

        /**
         * Sets the number for this error.
         * @param number the value of the NUMBER field of this return structure
         */
		public void setNumber(int number)
		{
			this.number = number;
		}

		/**
		 * Returns the number of this error.
		 * @return the value of the NUMBER field of this return structure
		 */
		public int getNumber()
		{
			return this.number;
		}

        /**
         * Sets a message variable for this error.
         * @param index the index of the message variable; must be in the interval [0..3]
         * @param value the value of the MESSAGE_Vindex field of this return structure
         */
		public void setMessageVar(int index, String value) throws IndexOutOfBoundsException
		{
			this.messageVar[index] = value;
		}

        /**
         * Returns a message variable of this error.
         * @param index the index of the message variable; must be in the interval [0..3]
         * @return value the value of the MESSAGE_Vindex field of this return structure
         */
		public String getMessageVar(int index) throws IndexOutOfBoundsException
		{
			return this.messageVar[index];
		}

        /**
         * Sets the parameter for this error.
         * @param parameter the value of the PARAMETER field of this return structure
         */
		public void setParameter(String parameter)
		{
			this.parameter = parameter;
		}

		/**
		 * Returns the parameter of this error.
		 * @return the value of the PARAMETER field of this return structure
		 */
		public String getParameter()
		{
			return this.parameter;
		}

        /**
         * Sets the system for this error.
         * @param system the value of the SYSTEM field of this return structure
         */
		public void setSystem(String system)
		{
			this.system = system;
		}

		/**
		 * Returns the system of this error.
		 * @return the value of the SYSTEM field of this return structure
		 */
		public String getSystem()
		{
			return this.system;
		}
	}
}
