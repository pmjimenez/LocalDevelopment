package com.sap.caf.rt.bol.util;


import java.io.Serializable;
import java.util.Locale;


import com.sap.caf.rt.exception.CAFBaseRuntimeException;

/**
 * This class is used to describe a query filter for use with BO node query methods. 
 */
public class QueryFilter implements Serializable {
	
	public final static String WILDCARD_SYMBOL = "*";
	
	//public final static Object NULL = new Object();
	/** 
	 * A convenience constant which is used when creating a search condition 
	 * for the <code>findByMultipleParamers</code> operation.
	 */
	@Deprecated
    public final static QueryFilter AND;
	/** 
	 * A convenience constant which is used when creating a search condition 
	 * for the <code>findByMultipleParamers</code> operation.
	 */
	@Deprecated
    public final static QueryFilter OR;
	/** 
	 * A convenience constant which is used when creating a search condition 
	 * for the <code>findByMultipleParamers</code> operation.
	 */
	@Deprecated
    public final static QueryFilter NOT;
	/** 
	 * A convenience constant which is used when creating a search condition 
	 * for the <code>findByMultipleParamers</code> operation.
	 */
	@Deprecated
    public final static QueryFilter OPEN_BRACKET;
	/** 
	 * A convenience constant which is used when creating a search condition 
	 * for the <code>findByMultipleParamers</code> operation.
	 */
	@Deprecated
    public final static QueryFilter CLOSE_BRACKET;
    
    
	
	/**
	 * A constant which is used to specify TREX search by category.
	 * @see #setOperation(String)
	 */
    @Deprecated
    public static String OPERATION_CATEGORY = "category";

	/**
	 * A constant which is used to specify TREX search by attribute.
	 * @see #setOperation(String)
	 */
    @Deprecated
    public static String OPERATION_ATTRIBUTE = "attribute";

	/**
	 * A constant which is used to specify TREX search by term.
	 * @see #setOperation(String)
	 */
    @Deprecated
    public static String OPERATION_TERM = "term";

	/**
	 * A constant which is used to specify that this instance won't be treated as a search constraint but as a logical operator "and".
	 * @see #setOperation(String)
	 */
    @Deprecated
    public static String OPERATION_AND = "and";

	/**
	 * A constant which is used to specify that this instance won't be treated as a search constraint but as a logical operator "or".
	 * @see #setOperation(String)
	 */
    @Deprecated
    public static String OPERATION_OR = "or";

    /**
	 * A constant which is used to specify that this instance won't be treated as a search constraint but as a logical operator "no".
	 * @see #setOperation(String)
	 */
    @Deprecated
    public static String OPERATION_NOT = "not";

	/**
	 * A constant which is used to specify that this instance won't be treated as a search constraint but as an opening bracket.
	 * @see #setOperation(String)
	 */
    @Deprecated
    public static String OPERATION_BRACKET_OPEN = "(";

	/**
	 * A constant which is used to specify that this instance won't be treated as a search constraint but as a closing bracket.
	 * @see #setOperation(String)
	 */
    @Deprecated
    public static String OPERATION_BRACKET_CLOSE = ")";

	
    /**
	 * A constant which is used to specify TREX liguistic search.
	 * @see #setOperation(String)
	 */
    @Deprecated
    public static String ACTION_LINGUISTIC = "linguistic";

    /**
	 * A constant which is used to specify TREX fuzzy search.
	 * @see #setOperation(String)
	 */
    @Deprecated
    public static String ACTION_FUZZY = "fuzzy";

    /**
	 * A constant which is used to specify TREX exact search.
	 * @see #setOperation(String)
	 */
    @Deprecated
    public static String ACTION_EXACT = "exact";

    static {
    	AND = new QueryFilter();
    	AND.setOperation(OPERATION_AND);
    	
    	OR = new QueryFilter();
    	OR.setOperation(OPERATION_OR);
    	
    	NOT = new QueryFilter();
    	NOT.setOperation(OPERATION_NOT);
    	
    	OPEN_BRACKET = new QueryFilter();
    	OPEN_BRACKET.setOperation(OPERATION_BRACKET_OPEN);
    	
    	CLOSE_BRACKET = new QueryFilter();
    	CLOSE_BRACKET.setOperation(OPERATION_BRACKET_CLOSE);
    }
	
	private String attribute;
	private Condition condition;
	private String operation;
	private String action;
	
	
	private Object oValueLow, oValueHigh;
	
	/**
	 * Creates an empty query filter instance.
	 * This method is deprecated, use {@link QueryFilterFactory#createFilter(Object)} instead. 
	 */
	@Deprecated
	public QueryFilter() {
	}
    
	
	/**
	 * Creates a copy of a query filter instance.
	 * This method is deprecated, use {@link QueryFilterFactory#createFilter(Object)} instead.  
	 * @param qFilter filter to copy
	 */
	@Deprecated
	public  QueryFilter(QueryFilter qFilter) {
			
			this.setValueLow(qFilter.getValueLow());
			this.setValueHigh(qFilter.getValueHigh());
			
			this.setAction(qFilter.getAction());
	}
	
	/**
	 * Creates a query filter instance for a given value.
	 * This method is deprecated, use {@link QueryFilterFactory#createFilter(Object)} instead. 
	 * @param value the value to be searched for
	 */
	@Deprecated
	public QueryFilter(Object value) {
		
		this.setValueLow(value);
		this.setValueHigh(value);
		this.setCondition(Condition.EQ);		
		this.setAction(QueryFilter.ACTION_LINGUISTIC);
	}
	/**
	 * Creates a query filter instance for a given value and condition.
	 * This method is deprecated, use {@link QueryFilterFactory#createFilter(Object, Condition)} instead. 
	 * @param value the value to be searched for
	 * @param condition the search condition
	 */
	@Deprecated
	public QueryFilter(Object value, Condition condition) {
		this.setValue(value);
		this.setCondition(condition);		
	}

	/**
	 * Transforms this query filter instance to an operator (or, and, etc).
	 * This method is deprecated because direct use of
	 * the <code>findByMultipleParameter</code> operation is discouraged.
	 * @param operation one of the following:
	 * 		{@link #OPERATION_AND}, {@link #OPERATION_OR}, {@link #OPERATION_NOT}, {@link #OPERATION_BRACKET_OPEN}, {@link #OPERATION_BRACKET_CLOSE}
	 * @see #getOperation()
	 */
	@Deprecated
	public void setOperation(String operation) {
		this.operation = operation;
	}

	/**
	 * Returns the operation which this instance represents.
	 * @return the operation
	 * @see #setOperation(String)
	 */
	public String getOperation() {
		return operation;
	}


	/**
	 * Sets the action for TREX search.
	 * @param action the TREX action
	 * @see #getAction()
	 */
	@Deprecated
	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * Gets the action for TREX search.
	 * @return action for TREX search
	 * @see #setAction(String)
	 */
	@Deprecated
	public String getAction() {
		return action;
	}
	
	
	
	/**
	 * Sets the attribute which this query filter instance is for.
	 * @param attribute the BO Node attribute which will be queried
	 * @see QueryFilterFactory#createFilter(String, Condition, Object)
	 * @see #getAttribute()
	 */
	public void setAttribute(String attribute){
		this.attribute = attribute;
	}
	
	/**
	 * Returns the attribute which this query filter instance is for.
	 * @return the BO Node attribute which will be queried
	 * @see #setAttribute(String)
	 * @see QueryFilterFactory#createFilter(String, Condition, Object)
	 */
	public String getAttribute(){
		return this.attribute;
	}
	
	
	/**
	 * Returns the value which this query filter instance will search for.
	 * @return the value which will be searched
	 * @see #setValue(Object)
	 */
	public Object getValue() {
	    return this.oValueLow;
	}

	/**
	 * Sets the value which this query filter instance will search for.
	 * @param value the value which will be searched
	 * @see QueryFilterFactory#createFilter(Object)
	 * @see #getValue()
	 */
	public void setValue(Object value){
		this.oValueLow = this.oValueHigh = value;
	}

	
	/**
	 * Returns the low value which this query filter instance will search for.
	 * Should be used only if the query filter represents a "between" search.
	 * @return the low bound of the search range
	 * @see QueryFilterFactory#createFilterForBetween(Object, Object)
	 * @see #setValueLow(Object)
	 */
	public Object getValueLow() {
		return this.oValueLow;
	}
	/**
	 * Returns the high value which this query filter instance will search for.
	 * Should be used only if the query filter represents a "between" search.
	 * @return the high bound of the search range
	 * @see QueryFilterFactory#createFilterForBetween(Object, Object)
	 * @see #setValueHigh(Object)
	 */
	public Object getValueHigh() {
		return this.oValueHigh;
	}
	
	/**
	 * Sets the low value which this query filter instance will search for.
	 * Should be used only if the query filter represents a "between" search.
	 * @param value the low bound of the search range
	 * @see QueryFilterFactory#createFilterForBetween(Object, Object)
	 * @see #getValueLow()
	 */
	public void setValueLow(Object value){
		this.oValueLow = value;
		
	}
	/**
	 * Sets the high value which this query filter instance will search for.
	 * Should be used only if the query filter represents a "between" search.
	 * @param value the high bound of the search range
	 * @see QueryFilterFactory#createFilterForBetween(Object, Object)
	 * @see #getValueHigh()
	 */
	public void setValueHigh(Object value){
		this.oValueHigh = value;
	}
	
	/**
	 * A convenience method to get the "value" and "operation" properties of this query filter instance.
	 * @param propertyName the name of the propery; valid values are: "minValue", "maxValue", "operation"
	 * @return the value of the requested property
	 * @see #getValueLow()
	 * @see #getValueHigh()
	 * @see #getOperation()
	 */
	public Object getProperty(String propertyName) {
		if ("minValue".equals(propertyName)){
			return this.oValueLow;
		}
		else if ("maxValue".equals(propertyName)) {
			return this.oValueHigh ;
		}
		else if ("operation".equals(propertyName)){
			return this.operation;
		}
		else {
			throw new CAFBaseRuntimeException("Invalid property requested : " + propertyName);
		}
	}

	/**
	 * Indicates whether the search will be performed over a BO node association.
	 * @return true if the search will be over a BO Node association, false if the search will be over a regular BO Node attribute
	 * @see QueryFilterFactory#createFilter(String, Condition, Object)
	 */
	@Deprecated
	public boolean isAssociation() {
		if (this.attribute!=null){
			return (this.attribute.indexOf('.')!=-1);
		}
		return false;
	}
    
	
	/**
	 * Indicates whether the search will be performed over a BO node association and is about the association itself
	 * rather than for a regular attribute of the associated BO Node.
	 * @return true if the search is for a BO Node association
	 * @see QueryFilterFactory#createFilter(String, Condition, Object)
	 */
	@Deprecated
	public boolean isAssociationAttribute() {
		if (this.attribute!=null){
			return (this.attribute.indexOf('.')!=-1 && !this.attribute.toLowerCase(Locale.ENGLISH).endsWith(".key"));
		}
		return false;
	}

	
	/**
	 * Sets the search condition for this query filter instance.
	 * @param condition the search condition
	 * @see Condition
	 * @see #getCondition()
	 */
	public void setCondition(Condition condition) {
		this.condition = condition;
	}
	/**
	 * Gets the search condition of this query filter instance.
	 * @return the search condition of this instance
	 * @see Condition
	 * @see #setCondition(Condition)
	 */
	public Condition getCondition(){
		return this.condition;
		
	}
	/**
	 * Returns a string representation of this query filter's condition.
	 * @return the string representation of the condition
	 */
	public String getConditionAsString(){
		if (this.condition != null){
			return this.condition.toJPAString();
		}
		return null;
	}
	
	/**
	 * Returns a string representation of this query filter
	 * @return the string representation of query filter
	 */
	public String toString() {
		StringBuilder filter = new StringBuilder();
		if (this.operation != null) {
			filter.append(this.operation);
		} else {
			filter.append(this.attribute);
			filter.append(' ');
			filter.append(getConditionAsString());
			filter.append(' ');
			filter.append(this.oValueLow);
			if (this.oValueHigh != null && this.oValueHigh != this.oValueLow) {
				filter.append(',');
				filter.append(this.oValueHigh);
			}
		}
		return filter.toString();
	}
}
