package com.sap.caf.rt.bol.da.jpa.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.sap.caf.rt.bol.da.jpa.ILanguageDependent;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface CAFStructure {
	public Class pojoClass();
	public boolean mainStructure() default false;
	public String version() default "1.0.0.1";
	public CAFProperty[] properties() default {};
	public Class languageDependendClass() default ILanguageDependent.class;
}
