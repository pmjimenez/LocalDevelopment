/*
 * Created on Mar 25, 2004
 */
package com.sap.caf.rt.exception;

import com.sap.caf.rt.util.CAFResourceAccessor;
import com.sap.exception.BaseExceptionInfo;
import com.sap.localization.LocalizableText;
import com.sap.localization.LocalizableTextFormatter;
import com.sap.localization.ResourceAccessor;
import com.sap.localization.LocalizableText.Msg;
import com.sap.tc.logging.Category;
import com.sap.tc.logging.Location;

/**
 * This exception is thrown when a problem with security checks arises.
 */
@javax.xml.ws.WebFault(name = "CAFPermissionException", targetNamespace = "http://www.sap.com/caf/sap.com/caf.core/faults", faultBean = "com.sap.caf.rt.exception.FaultInfo")
public class CAFPermissionException extends CAFServiceException
{
	private static final long serialVersionUID = -4825084477971603075L;

	/**
	 * Constructs a new CAFPermissionException.
	 * @param location logging location
	 */
	public CAFPermissionException(Location location)
	{
		super(location);
	}
	
	/**
	 * Constructs a new CAFPermissionException.
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location)} instead.
	 */
	public CAFPermissionException()
	{
		super();
	}
	
	/**
	 * Constructs a new CAFPermissionException.
	 * @param baseExcInfo information about the throwable which caused this exception
	 */
	public CAFPermissionException(BaseExceptionInfo baseExcInfo)
	{
		super(baseExcInfo);
	}

	/**
	 * Constructs a new CAFPermissionException.
	 * @param baseExcInfo information about the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFPermissionException(BaseExceptionInfo baseExcInfo, boolean isRealCause)
	{
		super(baseExcInfo, isRealCause);
	}

	/**
	 * Constructs a new CAFPermissionException.
	 * @param location logging location
	 * @param cause the throwable which caused this exception
	 */
	public CAFPermissionException(Location location, Throwable cause)
	{
		super(location, cause);
	}

	/**
	 * Constructs a new CAFPermissionException.
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location, Throwable)} instead.
	 */
	public CAFPermissionException(Throwable cause)
	{
		super(cause);
	}

	/**
	 * Constructs a new CAFPermissionException.
	 * @param location logging location
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFPermissionException(Location location, Throwable cause, boolean isRealCause)
	{
		super(location, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFPermissionException.
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location, Throwable, boolean)} instead.
	 */
	public CAFPermissionException(Throwable cause, boolean isRealCause)
	{
		super(cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFPermissionException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 */
	public CAFPermissionException(Location location, ResourceAccessor ra, String key)
	{
		super(location, ra, key);
	}

	/**
	 * Constructs a new CAFPermissionException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location, ResourceAccessor, String)} instead.
	 */
	public CAFPermissionException(ResourceAccessor ra, String key)
	{
		super(ra, key);
	}
	
	/**
	 * Constructs a new CAFPermissionException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 */
	public CAFPermissionException(Location location, ResourceAccessor ra, String key, Throwable cause)
	{
		super(location, ra, key, cause);
	}
	
	/**
	 * Constructs a new CAFPermissionException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location, ResourceAccessor, String, Throwable)} instead.
	 */
	public CAFPermissionException(ResourceAccessor ra, String key, Throwable cause)
	{
		super(ra, key, cause);
	}

	/**
	 * Constructs a new CAFPermissionException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFPermissionException(Location location, ResourceAccessor ra, String key, Throwable cause, boolean isRealCause)
	{
		super(location, ra, key, cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFPermissionException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location, ResourceAccessor, String, Throwable, boolean)} instead.
	 */
	public CAFPermissionException(ResourceAccessor ra, String key, Throwable cause, boolean isRealCause)
	{
		super(ra, key, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFPermissionException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 */
	public CAFPermissionException(Location location, ResourceAccessor ra, String key, Object[] args)
	{
		super(location, ra, key, args);
	}
	
	/**
	 * Constructs a new CAFPermissionException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location, ResourceAccessor, String, Object[])} instead.
	 */
	public CAFPermissionException(ResourceAccessor ra, String key, Object[] args)
	{
		super(ra, key, args);
	}

	/**
	 * Constructs a new CAFPermissionException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 */
	public CAFPermissionException(Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause)
	{
		super(location, ra, key, args, cause);
	}
	
	/**
	 * Constructs a new CAFPermissionException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location, ResourceAccessor, String, Object[], Throwable)} instead. 
	 */
	public CAFPermissionException(ResourceAccessor ra, String key, Object[] args, Throwable cause)
	{
		super(ra, key, args, cause);
	}
	
	/**
	 * Constructs a new CAFPermissionException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFPermissionException(Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		super(location, ra, key, args, cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFPermissionException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location, ResourceAccessor, String, Object[], Throwable, boolean)} instead.
	 */
	public CAFPermissionException(ResourceAccessor ra, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		super(ra, key, args, cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFPermissionException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 */
	public CAFPermissionException(Location location, ResourceAccessor ra, Msg msg)
	{
		super(location, ra, msg);
	}
	
	/**
	 * Constructs a new CAFPermissionException.
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location, ResourceAccessor, LocalizableText.Msg)} instead.
	 */
	public CAFPermissionException(ResourceAccessor ra, Msg msg)
	{
		super(ra, msg);
	}

	/**
	 * Constructs a new CAFPermissionException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception 
	 */
	public CAFPermissionException(Location location, ResourceAccessor ra, Msg msg, Throwable cause)
	{
		super(location, ra, msg, cause);
	}

	/**
	 * Constructs a new CAFPermissionException.
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location, ResourceAccessor, LocalizableText.Msg, Throwable)} instead. 
	 */
	public CAFPermissionException(ResourceAccessor ra, Msg msg, Throwable cause)
	{
		super(ra, msg, cause);
	}
	
	/**
	 * Constructs a new CAFPermissionException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFPermissionException(Location location, ResourceAccessor ra, Msg msg, Throwable cause, boolean isRealCause)
	{
		super(location, ra, msg, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFPermissionException.
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location, ResourceAccessor, LocalizableText.Msg, Throwable, boolean)} instead. 
	 */
	public CAFPermissionException(ResourceAccessor ra, Msg msg, Throwable cause, boolean isRealCause)
	{
		super(ra, msg, cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFPermissionException.
	 * @param location logging location
	 * @param localizableText localizable message
	 */
	public CAFPermissionException(Location location, LocalizableText localizableText)
	{
		super(location, localizableText);
	}

	/**
	 * Constructs a new CAFPermissionException.
	 * @param localizableText localizable message
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location, LocalizableText)} instead. 
	 */
	public CAFPermissionException(LocalizableText localizableText)
	{
		super(localizableText);
	}

	/**
	 * Constructs a new CAFPermissionException.
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 */
	public CAFPermissionException(Location location, LocalizableText localizableText, Throwable cause)
	{
		super(location, localizableText, cause);
	}
	
	/**
	 * Constructs a new CAFPermissionException.
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location, LocalizableText, Throwable)} instead.
	 */
	public CAFPermissionException(LocalizableText localizableText, Throwable cause)
	{
		super(localizableText, cause);
	}

	/**
	 * Constructs a new CAFPermissionException.
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFPermissionException(Location location, LocalizableText localizableText, Throwable cause, boolean isRealCause)
	{
		super(location, localizableText, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFPermissionException.
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location, LocalizableText, Throwable, boolean)} instead.
	 */
	public CAFPermissionException(LocalizableText localizableText, Throwable cause, boolean isRealCause)
	{
		super(localizableText, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFPermissionException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @deprecated
	 */
	public CAFPermissionException(Category category, int severity, Location location, LocalizableText localizableText, Throwable cause)
	{
		super(category, severity, location, localizableText, cause);
	}

	/**
	 * Constructs a new CAFPermissionException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated
	 */
	public CAFPermissionException(Category category, int severity, Location location, LocalizableText localizableText, Throwable cause, boolean isRealCause)
	{
		super(category, severity, location, localizableText, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFPermissionException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @deprecated
	 */
	public CAFPermissionException(Category category, int severity, Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause)
	{
		super(category, severity, location, ra, key, args, cause);
	}
	
	/**
	 * Constructs a new CAFPermissionException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated
	 */
	public CAFPermissionException(Category category, int severity, Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		super(category, severity, location, ra, key, args, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFPermissionException.
	 * @param textFormatter localizable message
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location, LocalizableText)} instead.
	 */
	public CAFPermissionException(LocalizableTextFormatter textFormatter)
	{
		this((LocalizableText)textFormatter);
	}

	/**
	 * Constructs a new CAFPermissionException.
	 * @param textFormatter localizable message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location, LocalizableText, Throwable)} instead.
	 */
	public CAFPermissionException(LocalizableTextFormatter textFormatter, Throwable cause)
	{
		this((LocalizableText)textFormatter, cause);
	}

	/**
	 * Constructs a new CAFPermissionException.
	 * @param textFormatter localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location, LocalizableText, Throwable, boolean)} instead.
	 */
	public CAFPermissionException(LocalizableTextFormatter textFormatter, Throwable cause, boolean isRealCause)
	{
		this((LocalizableText)textFormatter, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFPermissionException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 */
	public CAFPermissionException(Location location, String key)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key));
	}
	
	/**
	 * Constructs a new CAFPermissionException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location, String)} instead.
	 */
	public CAFPermissionException(String key)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key));
	}
	
	/**
	 * Constructs a new CAFPermissionException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 */
	public CAFPermissionException(Location location, String key, Throwable cause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause);
	}

	/**
	 * Constructs a new CAFPermissionException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location, String, Throwable)} instead.
	 */
	public CAFPermissionException(String key, Throwable cause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause);
	}

	/**
	 * Constructs a new CAFPermissionException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFPermissionException(Location location, String key, Throwable cause, boolean isRealCause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause, isRealCause);
	}

	/**
	 * Constructs a new CAFPermissionException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location, String, Throwable, boolean)} instead.
	 */
	public CAFPermissionException(String key, Throwable cause, boolean isRealCause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause, isRealCause);
	}

	/**
	 * Constructs a new CAFPermissionException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 */
	public CAFPermissionException(Location location, String key, Object[] args)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args));
	}

	/**
	 * Constructs a new CAFPermissionException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location, String, Object[])} instead.
	 */
	public CAFPermissionException(String key, Object[] args)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args));
	}

	/**
	 * Constructs a new CAFPermissionException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 */
	public CAFPermissionException(Location location, String key, Object[] args, Throwable cause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause);
	}

	/**
	 * Constructs a new CAFPermissionException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location, String, Object[], Throwable)} instead.
	 */
	public CAFPermissionException(String key, Object[] args, Throwable cause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause);
	}

	/**
	 * Constructs a new CAFPermissionException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFPermissionException(Location location, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause, isRealCause);
	}

	/**
	 * Constructs a new CAFPermissionException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFPermissionException#CAFPermissionException(Location, String, Object[], Throwable, boolean)} instead.
	 */
	public CAFPermissionException(String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause, isRealCause);
	}
}
