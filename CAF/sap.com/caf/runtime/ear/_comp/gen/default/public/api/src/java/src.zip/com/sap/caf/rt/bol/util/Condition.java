package com.sap.caf.rt.bol.util;

import com.sap.caf.rt.exception.CAFBaseRuntimeException;

/**
 * This enumeration represents, possible conditions that can be used in 
 * {@link QueryFilter} instance.
 * @see QueryFilterFactory#createFilter(Condition, Object)
 * @author Pavel Zahariev
 */
public enum Condition {
	/**
	 * Represents = constraint.
	 */
	EQ,
	/**
	 * Represents &lt; constraint.
	 */
	LT,
	/**
	 * Represents &gt; constraint.
	 */
	GT,
	/**
	 * Represents &lt;= constraint.
	 */
	LE,
	/**
	 * Represents &gt;= constraint.
	 */
	GE,
	/**
	 * Represents != constraint.
	 */
	NEQ,
	/**
	 * Represents between constraint.
	 */
	BETWEEN;
	
	/**
	 * Returns a Condition that corresponds to the supplied string representation.
	 * @param sCondition a String that corresponds to a Condition.
	 * @return the corresponding Condition
	 */
	public static Condition fromString(String sCondition){
		if ("=".equals(sCondition)){
			return EQ;
		}
		else if ("<".equals(sCondition)) {
			return LT;
		}
		else if (">".equals(sCondition)){
			return GT;
		}
		else if ("<=".equals(sCondition)){
			return LE;
		}
		else if (">=".equals(sCondition)){
			return GE;
		}
		else if ("<>".equals(sCondition)){
			return NEQ;
		}
		else if ("BETWEEN".equals(sCondition)){
			return BETWEEN;	
		}
		else 
			throw new CAFBaseRuntimeException ("EXCEPTION_CONDITION_NOT_SUPPORTE", new Object[] {sCondition});
			
	
	}
	/**
	 * Returns JPA representation string for this Condition.
	 * @return JPA representation string for this Condition.
	 */
	public String toJPAString(){
		if (this == EQ){
			return "=";
		}
		else if (this == LT) {
			return "<";
		}
		else if (this == GT){
			return ">";
		}
		else if (this == LE){
			return "<=";
		}
		else if (this == GE){
			return ">=";
		}
		else if (this == NEQ){
			return "<>";
		}
		else if (this == BETWEEN){
			return "BETWEEN";	
		}
		else 
			throw new RuntimeException ("Program error - missing brach for condition " + this);
			
	
	}
}
