package com.sap.caf.rt.util;

import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;

public class DateUtils {
	private static DatatypeFactory datatypeFactory;
	private static Location location = Location.getLocation(DateUtils.class);
	
	static {
		try {
			datatypeFactory = DatatypeFactory.newInstance();	
		} catch (DatatypeConfigurationException e) {
			location.traceThrowableT(Severity.ERROR, "DateUtils.static", e);
		}
		 
	}
	public static Date toDate(XMLGregorianCalendar xmlCalendar) {
		if (xmlCalendar == null) {
			return null;
		}
		
		return xmlCalendar.toGregorianCalendar().getTime();
	}
	
	public static XMLGregorianCalendar fromDate(Date date) {
		if (date == null) {
			return null;
		}
		
		GregorianCalendar gcal = new GregorianCalendar();
		gcal.setTime(date);
		return datatypeFactory.newXMLGregorianCalendar(gcal);
	}
	
	public static XMLGregorianCalendar fromString(String date) {
		if (date == null) {
			return null;
		}
		return datatypeFactory.newXMLGregorianCalendar(date);
	}
	
	/**
	 * Construct new instance of XMLGregorianCalendar for xsd:dateTime data 
	 * types from GregorianCalendar.  
	 * 
	 * @param gcal GregorianCalendar instance 
	 * @return XMLGregorianCalendar with set fields for date and time.
	 */
	public static XMLGregorianCalendar newXMLGregorianCalendar(java.util.GregorianCalendar gcal) {
		int year = gcal.get(GregorianCalendar.YEAR);
		int month = gcal.get(GregorianCalendar.MONTH) + 1;
		int day = gcal.get(GregorianCalendar.DAY_OF_MONTH);
		int hour = gcal.get(GregorianCalendar.HOUR_OF_DAY);
		int minute = gcal.get(GregorianCalendar.MINUTE);
		int second = gcal.get(GregorianCalendar.SECOND);
		int fractionalSecond = gcal.get(GregorianCalendar.MILLISECOND);
		int timezone = (gcal.get(GregorianCalendar.ZONE_OFFSET) + gcal.get(GregorianCalendar.DST_OFFSET)) / (60 * 1000);
		return datatypeFactory.newXMLGregorianCalendar(year, month, day, hour, minute, second, fractionalSecond, timezone);
	}
	
	/**
	 * Construct new instance of XMLGregorianCalendar for xsd:dateTime data
	 * types from Date. 
	 * 
	 * @param date Date instance 
	 * @return XMLGregorianCalendar with set fields for date and time.
	 */
	public static XMLGregorianCalendar newXMLGregorianCalendar(java.util.Date date) {
		if (date == null) {
			return null;
		}
		GregorianCalendar gcal = new GregorianCalendar();
		gcal.setTime(date);
		return newXMLGregorianCalendar(gcal);
	}
	
	/**
	 * Construct new instance of XMLGregorianCalendar for xsd:date and xsd:g* 
	 * data types from GregorianCalendar. 
	 * 
	 * @param gcal GregorianCalendar instance 
	 * @return XMLGregorianCalendar with set fields for date.
	 */

	public static XMLGregorianCalendar newXMLGregorianCalendarDate(java.util.GregorianCalendar gcal) {
		if (gcal == null) {
			return null;
		}
		int year = gcal.get(GregorianCalendar.YEAR);
		int month = gcal.get(GregorianCalendar.MONTH) + 1; 
		int day = gcal.get(GregorianCalendar.DAY_OF_MONTH);
		int timezone = (gcal.get(GregorianCalendar.ZONE_OFFSET) + gcal.get(GregorianCalendar.DST_OFFSET)) / (60 * 1000);
		return datatypeFactory.newXMLGregorianCalendarDate(year, month, day, timezone);
	}
	
	/**
	 * Construct new instance of XMLGregorianCalendar for for xsd:date and xsd:g* 
	 * data types from Date. 
	 * 
	 * @param date Date instance 
	 * @return XMLGregorianCalendar with set fields for date.
	 */
	public static XMLGregorianCalendar newXMLGregorianCalendarDate(Date date) {
		if (date == null) {
			return null;
		}
		GregorianCalendar gcal = new GregorianCalendar();
		gcal.setTime(date);
		return newXMLGregorianCalendarDate(gcal);
	}
	
	/**
	 * Construct new instance of XMLGregorianCalendar for xsd:time 
	 * data types from GregorianCalendar. 
	 * 
	 * @param gcal GregorianCalendar instance
	 * @return XMLGregorianCalendar with set fields for time.
	 */
	public static XMLGregorianCalendar newXMLGregorianCalendarTime(java.util.GregorianCalendar gcal) {
		if (gcal == null) {
			return null;
		}
		int hours = gcal.get(GregorianCalendar.HOUR_OF_DAY);
		int minutes = gcal.get(GregorianCalendar.MINUTE);
		int seconds = gcal.get(GregorianCalendar.SECOND);
		int milliseconds = gcal.get(GregorianCalendar.MILLISECOND);
		int timezone = (gcal.get(GregorianCalendar.ZONE_OFFSET) + gcal.get(GregorianCalendar.DST_OFFSET)) / (60 * 1000);
		
		return datatypeFactory.newXMLGregorianCalendarTime(hours, minutes, seconds, milliseconds, timezone);
	}
	
	/**
	 * Construct new instance of XMLGregorianCalendar for for xsd:time 
	 * data types from Date. 
	 * 
	 * @param date Date instance 
	 * @return XMLGregorianCalendar with set fields for time.
	 */
	public static XMLGregorianCalendar newXMLGregorianCalendarTime(Date date) {
		if (date == null) {
			return null;
		}
		GregorianCalendar gcal = new GregorianCalendar();
		gcal.setTime(date);
		return newXMLGregorianCalendarTime(gcal);
	}
}
