package com.sap.caf.rt.bol.da.jpa;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

import com.sap.caf.foundation.mfw.impl.AbstractElement;
import com.sap.caf.rt.exception.CAFBaseRuntimeException;
import com.sap.tc.logging.Location;

public class PersistentClassHelper {
	private static final Location location = Location.getLocation(PersistentClassHelper.class); 
	
	public static String getEntitySchemaName(Class persistentClass){
		javax.persistence.Entity entityAnnotation = (javax.persistence.Entity)persistentClass.getAnnotation(javax.persistence.Entity.class);
		if (entityAnnotation.name().length() == 0){
			return persistentClass.getSimpleName();
		}
		else{
			return entityAnnotation.name();
		}
	}
	
	public static javax.persistence.TemporalType getTemporalType(Class persistentClass, String fieldName) {
		Method getterMethod = null;
		try {
			getterMethod = persistentClass.getMethod(getGetterMethodByFieldName(fieldName));
		}
		catch(NoSuchMethodException methodExc){
			throw new CAFBaseRuntimeException(location, "EXCEPTION_METHOD_NOT_FOUND_FOR_A", new Object[] {getGetterMethodByFieldName(fieldName), fieldName});
		}
		Annotation[] annotations = getterMethod.getAnnotations();
		for (Annotation annotation: annotations){
			if (annotation instanceof javax.persistence.Temporal) {
				return ((javax.persistence.Temporal)annotation).value();
			}
		}
	
		return null;
		
		
	}
	
	public static Class getFieldType(Class persistentClass, String fieldName) {
		Method getterMethod = null;
		try {
			getterMethod = persistentClass.getMethod(getGetterMethodByFieldName(fieldName));
		}
		catch(NoSuchMethodException methodExc){
			throw new CAFBaseRuntimeException(location, "EXCEPTION_METHOD_NOT_FOUND_FOR_A", new Object[] {getGetterMethodByFieldName(fieldName), fieldName});
		}
		
		return getterMethod.getReturnType();
		
		
	}
	
	
	/**
	 * 
	 * @param fieldName
	 * @return
	 * @note Dublicated with logic from foundation, this method place is not in this class for sure
	 */
	public static String getJAXBDerivedName(String fieldName){
		return AbstractElement.capitalize(fieldName, false);
	}

	public static String getGetterMethodByFieldName(String fieldName) {
		return "get" + AbstractElement.capitalize(fieldName, true);
	}
}
