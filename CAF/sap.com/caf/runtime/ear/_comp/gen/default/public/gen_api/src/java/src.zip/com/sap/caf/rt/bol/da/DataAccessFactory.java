package com.sap.caf.rt.bol.da;

import java.util.Map;

import com.sap.caf.rt.bol.da.remote.RemoteDataAccessService;
import com.sap.caf.rt.exception.CAFDataAccessException;
import com.sap.caf.rt.exception.CAFIllegalStateException;
import com.sap.caf.rt.bol.da.jpa.JPADataAccessService;
import com.sap.caf.rt.bol.da.km.DocumentDataAccessService;

public class DataAccessFactory {
	public static final int DATASOURCE_REMOTE = 2;
	public static final int DATASOURCE_KM = 3;
	public static final int DATASOURCE_JPA = 9;
	
	public static final String ENTITY_MANAGER_PROPERTY = "EntityManager";
	public static final String SESSION_CONTEXT_PROPERTY = "SessionContext";
	public static final String BO_NODE_GUID_PROPERTY = "BONodeGUID";
	public static final String BO_NODE_PROVIDER_PROPERTY = "BONodeProvider";
	public static final String BO_NODE_APPLICATION_PROPERTY = "BONodeApplication";
	public static final String BO_NODE_SERVICE_NAME_PROPERTY = "BONodeServiceName";
	public static final String BO_NODE_NAMESPACE_PROPERTY = "BONodeNamespace";
	public static final String BO_NODE_FULLY_QUALIFIED_NAME = "BONodeFQN";
	public static final String BO_NODE_OBJECT_NAME_PROPERTY = "BONodeObjectName";
	public static final String BO_NODE_OBJECT_TYPE_PROPERTY = "BONodeObjectType";
	public static final String BO_NODE_PERSISTENT_CLASS_PROPERTY = "BONodePersistentClass";
	public static final String BO_NODE_MAIN_STRUCT_CLASS_PROPERTY = "BONodeMainStructClass";
	
	private DataAccessFactory() throws CAFDataAccessException {
	}
	
	public static IDataAccessService getDataAccessService(int origin, Map<String, Object> properties)
		throws CAFDataAccessException {
		switch (origin) {
			case DATASOURCE_REMOTE :
				return new RemoteDataAccessService(properties);
			case DATASOURCE_KM :
				return new DocumentDataAccessService(properties);
			case DATASOURCE_JPA :
				return new JPADataAccessService(properties);
			default :
				throw new CAFIllegalStateException("No such data access service.");
		}
	}
}
