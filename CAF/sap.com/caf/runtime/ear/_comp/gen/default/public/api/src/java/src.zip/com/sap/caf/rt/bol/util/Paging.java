package com.sap.caf.rt.bol.util;

/**
 * This objects specifies paging properties for a particular query
 * @author I034234
 *
 */
public class Paging {
	private int maxResults;
	private int firstResult;
	
	/**
	 * Constructs a paging option that specifies only the maximum number of results to be returned
	 * @param maxResults the maximum number of results to be returned
	 */
	public Paging(int maxResults) {
		this.maxResults = maxResults;
	}
	
	/**
	 * Constructs a paging option that specifies the starting index from the result and the the maximum number of results to be returned   
	 * @param firstResult the starting index from the result
	 * @param maxResults the maximum number of results to be returned
	 */
	public Paging(int firstResult, int maxResults) {
		this.firstResult = firstResult;
		this.maxResults = maxResults;
	}

	/**
	 * Returns the maximum number of results to be returned
	 * @return the maximum number of results to be returned
	 */
	public int getMaxResults() {
		return maxResults;
	}

	/**
	 * Returns the starting index from the result to be returned
	 * @return the starting index from the result to be returned
	 */
	public int getFirstResult() {
		return firstResult;
	}
}
