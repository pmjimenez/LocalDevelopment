package com.sap.caf.rt.bol.da.jpa.annotations;

public @interface CAFProperty {

	public String key();
	
	public String value();
}
