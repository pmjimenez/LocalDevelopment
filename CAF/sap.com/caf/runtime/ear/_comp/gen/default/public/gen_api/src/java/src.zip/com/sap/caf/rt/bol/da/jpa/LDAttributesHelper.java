package com.sap.caf.rt.bol.da.jpa;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;

import com.sap.caf.rt.bol.IDependentObject;
import com.sap.caf.rt.exception.CAFDataAccessException;
import com.sap.guid.IGUIDGenerator;
import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;

public class LDAttributesHelper {
	
	private static final Location log = Location.getLocation(LDAttributesHelper.class);
	
	private final String defaultLanguage;
	private final EntityManager entityManager;
	private final IGUIDGenerator guidGenerator;

	public LDAttributesHelper(EntityManager entityManager, IGUIDGenerator guidGenerator, String defaultLanguage) {
		this.entityManager = entityManager;
		this.guidGenerator = guidGenerator;
		this.defaultLanguage = defaultLanguage;
	}
	
	@SuppressWarnings("unchecked")
	public void detachLanguageDependentAttribute(IPersistableStructure attached, IDependentObject detached, String attributeName) throws InvocationTargetException, IllegalAccessException{
		Map<String, ILanguageDependent> ldAttributesMap = attached.getLanguageDependentAttributes();
		Map<String, String> ldValues = new HashMap<String, String>();
		
		for (Entry<String, ILanguageDependent> entry : ldAttributesMap.entrySet()) {
			String value = entry.getValue()._getProperty(attributeName); 
			if (value == null) {
				continue;
			}
			ldValues.put(entry.getKey(), value);
		}
		
		if (isSimpleSetterCalledFieldPresent(detached, attributeName)) {
			setAttributeValues(detached, attributeName, ldValues);
		}

		detachDefaulLanguageAttributeValue(attached, detached, attributeName, ldValues);
		updateSimpleSetterCalledField(detached, attributeName);
	}
	
	public void attachLanguageDependentAttribute(IPersistableStructure attached, IDependentObject detached, String attributeName, Class<ILanguageDependent> ldClass) throws IllegalAccessException, InvocationTargetException, CAFDataAccessException {
		try {
			boolean wasSimpleSetterCalled = wasSimpleSetterCalled(detached, attributeName);
			attachNewLanguageDependentAttribute(attached, detached, attributeName, ldClass, wasSimpleSetterCalled);
		} catch(NoSuchFieldException ex) {
			//old project - pre Ehp1
			attachOldLanguageDependentAttribute(attached, detached, attributeName, ldClass);
		}
	}
	
	@SuppressWarnings("unchecked")
	private void attachOldLanguageDependentAttribute(IPersistableStructure attached, IDependentObject detached, String attributeName, Class<ILanguageDependent> ldClass) throws CAFDataAccessException{
		
		Map<String, ILanguageDependent> persistentMap = attached.getLanguageDependentAttributes();
		String detachedAttribute = (String) attached.getAttribute(detached, attributeName);
		
		if (detachedAttribute == null && persistentMap != null && !persistentMap.isEmpty()) {
			ILanguageDependent languageDependent = (ILanguageDependent) persistentMap.get(defaultLanguage);
			if (languageDependent != null) {
				languageDependent._setProperty(attributeName, null);
				boolean isEmpty = true;
				for (String propertyName : languageDependent._getPropertyNames()) {
					if (languageDependent._getProperty(propertyName) != null) {
						isEmpty = false;
						break;
					}
				}
				
				if (isEmpty) {
					persistentMap.remove(defaultLanguage);
					entityManager.remove(languageDependent);
				}
			}
		} else if (detachedAttribute != null) {
			ILanguageDependent languageDependent = persistentMap.get(defaultLanguage);
			if (languageDependent != null) {
				languageDependent._setProperty(attributeName, detachedAttribute);
			} else {
				try {
					languageDependent = ldClass.newInstance();
					languageDependent.setKey(guidGenerator.createGUID().toString());
					languageDependent.setOwner(attached);
					languageDependent.setLanguage(defaultLanguage);
					languageDependent._setProperty(attributeName, detachedAttribute);
				} catch (InstantiationException e) {
					log.traceThrowableT(Severity.ERROR, "Unable to instantiate " + ldClass.getName(), e);
					throw new CAFDataAccessException(log, e);
				} catch (IllegalAccessException e) {
					log.traceThrowableT(Severity.ERROR, "Unable to instantiate " + ldClass.getName(), e);
					throw new CAFDataAccessException(log, e);
				}
				persistentMap.put(defaultLanguage, languageDependent);
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	private void attachNewLanguageDependentAttribute(IPersistableStructure attached, IDependentObject detached, String attributeName, Class<ILanguageDependent> ldClass, boolean wasSimpleSetterCalled) throws IllegalAccessException, InvocationTargetException, CAFDataAccessException{
		Map<String, String> ldValues = getAttributeValues(detached, attributeName);
		
		if (wasSimpleSetterCalled) {
			String defaultLocaleValue = (String) attached.getAttribute(detached, attributeName);
			ldValues.put(defaultLanguage, defaultLocaleValue);
		}

		Map<String, ILanguageDependent> languageDependentMap = attached.getLanguageDependentAttributes();
		
		for (Map.Entry<String, String> entry : ldValues.entrySet()) {
			ILanguageDependent languageDependent = (ILanguageDependent) languageDependentMap.get(entry.getKey());
			
			if (languageDependent != null) {
				languageDependent._setProperty(attributeName, entry.getValue());
				
				boolean isEmpty = true;
				for (String propertyName : languageDependent._getPropertyNames()) {
					if (languageDependent._getProperty(propertyName) != null) {
						isEmpty = false;
						break;
					}
				}
				
				if (isEmpty) {
					languageDependentMap.remove(entry.getKey());
					entityManager.remove(languageDependent);
				}				
			} else if (languageDependent == null && entry.getValue() != null){
				try {
					languageDependent = ldClass.newInstance();
					languageDependent.setKey(guidGenerator.createGUID().toString());
					languageDependent.setOwner(attached);
					languageDependent.setLanguage(entry.getKey());
					languageDependent._setProperty(attributeName, entry.getValue());
					languageDependentMap.put(entry.getKey(), languageDependent);
				} catch (InstantiationException e) {
					log.traceThrowableT(Severity.ERROR, "Unable to instantiate " + ldClass.getName(), e);
					throw new CAFDataAccessException(log, e);
				} catch (IllegalAccessException e) {
					log.traceThrowableT(Severity.ERROR, "Unable to instantiate " + ldClass.getName(), e);
					throw new CAFDataAccessException(log, e);
				}
				
			}
		}
		updateSimpleSetterCalledField(detached, attributeName);
	}
	
	private boolean wasSimpleSetterCalled(IDependentObject detached, String attributeName) throws IllegalAccessException, NoSuchFieldException {
		Field field = detached.getClass().getField("__was_set_" + attributeName + "_called");
		return field.getBoolean(detached);
	}
	
	private boolean isSimpleSetterCalledFieldPresent(Object detached, String attributeName) {
		try {
			detached.getClass().getField("__was_set_" + attributeName + "_called");
			return true;
		} catch (NoSuchFieldException e) {
			return false;
		}
	}
	
	private void updateSimpleSetterCalledField(IDependentObject detached, String attributeName) throws IllegalAccessException {
		Field field;
		try {
			field = detached.getClass().getField("__was_set_" + attributeName + "_called");
			field.setBoolean(detached, false);
		} catch (NoSuchFieldException e) {
			// $JL-EXC$ do nothing
		}
	}
	
	private void detachDefaulLanguageAttributeValue(IPersistableStructure attached, IDependentObject detached, String attributeName, Map<String, String> ldValues) {

		//requested language
		String value = ldValues.get(defaultLanguage);
		
		//VM language
		if (value == null) {
			value = ldValues.get(Locale.getDefault().getLanguage());
		}
		
		//English
		if (value == null) {
			value = ldValues.get("en");
		}
		
		attached.setAttribute(detached, attributeName, value);
	}
	
	private void setAttributeValues(Object structure, String name, Map<String, String> values) throws InvocationTargetException, IllegalAccessException {
		Method setter = getMethod(structure.getClass(), "set" + name, false, String.class, String.class);
		for (Map.Entry<String, String> entry : values.entrySet()) {
			setter.invoke(structure, entry.getKey(), entry.getValue());
		}
	}
	
	@SuppressWarnings("unchecked")
	private Map<String, String> getAttributeValues(Object structure, String name) throws IllegalAccessException, InvocationTargetException {
		Method languagesGetterMethod = getMethod(structure.getClass(), "get" + name + "Languages", false);
		Method getter = getMethod(structure.getClass(), "get" + name, false, String.class);
		
		Collection<String> languages = (Collection<String>) languagesGetterMethod.invoke(structure);
		Map<String, String> values = new HashMap<String, String>();
		for (String language : languages) {
			values.put(language, (String) getter.invoke(structure, language));
		}
		return values;
	}
	
	private Method getMethod(Class<?> clazz, String name, boolean caseSensitive, Class<?>... parameterTypes) {
		try {
			if (caseSensitive) {
				return clazz.getDeclaredMethod(name, parameterTypes);
			} else {
				Method[] declaredMethods = clazz.getDeclaredMethods();
				for (Method method : declaredMethods) {
					if (name.equalsIgnoreCase(method.getName()) && compareParameterTypes(parameterTypes, method.getParameterTypes())) {
						return method;
					}
				}
			}
			return null;
		} catch (NoSuchMethodException e) {
			return null;
		}
	}
	
	private boolean compareParameterTypes(Class<?>[] params1, Class<?>[] params2) {
		if (params1 == null) {
			return params2 == null ? true : false; 
		}
		
		if (params2 == null) {
			return false;
		}
		
		if (params1.length != params2.length) {
			return false;
		}
		
		for (int ndx = 0; ndx < params1.length; ndx++) {
			if (!params1[ndx].equals(params2[ndx])) {
				return false;
			}
		}
		
		return true;
	}

}
