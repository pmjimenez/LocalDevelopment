package com.sap.caf.rt.bol.util;

/**
 * Specifies the type of ordering to be used. Use ASC for Ascending and DESC for Descending
 * @author I034234
 *
 */
public enum Order {
	/**
	 * Specifies ascending order
	 */
	ASC, 
	
	/**
	 * Specifies descending order
	 */
	DESC
}
