/*
 * Created on Mar 24, 2004
 */
package com.sap.caf.rt.util;

import com.sap.localization.ResourceAccessor;

import java.util.HashMap;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;


/**
 * This class is used to access CAF localizable messages resources.
 *
 * @author I028584 
 */
public class CAFResourceAccessor extends ResourceAccessor {
    private static final long serialVersionUID = 1;

    private static final String BUNDLE_NAME = "com.sap.caf.rt.resources.CAFExceptionResources";
    private static ResourceAccessor cafStaticResourceAccessor = new CAFResourceAccessor();

    private String cafResourceBundleName;
    private transient HashMap cafBundles;
    private transient ClassLoader resourceAccessorClassLoader;

    /**
     * Creates a new CAFResourceAccessor object.
     */
    public CAFResourceAccessor() {
        this(BUNDLE_NAME, CAFResourceAccessor.class.getClassLoader());
    }

    /**
     * Methods overwrited from base class.
     *
     * @param resourceBundleName the name of the resource bundle
     * @param classLoader class loader
     * 
     */
    public CAFResourceAccessor(String resourceBundleName,
    	ClassLoader classLoader) {
        super(resourceBundleName);
        cafBundles = new HashMap(5);
        this.cafResourceBundleName = resourceBundleName;
        this.resourceAccessorClassLoader = classLoader;
    }

    /**
     * Returns default instance of the resource accessor
     * 
     * @return default instance of the resource accessor
     */
	public static ResourceAccessor getResourceAccessor() {
    	return CAFResourceAccessor.cafStaticResourceAccessor;
    }

    /**
     * Returns a resource accessor for given key
     *
     * @param key the key
     * @param bundleName the name of the bundle
     *
     * @return a resource accessor for the given key
     */
	public static ResourceAccessor getResourceAccessor(
		String key, String bundleName) {
		return new CAFResourceAccessor(bundleName, CAFResourceAccessor.class.getClassLoader());
    }

    /**
     * Returns a resource accessor for given key
     *
     * @param key the key
     * @param bundleName the name of the bundle
     * @param classLoader class loader
     *
     * @return a resource accessor for given key
     */
	public static ResourceAccessor getResourceAccessor(
		String key, String bundleName, ClassLoader classLoader) {
		return new CAFResourceAccessor(bundleName, classLoader);
    }

    /**
     * Returns a localized message text
     *
     * @param locale target locale
     * @param patternKey key of the message
     *
     * @return a localized message text
     */
    public String getMessageText(Locale locale, String patternKey) {
        if (cafBundles == null) {
            cafBundles = new HashMap(5);
        }

        String message = null;

        if (locale == null) {
            locale = Locale.getDefault();
        }

        if ((cafResourceBundleName != null) && (patternKey != null)) {
            synchronized (cafBundles) {
                try {
                    ResourceBundle rb = (ResourceBundle) cafBundles.get(locale);

                    if (rb == null) {
                        rb = ResourceBundle.getBundle(cafResourceBundleName,
                                locale, resourceAccessorClassLoader);

                        if (rb != null) {
                            message = rb.getString(patternKey);
                            cafBundles.put(locale, rb);
                        }
                    } else {
                        message = rb.getString(patternKey);
                    }
                } catch (MissingResourceException e) { // $JL-EXC$
                    message = patternKey;
                }
            }
        }

        return message;
    }

    /**
     * Returns the name of the CAF resource bundle
     *
     * @return the name of the CAF resource bundle
     */
    public String getResourceBundleName() {
        return cafResourceBundleName;
    }
}
