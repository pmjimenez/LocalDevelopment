package com.sap.caf.rt.exception;

import com.sap.caf.rt.util.CAFResourceAccessor;
import com.sap.exception.BaseExceptionInfo;
import com.sap.localization.LocalizableText;
import com.sap.localization.LocalizableTextFormatter;
import com.sap.localization.ResourceAccessor;
import com.sap.localization.LocalizableText.Msg;
import com.sap.tc.logging.Category;
import com.sap.tc.logging.Location;

/**
 * This exception is thrown when a pessimistic lock conflict occurs.
 */
@javax.xml.ws.WebFault(name = "CAFPessimisticLockException", targetNamespace = "http://www.sap.com/caf/sap.com/caf.core/faults", faultBean = "com.sap.caf.rt.exception.FaultInfo")
public class CAFPessimisticLockException extends CAFLockException
{
	private static final long serialVersionUID = 2785674713028443164L;

	/**
	 * A constant indicating that the type of the message is not known. This is the default type.
	 */
	public static final int TYPE_UNDEFINED 					= 1000;
	
	/**
	 * A constant indicating that the locking factory could not be found.
	 */
	public static final int TYPE_NO_FACTORY_FOUND 			= 1100;
	
	/**
	 * A constant indicating a locking collision.
	 */
	public static final int TYPE_LOCK_EXCEPTION 			= 1200; //LockException
	
	/**
	 * A constant indicating that a TechnicalLockException has been thrown by the enqueue server. 
	 */
	public static final int TYPE_TECHNICAL_LOCK_EXCEPTION 	= 1300; //TechnicalLockException
	
	/**
	 * A constant indicating that an IllegalArgumentException has been thrown by the enqueue server.
	 */
	public static final int TYPE_ILLEGAL_ARGUMENT_EXCEPTION = 1400; //IllegalArgumentException
	
	/**
	 * A constant indicating that pessimistic locking is not supported.
	 */
	public static final int TYPE_LOCK_NOT_SUPPORTED			= 1500; 
		

	private int type = TYPE_UNDEFINED;	

	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param location logging location
	 */
	public CAFPessimisticLockException(Location location)
	{
		super(location);
	}
	
	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location)} instead.
	 */
	public CAFPessimisticLockException()
	{
		super();
	}
	
	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param baseExcInfo information about the throwable which caused this exception
	 */
	public CAFPessimisticLockException(BaseExceptionInfo baseExcInfo)
	{
		super(baseExcInfo);
	}

	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param baseExcInfo information about the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFPessimisticLockException(BaseExceptionInfo baseExcInfo, boolean isRealCause)
	{
		super(baseExcInfo, isRealCause);
	}

	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param location logging location
	 * @param cause the throwable which caused this exception
	 */
	public CAFPessimisticLockException(Location location, Throwable cause)
	{
		super(location, cause);
	}

	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location, Throwable)} instead.
	 */
	public CAFPessimisticLockException(Throwable cause)
	{
		super(cause);
	}

	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param location logging location
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFPessimisticLockException(Location location, Throwable cause, boolean isRealCause)
	{
		super(location, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location, Throwable, boolean)} instead.
	 */
	public CAFPessimisticLockException(Throwable cause, boolean isRealCause)
	{
		super(cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 */
	public CAFPessimisticLockException(Location location, ResourceAccessor ra, String key)
	{
		super(location, ra, key);
	}

	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location, ResourceAccessor, String)} instead.
	 */
	public CAFPessimisticLockException(ResourceAccessor ra, String key)
	{
		super(ra, key);
	}
	
	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 */
	public CAFPessimisticLockException(Location location, ResourceAccessor ra, String key, Throwable cause)
	{
		super(location, ra, key, cause);
	}
	
	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location, ResourceAccessor, String, Throwable)} instead.
	 */
	public CAFPessimisticLockException(ResourceAccessor ra, String key, Throwable cause)
	{
		super(ra, key, cause);
	}

	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFPessimisticLockException(Location location, ResourceAccessor ra, String key, Throwable cause, boolean isRealCause)
	{
		super(location, ra, key, cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location, ResourceAccessor, String, Throwable, boolean)} instead.
	 */
	public CAFPessimisticLockException(ResourceAccessor ra, String key, Throwable cause, boolean isRealCause)
	{
		super(ra, key, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 */
	public CAFPessimisticLockException(Location location, ResourceAccessor ra, String key, Object[] args)
	{
		super(location, ra, key, args);
	}
	
	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location, ResourceAccessor, String, Object[])} instead.
	 */
	public CAFPessimisticLockException(ResourceAccessor ra, String key, Object[] args)
	{
		super(ra, key, args);
	}

	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 */
	public CAFPessimisticLockException(Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause)
	{
		super(location, ra, key, args, cause);
	}
	
	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location, ResourceAccessor, String, Object[], Throwable)} instead. 
	 */
	public CAFPessimisticLockException(ResourceAccessor ra, String key, Object[] args, Throwable cause)
	{
		super(ra, key, args, cause);
	}
	
	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFPessimisticLockException(Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		super(location, ra, key, args, cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location, ResourceAccessor, String, Object[], Throwable, boolean)} instead.
	 */
	public CAFPessimisticLockException(ResourceAccessor ra, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		super(ra, key, args, cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 */
	public CAFPessimisticLockException(Location location, ResourceAccessor ra, Msg msg)
	{
		super(location, ra, msg);
	}
	
	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location, ResourceAccessor, LocalizableText.Msg)} instead.
	 */
	public CAFPessimisticLockException(ResourceAccessor ra, Msg msg)
	{
		super(ra, msg);
	}

	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception 
	 */
	public CAFPessimisticLockException(Location location, ResourceAccessor ra, Msg msg, Throwable cause)
	{
		super(location, ra, msg, cause);
	}

	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location, ResourceAccessor, LocalizableText.Msg, Throwable)} instead. 
	 */
	public CAFPessimisticLockException(ResourceAccessor ra, Msg msg, Throwable cause)
	{
		super(ra, msg, cause);
	}
	
	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFPessimisticLockException(Location location, ResourceAccessor ra, Msg msg, Throwable cause, boolean isRealCause)
	{
		super(location, ra, msg, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location, ResourceAccessor, LocalizableText.Msg, Throwable, boolean)} instead. 
	 */
	public CAFPessimisticLockException(ResourceAccessor ra, Msg msg, Throwable cause, boolean isRealCause)
	{
		super(ra, msg, cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param location logging location
	 * @param localizableText localizable message
	 */
	public CAFPessimisticLockException(Location location, LocalizableText localizableText)
	{
		super(location, localizableText);
	}

	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param localizableText localizable message
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location, LocalizableText)} instead. 
	 */
	public CAFPessimisticLockException(LocalizableText localizableText)
	{
		super(localizableText);
	}

	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 */
	public CAFPessimisticLockException(Location location, LocalizableText localizableText, Throwable cause)
	{
		super(location, localizableText, cause);
	}
	
	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location, LocalizableText, Throwable)} instead.
	 */
	public CAFPessimisticLockException(LocalizableText localizableText, Throwable cause)
	{
		super(localizableText, cause);
	}

	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFPessimisticLockException(Location location, LocalizableText localizableText, Throwable cause, boolean isRealCause)
	{
		super(location, localizableText, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location, LocalizableText, Throwable, boolean)} instead.
	 */
	public CAFPessimisticLockException(LocalizableText localizableText, Throwable cause, boolean isRealCause)
	{
		super(localizableText, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @deprecated
	 */
	public CAFPessimisticLockException(Category category, int severity, Location location, LocalizableText localizableText, Throwable cause)
	{
		super(category, severity, location, localizableText, cause);
	}

	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated
	 */
	public CAFPessimisticLockException(Category category, int severity, Location location, LocalizableText localizableText, Throwable cause, boolean isRealCause)
	{
		super(category, severity, location, localizableText, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @deprecated
	 */
	public CAFPessimisticLockException(Category category, int severity, Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause)
	{
		super(category, severity, location, ra, key, args, cause);
	}
	
	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated
	 */
	public CAFPessimisticLockException(Category category, int severity, Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		super(category, severity, location, ra, key, args, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param textFormatter localizable message
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location, LocalizableText)} instead.
	 */
	public CAFPessimisticLockException(LocalizableTextFormatter textFormatter)
	{
		this((LocalizableText)textFormatter);
	}

	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param textFormatter localizable message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location, LocalizableText, Throwable)} instead.
	 */
	public CAFPessimisticLockException(LocalizableTextFormatter textFormatter, Throwable cause)
	{
		this((LocalizableText)textFormatter, cause);
	}

	/**
	 * Constructs a new CAFPessimisticLockException.
	 * @param textFormatter localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location, LocalizableText, Throwable, boolean)} instead.
	 */
	public CAFPessimisticLockException(LocalizableTextFormatter textFormatter, Throwable cause, boolean isRealCause)
	{
		this((LocalizableText)textFormatter, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFPessimisticLockException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 */
	public CAFPessimisticLockException(Location location, String key)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key));
	}
	
	/**
	 * Constructs a new CAFPessimisticLockException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location, String)} instead.
	 */
	public CAFPessimisticLockException(String key)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key));
	}
	
	/**
	 * Constructs a new CAFPessimisticLockException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 */
	public CAFPessimisticLockException(Location location, String key, Throwable cause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause);
	}

	/**
	 * Constructs a new CAFPessimisticLockException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location, String, Throwable)} instead.
	 */
	public CAFPessimisticLockException(String key, Throwable cause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause);
	}

	/**
	 * Constructs a new CAFPessimisticLockException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFPessimisticLockException(Location location, String key, Throwable cause, boolean isRealCause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause, isRealCause);
	}

	/**
	 * Constructs a new CAFPessimisticLockException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location, String, Throwable, boolean)} instead.
	 */
	public CAFPessimisticLockException(String key, Throwable cause, boolean isRealCause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause, isRealCause);
	}

	/**
	 * Constructs a new CAFPessimisticLockException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 */
	public CAFPessimisticLockException(Location location, String key, Object[] args)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args));
	}

	/**
	 * Constructs a new CAFPessimisticLockException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location, String, Object[])} instead.
	 */
	public CAFPessimisticLockException(String key, Object[] args)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args));
	}

	/**
	 * Constructs a new CAFPessimisticLockException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 */
	public CAFPessimisticLockException(Location location, String key, Object[] args, Throwable cause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause);
	}

	/**
	 * Constructs a new CAFPessimisticLockException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location, String, Object[], Throwable)} instead.
	 */
	public CAFPessimisticLockException(String key, Object[] args, Throwable cause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause);
	}

	/**
	 * Constructs a new CAFPessimisticLockException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFPessimisticLockException(Location location, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause, isRealCause);
	}

	/**
	 * Constructs a new CAFPessimisticLockException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFPessimisticLockException#CAFPessimisticLockException(Location, String, Object[], Throwable, boolean)} instead.
	 */
	public CAFPessimisticLockException(String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause, isRealCause);
	}

	/**
	 * Sets the type of the exception.
	 * @param pType one of the following:
	 *		{@link CAFPessimisticLockException#TYPE_UNDEFINED},
	 *		{@link CAFPessimisticLockException#TYPE_NO_FACTORY_FOUND},
	 *		{@link CAFPessimisticLockException#TYPE_LOCK_EXCEPTION},  
	 *		{@link CAFPessimisticLockException#TYPE_TECHNICAL_LOCK_EXCEPTION}, 
	 *		{@link CAFPessimisticLockException#TYPE_ILLEGAL_ARGUMENT_EXCEPTION},
	 *		{@link CAFPessimisticLockException#TYPE_LOCK_NOT_SUPPORTED}
	 * @see #getType() 
	 */
	public void setType(int pType) {
		this.type = pType;
	}

	/**
	 * Returns the type of the exception.
	 * @return one of the following:
	 *		{@link CAFPessimisticLockException#TYPE_UNDEFINED},
	 *		{@link CAFPessimisticLockException#TYPE_NO_FACTORY_FOUND},
	 *		{@link CAFPessimisticLockException#TYPE_LOCK_EXCEPTION},  
	 *		{@link CAFPessimisticLockException#TYPE_TECHNICAL_LOCK_EXCEPTION}, 
	 *		{@link CAFPessimisticLockException#TYPE_ILLEGAL_ARGUMENT_EXCEPTION},
	 *		{@link CAFPessimisticLockException#TYPE_LOCK_NOT_SUPPORTED}
	 * @see #setType(int)
	 */
	public int getType() {
		return this.type;
	}	
}
