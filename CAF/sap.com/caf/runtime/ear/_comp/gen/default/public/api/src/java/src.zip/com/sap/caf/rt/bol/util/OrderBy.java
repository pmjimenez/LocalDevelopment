package com.sap.caf.rt.bol.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.sap.caf.rt.util.OrderByEntry;

/**
 * Represents a list of attributes that should be used to sort the result of a query 
 * @author I034234
 *
 */
public class OrderBy {
	private ArrayList<OrderByEntry> entries;
	
	/**
	 * Constructs empty instance
	 */
	public OrderBy() {
		entries = new ArrayList<OrderByEntry>();
	}
	
	/**
	 * Constructs order by clause for a single attribute. Further attributes may be added using the add() methods
	 * @param attributeName the name of the attribute to be used for sorting
	 * @param order either of Order.ASC or Order.DESC
	 */
	public OrderBy(String attributeName, Order order) {	
		this();
		add(attributeName, order);
	}
	
	/**
	 * Constructs order by clause for a single attribute in ascending order. Further attributes may be added using the add() methods
	 * @param attributeName the name of the attribute to be used for sorting
	 */
	public OrderBy(String attributeName) {	
		this();
		add(attributeName);
	}
	
	/**
	 * Adds attribute to be used for sorting
	 * @param attributeName the name of the attribute to be used for sorting
	 * @param order either of Order.ASC or Order.DESC
	 * @return this instance
	 */
	public OrderBy add(String attributeName, Order order) {
		entries.add(new OrderByEntry(attributeName, order));
		return this;
	}
	
	/**
	 * Adds attribute to be used for sorting
	 * @param attributeName the name of the attribute to be used for sorting
	 * @return this instance
	 */
	public OrderBy add(String attributeName) {
		return add(attributeName, Order.ASC);
	}
	
	/**
	 * Returns a list of attributes-order pairs that will be used for sorting 
	 * @return a list of attributes-order pairs that will be used for sorting
	 */
	public List<OrderByEntry> getEntries() {
		return entries;
	}
	
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		for (Iterator<OrderByEntry> iterator = entries.iterator(); iterator.hasNext();) {
			OrderByEntry entry = (OrderByEntry) iterator.next();
			sb.append(entry.getAttribute()).append(" ").append(entry.getOrder());
			if (iterator.hasNext()) {
				sb.append(", ");
			}
		}
		return sb.toString();
	}
	
}
