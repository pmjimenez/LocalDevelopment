package com.sap.caf.rt.util;

import java.lang.reflect.Method;
import java.text.MessageFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.Duration;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;

import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.sap.caf.rt.exception.CAFBaseRuntimeException;
import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;

import static com.sap.sql.DateTimeNormalizer.*;

public class JPAValuesConvertor {
	private static DatatypeFactory datatypeFactory;
	private static Location loc = Location.getLocation(JPAValuesConvertor.class);
	private static final int RAW_OFFSET = TimeZone.getDefault().getOffset(0)/60000;
	static {
		try {
			datatypeFactory = DatatypeFactory.newInstance();
		}
		catch (DatatypeConfigurationException e){
			loc.traceThrowableT(Severity.ERROR, "Error getting the DatatypeFactory", e);
			throw new RuntimeException(e); 
		}
	}
	
	public static <T>	T convertFromJPAValue(Object value, Class<T> targetClass , String fieldName){
		if (value == null){
			return null;
		}
		if (targetClass.isEnum()) {			
			try {
				Method method = targetClass.getMethod("fromValue", String.class);
				return (T) method.invoke(null, value.toString());
			} catch (Exception e) {
				throw new RuntimeException (e);
			} 			
		}
		if (targetClass.isPrimitive()) {
			return (T) value;
		}		
		if (targetClass.isInstance(value)){
			return (T)value;
		}
		if (datatypeFactory== null){
			throw new CAFBaseRuntimeException(loc, "Unable to create datatype factory");
		}
		if (targetClass == XMLGregorianCalendar.class){
			if (value instanceof String){
				return (T)datatypeFactory.newXMLGregorianCalendar((String)value);
			}
			if (value instanceof java.util.Date){
				java.util.Date dateValue = (java.util.Date)value;
				if (value instanceof java.sql.Date){
					Calendar c = Calendar.getInstance();
					c.setTime(dateValue);
					return (T)datatypeFactory.newXMLGregorianCalendarDate(c.get(Calendar.YEAR), c.get(Calendar.MONTH)+1, c.get(Calendar.DATE),TimeZone.getDefault().getOffset(c.getTimeInMillis())/60000);
				}
				else if (value instanceof java.sql.Time){
					Calendar c = Calendar.getInstance();
					c.setTime(dateValue);
					return (T)datatypeFactory.newXMLGregorianCalendarTime(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE),c.get(Calendar.SECOND), c.get(Calendar.MILLISECOND),RAW_OFFSET);
				}
				else {
					GregorianCalendar gc = new GregorianCalendar();
					gc.setTime(dateValue);
					return (T)datatypeFactory.newXMLGregorianCalendar(gc);
				}
			}
		}else if (targetClass  == Duration.class ){
			assert value instanceof String;
			return (T)datatypeFactory.newDuration((String)value);
		}else if (targetClass == QName.class){
			assert value instanceof String;
			return (T)QName.valueOf((String)value);
		}
		
		throw new CAFBaseRuntimeException(loc, formErrorMessage("EXCEPTION_UNSUPPORTED_FROM_JPA", fieldName,value.getClass().getName(),targetClass.getName()));
	}
	
	
	/**
	 * Performs conversion of value, coming from the client layer into JPA persistable value.
	 * Values coming from client layer are not necessarily directly persistable, but need some conversion.
	 *  
	 * @param <T>
	 * @param value
	 * @param targetClass
	 * @param fieldName name of the CAF field for which conversion takes place. This is only needed in order of throwing exception. 
	 * @return
	 */
	public static <T> T convertToJPAValue (Object value, Class<T> targetClass, String fieldName){
		
		if (value==null){
			return null;
		}
		
		if (value.getClass().isEnum()) {
			try {
				Method method = value.getClass().getMethod("value");
				value = method.invoke(value);
			} catch (Exception e) {
				throw new RuntimeException (e);
			} 	
		}
		
		if (targetClass.isPrimitive()) {
			return (T) value;
		}
		
	    if (value instanceof XMLGregorianCalendar ){
	    	XMLGregorianCalendar xgcValue = (XMLGregorianCalendar)value;
	    	if (targetClass == String.class){
				return (T)xgcValue.toXMLFormat();
			} else if (targetClass == java.util.Date.class){ //Backward compatibility to M3
				return (T)new java.util.Date(getMilliseconds(value));
			} 
	    }
		if (value instanceof XMLGregorianCalendar || value instanceof java.util.Date){
			
			 
			if (targetClass == java.sql.Date.class){
				return (T)new java.sql.Date(normalizeSqlDateMillies(getMilliseconds(value)));
			} else if (targetClass == java.sql.Time.class){
				return (T)new java.sql.Time(normalizeSqlTimeMillies(getMilliseconds(value)));
			} else if (targetClass == java.sql.Timestamp.class){
				return (T)new java.sql.Timestamp(getMilliseconds(value));
			} 
		}else if (value instanceof Duration){
			assert targetClass == String.class;
			return (T)((Duration)value).toString();
		}else if (value instanceof QName){
			assert targetClass == String.class;
			return (T)value.toString();
		}else if (value instanceof Element){	// Workaround for https://jaxb.dev.java.net/issues/show_bug.cgi?id=648
			return (T)getNodeContent((Element)value);
		}
		
		if (targetClass.isInstance(value)){
			if (targetClass == String.class){
				String trimmedStringValue = ((String)value).trim();
				if (trimmedStringValue.length()==0){
					return null;
				}else {
					return (T)trimmedStringValue;
				}
				
			}
			return (T)value;
		}
		if (targetClass==java.io.Serializable.class){
			if (! (value instanceof java.io.Serializable) ){
				throw new CAFBaseRuntimeException(loc, formErrorMessage("EXCEPTION_SERIALIZABLE_EXPECTED" , fieldName, value.getClass().getName()));
			}
			return (T)value;
		}
		throw new CAFBaseRuntimeException(loc, formErrorMessage("EXCEPTION_UNSUPPORTED_JPA_TO",fieldName,value.getClass().getName()));
	}
	
	private static long getMilliseconds(Object value){
		if (value instanceof XMLGregorianCalendar){
			return ((XMLGregorianCalendar)value).toGregorianCalendar().getTimeInMillis();
		}
		else {
			return ((java.util.Date)value).getTime();
		}
		
	}
	
	
	public static <T> T convertToJPAValue (Object value, Class<T> targetClass){
		return convertToJPAValue(value, targetClass, null);
	}
	
	public static <T> T convertFromJPAValue(Object value, Class<T> targetClass){
		return convertFromJPAValue(value, targetClass ,null);
	}
	
	private static String formErrorMessage(String errorTextKey, String fieldName, Object...params ) {
		StringBuilder message = new StringBuilder();
		if (fieldName==null){
			message.append( MessageFormat.format(CAFResourceAccessor.getResourceAccessor().getMessageText(Locale.getDefault(), "PROBLEM_IN_CONVERTING_KEY"), new Object[]{fieldName}));
		}
		message.append(MessageFormat.format(CAFResourceAccessor.getResourceAccessor().getMessageText(Locale.getDefault(), errorTextKey),params ));
		return message.toString();
	}
	
	
	private static String getNodeContent(Element node)
	{
	    StringBuilder result = new StringBuilder();
	    if (node.getNodeType() == Node.ELEMENT_NODE)
	    {
	    	Node child = node.getFirstChild();
	    	while (child != null)
	    	{
		        switch (child.getNodeType())
		        {
		        	case Node.TEXT_NODE:
		        	case Node.CDATA_SECTION_NODE:
		        	case Node.ENTITY_REFERENCE_NODE:
		        	{
		        		result.append(child.getNodeValue());
		        		break;
		        	}
		        }
		        child = child.getNextSibling();
	    	}
	    }
	    return result.toString();
	}
}
