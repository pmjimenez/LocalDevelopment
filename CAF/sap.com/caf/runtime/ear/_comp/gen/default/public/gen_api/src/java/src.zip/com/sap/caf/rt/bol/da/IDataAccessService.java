package com.sap.caf.rt.bol.da;

import java.util.Collection;

import com.sap.caf.rt.bol.IBusinessObjectNodeBase;
import com.sap.caf.rt.bol.util.OrderBy;
import com.sap.caf.rt.bol.util.Paging;
import com.sap.caf.rt.bol.util.QueryFilter;
import com.sap.caf.rt.exception.CAFDataAccessException;

public interface IDataAccessService extends java.io.Serializable {

	void destroy();

	String create(IBusinessObjectNodeBase obj)
		throws CAFDataAccessException;
	Collection<String> create(Collection<? extends IBusinessObjectNodeBase> obj)
		throws CAFDataAccessException;
	IBusinessObjectNodeBase load(String key)
		throws CAFDataAccessException;
	IBusinessObjectNodeBase loadByCustomKeys(IBusinessObjectNodeBase obj)
		throws CAFDataAccessException;
	void store(IBusinessObjectNodeBase obj)
		throws CAFDataAccessException;
	void store(Collection<? extends IBusinessObjectNodeBase> obj)
		throws CAFDataAccessException;
	void remove(IBusinessObjectNodeBase obj)
		throws CAFDataAccessException;
	void remove(Collection<? extends IBusinessObjectNodeBase> obj)
		throws CAFDataAccessException;
	Collection<? extends IBusinessObjectNodeBase> query(QueryFilter[] filters, String operationName)
		throws CAFDataAccessException;
	public Collection<? extends IBusinessObjectNodeBase> query(QueryFilter[] filters, OrderBy orderBy, Paging paging, String operationName) throws CAFDataAccessException;
	
	String getCardinalityOneAssociationTargetKey(String sourceKey, String associationName)
		throws CAFDataAccessException;
	void setCardinalityOneAssociationTargetKey(String sourceKey, String targetKey, String associationName, boolean isComposition)
		throws CAFDataAccessException;

	String[] getCardinalityManyAssociationTargetKeys(String sourceKey, String associationName)
		throws CAFDataAccessException;
	void addCardinalityManyAssociationTargetKeys(String sourceKey, String[] targetKeys, String associationName)
		throws CAFDataAccessException;
	void removeCardinalityManyAssociationTargetKeys(String sourceKey, String[] targetKeys, String associationName, boolean isComposition)
		throws CAFDataAccessException;
}
