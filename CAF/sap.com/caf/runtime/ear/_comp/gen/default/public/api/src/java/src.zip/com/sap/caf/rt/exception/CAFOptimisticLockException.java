package com.sap.caf.rt.exception;

import com.sap.caf.rt.util.CAFResourceAccessor;
import com.sap.exception.BaseExceptionInfo;
import com.sap.localization.LocalizableText;
import com.sap.localization.LocalizableTextFormatter;
import com.sap.localization.ResourceAccessor;
import com.sap.localization.LocalizableText.Msg;
import com.sap.tc.logging.Category;
import com.sap.tc.logging.Location;

/**
 * This exception is thrown when an optimistic lock conflict occures.
 */
@javax.xml.ws.WebFault(name = "CAFOptimisticLockException", targetNamespace = "http://www.sap.com/caf/sap.com/caf.core/faults", faultBean = "com.sap.caf.rt.exception.FaultInfo")
public class CAFOptimisticLockException extends CAFLockException
{
	private static final long serialVersionUID = 874534138012775054L;

	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param location logging location
	 */
	public CAFOptimisticLockException(Location location)
	{
		super(location);
	}
	
	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location)} instead.
	 */
	public CAFOptimisticLockException()
	{
		super();
	}
	
	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param baseExcInfo information about the throwable which caused this exception
	 */
	public CAFOptimisticLockException(BaseExceptionInfo baseExcInfo)
	{
		super(baseExcInfo);
	}

	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param baseExcInfo information about the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFOptimisticLockException(BaseExceptionInfo baseExcInfo, boolean isRealCause)
	{
		super(baseExcInfo, isRealCause);
	}

	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param location logging location
	 * @param cause the throwable which caused this exception
	 */
	public CAFOptimisticLockException(Location location, Throwable cause)
	{
		super(location, cause);
	}

	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location, Throwable)} instead.
	 */
	public CAFOptimisticLockException(Throwable cause)
	{
		super(cause);
	}

	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param location logging location
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFOptimisticLockException(Location location, Throwable cause, boolean isRealCause)
	{
		super(location, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location, Throwable, boolean)} instead.
	 */
	public CAFOptimisticLockException(Throwable cause, boolean isRealCause)
	{
		super(cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 */
	public CAFOptimisticLockException(Location location, ResourceAccessor ra, String key)
	{
		super(location, ra, key);
	}

	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location, ResourceAccessor, String)} instead.
	 */
	public CAFOptimisticLockException(ResourceAccessor ra, String key)
	{
		super(ra, key);
	}
	
	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 */
	public CAFOptimisticLockException(Location location, ResourceAccessor ra, String key, Throwable cause)
	{
		super(location, ra, key, cause);
	}
	
	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location, ResourceAccessor, String, Throwable)} instead.
	 */
	public CAFOptimisticLockException(ResourceAccessor ra, String key, Throwable cause)
	{
		super(ra, key, cause);
	}

	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFOptimisticLockException(Location location, ResourceAccessor ra, String key, Throwable cause, boolean isRealCause)
	{
		super(location, ra, key, cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location, ResourceAccessor, String, Throwable, boolean)} instead.
	 */
	public CAFOptimisticLockException(ResourceAccessor ra, String key, Throwable cause, boolean isRealCause)
	{
		super(ra, key, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 */
	public CAFOptimisticLockException(Location location, ResourceAccessor ra, String key, Object[] args)
	{
		super(location, ra, key, args);
	}
	
	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location, ResourceAccessor, String, Object[])} instead.
	 */
	public CAFOptimisticLockException(ResourceAccessor ra, String key, Object[] args)
	{
		super(ra, key, args);
	}

	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 */
	public CAFOptimisticLockException(Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause)
	{
		super(location, ra, key, args, cause);
	}
	
	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location, ResourceAccessor, String, Object[], Throwable)} instead. 
	 */
	public CAFOptimisticLockException(ResourceAccessor ra, String key, Object[] args, Throwable cause)
	{
		super(ra, key, args, cause);
	}
	
	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFOptimisticLockException(Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		super(location, ra, key, args, cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location, ResourceAccessor, String, Object[], Throwable, boolean)} instead.
	 */
	public CAFOptimisticLockException(ResourceAccessor ra, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		super(ra, key, args, cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 */
	public CAFOptimisticLockException(Location location, ResourceAccessor ra, Msg msg)
	{
		super(location, ra, msg);
	}
	
	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location, ResourceAccessor, LocalizableText.Msg)} instead.
	 */
	public CAFOptimisticLockException(ResourceAccessor ra, Msg msg)
	{
		super(ra, msg);
	}

	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception 
	 */
	public CAFOptimisticLockException(Location location, ResourceAccessor ra, Msg msg, Throwable cause)
	{
		super(location, ra, msg, cause);
	}

	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location, ResourceAccessor, LocalizableText.Msg, Throwable)} instead. 
	 */
	public CAFOptimisticLockException(ResourceAccessor ra, Msg msg, Throwable cause)
	{
		super(ra, msg, cause);
	}
	
	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFOptimisticLockException(Location location, ResourceAccessor ra, Msg msg, Throwable cause, boolean isRealCause)
	{
		super(location, ra, msg, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location, ResourceAccessor, LocalizableText.Msg, Throwable, boolean)} instead. 
	 */
	public CAFOptimisticLockException(ResourceAccessor ra, Msg msg, Throwable cause, boolean isRealCause)
	{
		super(ra, msg, cause, isRealCause);
	}
	
	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param location logging location
	 * @param localizableText localizable message
	 */
	public CAFOptimisticLockException(Location location, LocalizableText localizableText)
	{
		super(location, localizableText);
	}

	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param localizableText localizable message
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location, LocalizableText)} instead. 
	 */
	public CAFOptimisticLockException(LocalizableText localizableText)
	{
		super(localizableText);
	}

	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 */
	public CAFOptimisticLockException(Location location, LocalizableText localizableText, Throwable cause)
	{
		super(location, localizableText, cause);
	}
	
	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location, LocalizableText, Throwable)} instead.
	 */
	public CAFOptimisticLockException(LocalizableText localizableText, Throwable cause)
	{
		super(localizableText, cause);
	}

	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFOptimisticLockException(Location location, LocalizableText localizableText, Throwable cause, boolean isRealCause)
	{
		super(location, localizableText, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location, LocalizableText, Throwable, boolean)} instead.
	 */
	public CAFOptimisticLockException(LocalizableText localizableText, Throwable cause, boolean isRealCause)
	{
		super(localizableText, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @deprecated
	 */
	public CAFOptimisticLockException(Category category, int severity, Location location, LocalizableText localizableText, Throwable cause)
	{
		super(category, severity, location, localizableText, cause);
	}

	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated
	 */
	public CAFOptimisticLockException(Category category, int severity, Location location, LocalizableText localizableText, Throwable cause, boolean isRealCause)
	{
		super(category, severity, location, localizableText, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @deprecated
	 */
	public CAFOptimisticLockException(Category category, int severity, Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause)
	{
		super(category, severity, location, ra, key, args, cause);
	}
	
	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated
	 */
	public CAFOptimisticLockException(Category category, int severity, Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		super(category, severity, location, ra, key, args, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param textFormatter localizable message
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location, LocalizableText)} instead.
	 */
	public CAFOptimisticLockException(LocalizableTextFormatter textFormatter)
	{
		this((LocalizableText)textFormatter);
	}

	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param textFormatter localizable message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location, LocalizableText, Throwable)} instead.
	 */
	public CAFOptimisticLockException(LocalizableTextFormatter textFormatter, Throwable cause)
	{
		this((LocalizableText)textFormatter, cause);
	}

	/**
	 * Constructs a new CAFOptimisticLockException.
	 * @param textFormatter localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location, LocalizableText, Throwable, boolean)} instead.
	 */
	public CAFOptimisticLockException(LocalizableTextFormatter textFormatter, Throwable cause, boolean isRealCause)
	{
		this((LocalizableText)textFormatter, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFOptimisticLockException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 */
	public CAFOptimisticLockException(Location location, String key)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key));
	}
	
	/**
	 * Constructs a new CAFOptimisticLockException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location, String)} instead.
	 */
	public CAFOptimisticLockException(String key)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key));
	}
	
	/**
	 * Constructs a new CAFOptimisticLockException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 */
	public CAFOptimisticLockException(Location location, String key, Throwable cause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause);
	}

	/**
	 * Constructs a new CAFOptimisticLockException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location, String, Throwable)} instead.
	 */
	public CAFOptimisticLockException(String key, Throwable cause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause);
	}

	/**
	 * Constructs a new CAFOptimisticLockException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFOptimisticLockException(Location location, String key, Throwable cause, boolean isRealCause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause, isRealCause);
	}

	/**
	 * Constructs a new CAFOptimisticLockException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location, String, Throwable, boolean)} instead.
	 */
	public CAFOptimisticLockException(String key, Throwable cause, boolean isRealCause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause, isRealCause);
	}

	/**
	 * Constructs a new CAFOptimisticLockException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 */
	public CAFOptimisticLockException(Location location, String key, Object[] args)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args));
	}

	/**
	 * Constructs a new CAFOptimisticLockException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location, String, Object[])} instead.
	 */
	public CAFOptimisticLockException(String key, Object[] args)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args));
	}

	/**
	 * Constructs a new CAFOptimisticLockException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 */
	public CAFOptimisticLockException(Location location, String key, Object[] args, Throwable cause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause);
	}

	/**
	 * Constructs a new CAFOptimisticLockException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location, String, Object[], Throwable)} instead.
	 */
	public CAFOptimisticLockException(String key, Object[] args, Throwable cause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause);
	}

	/**
	 * Constructs a new CAFOptimisticLockException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFOptimisticLockException(Location location, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause, isRealCause);
	}

	/**
	 * Constructs a new CAFOptimisticLockException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFOptimisticLockException#CAFOptimisticLockException(Location, String, Object[], Throwable, boolean)} instead.
	 */
	public CAFOptimisticLockException(String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause, isRealCause);
	}
}
