package com.sap.caf.rt.services.eventing;

import java.lang.reflect.Method;

import javax.naming.InitialContext;
import javax.transaction.Transaction;

import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;

public class TransactionProvider implements ITransactionProvider {

	private final static Location LOC = Location
			.getLocation(TransactionProvider.class);

	private Object transactionManager;
	private Method getTransaction;

	public TransactionProvider() throws EventException {
		try {
			InitialContext ctx = new InitialContext();
			transactionManager = ctx.lookup("ts");
			getTransaction = transactionManager.getClass().getMethod(
					"getTransaction", new Class[] {});
		} catch (Exception e) {
			LOC.traceThrowableT(Severity.ERROR,
					"Error while trying to get the current transaction", e);
			throw new EventException(
					"Error while trying to get the current transaction", e);
		}

	}

	/**
	 * @return The current transaction
	 * @throws EventException
	 *             If there is no current transaction defined or in case of any
	 *             error in time of getting it
	 */
	public Transaction getCurrentTransaction() throws EventException {
		try {
			Transaction tx = (Transaction) getTransaction.invoke(
					transactionManager, new Object[] {});
			if (tx == null) {
				throw new EventException(
						"There is no transaction available. Auditing requires an active transaction!");
			}
			return tx;
		} catch (Exception e) {
			LOC.traceThrowableT(Severity.ERROR,
					"Error while trying to get the current transaction", e);
			throw new EventException(
					"Error while trying to get the current transaction", e);
		}
	}
}
