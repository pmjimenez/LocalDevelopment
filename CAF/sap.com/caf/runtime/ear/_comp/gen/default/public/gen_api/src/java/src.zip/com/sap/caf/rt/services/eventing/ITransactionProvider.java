package com.sap.caf.rt.services.eventing;

import javax.transaction.Transaction;

public interface ITransactionProvider {
	/**
	 * @return The current transaction
	 * @throws EventException
	 *             If there is no current transaction defined or in case of any
	 *             error in time of getting it
	 */
	public Transaction getCurrentTransaction() throws EventException;
}
