/*
 * Created on 2004-11-9
 */
package com.sap.caf.rt.exception;

import java.util.Locale;
import java.util.TimeZone;

import javax.xml.bind.annotation.XmlTransient;

import com.sap.caf.rt.util.CAFResourceAccessor;
import com.sap.localization.ResourceAccessor;
import com.sap.exception.BaseException;
import com.sap.exception.BaseExceptionInfo;
import com.sap.exception.BaseRuntimeException;
import com.sap.localization.LocalizableText;
import com.sap.localization.LocalizableTextFormatter;
import com.sap.localization.LocalizableText.Msg;
import com.sap.tc.logging.Category;
import com.sap.tc.logging.Location;

/**
 * This is the superclass of all unchecked CAF exceptions.
 */
public class CAFBaseRuntimeException extends BaseRuntimeException
{
	private static final long serialVersionUID = -5417000507692539523L;
	
	private boolean isRealCause;

	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param location logging location
	 */
	public CAFBaseRuntimeException(Location location)
	{
		super(location);
		this.isRealCause = true;
	}
	
	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location)} instead.
	 */
	public CAFBaseRuntimeException()
	{
		super();
		this.isRealCause = true;
	}
	
	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param baseExcInfo information about the throwable which caused this exception
	 */
	public CAFBaseRuntimeException(BaseExceptionInfo baseExcInfo)
	{
		super(baseExcInfo);
		this.isRealCause = false;
	}

	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param baseExcInfo information about the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBaseRuntimeException(BaseExceptionInfo baseExcInfo, boolean isRealCause)
	{
		super(baseExcInfo);
		this.isRealCause = isRealCause;
	}

	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param location logging location
	 * @param cause the throwable which caused this exception
	 */
	public CAFBaseRuntimeException(Location location, Throwable cause)
	{
		super(location, cause);
		this.isRealCause = false;
	}

	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location, Throwable)} instead.
	 */
	public CAFBaseRuntimeException(Throwable cause)
	{
		super(cause);
		this.isRealCause = false;
	}

	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param location logging location
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBaseRuntimeException(Location location, Throwable cause, boolean isRealCause)
	{
		super(location, cause);
		this.isRealCause = isRealCause;
	}

	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location, Throwable, boolean)} instead.
	 */
	public CAFBaseRuntimeException(Throwable cause, boolean isRealCause)
	{
		super(cause);
		this.isRealCause = isRealCause;
	}
	
	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 */
	public CAFBaseRuntimeException(Location location, ResourceAccessor ra, String key)
	{
		super(location, ra, key);
		this.isRealCause = true;
	}

	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location, ResourceAccessor, String)} instead.
	 */
	public CAFBaseRuntimeException(ResourceAccessor ra, String key)
	{
		super(ra, key);
		this.isRealCause = true;
	}
	
	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 */
	public CAFBaseRuntimeException(Location location, ResourceAccessor ra, String key, Throwable cause)
	{
		super(location, ra, key, cause);
		this.isRealCause = false;
	}
	
	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location, ResourceAccessor, String, Throwable)} instead.
	 */
	public CAFBaseRuntimeException(ResourceAccessor ra, String key, Throwable cause)
	{
		super(ra, key, cause);
		this.isRealCause = false;
	}

	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBaseRuntimeException(Location location, ResourceAccessor ra, String key, Throwable cause, boolean isRealCause)
	{
		super(location, ra, key, cause);
		this.isRealCause = isRealCause;
	}
	
	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location, ResourceAccessor, String, Throwable, boolean)} instead.
	 */
	public CAFBaseRuntimeException(ResourceAccessor ra, String key, Throwable cause, boolean isRealCause)
	{
		super(ra, key, cause);
		this.isRealCause = isRealCause;
	}

	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 */
	public CAFBaseRuntimeException(Location location, ResourceAccessor ra, String key, Object[] args)
	{
		super(location, ra, key, args);
		this.isRealCause = true;
	}
	
	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location, ResourceAccessor, String, Object[])} instead.
	 */
	public CAFBaseRuntimeException(ResourceAccessor ra, String key, Object[] args)
	{
		super(ra, key, args);
		this.isRealCause = true;
	}

	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 */
	public CAFBaseRuntimeException(Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause)
	{
		super(location, ra, key, args, cause);
		this.isRealCause = false;
	}
	
	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location, ResourceAccessor, String, Object[], Throwable)} instead. 
	 */
	public CAFBaseRuntimeException(ResourceAccessor ra, String key, Object[] args, Throwable cause)
	{
		super(ra, key, args, cause);
		this.isRealCause = false;
	}
	
	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBaseRuntimeException(Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		super(location, ra, key, args, cause);
		this.isRealCause = isRealCause;
	}
	
	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location, ResourceAccessor, String, Object[], Throwable, boolean)} instead.
	 */
	public CAFBaseRuntimeException(ResourceAccessor ra, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		super(ra, key, args, cause);
		this.isRealCause = isRealCause;
	}
	
	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 */
	public CAFBaseRuntimeException(Location location, ResourceAccessor ra, Msg msg)
	{
		super(location, ra, msg);
		this.isRealCause= true;
	}
	
	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location, ResourceAccessor, LocalizableText.Msg)} instead.
	 */
	public CAFBaseRuntimeException(ResourceAccessor ra, Msg msg)
	{
		super(ra, msg);
		this.isRealCause= true;
	}

	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception 
	 */
	public CAFBaseRuntimeException(Location location, ResourceAccessor ra, Msg msg, Throwable cause)
	{
		super(location, ra, msg, cause);
		this.isRealCause = false;
	}

	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location, ResourceAccessor, LocalizableText.Msg, Throwable)} instead. 
	 */
	public CAFBaseRuntimeException(ResourceAccessor ra, Msg msg, Throwable cause)
	{
		super(ra, msg, cause);
		this.isRealCause = false;
	}
	
	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param location logging location
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBaseRuntimeException(Location location, ResourceAccessor ra, Msg msg, Throwable cause, boolean isRealCause)
	{
		super(location, ra, msg, cause);
		this.isRealCause = isRealCause;
	}

	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param ra resource accessor
	 * @param msg message from a resource bundle
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location, ResourceAccessor, LocalizableText.Msg, Throwable, boolean)} instead. 
	 */
	public CAFBaseRuntimeException(ResourceAccessor ra, Msg msg, Throwable cause, boolean isRealCause)
	{
		super(ra, msg, cause);
		this.isRealCause = isRealCause;
	}
	
	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param location logging location
	 * @param localizableText localizable message
	 */
	public CAFBaseRuntimeException(Location location, LocalizableText localizableText)
	{
		super(location, localizableText);
		this.isRealCause = true;
	}

	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param localizableText localizable message
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location, LocalizableText)} instead. 
	 */
	public CAFBaseRuntimeException(LocalizableText localizableText)
	{
		super(localizableText);
		this.isRealCause = true;
	}

	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 */
	public CAFBaseRuntimeException(Location location, LocalizableText localizableText, Throwable cause)
	{
		super(location, localizableText, cause);
		this.isRealCause = false;
	}
	
	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location, LocalizableText, Throwable)} instead.
	 */
	public CAFBaseRuntimeException(LocalizableText localizableText, Throwable cause)
	{
		super(localizableText, cause);
		this.isRealCause = false;
	}

	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBaseRuntimeException(Location location, LocalizableText localizableText, Throwable cause, boolean isRealCause)
	{
		super(location, localizableText, cause);
		this.isRealCause = isRealCause;
	}

	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location, LocalizableText, Throwable, boolean)} instead.
	 */
	public CAFBaseRuntimeException(LocalizableText localizableText, Throwable cause, boolean isRealCause)
	{
		super(localizableText, cause);
		this.isRealCause = isRealCause;
	}

	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @deprecated
	 */
	public CAFBaseRuntimeException(Category category, int severity, Location location, LocalizableText localizableText, Throwable cause)
	{
		super(category, severity, location, localizableText, cause);
		this.isRealCause = false;
	}

	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param localizableText localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated
	 */
	public CAFBaseRuntimeException(Category category, int severity, Location location, LocalizableText localizableText, Throwable cause, boolean isRealCause)
	{
		super(category, severity, location, localizableText, cause);
		this.isRealCause = isRealCause;
	}

	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @deprecated
	 */
	public CAFBaseRuntimeException(Category category, int severity, Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause)
	{
		super(category, severity, location, ra, key, args, cause);
		this.isRealCause = false;
	}
	
	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param category logging category
	 * @param severity logging severity
	 * @param location logging location
	 * @param ra resource accessor
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception 
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated
	 */
	public CAFBaseRuntimeException(Category category, int severity, Location location, ResourceAccessor ra, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		super(category, severity, location, ra, key, args, cause);
		this.isRealCause = isRealCause;
	}

	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param textFormatter localizable message
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location, LocalizableText)} instead.
	 */
	public CAFBaseRuntimeException(LocalizableTextFormatter textFormatter)
	{
		this((LocalizableText)textFormatter);
	}

	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param textFormatter localizable message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location, LocalizableText, Throwable)} instead.
	 */
	public CAFBaseRuntimeException(LocalizableTextFormatter textFormatter, Throwable cause)
	{
		this((LocalizableText)textFormatter, cause);
	}

	/**
	 * Constructs a new CAFBaseRuntimeException.
	 * @param textFormatter localizable message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location, LocalizableText, Throwable, boolean)} instead.
	 */
	public CAFBaseRuntimeException(LocalizableTextFormatter textFormatter, Throwable cause, boolean isRealCause)
	{
		this((LocalizableText)textFormatter, cause, isRealCause);
	}

	/**
	 * Constructs a new CAFBaseRuntimeException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 */
	public CAFBaseRuntimeException(Location location, String key)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key));
	}
	
	/**
	 * Constructs a new CAFBaseRuntimeException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location, String)} instead.
	 */
	public CAFBaseRuntimeException(String key)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key));
	}
	
	/**
	 * Constructs a new CAFBaseRuntimeException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 */
	public CAFBaseRuntimeException(Location location, String key, Throwable cause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause);
	}

	/**
	 * Constructs a new CAFBaseRuntimeException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location, String, Throwable)} instead.
	 */
	public CAFBaseRuntimeException(String key, Throwable cause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause);
	}

	/**
	 * Constructs a new CAFBaseRuntimeException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBaseRuntimeException(Location location, String key, Throwable cause, boolean isRealCause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause, isRealCause);
	}

	/**
	 * Constructs a new CAFBaseRuntimeException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location, String, Throwable, boolean)} instead.
	 */
	public CAFBaseRuntimeException(String key, Throwable cause, boolean isRealCause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key), cause, isRealCause);
	}

	/**
	 * Constructs a new CAFBaseRuntimeException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 */
	public CAFBaseRuntimeException(Location location, String key, Object[] args)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args));
	}

	/**
	 * Constructs a new CAFBaseRuntimeException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location, String, Object[])} instead.
	 */
	public CAFBaseRuntimeException(String key, Object[] args)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args));
	}

	/**
	 * Constructs a new CAFBaseRuntimeException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 */
	public CAFBaseRuntimeException(Location location, String key, Object[] args, Throwable cause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause);
	}

	/**
	 * Constructs a new CAFBaseRuntimeException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location, String, Object[], Throwable)} instead.
	 */
	public CAFBaseRuntimeException(String key, Object[] args, Throwable cause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause);
	}

	/**
	 * Constructs a new CAFBaseRuntimeException with the default CAF resource accessor.
	 * @param location logging location
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 */
	public CAFBaseRuntimeException(Location location, String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		this(location, new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause, isRealCause);
	}

	/**
	 * Constructs a new CAFBaseRuntimeException with the default CAF resource accessor.
	 * @param key the key of the message in the resource bundle
	 * @param args arguments for the message
	 * @param cause the throwable which caused this exception
	 * @param isRealCause <b>true</b> if the currently constructed exception is the real exception and not just a wrapper, <b>false</b> if <code>cause</code> is the real one
	 * @deprecated Use {@link CAFBaseRuntimeException#CAFBaseRuntimeException(Location, String, Object[], Throwable, boolean)} instead.
	 */
	public CAFBaseRuntimeException(String key, Object[] args, Throwable cause, boolean isRealCause)
	{
		this(new LocalizableTextFormatter(CAFResourceAccessor.getResourceAccessor(), key, args), cause, isRealCause);
	}

	/**
	 * Returns the real cause of this exception. This method traverses through the nested exceptions to find the original exception.
	 * @return the real cause of this exception
	 */
	public Throwable getRealCause()
	{
		Throwable currentThrowable = this;
		for (;;)
		{
			
			if (currentThrowable instanceof CAFBaseRuntimeException)
			{
				if (((CAFBaseRuntimeException)currentThrowable).isRealCause)
				{
					break;
				}
			}
			else
			{
				break;
			}
			if (currentThrowable.getCause() == null)
			{
				break;
			}
			currentThrowable = currentThrowable.getCause();
		}
		return currentThrowable;
	}
	
	/**
	 * Returns the localized message of the real cause.
	 * @return localized message string
	 */
	public String getLocalizedMessage()
	{
		Throwable realCause = this.getRealCause();
		if (realCause == this)
		{
			return super.getLocalizedMessage();
		} 
		return realCause.getLocalizedMessage();
	}
	
	/**
	 *  Returns the message of the real cause.
	 *  @return message string
	 */
	public String getMessage()
	{
		Throwable realCause = this.getRealCause();
		if (realCause == this)
		{
			return super.getMessage();
		} 
		return realCause.getMessage();
	} 
	

	/**
	 * Returns the localized message of the real cause. 
	 * @param locale locale to use for formatting
	 * @param timeZone time zone to use for formatting
	 * @return localized message string
	 */
	@XmlTransient
	public String getLocalizedMessage(Locale locale, TimeZone timeZone)
	{
		Throwable realCause = this.getRealCause();
		if (realCause == this)
		{
			return super.getLocalizedMessage();
		}
		if (realCause instanceof BaseException)
		{
			return ((BaseException)realCause).getLocalizedMessage(locale, timeZone);
		}
		return (new BaseException(this.getLogLocation(), realCause)).getNestedLocalizedMessage(locale, timeZone);
	}
	
	/**
	 * Returns the localized message of the real cause.
	 * @param locale locale to use for formatting
	 * @return localized message string
	 */
	@XmlTransient
	public String getLocalizedMessage(Locale locale)
	{
		Throwable realCause = this.getRealCause();
		if (realCause == this)
		{
			return super.getLocalizedMessage();
		}
		if (realCause instanceof BaseException)
		{
			return ((BaseException)realCause).getLocalizedMessage(locale);
		}
		return (new BaseException(this.getLogLocation(), realCause)).getNestedLocalizedMessage(locale);
	}
	
	/**
	 * Returns the localized message of the real cause.
	 * @param timeZone time zone to use for formatting
	 * @return localized message string
	 */
	@XmlTransient
	public String getLocalizedMessage(TimeZone timeZone)
	{
		Throwable realCause = this.getRealCause();
		if (realCause == this)
		{
			return super.getLocalizedMessage();
		}
		if (realCause instanceof BaseException)
		{
			return ((BaseException)realCause).getLocalizedMessage(timeZone);
		}
		return (new BaseException(this.getLogLocation(), realCause)).getNestedLocalizedMessage(timeZone);
	}
}
