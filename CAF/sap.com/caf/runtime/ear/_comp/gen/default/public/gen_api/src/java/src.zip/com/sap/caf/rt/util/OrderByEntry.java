package com.sap.caf.rt.util;

import com.sap.caf.rt.bol.util.Order;

public class OrderByEntry {
	private String attribute;
	private Order order;
	
	
	public OrderByEntry(String attribute, Order order) {
		super();
		this.attribute = attribute;
		this.order = order;
	}
	
	public OrderByEntry(String attribute) {
		this(attribute, Order.ASC);
	}

	public String getAttribute() {
		return attribute;
	}

	public Order getOrder() {
		return order;
	}
}
