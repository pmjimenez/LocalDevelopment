package com.sap.caf.rt.bol.da.jpa.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.sap.caf.rt.bol.da.jpa.model.AttributeType;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface CAFAttribute {
	
	public AttributeType type() default AttributeType.SIMPLE;
	
	/** The attribute name as stored in the model */
	public String name();
	
	/** Is this attribute part of a custom key */
	public boolean customKey() default false;
	
	/** Is this attribute mandatory */
	public boolean mandatory() default false;
	
	/** Meaningful only for String based attributes */
	public int length() default -1;
	
	/** Placeholder for additional properties */
	public CAFProperty[] properties() default {};
}
