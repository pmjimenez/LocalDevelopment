package com.sap.caf.rt.security.util;

import java.util.HashMap;
import java.util.Iterator;

import com.sap.security.api.acl.IAclManager;

public class CAFPermissionName 
{
	
	public static final String create = "create";
	public static final String read = "read";
	public static final String update = "update";
	public static final String delete = "delete";
	public static final String owner = IAclManager.OWNER_PERMISSION;
	public static final String fullcontrol = "fullcontrol";
  
	public static final String remove = "remove";
	public static final String write = "write";
	
	private static final HashMap enu = new HashMap();
	
	private String name = "";
	private CAFPermissionName(String name) {
		this.name = name;
	}

	static {
		   enu.put(delete,new CAFPermissionName(delete));
		   enu.put(fullcontrol,new CAFPermissionName(fullcontrol));
		   enu.put(update,new CAFPermissionName(update));
		   enu.put(owner,new CAFPermissionName(owner));
		   enu.put(read,new CAFPermissionName(read));
		   enu.put(create,new CAFPermissionName(create));
		   enu.put(remove,new CAFPermissionName(remove));
		   enu.put(write,new CAFPermissionName(write));
	  }

	/**
	 *  Returns the name of this CAFPermissionName object  
	 *  @return the name of the CAFPermissionName object
	 * */
	public String getName() {
		return name;
	}

	/**
	 *  Returns Collection of this CAFPermissionName objects as an iterator object 
	 *  @return Collection of this CAFPermissionName objects as an iterator object
	 * */
	public static Iterator getAllNames() {
		return enu.values().iterator();
	}
}
