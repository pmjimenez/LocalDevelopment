/*
 * Created on May 5, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.sap.caf.rt.bol;

import java.util.List;

import javax.jws.WebMethod;

import com.sap.caf.rt.bol.util.QueryFilter;
import com.sap.caf.rt.exception.*;
import com.sap.engine.frame.core.locking.LockingConstants;

/**
 * This is the base interface of all BO Node services.
 */
public interface IBusinessObjectNodeServiceBase {
	
	
	
	/**
	 * Provides a generic way to invoke the create operation.
	 * @param attributes a list of parameter values 
	 * @return the newly created BO node instance
	 * @throws CAFCreateException in case of any problems
	 */
	@WebMethod(exclude = true)
	IBusinessObjectNodeBase createGeneric(List attributes) throws CAFCreateException;
	
	/**
	 * Provides a generic way to invoke the create operation.
	 * This method gives the ability to explicitly assign a value for the key attribute.
	 * This is not recommended since the value of the key is usually assigned inside CAF.
	 * @param key the key value
	 * @param attributes a list of parameter values
	 * @return the newly created BO node instance
	 * @throws CAFCreateException in case of any problems
	 */
	@WebMethod(exclude = true)
	@Deprecated
	IBusinessObjectNodeBase createWithKeyGeneric(String key, List attributes) throws CAFCreateException;
	
	/**
	 * Provides a generic way to invoke the read operation.
	 * @param key the key of the BO Node instance 
	 * @return IBusinessObjectNodeBase the requested BO Node instance
	 * @throws CAFRetrieveException in case of any problems, including a non-existing instance
	 */
	@WebMethod(exclude = true)
	IBusinessObjectNodeBase readGeneric(String key) throws CAFRetrieveException;
	
	/**
	 * Provides a generic way to invoke the update operation.
	 * @param obj the BO Node instance to be updated
	 * @throws CAFUpdateException in case of any problems
	 */
	@WebMethod(exclude = true)
	void updateGeneric(IBusinessObjectNodeBase obj) throws CAFUpdateException;
	
	/**
	 * Provides a generic way to invoke the delete operation. 
	 * @param obj the BO Node instance to be deleted
	 * @throws CAFDeleteException in case of any problems
	 */
	@WebMethod(exclude = true)
	void deleteGeneric(IBusinessObjectNodeBase obj) throws CAFDeleteException;
	
	/**
	 * Provides a generic way to invoke a query operation.
	 * @param operationName the query operation name as defined by the application developer
	 * @param attributes a list of parameter values (instances of {@link QueryFilter})
	 * @return array of found BO Node instances
	 * @throws CAFFindException in case of any problems
	 */
	@WebMethod(exclude = true)
	Object[] findGeneric(String operationName, List attributes) throws CAFFindException;
	
	/** 
	 * A constant used for pessimistic read locking.
	 */
	public static final char MODE_READ = LockingConstants.MODE_SHARED;
	
	/** 
	 * A constant used for pessimistic write locking.
	 */
	public static final char MODE_WRITE = LockingConstants.MODE_EXCLUSIVE_CUMULATIVE;

	/**
	 * Locks a BO Node instance. 
	 * 
	 * @param argument the key of the BO node instance
	 * @param mode the lock mode; one of {@link #MODE_READ} and {@link #MODE_WRITE}
	 * 
	 * @throws CAFPessimisticLockException in case of any problems (including inability to obtain the required lock)
	 */
	@WebMethod(exclude = true)
	public void lock(String argument, char mode) 
		throws CAFPessimisticLockException;

	/**
	 * Locks a few BO Node instances together. 
	 * 
	 * @param arguments the keys of the BO node instances
	 * @param mode the lock mode; one of {@link #MODE_READ} and {@link #MODE_WRITE}
	 * 
	 * @throws CAFPessimisticLockException in case of any problems (including inability to obtain the required lock)
	 */
	@WebMethod(exclude = true)
	public void lock(String arguments[], char mode) 
		throws CAFPessimisticLockException;

	/**
	 * Locks a BO Node instance with timeout.
	 * 
	 * @param argument the key of the BO node instance
	 * @param mode the lock mode; one of {@link #MODE_READ} and {@link #MODE_WRITE}
	 * @param timeout timeout in milliseconds; in case of collision the lock will be requested several times within this timeout
	 * 
	 * @throws CAFPessimisticLockException in case of any problems (including inability to obtain the required lock)
	 */
	@WebMethod(exclude = true)
	public void lock(String argument, char mode, int timeout)
		throws CAFPessimisticLockException;

	/**
	 * Locks a few BO Node instances together with timeout.
	 * 
	 * @param arguments the keys of the BO node instances
	 * @param mode the lock mode; one of {@link #MODE_READ} and {@link #MODE_WRITE}
	 * @param timeout timeout in milliseconds; in case of collision the lock will be requested several times within this timeout
	 * 
	 * @throws CAFPessimisticLockException in case of any problems (including inability to obtain the required lock)
	 */
	@WebMethod(exclude = true)
	public void lock(String arguments[], char mode, int timeout)
		throws CAFPessimisticLockException;

	/**
	 * Unlocks a BO Node instance asynchronously.
	 * 
	 * @param argument the key of the BO node instance
	 * @param mode the lock mode; one of {@link #MODE_READ} and {@link #MODE_WRITE}
	 * @throws CAFPessimisticLockException in case of any problems
	 */
	@WebMethod(exclude = true)
	public void unlock(String argument, char mode) 
		throws CAFPessimisticLockException;

	/**
	 * Unlocks a few BO Node instances asynchronously.
	 * 
	 * @param arguments the keys of the BO node instances
	 * @param mode the lock mode; one of {@link #MODE_READ} and {@link #MODE_WRITE}
	 * @throws CAFPessimisticLockException in case of any problems
	 */
	@WebMethod(exclude = true)
	public void unlock(String arguments[], char mode) 
		throws CAFPessimisticLockException;

	/**
	 * Unlocks a BO Node instance.
	 * 
	 * @param argument the key of the BO node instance
	 * @param mode the lock mode; one of {@link #MODE_READ} and {@link #MODE_WRITE}
	 * @param asynchronous <code>true</code> if the unlocking should be done asynchronously, <code>false</code> if synchronously
	 * @throws CAFPessimisticLockException in case of any problems
	 */
	@WebMethod(exclude = true)
	public void unlock(String argument, char mode, boolean asynchronous)
		throws CAFPessimisticLockException;

	/**
	 * Unlocks a few BO Node instances.
	 * 
	 * @param arguments the keys of the BO node instances
	 * @param mode the lock mode; one of {@link #MODE_READ} and {@link #MODE_WRITE}
	 * @param asynchronous <code>true</code> if the unlocking should be done asynchronously, <code>false</code> if synchronously
	 * @throws CAFPessimisticLockException in case of any problems
	 */
	@WebMethod(exclude = true)
	public void unlock(String arguments[], char mode, boolean asynchronous)
		throws CAFPessimisticLockException;

	/**
	 * Checks whether a BO Node instance may be locked.
	 * <p>
	 * This method is not needed to use the locking. 
	 * It is meant mostly for debugging and tracing.
	 * 
	 *
	 * @throws CAFPessimisticLockException in case of any problems
	 */
	@WebMethod(exclude = true)
	public void assertLocking() 
		throws CAFPessimisticLockException;

	/**
	 * Returns the user to which all locks belong.
	 * It is dependent on the current session or the current transaction.
	 * <p>
	 * This method is not needed to use the locking. 
	 * It is meant mostly for debugging and tracing.
	 * 
	 * @return the user ID of the locks owner
	 * @throws CAFPessimisticLockException in case of any problems
	 */
	@WebMethod(exclude = true)
	public String getCurrentOwner() 
		throws CAFPessimisticLockException;
}
