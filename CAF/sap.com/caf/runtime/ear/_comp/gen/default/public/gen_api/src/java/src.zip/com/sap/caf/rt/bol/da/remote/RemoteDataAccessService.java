/*
 * Created on Mar 15, 2004 
 */
package com.sap.caf.rt.bol.da.remote;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.sap.caf.foundation.mm.cafmm.IAttributePath;
import com.sap.caf.foundation.mm.cafmm.IBONodeCAFInterface;
import com.sap.caf.foundation.mm.cafmm.ICAFOperation;
import com.sap.caf.foundation.mm.cafmm.IOperationType;
import com.sap.caf.foundation.mm.coremm.IAttribute;
import com.sap.caf.foundation.mm.coremm.IOperation;
import com.sap.caf.foundation.mm.coremm.IOperationMessage;
import com.sap.caf.foundation.mm.coremm.IStructure;
import com.sap.caf.foundation.mm.coremm.ITypeReference;
import com.sap.caf.metamodel.values.IOperationMessageValue;
import com.sap.caf.metamodel.values.converters.IQueryFilterValueConverter;
import com.sap.caf.metamodel.values.converters.ValueConvertersFactory;
import com.sap.caf.rt.bol.IBusinessObjectNodeBase;
import com.sap.caf.rt.bol.da.DataAccessFactory;
import com.sap.caf.rt.bol.da.IDataAccessService;
import com.sap.caf.rt.bol.da.jpa.JPADataAccessService;
import com.sap.caf.rt.bol.da.remote.internal.RemoteDataAccessHelper;
import com.sap.caf.rt.bol.pk.PrimaryKeyFactory;
import com.sap.caf.rt.bol.util.OrderBy;
import com.sap.caf.rt.bol.util.Paging;
import com.sap.caf.rt.bol.util.QueryFilter;
import com.sap.caf.rt.connectivity.ConnectivityFactory;
import com.sap.caf.rt.connectivity.IExternalOperationExecutor;
import com.sap.caf.rt.connectivity.exception.CAFExtExecException;
import com.sap.caf.rt.connectivity.exception.CAFMappingException;
import com.sap.caf.rt.exception.CAFDataAccessException;
import com.sap.caf.rt.metamodel.MetaModel;
import com.sap.caf.rt.metamodel.MetaModel.MetadataSource;
import com.sap.caf.rt.util.DateUtils;
import com.sap.caf.rt.util.internal.Utils;
import com.sap.security.api.UMFactory;
import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;

/**
 * @author Daniel Simeonov i028505
 */
public class RemoteDataAccessService implements IDataAccessService {
	private static final long serialVersionUID = 1;
	private static final Location location = Location.getLocation(RemoteDataAccessService.class);
	
	private IDataAccessService jpaDataAccessService;	
	private static RemoteDataAccessHelper remoteDataAccessHelper = new RemoteDataAccessHelper();
	private String boNodeGUID; 
	private Class persistentClass;
	
	private static Set defaultAttributesSet = new HashSet<String>(Arrays.asList(IStructure.DEFAULT_ATTRIBUTES)); 
	
	public RemoteDataAccessService(Map<String, Object> properties) throws CAFDataAccessException {
		this.jpaDataAccessService = DataAccessFactory.getDataAccessService(com.sap.caf.rt.bol.da.DataAccessFactory.DATASOURCE_JPA, properties);
		this.boNodeGUID = (String)properties.get(DataAccessFactory.BO_NODE_GUID_PROPERTY);;
		this.persistentClass = (Class)properties.get(DataAccessFactory.BO_NODE_PERSISTENT_CLASS_PROPERTY);
	}

	public String create(IBusinessObjectNodeBase object) throws CAFDataAccessException {
		Collection<IBusinessObjectNodeBase> objects = new LinkedList<IBusinessObjectNodeBase>();
		objects.add(object);
		return this.create(objects).iterator().next();
	}
	
	public Collection<String> create(Collection<? extends IBusinessObjectNodeBase> objects) throws CAFDataAccessException {
		IBONodeCAFInterface boNode = MetaModel.getInstance().getBusinessEntityInterfaceByBOGUID(this.boNodeGUID, MetadataSource.MMR);
		ICAFOperation internalOperation = remoteDataAccessHelper.getInternalOperation(boNode, IOperationType.CREATE);
		if (!hasOperationMapping(internalOperation)) {
			throw new CAFDataAccessException(location, "SERVICE_OPERATION_NOT_MAPPED",  new Object[] {internalOperation.getName()});
		}
		ICAFOperation externalOperation = internalOperation.getInternalMapping().getExternalMappingHostOperation();
		IExternalOperationExecutor executor = ConnectivityFactory.getExternalOperationExecutor();
		
		for (IBusinessObjectNodeBase object : objects)
		{
			try {
				List source = prepareInputParameters(object, internalOperation);
				List list = executor.execute(source, internalOperation, externalOperation, Utils.getCallerLocale(), 
							object.getClass().getClassLoader());
				
				// if the external operation returns the custom key, they are set, unless the particular custom key is set in the input of the operation.
				HashSet<String> customKeysSetInInput = new HashSet<String>();			
				Collection<IAttributePath> attrPaths = boNode.getCustomKeyAttributePaths();			
				for (IAttributePath path : attrPaths) {
					IAttribute customKey = path.getLeafAttribute();
					Object customKeyValue = object.getProperty(customKey.getName());
	
					if (customKeyValue != null && !customKeyValue.equals("")) customKeysSetInInput.add(customKey.getName());
				}
	
				Iterator listIterator = list.iterator();
				for (ITypeReference argument : internalOperation.getOutputOperationMessage().getArguments()) {
					Object obj = listIterator.next();
	
					if (obj != null && !obj.equals("") && !customKeysSetInInput.contains(argument.getName())) {
						object.setProperty(argument.getName(), obj);
					}
				}
			} catch (CAFMappingException e) {
				Object[] args = { object };
				location.traceThrowableT(Severity.ERROR, "Error creating BONode of {0}", args, e);
				throw new CAFDataAccessException(location, e);
			} catch (CAFExtExecException e) {
				Object[] args = { object };
				location.traceThrowableT(Severity.ERROR, "Error creating BONode of {0}", args, e);
				throw new CAFDataAccessException(location, e);
			}
		}

		return jpaDataAccessService.create(objects);
	}	

	public void destroy() {	}

	public IBusinessObjectNodeBase load(String key) throws CAFDataAccessException {
		IBusinessObjectNodeBase object = jpaDataAccessService.load(key);
		if (object == null) { // BO does not exist
			return null;
		}
		IBusinessObjectNodeBase result = loadByCustomKeys(object);
		return result;
	}
	
	public IBusinessObjectNodeBase loadByCustomKeys(IBusinessObjectNodeBase object) throws CAFDataAccessException {
		if (object != null) {
			IBONodeCAFInterface boNode = MetaModel.getInstance().getBusinessEntityInterfaceByBOGUID(this.boNodeGUID, MetadataSource.MMR);		
			IExternalOperationExecutor executor = ConnectivityFactory.getExternalOperationExecutor();
			
			try {
				ICAFOperation internalOperation = remoteDataAccessHelper.getInternalOperation(boNode, IOperationType.READ);
				if (!hasOperationMapping(internalOperation)) {
					throw new CAFDataAccessException(location, "SERVICE_OPERATION_NOT_MAPPED",  new Object[] {internalOperation.getName()});
				}

				List source = prepareInputParameters(object, internalOperation);
				ICAFOperation externalOperation = internalOperation.getInternalMapping().getExternalMappingHostOperation();
				List list = executor.execute(source, internalOperation, externalOperation, Utils.getCallerLocale(), object.getClass().getClassLoader());
				
				Collection attrPaths = boNode.getCustomKeyAttributePaths();

				List<ITypeReference> arguments = internalOperation.getOutputOperationMessage().getArguments();
				Iterator valuesIter = list.iterator();
				for (ITypeReference reference : arguments) {
					String refName = reference.getName();
					Object value = valuesIter.next();
					
					if (isCustomNonKeyAttribute(refName, attrPaths) ) {
						object.setProperty(refName, value);
					}
				}
			} catch (CAFMappingException e) {
				Object[] args = { object };
				location.traceThrowableT(Severity.ERROR, "Error reading BONode of {0}", args, e);
				throw new CAFDataAccessException(location, e);
			} catch (CAFExtExecException e) {
				Object[] args = { object };
				location.traceThrowableT(Severity.ERROR, "Error reading BONode of {0}", args, e);
				throw new CAFDataAccessException(location, e);
			}
			((JPADataAccessService)jpaDataAccessService).store(object, DateUtils.toDate(object.getModifiedAt()), object.getModifiedBy());
		}
		
		return object;
	}

	private boolean isCustomNonKeyAttribute(String propertyName, Collection attrPaths) {
		for (Iterator iter = attrPaths.iterator(); iter.hasNext();) {
			IAttributePath path = (IAttributePath) iter.next();
			IAttribute attribute = path.getLeafAttribute();
			if (attribute.getName().equals(propertyName)) return false;
		}

		return !defaultAttributesSet.contains(propertyName);
	}

	public Collection<IBusinessObjectNodeBase> query(QueryFilter[] filters, String operationName) throws CAFDataAccessException {
		if (operationName == null || "".equals(operationName) || "findByMultipleParameters".equals(operationName)) { // handle findByMultipleParamters
			throw new CAFDataAccessException(location, "Operation not supported.");
		}
		
		try {
			ArrayList<QueryFilter> filtersWithBONodeAssosiations = new ArrayList<QueryFilter>();
			ArrayList<QueryFilter> filtersWithoutBONodeAssosiations = new ArrayList<QueryFilter>();
			for (int i = 0; i < filters.length; i++) {
				if (filters[i].isAssociationAttribute()) {
					throw new CAFDataAccessException(location, "Operation not supported.");
				}
				if (filters[i].isAssociation()) {
					filtersWithBONodeAssosiations.add(filters[i]);
				} else {
					filtersWithoutBONodeAssosiations.add(filters[i]);				
				}
			}

			Collection result;
			
			if (filtersWithBONodeAssosiations.isEmpty()) {			
				result = queryWithoutBONodeAssosiations(filters, operationName);			
			} else {
				QueryFilter[] withBONodeAssosiations = (QueryFilter[]) filtersWithBONodeAssosiations.toArray(new QueryFilter[0]);		
				QueryFilter[] withoutBONodeAssosiations = (QueryFilter[]) filtersWithoutBONodeAssosiations.toArray(new QueryFilter[0]);

				Collection resultWithEntityRefs = jpaDataAccessService.query(withBONodeAssosiations, operationName);			
				if (resultWithEntityRefs.isEmpty()) {
					result = Collections.EMPTY_LIST; 
				} else {
					Collection resultWithoutEntityRefs = queryWithoutBONodeAssosiations(withoutBONodeAssosiations, operationName);
					result = intersect(resultWithEntityRefs, resultWithoutEntityRefs);
				}			
			}
			
			return result;
		} catch (CAFMappingException e) {			
			Object[] args = { filters };
			location.traceThrowableT(Severity.ERROR, "Error quering Business-Object-Instance of type {0} with filters {1}", args, e);			
			throw new CAFDataAccessException(location, e);
		} catch (CAFExtExecException e) {
			Object[] args = { filters };
			location.traceThrowableT(Severity.ERROR, "Error quering Business-Object-Instance of type {0} with filters {1}", args, e);			
			throw new CAFDataAccessException(location, e);
		}
	}
	
	private Collection intersect(Collection<IBusinessObjectNodeBase> coll1, Collection<IBusinessObjectNodeBase> coll2) {
		ArrayList<String> guids = new ArrayList<String>();
		
		for (IBusinessObjectNodeBase boNodeBase : coll1) {
			guids.add(boNodeBase.getKey());			
		} 
		
		ArrayList<IBusinessObjectNodeBase> result = new ArrayList<IBusinessObjectNodeBase>();		
		for (IBusinessObjectNodeBase boNodeBase : coll2) {			
			if (guids.contains(boNodeBase.getKey())) {
				result.add(boNodeBase);
			}			
		}

		return result;
	}

	private Collection queryWithoutBONodeAssosiations(QueryFilter[] filters, String operationName) throws CAFMappingException, CAFExtExecException, CAFDataAccessException {		
		IBONodeCAFInterface boNode = MetaModel.getInstance().getBusinessEntityInterfaceByBOGUID(this.boNodeGUID, MetadataSource.MMR);
		IExternalOperationExecutor executor = ConnectivityFactory.getExternalOperationExecutor();
		
		ICAFOperation internalOperation = remoteDataAccessHelper.getInternalOperation(boNode, operationName);	
		if (!hasOperationMapping(internalOperation)) {
			throw new CAFDataAccessException(location, "SERVICE_OPERATION_NOT_MAPPED",  new Object[] {internalOperation.getName()});
		}
		IQueryFilterValueConverter converter = ValueConvertersFactory.getInstance().getQueryFilterValueConverter();	
		IOperationMessageValue sourceValue = converter.convertFromJava(filters, internalOperation.getInputOperationMessage());
		ICAFOperation externalOperation = internalOperation.getInternalMapping().getExternalMappingHostOperation();
		IOperationMessageValue resultMessageValue = executor.execute(sourceValue, internalOperation, externalOperation, Utils.getCallerLocale(), 
				persistentClass.getClassLoader());
	
		IOperation operationForApplDev = boNode.getOperationForApplicationDeveloperByName(operationName);
		IOperationMessage operMessageForApplDev = operationForApplDev.getOutputOperationMessage();
		
		Collection<IBusinessObjectNodeBase> externalList = converter.convertToJava(resultMessageValue, operMessageForApplDev, persistentClass.getClassLoader());

		return processQueryResults(externalList, operationName);		
	}
	
	
	private Collection processQueryResults(Collection results, String operationName) throws CAFDataAccessException {
		Collection<IBusinessObjectNodeBase> result = new ArrayList<IBusinessObjectNodeBase>();
		if (results == null) {
			return result;
		}
		Collection<IBusinessObjectNodeBase> boNodesForCreate = new LinkedList<IBusinessObjectNodeBase>();
		Collection<IBusinessObjectNodeBase> boNodesForStore = new LinkedList<IBusinessObjectNodeBase>();
		for (Iterator iter = results.iterator(); iter.hasNext();) {
			
			IBusinessObjectNodeBase boNode = (IBusinessObjectNodeBase) iter.next();

			IBusinessObjectNodeBase jdoBoNode = (IBusinessObjectNodeBase)jpaDataAccessService.loadByCustomKeys(boNode);
			if (jdoBoNode == null) {
				String key = PrimaryKeyFactory.getInstance().getPrimaryKey();
				
				boNode.setProperty(IStructure.ATTRIBUTE_NAME__KEY, key);
				boNode.setProperty(IStructure.ATTRIBUTE_NAME__MODIFIED_BY, UMFactory.getLogonAuthenticator().getLoggedInUser().getName());				
				boNode.setProperty(IStructure.ATTRIBUTE_NAME__MODIFIED_AT, DateUtils.fromDate ( new Date() ) );
				boNode.setProperty(IStructure.ATTRIBUTE_NAME__CREATED_BY, UMFactory.getLogonAuthenticator().getLoggedInUser().getName());				
				boNode.setProperty(IStructure.ATTRIBUTE_NAME__CREATED_AT, DateUtils.fromDate ( new Date() ) );
				
				boNodesForCreate.add(boNode);
				result.add(boNode);
			} else {
				String[] properties = boNode.getPropertyList();	
				for (int i=0; i<properties.length; i++) {
					String propertyName = properties[i];

					if (!defaultAttributesSet.contains(propertyName)) {
						jdoBoNode.setProperty(propertyName, boNode.getProperty(propertyName));
					}
				} // for

				boNodesForStore.add(jdoBoNode);
				result.add(jdoBoNode);
			} // else
		} // for
		jpaDataAccessService.create(boNodesForCreate);
		jpaDataAccessService.store(boNodesForStore);
		return result;
	}
	
	public void remove(IBusinessObjectNodeBase object) throws CAFDataAccessException {
		Collection<IBusinessObjectNodeBase> objects = new LinkedList<IBusinessObjectNodeBase>();
		objects.add(object);
		this.remove(objects);
	}
	
	public void remove(Collection<? extends IBusinessObjectNodeBase> objects) throws CAFDataAccessException {
		IBONodeCAFInterface boNode = MetaModel.getInstance().getBusinessEntityInterfaceByBOGUID(this.boNodeGUID, MetadataSource.MMR);
		IExternalOperationExecutor executor = ConnectivityFactory.getExternalOperationExecutor();
		ICAFOperation internalOperation = remoteDataAccessHelper.getInternalOperation(boNode, IOperationType.DELETE);
		if (!hasOperationMapping(internalOperation)) {
			throw new CAFDataAccessException(location, "SERVICE_OPERATION_NOT_MAPPED",  new Object[] {internalOperation.getName()});
		}
		ICAFOperation externalOperation = internalOperation.getInternalMapping().getExternalMappingHostOperation();

		for (IBusinessObjectNodeBase object : objects)
		{
			try {
				List source = prepareInputParameters(object, internalOperation);		
				executor.execute(source, internalOperation, externalOperation, Utils.getCallerLocale(), object.getClass().getClassLoader());
			} catch (CAFMappingException e) {
				Object[] args = { object };
				location.traceThrowableT(Severity.ERROR, "Error deleting BONode of {0}", args, e);
				throw new CAFDataAccessException(location, e);
			} catch (CAFExtExecException e) {
				Object[] args = { object };
				location.traceThrowableT(Severity.ERROR, "Error deleting BONode of {0}", args, e);
				throw new CAFDataAccessException(location, e);
			}
		}
		
		jpaDataAccessService.remove(objects);
	}

	public void store(IBusinessObjectNodeBase object) throws CAFDataAccessException {
		Collection<IBusinessObjectNodeBase> objects = new LinkedList<IBusinessObjectNodeBase>();
		objects.add(object);
		this.store(objects);
	}
	
	public void store(Collection<? extends IBusinessObjectNodeBase> objects) throws CAFDataAccessException {
		IBONodeCAFInterface boNode = MetaModel.getInstance().getBusinessEntityInterfaceByBOGUID(this.boNodeGUID, MetadataSource.MMR);
		IExternalOperationExecutor executor = ConnectivityFactory.getExternalOperationExecutor();
		ICAFOperation internalOperation = remoteDataAccessHelper.getInternalOperation(boNode, IOperationType.UPDATE);	
		if (!hasOperationMapping(internalOperation)) {
			throw new CAFDataAccessException(location, "SERVICE_OPERATION_NOT_MAPPED",  new Object[] {internalOperation.getName()});
		}
		ICAFOperation externalOperation = internalOperation.getInternalMapping().getExternalMappingHostOperation();

		for (IBusinessObjectNodeBase object : objects)
		{
			try {
				List<Object> source = new ArrayList<Object>();
				
				String [] boNodePropNames = object.getPropertyList();
				for (int i = 0; i < boNodePropNames.length; i++) {
					if ("key".equals(boNodePropNames[i] ) )  continue;
					source.add (object.getProperty(boNodePropNames[i] ) );
				}
				
				executor.execute(source, internalOperation, externalOperation, Utils.getCallerLocale(), object.getClass().getClassLoader());
			} catch (CAFMappingException e) {
				Object[] args = { object };
				location.traceThrowableT(Severity.ERROR, "Error updating BONode of {0}", args, e);
				throw new CAFDataAccessException(location, e);
			} catch (CAFExtExecException e) {
				Object[] args = { object };
				location.traceThrowableT(Severity.ERROR, "Error updating BONode of {0}", args, e);
				throw new CAFDataAccessException(location, e);
			}
		}
		
		jpaDataAccessService.store(objects);
	}

	private List prepareInputParameters(IBusinessObjectNodeBase object, ICAFOperation internalOperation) {
		List<Object> source = new ArrayList<Object>();
		for (ITypeReference argument : internalOperation.getInputOperationMessage().getArguments()) {
			source.add(object.getProperty(argument.getName()));
		}
		return source;
	}
	
	public boolean hasOperationMapping(ICAFOperation cafOperation) {
		return cafOperation.getInternalMapping() != null;
	}
	
	// Association related methods
	public String getCardinalityOneAssociationTargetKey(String sourceKey, String associationName) throws CAFDataAccessException {
		return jpaDataAccessService.getCardinalityOneAssociationTargetKey(sourceKey, associationName);
	}
	public void setCardinalityOneAssociationTargetKey(String sourceKey, String targetKey, String associationName, boolean isComposition) throws CAFDataAccessException {
		jpaDataAccessService.setCardinalityOneAssociationTargetKey(sourceKey, targetKey, associationName, isComposition);
	}
	public String[] getCardinalityManyAssociationTargetKeys(String sourceKey, String associationName) throws CAFDataAccessException {
		return jpaDataAccessService.getCardinalityManyAssociationTargetKeys(sourceKey, associationName);
	}
	public void addCardinalityManyAssociationTargetKeys(String sourceKey, String[] targetKeys, String associationName) throws CAFDataAccessException {
		jpaDataAccessService.addCardinalityManyAssociationTargetKeys(sourceKey, targetKeys, associationName);
	}
	public void removeCardinalityManyAssociationTargetKeys(String sourceKey, String[] targetKeys, String associationName, boolean isComposition) throws CAFDataAccessException {
		jpaDataAccessService.removeCardinalityManyAssociationTargetKeys(sourceKey, targetKeys, associationName, isComposition);
	}

	/**
	 * OrderBy and Paging are not implemented for remote persistency 
	 */
	public Collection<? extends IBusinessObjectNodeBase> query(QueryFilter[] filters, OrderBy orderBy, Paging paging,
			String operationName) throws CAFDataAccessException {
		return query(filters, operationName);
	}
}