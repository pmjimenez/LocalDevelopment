package com.sap.caf.dt;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.annotation.ElementType;;

/**
 * Used to annotate a method as controlled by the CAF Designer.
 * This annotation is not available at runtime
 *  
 * @author I033024
 */

@Target({ElementType.METHOD})
@Retention(RetentionPolicy.SOURCE)
public @interface CAFOperation {

	/**
	 * The name of the CAF operation
	 * @return - operation name
	 */
	public String name();
}
