package com.sap.sa.rt.execution;

public class WorkflowExecutionException extends RuntimeException {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public WorkflowExecutionException(String message, Throwable cause) {
        super(message, cause);
    }
}
