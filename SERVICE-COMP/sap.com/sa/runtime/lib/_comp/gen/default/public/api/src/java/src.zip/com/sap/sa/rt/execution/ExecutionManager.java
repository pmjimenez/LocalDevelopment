package com.sap.sa.rt.execution;

public class ExecutionManager {
	
	public static Object execute(ExecutionContext ctx ){
		return getExecutor(ctx).execute(ctx);
	}
	
	
	public static IExecutor getExecutor(ExecutionContext ctx) {
		String property = (String) ctx.getProperty(IExecutor.COMPONENT_NAME);
		if ((property!=null) && (!property.equals(""))) { //$NON-NLS-1$
			return new SCADASExecutor();			
		} else {
			return new WSDASExecutor();			
		}		
	}
}
