package com.sap.sa.rt.mapping;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import com.sap.mapping.lib.definition.api.rule.Mapping;
import com.sap.mapping.lib.definition.implementation.Transporter;
import com.sap.mapping.lib.execution.implementation.Compiler;
import com.sap.sa.rt.logging.LocationFactory;
import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;
import com.sap.tc.logging.SimpleLogger;

public final class MappingsHelper {
    private static final Location location = LocationFactory.INSTANCE.createLocation(MappingsHelper.class);
    private static final String RESOURCE_SEPARATOR = "/"; //$NON-NLS-1$
    private static final int BUFF_SIZE = 4096;
    private static MappingsHelper INSTANCE = new MappingsHelper();

    public static MappingsHelper getInstance() {
        return INSTANCE;
    }

    public com.sap.mapping.lib.execution.api.rule.Mapping getCompiledMapping(String filepath, Class<?> c,
            ICompiledMappingRulesRegistry registry, Compiler compiler) throws CompiledMappingsCreationException {
        final Object cmp = registry.getCompiledMappingRule(c, filepath);
        if (cmp != null) {
            return (com.sap.mapping.lib.execution.api.rule.Mapping) cmp;
        }

        final String packedMappingRule;
        try {
            packedMappingRule = getPackedMappings(filepath, c);
        } catch (IOException e) {
            SimpleLogger.traceThrowable(Severity.FATAL, location, e,
                    "SOL.runtime.000008", "Cannot unpack mappings for {0} for class {1}", filepath, c.getName()); //$NON-NLS-1$ //$NON-NLS-2$
            throw new CompiledMappingsCreationException(e);
        }

        final Mapping runtimeMappingRule;

        try {
            runtimeMappingRule = new Transporter().unpackMapping(packedMappingRule);
        } catch (RuntimeException e) {
            SimpleLogger.traceThrowable(Severity.FATAL, location, e,
                    "SOL.runtime.000009", "Unpacking of packed mapping definitions failed:\n\n{0}", packedMappingRule); //$NON-NLS-1$ //$NON-NLS-2$
            throw new CompiledMappingsCreationException(e);
        }

        final com.sap.mapping.lib.execution.api.rule.Mapping compiledMapping;
        try {
            compiledMapping = compiler.compileMapping(runtimeMappingRule);
        } catch (RuntimeException e) {
            SimpleLogger.traceThrowable(Severity.FATAL, location, e,
                    "SOL.runtime.000010", "Compilation of runtime mapping rule failed:\n\n{0}", runtimeMappingRule.toString()); //$NON-NLS-1$ //$NON-NLS-2$
            throw new CompiledMappingsCreationException(e);
        }

        registry.addCompiledMappingRule(c, filepath, compiledMapping);

        return compiledMapping;
    }

    private String getPackedMappings(String mappingFilename, Class<?> c) throws IOException {
        if (location.beDebug()) {
            SimpleLogger
                    .trace(
                            Severity.DEBUG,
                            location,
                            "SOL.runtime.000011", "Unpacking Xml mapping descriptor {0} as a resource of class {1}", mappingFilename, c.getName()); //$NON-NLS-1$ //$NON-NLS-2$
        }

        final InputStream resourceAsStream;

        resourceAsStream = c.getResourceAsStream(new StringBuilder(RESOURCE_SEPARATOR).append(mappingFilename).toString());
        if (resourceAsStream == null) {
            SimpleLogger
                    .trace(
                            Severity.ERROR,
                            location,
                            "SOL.runtime.000012", "Cannot find Xml mapping descriptor {0} as a resource for class {1}.\n\n Further mapping execution will mostl likely fail. This is probably due to an error in the Service Adaptation Generation.", mappingFilename, c.getName()); //$NON-NLS-1$ //$NON-NLS-2$
            return null;
        }

        final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(resourceAsStream, "UTF-8")); //$NON-NLS-1$
        final StringBuilder content = new StringBuilder(BUFF_SIZE);

        int charsRead = 0;
        final char[] buff = new char[BUFF_SIZE];
        try {
            while ((charsRead = bufferedReader.read(buff, 0, BUFF_SIZE)) != -1) {
                content.append(buff, 0, charsRead);
            }
        } catch (IOException e) {
            SimpleLogger
                    .trace(
                            Severity.ERROR,
                            location,
                            "SOL.runtime.000013", "Xml mapping descriptor {0} as a resource for class {1} could not be unpacked. Further mapping execution will mostl likely fail.", mappingFilename, c.getName()); //$NON-NLS-1$ //$NON-NLS-2$
            throw e;
        } finally {
            try {
                bufferedReader.close();
            } catch (IOException e) {
                if (location.beDebug()) {
                    SimpleLogger
                            .trace(
                                    Severity.DEBUG,
                                    location,
                                    "SOL.runtime.000014", "Cannot close BufferedReader for Xml mapping descriptor {0} as a resource of class {1}.", mappingFilename, c.getName()); //$NON-NLS-1$ //$NON-NLS-2$
                }
            }
        }

        final String unpackedMappingXmlDescriptorContent = content.toString();
        if (location.beDebug()) {
            SimpleLogger
                    .trace(
                            Severity.DEBUG,
                            location,
                            "SOL.runtime.000015", "Unpacked Xml mapping descriptor {0} as a resource of class {1} is:\n\n {2}", mappingFilename, c.getName(), unpackedMappingXmlDescriptorContent); //$NON-NLS-1$ //$NON-NLS-2$
        }

        return unpackedMappingXmlDescriptorContent;
    }
}
