package com.sap.sa.rt.sdo.io;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/**
 * @author I038491
 * 
 *         This class is introduced because of performance improvements. The
 *         idea is to ensure direct access to the internal buffer of the byte
 *         array output stream and not to copy it when creating input stream out
 *         of it.
 */
public class ByteArrayStreamDecorator extends ByteArrayOutputStream {
    /**
     * Instantiates a new output stream with initial size of the internal
     * buffer.
     * 
     * @param initialSize
     *            initial size of the internal buffer.
     */
    public ByteArrayStreamDecorator(int initialSize) {
        super(initialSize);
    }

    /**
     * Creates a new <code>InputStream</code> with direct access to the internal
     * buffer, i.e. no copying of arrays is ever done.
     * 
     * @return an <code>InputStream</code> with direct access to the internal
     *         buffer of the decorator.
     */
    public InputStream createInputStream() {
        return new ByteArrayInputStream(buf, 0, count);
    }
}
