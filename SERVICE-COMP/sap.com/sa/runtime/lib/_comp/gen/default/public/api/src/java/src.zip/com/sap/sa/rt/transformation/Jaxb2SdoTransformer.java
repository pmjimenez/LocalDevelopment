package com.sap.sa.rt.transformation;

import java.io.IOException;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.namespace.QName;

import com.sap.sa.rt.logging.LocationFactory;
import com.sap.sa.rt.sdo.io.ByteArrayStreamDecorator;
import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;
import com.sap.tc.logging.SimpleLogger;
import commonj.sdo.DataObject;
import commonj.sdo.helper.HelperContext;
import commonj.sdo.helper.XMLDocument;
import commonj.sdo.helper.XMLHelper;

public final class Jaxb2SdoTransformer {
    private static final Location location = LocationFactory.INSTANCE.createLocation(Jaxb2SdoTransformer.class);
    private static final int INITIAL_SIZE = 4096;

    public static DataObject transform(Object value, String namespace, String name, IJAXBContextProvider jaxbContextProvider,
            HelperContext helperContext) {
        Class<?> c = value.getClass();

        if (value instanceof JAXBElement<?>) {
            final Object obj = ((JAXBElement<?>) value).getValue();
            if (obj == null) {
                if (location.beWarning()) {
                    SimpleLogger
                            .trace(
                                    Severity.WARNING,
                                    location,
                                    "SOL.runtime.000018", "Value of passed JAXBElement is null. Cannot do JAX-B to SDO transformation ... Returning null"); //$NON-NLS-1$ //$NON-NLS-2$
                }

                return null;
            }

            c = obj.getClass();
        }

        return transform(value, namespace, name, jaxbContextProvider, helperContext, c);
    }

    public static DataObject transform(Object value, String namespace, String name, IJAXBContextProvider jaxbContextProvider,
            HelperContext helperContext, Class<?> c) {
        final DataObject dataObject;
        try {
            ByteArrayStreamDecorator out = new ByteArrayStreamDecorator(INITIAL_SIZE);
            try {
                Marshaller marshaller;

                marshaller = jaxbContextProvider.getContextInstance().createMarshaller();
                marshaller.marshal(new JAXBElement(new QName(namespace, name), c, value), out);
                marshaller = null;
            } catch (JAXBException e) {
                SimpleLogger
                        .traceThrowable(
                                Severity.ERROR,
                                location,
                                e,
                                "SOL.runtime.000019", "JAXB-to-SDO transformation failed.\n\n Marshalling of [JAXBElement<{0}>({1}, {2}, {3}.class)] failed. \n\n See nested exception for detailed information", c.getName(), namespace, name, c.getName()); //$NON-NLS-1$ //$NON-NLS-2$
                throw new RuntimeException(e);
            }

            final XMLHelper xmlHelper = helperContext.getXMLHelper();
            try {
                XMLDocument doc = null;
                try {
                    doc = xmlHelper.load(out.createInputStream());
                } finally {
                    out = null;
                }

                dataObject = doc.getRootObject();
                doc = null;
            } catch (IOException e) {
                SimpleLogger.trace(Severity.ERROR, location, "SOL.runtime.000020", "Loading SDO XML document failed"); //$NON-NLS-1$ //$NON-NLS-2$
                throw new RuntimeException(e);
            }

            if (location.beDebug()) {
                SimpleLogger.trace(Severity.DEBUG, location,
                        "SOL.runtime.000021", "Loaded SDO XML document:\n\n[{0}]", xmlHelper.save(dataObject, namespace, name)); //$NON-NLS-1$ //$NON-NLS-2$
            }
        } catch (RuntimeException e) {
            SimpleLogger.traceThrowable(Severity.ERROR, location, e,
                    "SOL.runtime.000022", "JAXB-to-SDO Transformation failed because of an unexpected error"); //$NON-NLS-1$ //$NON-NLS-2$
            throw e;
        }

        return dataObject;
    }

    private Jaxb2SdoTransformer() {
    }
}