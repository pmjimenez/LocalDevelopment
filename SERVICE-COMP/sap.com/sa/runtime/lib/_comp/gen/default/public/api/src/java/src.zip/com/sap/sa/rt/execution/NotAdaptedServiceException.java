package com.sap.sa.rt.execution;

public class NotAdaptedServiceException extends IllegalStateException {
    private static final long serialVersionUID = -2866963240430715912L;

    public NotAdaptedServiceException() {
        super();
    }

    public NotAdaptedServiceException(String s) {
        super(s);
    }

    public NotAdaptedServiceException(String message, Throwable cause) {
        super(message, cause);
    }

    public NotAdaptedServiceException(Throwable cause) {
        super(cause);
    }
}