package com.sap.sa.rt.transformation;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

public interface IJAXBContextProvider {
    JAXBContext getContextInstance() throws JAXBException;
}