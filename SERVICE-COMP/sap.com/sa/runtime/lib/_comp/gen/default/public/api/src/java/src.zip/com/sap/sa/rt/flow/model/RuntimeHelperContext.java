package com.sap.sa.rt.flow.model;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sap.sa.rt.logging.LocationFactory;
import com.sap.sdo.api.helper.SapXmlHelper;
import com.sap.sdo.api.helper.SapXsdHelper;
import com.sap.sdo.api.helper.SchemaResolver;
import com.sap.sdo.api.types.schema.Schema;
import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;
import com.sap.tc.logging.SimpleLogger;
import commonj.sdo.helper.HelperContext;
import commonj.sdo.helper.XMLDocument;
import commonj.sdo.helper.XMLHelper;

public class RuntimeHelperContext {

    private static final Location location = LocationFactory.INSTANCE.createLocation(RuntimeHelperContext.class);

    public static HelperContext define(String[] schemas, Object obj, HelperContext helperContext) {

        try {
            // Assuming there is a List of schemas as Strings.
            // See XmlHelper.load for other supported sources!

            // Define the options for parsing: Don't define the types in this
            // step!
            Map<Object, Object> options = new HashMap<Object, Object>();
            options.put(SapXmlHelper.OPTION_KEY_SCHEMA_RESOLVER, new RuntimeHelperContext.NullSchemaResolver());
            options.put(SapXmlHelper.OPTION_KEY_DEFINE_SCHEMAS, SapXmlHelper.OPTION_VALUE_FALSE);
            XMLHelper xmlHelper = helperContext.getXMLHelper();

            List<Schema> schemasAsSdo = new ArrayList<Schema>();

            // Parse each single schema by the XMLHelper without translating it
            // into types.
            for (String schemaLocation : schemas) {
                java.io.InputStream resourceAsStream = obj.getClass().getResourceAsStream("/" + schemaLocation); //$NON-NLS-1$
                BufferedReader reader = null;
                XMLDocument schemaDocument = null;
                try {
                    reader = new BufferedReader(new InputStreamReader(resourceAsStream, "UTF-8")); //$NON-NLS-1$
                    schemaDocument = xmlHelper.load(reader, null, options);
                } finally {
                    try {
                        reader.close();
                    } catch (Exception e) {
                        SimpleLogger.traceThrowable(Severity.WARNING, location, e.getMessage(), e);
                    }
                }
                Schema schemaSdo = (Schema) schemaDocument.getRootObject();
                // Collect the schema-DataObjects of the different schemas in a
                // List.
                schemasAsSdo.add(schemaSdo);
            }
            // Use the SapXsdHelper to translate it into SDO-types in one step:
            SapXsdHelper xsdHelper = ((SapXsdHelper) helperContext.getXSDHelper());
            xsdHelper.define(schemasAsSdo, options);
            // The types are now registered in the TypeHelper of that
            // HelperContext-
            return helperContext;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static HelperContext define(String[] schemas, Class pojoClass, HelperContext helperContext) {

        try {
            // Assuming there is a List of schemas as Strings.
            // See XmlHelper.load for other supported sources!

            // Define the options for parsing: Don't define the types in this
            // step!
            Map<Object, Object> options = new HashMap<Object, Object>();
            options.put(SapXmlHelper.OPTION_KEY_SCHEMA_RESOLVER, new RuntimeHelperContext.NullSchemaResolver());
            options.put(SapXmlHelper.OPTION_KEY_DEFINE_SCHEMAS, SapXmlHelper.OPTION_VALUE_FALSE);
            XMLHelper xmlHelper = helperContext.getXMLHelper();

            List<Schema> schemasAsSdo = new ArrayList<Schema>();

            // Parse each single schema by the XMLHelper without translating it
            // into types.
            for (String schemaLocation : schemas) {
                java.io.InputStream resourceAsStream = pojoClass.getResourceAsStream("/" + schemaLocation); //$NON-NLS-1$
                BufferedReader reader = null;
                XMLDocument schemaDocument = null;
                try {
                    reader = new BufferedReader(new InputStreamReader(resourceAsStream, "UTF-8")); //$NON-NLS-1$
                    schemaDocument = xmlHelper.load(reader, null, options);
                } finally {
                    try {
                        reader.close();
                    } catch (Exception e) {
                        SimpleLogger.traceThrowable(Severity.WARNING, location, e.getMessage(), e);
                    }
                }
                Schema schemaSdo = (Schema) schemaDocument.getRootObject();
                // Collect the schema-DataObjects of the different schemas in a
                // List.
                schemasAsSdo.add(schemaSdo);
            }
            // Use the SapXsdHelper to translate it into SDO-types in one step:
            SapXsdHelper xsdHelper = ((SapXsdHelper) helperContext.getXSDHelper());
            xsdHelper.define(schemasAsSdo, options);
            // The types are now registered in the TypeHelper of that
            // HelperContext-
            return helperContext;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static class NullSchemaResolver implements SchemaResolver {

        public String getAbsoluteSchemaLocation(String arg0, String arg1) throws URISyntaxException {
            // TODO Auto-generated method stub
            return null;
        }

        public Object resolveImport(String arg0, String arg1) throws IOException, URISyntaxException {
            // TODO Auto-generated method stub
            return null;
        }

        public Object resolveInclude(String arg0) throws IOException, URISyntaxException {
            // TODO Auto-generated method stub
            return null;
        }

    }

}
