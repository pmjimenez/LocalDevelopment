package com.sap.sa.rt.transformation;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.Result;
import javax.xml.transform.stream.StreamResult;

import com.sap.sa.rt.logging.LocationFactory;
import com.sap.sdo.api.helper.SapXmlHelper;
import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;
import com.sap.tc.logging.SimpleLogger;

import commonj.sdo.DataObject;
import commonj.sdo.helper.HelperContext;
import commonj.sdo.helper.XMLDocument;
import commonj.sdo.helper.XMLHelper;

public class Sdo2JaxbTransformer {
    private static final Location location = LocationFactory.INSTANCE.createLocation(Sdo2JaxbTransformer.class);
    private static final Map<Object, Object> SDO_SERIALIZING_OPTIONS;
    static {
        SDO_SERIALIZING_OPTIONS = new HashMap<Object, Object>();
        SDO_SERIALIZING_OPTIONS.put(SapXmlHelper.OPTION_KEY_INDENT, null);
    }

    public static <T> T transform(DataObject dataObject, String namespace, String name, IJAXBContextProvider jaxbContextProvider,
            HelperContext helperContext, Class<T> jaxbClass) {
        final T transformedJaxbInstance;
        if (dataObject==null) return null;
        try {
            if (location.beDebug()) {
                SimpleLogger.trace(Severity.DEBUG,location, "SOL.runtime.000023", "Transforming SDO DataObject [{0}] to Jax-b representation of [{1}, {2}] of type: [{3}]", dataObject.toString(), namespace, name, jaxbClass.getName()); //$NON-NLS-1$ //$NON-NLS-2$
            }

            final Unmarshaller unmarshaller;
            try {
                unmarshaller = jaxbContextProvider.getContextInstance().createUnmarshaller();
            } catch (JAXBException e) {
                SimpleLogger.traceThrowable(Severity.FATAL,location,e, "SOL.runtime.000024", "SDO-to-Jaxb transformation failed, because JaxbContext unmarshaller cannot be created."); //$NON-NLS-1$ //$NON-NLS-2$
                throw new RuntimeException(e);
            }

            final XMLHelper xmlHelper = helperContext.getXMLHelper();
            final XMLDocument document = xmlHelper.createDocument(dataObject, namespace, name);

            final StringWriter stringWriter = new StringWriter();
            final Result result = new StreamResult(stringWriter);
            try {
                xmlHelper.save(document, result, SDO_SERIALIZING_OPTIONS);
            } catch (IOException e) {
                SimpleLogger.traceThrowable(Severity.FATAL,location,e, "SOL.runtime.000025", "SDO-to-Jaxb transformation failed.\n\n Cannot serialize SDO XMLDocument into a StringWriter");                 //$NON-NLS-1$ //$NON-NLS-2$
                throw new RuntimeException(e);
            }

            final String xml = stringWriter.getBuffer().toString();
            if (location.beDebug()) {
                SimpleLogger.trace(Severity.DEBUG,location, "SOL.runtime.000026", "XML document to unmarshall a JAX-B instance from:\n\n[{0}]", xml); //$NON-NLS-1$ //$NON-NLS-2$
            }

            final JAXBElement<T> element;
            try {
                element = unmarshaller.unmarshal(new javax.xml.transform.stream.StreamSource(new StringReader(xml)), jaxbClass);
            } catch (JAXBException e) {
                SimpleLogger.traceThrowable(Severity.FATAL,location,e, "SOL.runtime.000027", "SDO-to-Jaxb transformation failed.\n\n Cannot unmarshall a JAX-B instance");                 //$NON-NLS-1$ //$NON-NLS-2$
                throw new RuntimeException(e);
            }

            transformedJaxbInstance = element.getValue();
        } catch (RuntimeException e) {
        	SimpleLogger.traceThrowable(Severity.FATAL,location,e, "SOL.runtime.000028", "SDO-to-JAX-B transformation failed because of an unexpected error"); //$NON-NLS-1$ //$NON-NLS-2$
            throw e;
        }

        return transformedJaxbInstance;
    }
}