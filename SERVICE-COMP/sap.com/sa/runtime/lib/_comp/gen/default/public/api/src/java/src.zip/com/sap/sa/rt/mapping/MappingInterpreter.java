package com.sap.sa.rt.mapping;

import static com.sap.mapping.lib.execution.implementation.Runner.INSTANCE;

import com.sap.mapping.lib.execution.implementation.Compiler;
import com.sap.mapping.lib.execution.implementation.data.SdoNode;
import com.sap.mapping.lib.execution.implementation.data.SdoSourceNode;
import com.sap.mapping.lib.util.api.sdo.HelperContextProvider;
import com.sap.sa.rt.logging.LocationFactory;
import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;
import com.sap.tc.logging.SimpleLogger;
import commonj.sdo.DataObject;
import commonj.sdo.helper.HelperContext;

public class MappingInterpreter implements HelperContextProvider {
    private static final Location location = LocationFactory.INSTANCE.createLocation(MappingInterpreter.class);

    private final HelperContext helperContext;
    private final Compiler compiler;

    public MappingInterpreter(HelperContext helperCtx) {
        this.helperContext = helperCtx;

        compiler = new Compiler(this);
        compiler.optimizeBuiltInFunctionInvocation(true);
    }

    public DataObject executeMapping(DataObject source, DataObject target, String filepath, Class<?> c,
            ICompiledMappingRulesRegistry registry) {
        final com.sap.mapping.lib.execution.api.rule.Mapping compiledMapping;
        try {
            compiledMapping = MappingsHelper.getInstance().getCompiledMapping(filepath, c, registry, compiler);
        } catch (CompiledMappingsCreationException e) {
            SimpleLogger.traceThrowable(Severity.FATAL,location,e, "SOL.runtime.000006", "An error during compilation of mappins prevented the mapping execution. See the nested exception for details."); //$NON-NLS-1$ //$NON-NLS-2$
            throw new RuntimeException("An error during compilation of mappins prevented the mapping execution. See the nested exception for details.", e);//$NON-NLS-1$
        }

        try {
            INSTANCE.map(compiledMapping, new SdoNode(helperContext, target), new SdoSourceNode(helperContext, source));
        } catch (RuntimeException e) {
            SimpleLogger.traceThrowable(Severity.FATAL,location,e, "SOL.runtime.000007", "Execution of compiled runtime mapping rule failed:\n\n{0}", compiledMapping.toString()); //$NON-NLS-1$ //$NON-NLS-2$
            throw e;
        }

        return target;
    }

    public HelperContext getHelperContext(String arg0) {
        return helperContext;
    }
}