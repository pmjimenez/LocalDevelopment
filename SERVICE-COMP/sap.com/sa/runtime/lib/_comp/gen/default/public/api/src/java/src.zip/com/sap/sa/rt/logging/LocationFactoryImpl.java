package com.sap.sa.rt.logging;

import com.sap.tc.logging.Location;

final class LocationFactoryImpl implements LocationFactory {
    private static final String DC_NAME = "sa/runtime"; //$NON-NLS-1$
    private static final String CSN_COMPONENT = ""; //$NON-NLS-1$

    public LocationFactoryImpl() {
    }

    public Location createLocation(Class<?> c) {
        final Location location;

        location = Location.getLocation(c);
        location.setDCName(DC_NAME);
        location.setCSNComponent(CSN_COMPONENT);

        return location;
    }
}
