package com.sap.sa.rt.util;

import java.util.Date;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.Duration;
import javax.xml.datatype.XMLGregorianCalendar;

import com.sap.sa.rt.logging.LocationFactory;
import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;
import com.sap.tc.logging.SimpleLogger;

public class DateUtils {
    private static final Location location = LocationFactory.INSTANCE.createLocation(DateUtils.class);
    private static DatatypeFactory datatypeFactory;

    static {
        try {
            datatypeFactory = DatatypeFactory.newInstance();
        } catch (DatatypeConfigurationException e) {
            SimpleLogger.traceThrowable(Severity.ERROR,location,e, "SOL.runtime.000029", "Cannot instantiate javax.xml.datatype.DatatypeFactory. Cannot transform dates"); //$NON-NLS-1$ //$NON-NLS-2$
        }
    }

    public static Date toDate(XMLGregorianCalendar xmlCalendar) {
    	if (xmlCalendar==null) return null;
    	if (xmlCalendar.getTimezone()==DatatypeConstants.FIELD_UNDEFINED) {
    		xmlCalendar.setTimezone(0);
    	}
    	return xmlCalendar.toGregorianCalendar().getTime();
    }

    public static XMLGregorianCalendar calendarFromString(String date) {
        return date != null ? datatypeFactory.newXMLGregorianCalendar(date) : null;
    }

    public static Duration durationFromString(String duration) {
        return duration != null ? datatypeFactory.newDuration(duration) : null;
    }
}
