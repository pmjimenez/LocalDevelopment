package com.sap.sa.rt.mapping;

public class CompiledMappingsCreationException extends Exception {
    private static final long serialVersionUID = 417082277836551140L;

    public CompiledMappingsCreationException() {
        super();
    }

    public CompiledMappingsCreationException(String message) {
        super(message);
    }

    public CompiledMappingsCreationException(Throwable cause) {
        super(cause);
    }

    public CompiledMappingsCreationException(String message, Throwable cause) {
        super(message, cause);
    }
}