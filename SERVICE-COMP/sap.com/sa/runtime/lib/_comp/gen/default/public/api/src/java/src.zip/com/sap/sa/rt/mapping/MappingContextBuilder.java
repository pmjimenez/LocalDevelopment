package com.sap.sa.rt.mapping;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;

import com.sap.sa.rt.logging.LocationFactory;
import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;
import com.sap.tc.logging.SimpleLogger;

import commonj.sdo.DataObject;
import commonj.sdo.Property;
import commonj.sdo.helper.DataFactory;
import commonj.sdo.helper.HelperContext;

public class MappingContextBuilder {
    private static final Location location = LocationFactory.INSTANCE.createLocation(MappingContextBuilder.class);

    private final HelperContext helperCtx;
    public static String SOURCE_CONTEXT_TYPE_NAME = "srcContainer"; //$NON-NLS-1$
    public static String TARGET_CONTEXT_TYPE_NAME = "trgContainer"; //$NON-NLS-1$

    public MappingContextBuilder(HelperContext helperCtx) {
        this.helperCtx = helperCtx;

    }

    public DataObject createSourceContext(String sourceContextTypeURI, List<QName> qNames) {
        return createContext(sourceContextTypeURI, SOURCE_CONTEXT_TYPE_NAME, qNames);
    }

    public DataObject createTargetContext(String targetContextTypeURI, List<QName> qNames) {
        return createContext(targetContextTypeURI, TARGET_CONTEXT_TYPE_NAME, qNames);
    }

    public DataObject getDataObjectFromContext(DataObject ctx, String name) {    	
        Property srcProp = ctx.getInstanceProperty(name);
        if (srcProp!=null) {
            return ctx.getDataObject(srcProp);        	
        } else return null;
    }

    private DataObject createContext(String contextTypeUri, String contextTypeName, List<QName> qNames) {
        if (qNames.isEmpty()) {
            SimpleLogger.trace(Severity.WARNING,location, "SOL.runtime.000004", "List of SDO annotated XSD schemas for {0} is empty. This may mean DT generation error", contextTypeUri); //$NON-NLS-1$ //$NON-NLS-2$
        }

        DataFactory dataFactory = helperCtx.getDataFactory();
        DataObject wrapperType = dataFactory.create("commonj.sdo", "Type"); //$NON-NLS-1$ //$NON-NLS-2$
        wrapperType.set("uri", contextTypeUri); //$NON-NLS-1$
        wrapperType.set("name", contextTypeName); //$NON-NLS-1$
        wrapperType.setBoolean("open", true); //$NON-NLS-1$
        Map<String, DataObject> dataObjMap = new HashMap<String, DataObject>();

        for (QName propQName : qNames) {
            Property prop = helperCtx.getTypeHelper().getOpenContentProperty(propQName.getNamespaceURI(),
                    propQName.getLocalPart());
            DataObject dataObject = helperCtx.getDataFactory().create(prop.getType());
            DataObject propType = wrapperType.createDataObject("property"); //$NON-NLS-1$
            
            List aliasNames = prop.getAliasNames();
            String propName;
            if ((aliasNames!=null) && (aliasNames.size()!=0)) {
            	propName = (String)aliasNames.get(0);
            } else {
            	propName = prop.getName();
            }                        
            propType.set("name", propName); //$NON-NLS-1$
            propType.set("type", prop.getType()); //$NON-NLS-1$
            dataObjMap.put(propName, dataObject);
        }

        helperCtx.getTypeHelper().define(wrapperType);
        DataObject wrapper = dataFactory.create(contextTypeUri, contextTypeName);
        for (String propName : dataObjMap.keySet()) {
            Property property = wrapper.getInstanceProperty(propName);
            wrapper.set(property, (DataObject) dataObjMap.get(propName));
        }

        if (location.beDebug()) {
            SimpleLogger.trace(Severity.DEBUG,location, "SOL.runtime.000005", "Created wrapper SDO DataObject:\n\n {0}", wrapper.toString()); //$NON-NLS-1$ //$NON-NLS-2$
        }

        return wrapper;
    }
}
