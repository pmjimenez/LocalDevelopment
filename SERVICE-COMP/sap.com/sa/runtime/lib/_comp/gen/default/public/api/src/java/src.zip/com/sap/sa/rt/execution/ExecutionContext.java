package com.sap.sa.rt.execution;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class ExecutionContext {
    private final Map<String, Object> properties;
    private final Map<String, Object> inputParameters;

    public ExecutionContext() {
        properties = new HashMap<String, Object>();
        inputParameters = new HashMap<String, Object>();
    }

    public void setProperty(String name, Object value) {
        properties.put(name, value);
    }

    public Object getProperty(String name) {
        return properties.get(name);
    }

    public void addInputParameter(String parameterName, Object parameterValue) {
        inputParameters.put(parameterName, parameterValue);
    }

    public Map<String, Object> getInputParameters() {
        return Collections.unmodifiableMap(inputParameters);
    }
}