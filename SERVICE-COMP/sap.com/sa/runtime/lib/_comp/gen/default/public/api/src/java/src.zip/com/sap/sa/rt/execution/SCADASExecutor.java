package com.sap.sa.rt.execution;


import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.xml.namespace.QName;

import com.sap.engine.interfaces.connector.ComponentExecutionContext;
import com.sap.engine.interfaces.sca.config.exception.ESBConfigurationException;
import com.sap.engine.interfaces.sca.das.OperationConfig;
import com.sap.engine.interfaces.sca.das.ParametersConfig;
import com.sap.engine.interfaces.sca.das.SCADAS;
import com.sap.engine.interfaces.sca.das.SCADASFactory;
import com.sap.engine.interfaces.sca.exception.SCADASException;
import com.sap.sa.rt.logging.LocationFactory;
import com.sap.tc.logging.Category;
import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;
import com.sap.tc.logging.SimpleLogger;
import commonj.sdo.helper.HelperContext;

public class SCADASExecutor implements IExecutor {
	
    private static final Location location = LocationFactory.INSTANCE.createLocation(SCADASExecutor.class);
    
    private static SCADASFactory factory = SCADASFactory.newInstance(SCADASFactory.SCADASFactoryMode.CacheEnabled);    

	public Object execute(ExecutionContext context) {
        QName intfQName = (QName) context.getProperty(INTERFACE_FULLY_QUALIFIED_NAME);
        String serviceIdentifier = (String) context.getProperty(SERVICE_IDENTIFIER);
        String serviceReferenceId = (String) context.getProperty(SERVICE_REFERENCE_ID);
        HelperContext helperContext = (HelperContext) context.getProperty(SDO_HELPER_CONTEXT);
        String operationName = (String) context.getProperty(OPERATION_NAME);
        String outputParameterName = (String) context.getProperty(OUTPUT_PARAMETER_NAME);		
        String componentName = (String) context.getProperty(COMPONENT_NAME);        
        String referenceName = (String) context.getProperty(REFERENCE_NAME);        
        
        final Map<String, Object> inputParametersMap = (Map<String, Object>) context.getInputParameters();        
	
        SCADAS scadas;
        try {        	
        	scadas = createSCADAS(componentName, referenceName, helperContext);
        } catch (Exception e) {
            SimpleLogger.traceThrowable(Severity.FATAL,location,e, "SOL.runtime.000001", "SCADAS creation for WSDL portType {0} failed.", intfQName.toString()); //$NON-NLS-1$ //$NON-NLS-2$
            throw createWorkflowException(intfQName, operationName, e);
        }		
        OperationConfig operationCfg = scadas.getOperationConfig(operationName);
        final Set<Entry<String, Object>> parameterEntries = inputParametersMap.entrySet();
        ParametersConfig paramConfig = scadas.getParametersConfig();
        for (Entry<String, Object> parameterEntry : parameterEntries) {
        	//Value[] value = new Value[1];
            //value[0] = new Value(parameterEntry.getValue());
            //paramConfig.put(parameterEntry.getKey(), value);
        	paramConfig.put(parameterEntry.getKey(), parameterEntry.getValue());
        }
        operationCfg.setInputData(paramConfig);
        Object result = null;
		try {
			scadas.invokeReference(operationCfg);
			result = operationCfg.getOutputData(); 
		} catch (SCADASException e) { 
			logException(intfQName, operationName, e);
            throw createWorkflowException(intfQName, operationName, e);
		} catch (InvocationTargetException e) {
			logException(intfQName, operationName, e);
            throw createWorkflowException(intfQName, operationName, e);
		} catch (RemoteException e) {
			logException(intfQName, operationName, e);
            throw createWorkflowException(intfQName, operationName, e);            
		} finally {
			factory.release(scadas);
		}
		
        return result;		
	}
	
    private void logException(QName intfQName, String operationName, Throwable e) {
        String msg = new StringBuilder("The invocation of the consumed service [").append(intfQName).append(" ").append(operationName) //$NON-NLS-1$ //$NON-NLS-2$
        .append("] failed with the following message:\n").append(e.getMessage()).toString(); //$NON-NLS-1$

        SimpleLogger.traceThrowable(Severity.ERROR, location, msg, e);
        
        while (e != null) {
            if (e instanceof ESBConfigurationException) {
    			msg = "The invocation of the consumed service [{0} {1}] failed due to a configuration problem. Please check if the service reference is configured properly. See the trace files for more information"; //$NON-NLS-1$    		
            	SimpleLogger.log(Severity.ERROR, Category.APPS_COMMON_CONFIGURATION, location, "SOL.runtime.000031", msg, intfQName, operationName);
            	break;
            }   
            e = e.getCause();
        }
	}

	private SCADAS createSCADAS(String componentName, String referenceName, HelperContext helperContext) throws Exception {
        return factory.createSCADAS(getApplicationName(), componentName, referenceName, helperContext);        
    }
    
    private WorkflowExecutionException createWorkflowException(QName intfQName, String operationName, Exception e) {
        final String msg;

        msg = new StringBuilder("The invocation of the consumed service [").append(intfQName).append(" ").append(operationName) //$NON-NLS-1$ //$NON-NLS-2$
                .append("] failed with the following message:\n").append(e.getMessage()).toString(); //$NON-NLS-1$
        
        return new WorkflowExecutionException(msg, e);
    }    
    
    private String getApplicationName() {
        try {
            final InitialContext jndiContext;
            try {
                jndiContext = new InitialContext();
            } catch (NamingException e) {
                SimpleLogger.traceThrowable(Severity.FATAL,location,e, "SOL.runtime.000000", "Finding the name of the current application failed. Cannot create initial context"); //$NON-NLS-1$ //$NON-NLS-2$
                throw new RuntimeException(e);
            }

            final ComponentExecutionContext execContext;
            try {
                execContext = (ComponentExecutionContext) jndiContext.lookup("interfaces/appcontext"); //$NON-NLS-1$
            } catch (NamingException e) {
                SimpleLogger.traceThrowable(Severity.FATAL,location,e, "SOL.runtime.000002", "Finding the name of the current application failed."); //$NON-NLS-1$ //$NON-NLS-2$
                throw new RuntimeException(e);
            }

            return execContext.getApplicationName();
        } catch (RuntimeException e) {
            SimpleLogger.traceThrowable(Severity.FATAL,location,e, "SOL.runtime.000003", "Finding the name of the current application failed because of unexpected error."); //$NON-NLS-1$ //$NON-NLS-2$
            throw e;
        }
    }    
}