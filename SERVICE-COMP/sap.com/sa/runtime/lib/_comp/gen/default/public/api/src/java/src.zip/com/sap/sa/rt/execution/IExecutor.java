package com.sap.sa.rt.execution;

public interface IExecutor {
	
    public static final String INTERFACE_FULLY_QUALIFIED_NAME = "INTERFACE_FULLY_QUALIFIED_NAME"; //$NON-NLS-1$
    public static final String SERVICE_IDENTIFIER = "SERVICE_IDENTIFIER"; //$NON-NLS-1$
    public static final String SERVICE_REFERENCE_ID = "SERVICE_REFERENCE_ID"; //$NON-NLS-1$
    public static final String SDO_HELPER_CONTEXT = "SDO_HELPER_CONTEXT"; //$NON-NLS-1$
    public static final String OPERATION_NAME = "OPERATION_NAME"; //$NON-NLS-1$
    public static final String OUTPUT_PARAMETER_NAME = "OUTPUT_PARAMETER_NAME";	 //$NON-NLS-1$
    public static final String COMPONENT_NAME = "COMPONENT_NAME"; //$NON-NLS-1$
    public static final String REFERENCE_NAME = "REFERENCE_NAME";	 //$NON-NLS-1$
	
	public Object execute( ExecutionContext context) ;
}
