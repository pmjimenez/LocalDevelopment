package com.sap.sa.rt.execution;

import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.xml.namespace.QName;

import com.sap.engine.interfaces.connector.ComponentExecutionContext;
import com.sap.engine.interfaces.sca.config.exception.ESBConfigurationException;
import com.sap.engine.services.webservices.espbase.wsdas.WSDAS;
import com.sap.engine.services.webservices.espbase.wsdas.WSDASFactory;
import com.sap.sa.rt.logging.LocationFactory;
import com.sap.tc.logging.Category;
import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;
import com.sap.tc.logging.SimpleLogger;
import commonj.sdo.helper.HelperContext;

public class WSDASExecutor implements IExecutor {
    private static final Location location = LocationFactory.INSTANCE.createLocation(WSDASExecutor.class);

    private static final WSDASFactory wsdasFactory = WSDASFactory.newInstanceWithCache();

    public Object execute(ExecutionContext context) {
        QName intfQName = (QName) context.getProperty(INTERFACE_FULLY_QUALIFIED_NAME);
        String serviceIdentifier = (String) context.getProperty(SERVICE_IDENTIFIER);
        String serviceReferenceId = (String) context.getProperty(SERVICE_REFERENCE_ID);
        HelperContext helperContext = (HelperContext) context.getProperty(SDO_HELPER_CONTEXT);
        String operationName = (String) context.getProperty(OPERATION_NAME);
        String outputParameterName = (String) context.getProperty(OUTPUT_PARAMETER_NAME);

        final Map<String, Object> inputParametersMap = (Map<String, Object>) context.getInputParameters();

        com.sap.engine.services.webservices.espbase.wsdas.OperationConfig operationCfg = null;

        WSDAS wsdas;
        try {
            if ((serviceReferenceId != null) && (!serviceReferenceId.equals(""))) { //$NON-NLS-1$
                wsdas = createWSDAS(getApplicationName(), serviceReferenceId, helperContext);
            } else {
                wsdas = createWSDAS(serviceIdentifier, intfQName, helperContext);
            }
        } catch (Exception e) {
            SimpleLogger.traceThrowable(Severity.FATAL,location,e, "SOL.runtime.000001", "WSDAS creation for WSDL portType {0} failed.", intfQName.toString()); //$NON-NLS-1$ //$NON-NLS-2$
            throw createWorkflowException(intfQName, operationName, e);
        }

        operationCfg = wsdas.getOperationCfg(operationName);
        final Set<Entry<String, Object>> parameterEntries = inputParametersMap.entrySet();
        for (Entry<String, Object> parameterEntry : parameterEntries) {
            operationCfg.setInputParamValue(parameterEntry.getKey(), parameterEntry.getValue());
        }

        try {
            wsdas.invokeOperation(operationCfg);
        } catch (RemoteException e) {
			logException(intfQName, operationName, e);
            throw createWorkflowException(intfQName, operationName, e);
        } catch (InvocationTargetException e) {
			logException(intfQName, operationName, e);
            throw createWorkflowException(intfQName, operationName, e);
        }

        return operationCfg.getOutputParamValue(outputParameterName);
    }

    private WorkflowExecutionException createWorkflowException(QName intfQName, String operationName, Exception e) {
        final String msg;

        msg = new StringBuilder("The invocation of the consumed service [").append(intfQName).append(" ").append(operationName) //$NON-NLS-1$ //$NON-NLS-2$
                .append("] failed with the following message:\n").append(e.getMessage()).toString(); //$NON-NLS-1$
        
        return new WorkflowExecutionException(msg, e);
    } 

    private static WSDAS createWSDAS(String logicalDestName, QName iterfQname, HelperContext helperContext) throws Exception {
        //WSDASFactory wsdasFactory = WSDASFactory.newInstance();
        return wsdasFactory.createWSDAS(logicalDestName, iterfQname, helperContext);
    }

    private static WSDAS createWSDAS(String applicationName, String serviceRefId, HelperContext helperContext) throws Exception {
        //WSDASFactory wsdasFactory = WSDASFactory.newInstance();
        return wsdasFactory.createWSDAS(applicationName, serviceRefId, helperContext);
    }

    private String getApplicationName() {
        try {
            final InitialContext jndiContext;
            try {
                jndiContext = new InitialContext();
            } catch (NamingException e) {
                SimpleLogger.traceThrowable(Severity.FATAL,location,e, "SOL.runtime.000000", "Finding the name of the current application failed. Cannot create initial context"); //$NON-NLS-1$ //$NON-NLS-2$
                throw new RuntimeException(e);
            }

            final ComponentExecutionContext execContext;
            try {
                execContext = (ComponentExecutionContext) jndiContext.lookup("interfaces/appcontext"); //$NON-NLS-1$
            } catch (NamingException e) {
                SimpleLogger.traceThrowable(Severity.FATAL,location,e, "SOL.runtime.000002", "Finding the name of the current application failed."); //$NON-NLS-1$ //$NON-NLS-2$
                throw new RuntimeException(e);
            }

            return execContext.getApplicationName();
        } catch (RuntimeException e) {
            SimpleLogger.traceThrowable(Severity.FATAL,location,e, "SOL.runtime.000003", "Finding the name of the current application failed because of unexpected error."); //$NON-NLS-1$ //$NON-NLS-2$
            throw e;
        }
    }
	
	private void logException(QName intfQName, String operationName, Throwable e) {
        String msg = new StringBuilder("The invocation of the consumed service [").append(intfQName).append(" ").append(operationName) //$NON-NLS-1$ //$NON-NLS-2$
        .append("] failed with the following message:\n").append(e.getMessage()).toString(); //$NON-NLS-1$

        SimpleLogger.traceThrowable(Severity.ERROR, location, msg, e);
        
        while (e != null) {
            if (e instanceof ESBConfigurationException) {
    			msg = "The invocation of the consumed service [{0} {1}] failed due to a configuration problem. Please check if the service reference is configured properly. See the trace files for more information";    		
            	SimpleLogger.log(Severity.ERROR, Category.APPS_COMMON_CONFIGURATION, location, "SOL.runtime.000031", msg, intfQName, operationName);
            	break;
            }   
            e = e.getCause();
        }
	}
}
