package com.sap.sa.rt.mapping;

public interface ICompiledMappingRulesRegistry {
    void addCompiledMappingRule(Class<?> c, String filepath, Object compiledMapping);

    Object getCompiledMappingRule(Class<?> c, String filepath);
}
