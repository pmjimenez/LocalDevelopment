package com.sap.sa.rt.logging;

import com.sap.tc.logging.Location;

public interface LocationFactory {
    public static final LocationFactory INSTANCE = new LocationFactoryImpl();

    public Location createLocation(Class<?> c);
}
