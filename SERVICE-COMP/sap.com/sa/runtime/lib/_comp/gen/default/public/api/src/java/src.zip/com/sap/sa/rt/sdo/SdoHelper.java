package com.sap.sa.rt.sdo;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.xml.datatype.Duration;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;

import com.sap.sa.rt.logging.LocationFactory;
import com.sap.sa.rt.util.DateUtils;
import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;
import com.sap.tc.logging.SimpleLogger;

import commonj.sdo.DataObject;
import commonj.sdo.Property;
import commonj.sdo.helper.HelperContext;
import commonj.sdo.helper.XSDHelper;

public final class SdoHelper {
    private static final Location location = LocationFactory.INSTANCE.createLocation(SdoHelper.class);

    private static final String XML_GREGORIAN_CALENDAR_CLASS_NAME = XMLGregorianCalendar.class.getName();
    private static final String XML_DURATION_CLASS_NAME = Duration.class.getName();
    private static final String XML_QNAME_CLASS_NAME = QName.class.getName();

    public static void adjustSdoNames(DataObject dataObject) {
        synchronized (dataObject) {
            /*
             * We need to wrap the list of instance properties within a simple
             * ArrayList, since the implementation of the list, which is
             * returned by the SDO implementation probably also uses a custom
             * implementation of java.lang.Iterable, which queries the
             * properties of a DataObject with each invocation of its next()
             * method. This causes unpredictable behavior with modification of
             * DataObjects.
             */
            final List<Property> properties = new ArrayList<Property>(dataObject.getInstanceProperties());
            for (Property property : properties) {
                final String name = property.getName();
                final Object value = dataObject.get(property);
                if (name != null && name.trim().length() > 0) {
                    if (!name.startsWith("$")) { //$NON-NLS-1$
                        dataObject.unset(name);
                        dataObject.set("$" + name, value); //$NON-NLS-1$
                    }
                }

                if (value instanceof DataObject) {
                    adjustSdoNames((DataObject) value);
                }
            }
        }
    }

    public static Property findProperty(DataObject dataObject, QName xsdQName, HelperContext ctx) {
        synchronized (dataObject) {
            final XSDHelper xsdHelper = ctx.getXSDHelper();
            final String targetNamespace = xsdQName.getNamespaceURI();
            final String localName = xsdQName.getLocalPart();

            final List<Property> properties = dataObject.getInstanceProperties();
            for (Property property : properties) {
                if (targetNamespace.equals(xsdHelper.getNamespaceURI(property))
                        && localName.equals(xsdHelper.getLocalName(property))) {
                    return property;
                }
            }
        }

        if (location.beWarning()) {
            SimpleLogger.trace(Severity.WARNING,location, "SOL.runtime.000016", "Cannot find SDO property with XSD QName: '{0}' in DataObject '{1}'", xsdQName.toString(), dataObject.toString()); //$NON-NLS-1$ //$NON-NLS-2$
        }

        return null;
    }

    public static Property findProperty(DataObject dataObject, String propertyName, HelperContext ctx) {
        synchronized (dataObject) {
            final XSDHelper xsdHelper = ctx.getXSDHelper();

            final List<Property> properties = dataObject.getInstanceProperties();
            for (Property property : properties) {
                if (propertyName.equals(xsdHelper.getLocalName(property))) {
                    return property;
                }
            }
        }

        if (location.beWarning()) {
            SimpleLogger.trace(Severity.WARNING,location, "SOL.runtime.000017", "Cannot find SDO property with XSD name: '{0}' in DataObject '{1}'", propertyName.toString(),dataObject.toString()); //$NON-NLS-1$ //$NON-NLS-2$
        }

        return null;
    }

    public static Object getPropertyValue(DataObject dataObject, Property property, String className) {
        if (XML_GREGORIAN_CALENDAR_CLASS_NAME.equals(className)) {
            return DateUtils.calendarFromString(dataObject.getString(property));
        } else if (XML_DURATION_CLASS_NAME.equals(className)) {
            return DateUtils.durationFromString(dataObject.getString(property));
        } else if (XML_QNAME_CLASS_NAME.equals(className)) {
            return getQName((String) dataObject.get(property));
        }

        return dataObject.get(property);
    }

    public static void setPropertyValue(DataObject dataObject, Property property, boolean value) {
        synchronized (dataObject) {
            dataObject.setBoolean(property, value);
        }
    }

    public static void setPropertyValue(DataObject dataObject, Property property, byte value) {
        synchronized (dataObject) {
            dataObject.setByte(property, value);
        }
    }

    public static void setPropertyValue(DataObject dataObject, Property property, byte[] value) {
        synchronized (dataObject) {
            if (value != null) {
                dataObject.setBytes(property, value);
            }
        }
    }

    public static void setPropertyValue(DataObject dataObject, Property property, short value) {
        synchronized (dataObject) {
            dataObject.setShort(property, value);
        }
    }

    public static void setPropertyValue(DataObject dataObject, Property property, int value) {
        synchronized (dataObject) {
            dataObject.setInt(property, value);
        }
    }

    public static void setPropertyValue(DataObject dataObject, Property property, char value) {
        synchronized (dataObject) {
            dataObject.setChar(property, value);
        }
    }

    public static void setPropertyValue(DataObject dataObject, Property property, long value) {
        synchronized (dataObject) {
            dataObject.setLong(property, value);
        }
    }

    public static void setPropertyValue(DataObject dataObject, Property property, float value) {
        synchronized (dataObject) {
            dataObject.setFloat(property, value);
        }
    }

    public static void setPropertyValue(DataObject dataObject, Property property, double value) {
        synchronized (dataObject) {
            dataObject.setDouble(property, value);
        }
    }

    public static void setPropertyValue(DataObject dataObject, Property property, String value) {
        synchronized (dataObject) {
            if (value != null) {
                dataObject.setString(property, value);
            }
        }
    }

    public static void setPropertyValue(DataObject dataObject, Property property, BigInteger value) {
        synchronized (dataObject) {
            if (value != null) {
                dataObject.setBigInteger(property, value);
            }
        }
    }

    public static void setPropertyValue(DataObject dataObject, Property property, BigDecimal value) {
        synchronized (dataObject) {
            if (value != null) {
                dataObject.setBigDecimal(property, value);
            }
        }
    }

    public static void setPropertyValue(DataObject dataObject, Property property, XMLGregorianCalendar value) {
        if (value != null) {
            synchronized (dataObject) {
                java.util.Date dateValue = com.sap.sa.rt.util.DateUtils.toDate(value);
                dataObject.setDate(property, dateValue);
            }
        }
    }

    public static void setPropertyValue(DataObject dataObject, Property property, Duration value) {
        if (value != null) {
            setPropertyValue(dataObject, property, value.toString());
        }
    }

    public static void setPropertyValue(DataObject dataObject, Property property, QName value) {
        synchronized (dataObject) {
            if (value != null) {
                dataObject.set(property, value.getNamespaceURI() + "#" + value.getLocalPart()); //$NON-NLS-1$
            }
        }
    }    
    
    public static void setPropertyValue(DataObject dataObject, Property property, Object value) {
        synchronized (dataObject) {
            if (value != null) {
                dataObject.set(property, value);
            }
        }
    }

    public static QName getQName(String sdoQName) {
        final int i = sdoQName.lastIndexOf("#"); //$NON-NLS-1$

        final String namespace = sdoQName.substring(0, i);
        final String localPart = sdoQName.substring(i + 1, sdoQName.length());

        return new QName(namespace, localPart);
    }

    private SdoHelper() {
    }
}