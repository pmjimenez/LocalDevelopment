package com.sap.bie.sca.scdl.adapter.maas;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.impl.CustomScdlElement;
import com.sap.bie.sca.scdl.adapter.impl.Implementation;

public class OperationMappingImplementation extends Implementation {
	private static final String IMPLEMENTATION_PIOM = "implementation.piom"; //$NON-NLS-1$
	private static final String IMPLEMENTATION_PIOM_NAMESPACE_VALUE = "http://www.sap.com/webas/2007/03/esoa/implementation/piom";
	private static final String IMPLEMENTATION_PIOM_NAMESPACE_NAME = "sapimplbpm";

	public OperationMappingImplementation() {
		super(new QName(IMPLEMENTATION_PIOM_NAMESPACE_VALUE, IMPLEMENTATION_PIOM, IMPLEMENTATION_PIOM_NAMESPACE_NAME));
		
		CustomScdlElement piopImpl = new CustomScdlElement(getName());
		
		addCustomElement(piopImpl);
	}


}
