package com.sap.bie.sca.scdl.contributors.maas;


/**
 * Class which holds the wsdl element names, attribute names and attribute values  as constants.
 * Also hold  values required for file system,.composite file element names and attribute names as constants.
 * @author I047304
 *
 */
public class WSDLConstants {

	// Element Names of .composite file
	public static final String INTERFACE_WSDL_ELEM_NAME = "interface.wsdl"; //$NON-NLS-1$
	public static final String BINDGING_WS_ELEM_NAME = "binding.ws"; //$NON-NLS-1$
	public static final String SAP_EXTENSIONS_ELEM_NAME = "sapextensions"; //$NON-NLS-1$
	public static final String INPUT_ELEM_NAME = "input"; //$NON-NLS-1$
	public static final String OUTPUT_ELEM_NAME = "output"; //$NON-NLS-1$
	public static final String TYPE_ELEM_NAME = "type"; //$NON-NLS-1$

	// Attribute Names of .composite file
	public static final String INTERFACE_ATTR_NAME = "interface"; //$NON-NLS-1$
	public static final String LOCATION_ATTR_NAME = "location"; //$NON-NLS-1$
	public static final String PORT_ATTR_NAME = "port"; //$NON-NLS-1$
	public static final String OMGUID_ATTR_NAME = "omguid"; //$NON-NLS-1$
	public static final String SVGUID_ATTR_NAME = "svguid"; //$NON-NLS-1$
	public static final String NAME_ATTR_NAME = "name"; //$NON-NLS-1$
	public static final String NAMESPACE_ATTR_NAME = "namespace"; //$NON-NLS-1$

	public static final String NAME_SPACE = "http://www.osoa.org/xmlns/sca/1.0"; //$NON-NLS-1$
	public static final String LOC_ATTR__NAME_SPACE = "http://www.osoa.org/xmlns/sca/1.0"; //$NON-NLS-1$

	//Element names of wsdl
	public static final String SCHEMA_ELEM_NAME = "xsd:schema"; //$NON-NLS-1$
	public static final String ELEMENT_ELEM_NAME = "xsd:element"; //$NON-NLS-1$
	public static final String SERVICE_ELEM_NAME = "wsdl:service"; //$NON-NLS-1$
	public static final String PORT_TYPE_ELEM_NAME = "wsdl:portType"; //$NON-NLS-1$
	public static final String DEFINITIONS_ELEM_NAME = "wsdl:definitions"; //$NON-NLS-1$
	public static final String MESSAGE_ELEM_NAME = "wsdl:message"; //$NON-NLS-1$
	public static final String PART_ELEM_NAME = "wsdl:part"; //$NON-NLS-1$ 
	public static final String PROPERTIES_ELEM_NAME = "ifw:properties"; //$NON-NLS-1$
	public static final String GENERIC_PROPS_ELEM_NAME = "ifw:genericProperties"; //$NON-NLS-1$
	public static final String OM_INFO_ELEM_NAME = "ifw:ominfo"; //$NON-NLS-1$
	public static final String SWCV_INFO_ELEM_NAME = "ifw:swcvinfo"; //$NON-NLS-1$

	//Attribute names of wsdl
	public static final String WSDL_MESSAGEPART_ATTRNAME = "element"; //$NON-NLS-1$
	public static final String TARGETNAMESPACE_ATTR_NAME = "targetNamespace"; //$NON-NLS-1$
	public static final String GUID_ATTR_NAME = "ifw:guid"; //$NON-NLS-1$

	//Attribute values of wsdl
	public static final String PREFIX = "sapinterfacewsdlloc"; //$NON-NLS-1$
	public static final String OM_REQUEST_MESSAGE = "OMRequestMessage"; //$NON-NLS-1$
	public static final String OM_RESPONSE_MESSAGE = "OMResponseMessage"; //$NON-NLS-1$

	//File location attributes
	public static final String SRC_FOLDER = "src"; //$NON-NLS-1$
	public static final String WSDL = "wsdl"; //$NON-NLS-1$

	public static final String WSDL_EXTENSION = ".wsdl"; //$NON-NLS-1$

	public static final String EMPTY_STRING = ""; //$NON-NLS-1$


}


