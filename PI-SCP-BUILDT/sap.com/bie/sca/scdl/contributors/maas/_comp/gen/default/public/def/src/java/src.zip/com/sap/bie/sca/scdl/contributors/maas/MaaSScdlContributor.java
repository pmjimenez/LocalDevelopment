package com.sap.bie.sca.scdl.contributors.maas;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.xml.namespace.QName;

import org.w3c.dom.Document;

import com.sap.bie.sca.scdl.adapter.IAttributeValue;
import com.sap.bie.sca.scdl.adapter.IBinding;
import com.sap.bie.sca.scdl.adapter.IComponent;
import com.sap.bie.sca.scdl.adapter.IComposite;
import com.sap.bie.sca.scdl.adapter.ICustomScdlAttribute;
import com.sap.bie.sca.scdl.adapter.ICustomScdlElement;
import com.sap.bie.sca.scdl.adapter.IInterface;
import com.sap.bie.sca.scdl.adapter.IScdlContributor;
import com.sap.bie.sca.scdl.adapter.ScdlContributorException;
import com.sap.bie.sca.scdl.adapter.impl.AttributeValue;
import com.sap.bie.sca.scdl.adapter.impl.Binding;
import com.sap.bie.sca.scdl.adapter.impl.Component;
import com.sap.bie.sca.scdl.adapter.impl.Composite;
import com.sap.bie.sca.scdl.adapter.impl.CustomScdlAttribute;
import com.sap.bie.sca.scdl.adapter.impl.CustomScdlElement;
import com.sap.bie.sca.scdl.adapter.impl.Service;
import com.sap.bie.sca.scdl.adapter.maas.OperationMappingImplementation;
import com.sap.ide.es.config.mc.model.mc.logicalsystem.Qname;
import com.sap.ide.es.config.mc.model.mc.servicereferences.ServiceReference;
import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.moin.repository.CRI;
import com.sap.tc.moin.repository.Connection;
import com.sap.tc.moin.repository.PRI;
import com.sap.tc.moin.repository.Partitionable;
import com.sap.tc.moin.repository.mmi.reflect.RefBaseObject;
import com.sap.tc.moin.repository.mql.FromEntry;
import com.sap.tc.moin.repository.mql.FromType;
import com.sap.tc.moin.repository.mql.MQLQuery;
import com.sap.tc.moin.repository.mql.MQLResultSet;
import com.sap.tc.moin.repository.mql.QueryScopeProvider;
import com.sap.tc.moin.repository.mql.SelectAlias;
import com.sap.tc.moin.repository.mql.SelectEntry;
import com.sap.tc.moin.repository.mql.WhereEntry;

/**
 * Generates the Icomposite object for the imported operation mapping which will be used to create the composite element
 * in the .composite file.
 * @author I047304
 */

public class MaaSScdlContributor implements IScdlContributor {
	private static final Object SCOPE_UNIVERSE = new Object();
	private static final String LOG_PREFIX = "		[SCDL_GEN-GALAXY]"; //$NON-NLS-1$
	private static final String LOG_PREFIX_ERROR = LOG_PREFIX + " ERROR:"; //$NON-NLS-1$

	private Connection connection;
	private CRI cri;

	// Component name
	private static final String OPERATION_MAPPING_COMPONENT_NAME = "OperationMappingComponent"; //$NON-NLS-1$
	private static final String tilde = "~"; //$NON-NLS-1$
	private static final String QUERY_RESULT_ALIAS = "results"; //$NON-NLS-1$


	//<component> element attribute name and value
	private static final String HELPER_CONTEXT_MANAGEMENT_ATTR_NAME = "helperContextManagement"; //$NON-NLS-1$
	private static final String HELPER_CONTEXT_MANAGEMENT_ATTR_VALUE = "containerManaged"; //$NON-NLS-1$

	/**  
	 * @param connection : {@link Connection} connection to the moin repository
	 * @param globalPluginUtil {@link IGlobalPluginUtil}
	 * @param pluginBuildInfo :  {@link IPluginBuildInfo} which contains build related information. Not null parameter
	 * @return {@link IComposite} object for PI operation mapping implementation 
	 */
	public IComposite getComposite(Connection connection,
			IGlobalPluginUtil globalPluginUtil, IPluginBuildInfo pluginBuildInfo) {
		setParams(connection, globalPluginUtil, pluginBuildInfo);
		final Composite composite = new Composite(pluginBuildInfo.getDCName());
		cri = createCRI(pluginBuildInfo.getDCName(), pluginBuildInfo.getDCVendor());
		try {
			// IComponent for PI imported operation mapping will be created and added to the IComposite 
			final IComponent piomComponent = createOperationMappingComponent(pluginBuildInfo);
			if (piomComponent != null) {
				int noOfServices = piomComponent.getServices().size();
				if (noOfServices > 0) {
					composite.addComponent(piomComponent);
				}
			}

		} catch (ScdlContributorException e) {
			final String message = "{0} Generation of component services failed as service  id {1} cannot be found in designtime metamodel !"; //$NON-NLS-1$
			Log.error(MessageFormat.format(message, LOG_PREFIX_ERROR, e.getMessage()));
		}
		return composite;
	}

	/*
	 *  Creates an operation mapping component, with a predefined name, and
	 *  includes all Services
	 *  @param pluginBuildInfo :  {@link IPluginBuildInfo} which contains build related information. Not null parameter
	 *  @return {@link IComponent} for PI operation mapping implementation. Not null parameter
	 *  @throws ScdlContributorException: When there are any issues in crating the {@link IComponent}, {@link Service}
	 */
	private IComponent createOperationMappingComponent(IPluginBuildInfo pluginBuildInfo) throws ScdlContributorException {
		final OperationMappingImplementation impl = new OperationMappingImplementation();
		final String COMPONENT_NAME = tildeName(pluginBuildInfo.getDCVendor()) + tilde + tildeName(pluginBuildInfo.getDCName()) + tilde +
		OPERATION_MAPPING_COMPONENT_NAME;
		final Component piomComponent = new Component(COMPONENT_NAME, impl);
		ICustomScdlAttribute helperContextAttr = getHelperContextAttr();
		if (helperContextAttr != null) {
			piomComponent.addAttribute(helperContextAttr);
		}
		addServices(piomComponent,pluginBuildInfo);
		return piomComponent;
	}

	/* 
	 * For each imported operation mapping ,if the service reference for the operation mapping is available in the process then 
	 * only the service element is created and added to the component.
	 * 
	 * @param component : {@link Component} created for PI operation mapping implementation. Not null parameter
	 * @param pluginBuildInfo: {@link IPluginBuildInfo} which contains build related information. Not null parameter
	 * 
	 * @throws ScdlContributorException: When there are any issues accessing the {@link Service}
	 * 
	 */
	private void addServices(Component component,IPluginBuildInfo pluginBuildInfo)throws ScdlContributorException {
		//getting all the ServiceReferences
		Collection<ServiceReference> services = query(connection,ServiceReference.class,
				new String[] {"mc", "servicereferences", "ServiceReference" }, true, null, null, cri); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
		
		for (ServiceReference serviceReference : services) {
			Qname portType = serviceReference.getPorttype();
			if(portType == null)continue;

			String ServRefPortType = portType.getName();
			String ServRefNamespace = portType.getNamespace();

			Map<Document, String> domObjectsVsWsdlNameForOM = WSDLParserForMaasComposite.getDOMObjectsForOperationMapping(pluginBuildInfo);

			for (Map.Entry<Document, String> entry : domObjectsVsWsdlNameForOM.entrySet()) {    
				Document document = entry.getKey();
				if(document == null)continue; // there is nothing to parse
				
				String wsdlName = entry.getValue();

				//getting the port type and target namespace for the operation mapping service
				String wsdlPortType = WSDLParserForMaasComposite.getPortType(document);
				String wsdlTargetNameSpace = WSDLParserForMaasComposite.getTargetNameSpace(document);

				//Create <service> elements ONLY IF :
				// the attributes <porttype> and <namespace> of ServiceReference and operation mapping are same.
				if (ServRefPortType == null || ServRefNamespace == null ||
						!(ServRefPortType.equals(wsdlPortType)) || !(ServRefNamespace.equals(wsdlTargetNameSpace))) {
					continue;
				}

				//creating the Service 
				String serviceName = WSDLParserForMaasComposite.getServiceName(document);
				if (serviceName == WSDLConstants.EMPTY_STRING) {
					continue;
				}
				Service service = new Service(serviceName, false);

				//creating the Interface and adding to the Service
				IInterface scdlInterface = createInterface(pluginBuildInfo, document, wsdlName);
				if (scdlInterface != null) {
					service.setScainterface(scdlInterface);
				}

				//creating the Binding  and adding to the Service
				IBinding binding = createBinding(pluginBuildInfo, document, wsdlName);
				if (binding != null) {
					service.setBinding(binding);
				}

				//creating the sap-extensions element and adding to the Service
				CustomScdlElement sapextnsScdlElement = createCustomScdlElement(pluginBuildInfo, document, WSDLConstants.SAP_EXTENSIONS_ELEM_NAME, WSDLConstants.NAME_SPACE, WSDLConstants.PREFIX, wsdlName);

				if (sapextnsScdlElement != null) {
					CustomScdlElement inputScdlElement = createCustomScdlElement(pluginBuildInfo, document, WSDLConstants.INPUT_ELEM_NAME, WSDLConstants.NAME_SPACE, WSDLConstants.PREFIX, wsdlName);
					if (inputScdlElement != null) {
						sapextnsScdlElement.addChild(inputScdlElement);
						//creating the type element for input element.
						createInputChildTypeElement(document, inputScdlElement, WSDLConstants.TYPE_ELEM_NAME, WSDLConstants.NAME_SPACE,WSDLConstants.PREFIX);
					}
					CustomScdlElement outputchildScdlElement = createCustomScdlElement(pluginBuildInfo, document, WSDLConstants.OUTPUT_ELEM_NAME, WSDLConstants.NAME_SPACE, WSDLConstants.PREFIX,wsdlName);
					if (outputchildScdlElement != null) {
						sapextnsScdlElement.addChild(outputchildScdlElement);
						//creating the type element for output element.
						createOutputChildTypeElement(document, outputchildScdlElement, WSDLConstants.TYPE_ELEM_NAME, WSDLConstants.NAME_SPACE,WSDLConstants.PREFIX);
					}
					service.addCustomElement(sapextnsScdlElement);
				}

				component.addService(service);
			}
		}
	}

	/*
	 * Searches for all instances of a given type in the provided partitions, if
	 * specified, or globally otherwise. The global scope may differ between
	 * environments. In a DC built, this would be the currently built and
	 * referenced DCs. In Eclipse, this would be the entire workspace.
	 * 
	 * Additional criteria can be specified to narrow down the search.
	 * 
	 * @param conn {@link Connection}
	 *            The MOIN connection to use
	 * @param classDescriptor {@link ServiceReference}
	 *            The class descriptor of the type to query for, e.g. XsdTypeDefinition.CLASS_DESCRIPTOR
	 * @param includeSubTypes
	 *            Whether to include sub types in the result list
	 * @param whereEntries
	 *            Further WHERE entries to narrow the query down to;
	 *            QUERY_RESULT_ALIAS is assumed to be the alias for
	 *            the target instances in question. May be <code>null</code>.
	 * @param fromEntries
	 *            Further FROM entries to narrow the query down to. May be
	 *            <code>null</code>.
	 * @param partitionables
	 *            The elements whose partitions the query shall be narrowed down
	 *            to. If unspecified, i.e. empty, a search of the visible scope is performed.
	 *            This means that in Ide the current DC and all referenced public parts are searched.
	 *            In the build plugin the visible scope is usually everything reachable by MOIN.
	 *            To perform a global search without considering visibility, pass SCOPE_UNIVERSE.
	 * 
	 * @return The instances of the specified type
	 */
	private <T> Collection<T> query(Connection conn, Class<ServiceReference> clazz, String[] qualifiedName, boolean includeSubTypes,
			WhereEntry[] whereEntries, FromEntry[] fromEntries, Object... partitionables) {
		if (conn == null || clazz == null ) return new ArrayList<T>();;

		// Create select entry.
		SelectEntry[] selectEntries = new SelectEntry[] { new SelectAlias(QUERY_RESULT_ALIAS) };

		// Create from entries.
		FromType mainFromEntry = new FromType(QUERY_RESULT_ALIAS, qualifiedName, !includeSubTypes);

		FromEntry[] _fromEntries = null;
		if (fromEntries != null) {
			_fromEntries = new FromEntry[fromEntries.length + 1];
			_fromEntries[0] = mainFromEntry;
			System.arraycopy(fromEntries, 0, _fromEntries, 1, fromEntries.length);
		} else {
			_fromEntries = new FromEntry[] { mainFromEntry };
		}

		// Create scope provider.
		QueryScopeProvider scopeProvider = createQueryScopeProvider(conn, partitionables);

		// Create and execute query.
		MQLQuery query = new MQLQuery(selectEntries, _fromEntries, (whereEntries != null) ? whereEntries
				: new WhereEntry[0]);

		MQLResultSet mqlResult = null;
		if (scopeProvider != null)
			mqlResult = conn.getMQLProcessor().execute(query, scopeProvider);
		else
			mqlResult = conn.getMQLProcessor().execute(query);

		// Collect result.
		Collection<T> result = new ArrayList<T>(mqlResult.getSize());
		for (int i = 0; i < mqlResult.getSize(); i++) {
			RefBaseObject obj = conn.getElement(mqlResult.getMri(i, QUERY_RESULT_ALIAS));
			if (obj != null && clazz.isInstance(obj))
				result.add((T) obj);
		}
		return result;
	}

	/*
	 *  This method is not supposed to be used by clients.
	 * 
	 *  @param conn {@link Connection}
	 *            The MOIN connection to use. Not null
	 *  @param partitionables
	 *            The partitionables to use. Not null and NON-EMPTY
	 *  @return the query scope provider, {@link QueryScopeProvider} for a connection and an optional list of
	 *  partitionables or null if not available
	 */
	private QueryScopeProvider createQueryScopeProvider(Connection conn, Object... partitionables) {
		QueryScopeProvider scopeProvider = null;
		if (partitionables != null && partitionables.length > 0) {
			if ((partitionables.length == 1) && (partitionables[0] == SCOPE_UNIVERSE))return null;		

			Set<PRI> pris = new HashSet<PRI>();
			Set<CRI> cris = new HashSet<CRI>();
			for (int i = 0; i < partitionables.length; i++) {
				if (partitionables[i] instanceof Partitionable) {
					PRI pri = ((Partitionable) partitionables[i]).get___Partition().getPri();
					pris.add(pri); // duplicates are ignored by design in sets
				}
				else if (partitionables[i] instanceof CRI)
					cris.add((CRI) partitionables[i]);
			}

			if(cris.size() != 0) {
				scopeProvider = conn.getMQLProcessor().getInclusiveQueryScopeProvider(
						pris.toArray(new PRI[pris.size()]), cris.toArray(new CRI[cris.size()]));
			}
			else {
				scopeProvider = conn.getMQLProcessor().getInclusivePartitionScopeProvider(
						pris.toArray(new PRI[pris.size()]));
			}
		}
		return scopeProvider;
	}

	/*
	 *  Replaces '/' with '~'
	 *  @param name : name for which '/' should be replaced with '~'.
	 *  @return name replaced '/' with '~'.
	 */
	private String tildeName(String name) {
		if(name == null)return WSDLConstants.EMPTY_STRING;
		return name.replace('/', '~');
	}

	/*
	 * Creates and adds the "type" element to the input element 
	 * 
	 * @param document -DOM object for the imported operation mapping wsdl.
	 * @param scdlElement - input scdl element. Not null
	 * @param elementName - name of the element i.e, "type". Not null
	 * @param nameSpace - namespace 
	 * @param prefix - prefix of the element
	 */
	private void createInputChildTypeElement(Document document, CustomScdlElement scdlElement, String elementName, String nameSpace, String prefix) {
		if (scdlElement == null || elementName == null) return ;
		Map<String, String> inputTypeAttributes = WSDLParserForMaasComposite.getInputTypeAttributes(document, elementName);
		CustomScdlElement childElement = createChildCustomScdlElement(elementName, nameSpace, prefix,inputTypeAttributes);
		if (childElement != null) {
			scdlElement.addChild(childElement);
		}
	}

	/*
	 * Creates and adds the "type" element to the output element 
	 * 
	 * @param document -DOM object for the imported operation mapping wsdl.
	 * @param scdlElement - output scdl element. Not null
	 * @param elementName - name of the element i.e, "type". Not null
	 * @param nameSpace - namespace 
	 * @param prefix - prefix of the element
	 */
	private void createOutputChildTypeElement(Document document, CustomScdlElement parentScdlElement, String elementName, String nameSpace, String prefix) {
		if (parentScdlElement == null || elementName == null) return ;
		Map<String, String> outputTypeAttributes = WSDLParserForMaasComposite.getOutputTypeAttributes(document, elementName);
		CustomScdlElement childElement = createChildCustomScdlElement(elementName, nameSpace, prefix, outputTypeAttributes);
		if (childElement != null) {
			parentScdlElement.addChild(childElement);
		}
	}

	private QName createQNameUsingAppropriateConstructor(String name,
			String nameSpace, String prefix) {
		if (name == null) {
			throw new IllegalArgumentException("name can not be null"); //$NON-NLS-1$
		}
		QName qName = null;
		if (nameSpace == null) {
			qName = new QName(name);
		} else {
			if (prefix == null) {
				qName = new QName(nameSpace, name);
			} else {
				qName = new QName(nameSpace, name, prefix);
			}
		}
		return qName;
	}

	/*
	 * Creates the custom scdl element for the child element - "type" for both input and output elements.
	 * 
	 * @param elementName - name of the element i.e, "type". Not null
	 * @param nameSpace - namespace 
	 * @param prefix - prefix of the element
	 * @param attributes -attributes for the child element -"type". Not null
	 * 
	 * @return CustomScdlElement for child element -"type"
	 */
	private CustomScdlElement createChildCustomScdlElement(String elementName, String nameSpace, String prefix, Map<String, String> attributes) {
		if (elementName == null || attributes == null) return null;
		QName qName = createQNameUsingAppropriateConstructor(elementName,nameSpace, prefix);
		CustomScdlElement scdlElement = new CustomScdlElement(qName);
		for (Map.Entry<String,String> attribute : attributes.entrySet()) { 
			String attrName = attribute.getKey(); 
			String attrValue = attribute.getValue();     
			QName attrQName = createQNameUsingAppropriateConstructor(attrName, null, prefix);
			QName valueQName = createQNameUsingAppropriateConstructor(attrValue, null, null);
			IAttributeValue scdlValue = new AttributeValue(valueQName);
			CustomScdlAttribute scdlAttr = new CustomScdlAttribute(attrQName, scdlValue);
			scdlElement.addAttribute(scdlAttr);
		} 

		return scdlElement;
	}

	/*
	 * 
	 * Creates the custom scdl element for all the  elements 
	 * 
	 * @param pluginBuildInfo - {@link IPluginBuildInfo} which contains build related information. Not null parameter
	 * @param document -DOM object for the imported operation mapping wsdl. Not null parameter
	 * @param elementName - name of the element. Not null parameter
	 * @param nameSpace - namespace 
	 * @param prefix - prefix of the element
	 * 
	 * @return CustomScdlElement for the element
	 */
	private CustomScdlElement createCustomScdlElement(IPluginBuildInfo pluginBuildInfo,Document document, String elementName, String nameSpace, String prefix, String wsdlName) {
		if ( elementName == null) return null;

		QName qName = createQNameUsingAppropriateConstructor(elementName,nameSpace, prefix);
		CustomScdlElement scdlElement = new CustomScdlElement(qName);
		String dcName = tildeName(pluginBuildInfo.getDCVendor())+ tilde +tildeName(pluginBuildInfo.getDCName());
		Map<String, String> attributes = WSDLParserForMaasComposite.getAttributes(document, elementName,dcName, wsdlName);
		for (Map.Entry<String,String> attribute : attributes.entrySet()) {  
			String attrName = attribute.getKey();   
			String attrValue = attribute.getValue(); 
			
			QName attrQName = null;
			
			// Replace space(' ') with tilde('~') in 'location' attribute value
			if (WSDLConstants.LOCATION_ATTR_NAME.equals(attrName) && WSDLConstants.NAME_SPACE.equals(nameSpace)) {
				attrValue = replaceSpaceWithTilde(pluginBuildInfo, attrValue);
				attrQName = createQNameUsingAppropriateConstructor(attrName, WSDLConstants.LOC_ATTR__NAME_SPACE, WSDLConstants.PREFIX);
			}else{
				attrQName = createQNameUsingAppropriateConstructor(attrName, null, prefix);
				
			}
			
			QName valueQName = createQNameUsingAppropriateConstructor(attrValue, null, null);
			IAttributeValue scdlValue = new AttributeValue(valueQName);
			CustomScdlAttribute scdlAttr = new CustomScdlAttribute(attrQName, scdlValue);
			scdlElement.addAttribute(scdlAttr);
		} 


		return scdlElement;
	}

	/*
	 * Creates the attribute "helperContextManagement" with prefix as "sapinterfacewsdlloc" to the
	 * <component> element in the .composite file. 
	 * @return
	 */
	private ICustomScdlAttribute getHelperContextAttr(){
		String elementName = HELPER_CONTEXT_MANAGEMENT_ATTR_NAME;
		String nameSpace = WSDLConstants.NAME_SPACE;
		String prefix = WSDLConstants.PREFIX;
		String value = HELPER_CONTEXT_MANAGEMENT_ATTR_VALUE;

		QName qName = createQNameUsingAppropriateConstructor(elementName, nameSpace, prefix);
		QName valueQName = createQNameUsingAppropriateConstructor(value, null, null);
		IAttributeValue scdlValue = new AttributeValue(valueQName);
		CustomScdlAttribute scdlAttr = new CustomScdlAttribute(qName, scdlValue);
		return scdlAttr;
	}

	/*
	 *  Replaces '' with '~'
	 *  @param pluginBuildInfo {@link IPluginBuildInfo} which contains build related information. Not null parameter
	 *  @param attrValue : value for which '' should be replaced with '~'. Not null
	 *  
	 *  @return value replaced '' with '~'.
	 */
	private String replaceSpaceWithTilde(IPluginBuildInfo pluginBuildInfo, String attrValue){
		if(attrValue == null)return WSDLConstants.EMPTY_STRING;
		
		int index = attrValue.lastIndexOf("wsdls/"+pluginBuildInfo.getDCVendor()+tilde+pluginBuildInfo.getDCName()); //$NON-NLS-1$
		if (index > 0) {
			String wsdlFileFolder = attrValue.substring(0, index);
			String wsdlFileName = attrValue.substring(index, attrValue.length());
			wsdlFileName = wsdlFileName.replace(' ', '~');
			attrValue = wsdlFileFolder + wsdlFileName;
		}
		return attrValue;
	}

	/*
	 * Creates the interface.
	 * 
	 * @param pluginBuildInfo - {@link IPluginBuildInfo} which contains build related information. Not null parameter
	 * @param document -DOM object of the imported operation mapping wsdl. Not null
	 * 
	 * @return IInterface
	 */
	private IInterface createInterface(IPluginBuildInfo pluginBuildInfo,Document document, String wsdlName){
		com.sap.bie.sca.scdl.adapter.impl.Interface scdlInterface = new com.sap.bie.sca.scdl.adapter.impl.Interface(WSDLConstants.INTERFACE_WSDL_ELEM_NAME);
		ICustomScdlElement scdlElement = createCustomScdlElement(pluginBuildInfo, document, WSDLConstants.INTERFACE_WSDL_ELEM_NAME, WSDLConstants.NAME_SPACE, null, wsdlName);
		if (scdlElement != null) {
			scdlInterface.addCustomElement(scdlElement);
		}
		return scdlInterface;
	}

	/*
	 * Creates the binding
	 * 
	 * @param pluginBuildInfo - {@link IPluginBuildInfo} which contains build related information. Not null parameter
	 * @param document -DOM object of the imported operation mapping wsdl. Not null
	 * @return IBinding
	 */
	private IBinding createBinding(IPluginBuildInfo pluginBuildInfo, Document document, String wsdlName){
		Binding binding = new Binding(WSDLConstants.BINDGING_WS_ELEM_NAME);
		CustomScdlElement scdlElement = createCustomScdlElement(pluginBuildInfo, document, WSDLConstants.BINDGING_WS_ELEM_NAME, WSDLConstants.NAME_SPACE, null, wsdlName);
		if (scdlElement != null) {
			binding.addCustomElement(scdlElement);
		}
		return binding;
	}

	/*
	 * Sets the parameters and checks for null values.
	 * 
	 * @param connection : {@link Connection} connection to the moin repository
	 * @param globalPluginUtil {@link IGlobalPluginUtil}
	 * @param pluginBuildInfo :  {@link IPluginBuildInfo} which contains build related information. Not null parameter
	 */
	private void setParams(Connection connection, IGlobalPluginUtil globalPluginUtil, IPluginBuildInfo pluginBuildInfo) 
	{
		MaaSScdlContributor.nullCheckParam(connection, "connection"); //$NON-NLS-1$
		MaaSScdlContributor.nullCheckParam(pluginBuildInfo, "pluginBuildInfo"); //$NON-NLS-1$
		this.connection = connection;
	}

	/*
	 * Checks whether parameter name or value are null
	 * @param paramValue -parameter value which needs to be checked whether it is null or not 
	 * @param paramName - parameter name which needs to be checked whether it is null or not
	 */
	private static void nullCheckParam(final Object paramValue, final String paramName)
	{
		if (paramName == null) {
			throw new NullPointerException("paramName must not be null"); //$NON-NLS-1$ 
		}

		if (paramValue == null) {
			throw new NullPointerException(paramName + " must not be null"); //$NON-NLS-1$ 
		}
	}

	private CRI createCRI(String name, String vendor){
		if ( name == null   ||  vendor == null) return null;
		return connection.getSession().getMoin().createCri("PF", "DefaultDataArea", vendor + "/" + name); //$NON-NLS-1$
	}
}