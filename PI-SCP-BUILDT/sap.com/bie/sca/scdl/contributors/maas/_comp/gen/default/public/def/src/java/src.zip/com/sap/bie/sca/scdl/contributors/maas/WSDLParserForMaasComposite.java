package com.sap.bie.sca.scdl.contributors.maas;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.log.Log;

/**
 * Class which retrieves the values from WSDL which are required while building the .composite file.
 * @author I047304
 *
 */
public class WSDLParserForMaasComposite {

	/**
	 * @param doc - {@link Document} DOM object of WSDL for which the service name has to be retrieved.
	 * @return service name
	 */
	public static String getServiceName(Document doc){

		String serviceName = WSDLConstants.EMPTY_STRING;
		if (doc == null) {
			return serviceName;
		}
		NodeList serviceNodeList = doc.getElementsByTagName(WSDLConstants.SERVICE_ELEM_NAME);
		Node serviceNode = serviceNodeList.item(0);
		if (serviceNode instanceof Element) {
			Element serviceElement = (Element)serviceNode;
			if (serviceElement != null) {
				return serviceElement.getAttribute(WSDLConstants.NAME_ATTR_NAME);
			}
		}
		return serviceName;
	}

	/**
	 * Returns the attributes of the elements(custom scdl element) in the .composite file
	 * @param document - {@link Document} DOM object of WSDL. Not null
	 * @param elementName - name of the element. Not null
	 * @param dcName - project name with vendor name. If null then Location attribute would not be created
	 * @param wsdlName - Name of the WSDL. If null then Location attribute would not be created
	 * 
	 * @return map of attribute name versus attribute value of the elements 
	 */
	public static Map<String,String> getAttributes(Document document, String elementName, String dcName, String wsdlName){
		Map<String,String> attrs = new HashMap<String, String>();
		if (document == null || elementName == null) return attrs; 

		String portType = getPortType(document);
		String targetNameSpace = getTargetNameSpace(document);
		if (WSDLConstants.INTERFACE_WSDL_ELEM_NAME.equals(elementName)) {
			attrs.put(WSDLConstants.INTERFACE_ATTR_NAME,targetNameSpace+"#wsdl.interface("+portType+")");  //$NON-NLS-1$ //$NON-NLS-1$

			if(wsdlName != null && dcName != null){
				attrs.put(WSDLConstants.LOCATION_ATTR_NAME, dcName+".bpem#wsdls/"+dcName+"/"+wsdlName+WSDLConstants.WSDL_EXTENSION);  //$NON-NLS-1$ //$NON-NLS-1$
			}
		}else if (WSDLConstants.BINDGING_WS_ELEM_NAME.equals(elementName)) {
			attrs.put(WSDLConstants.PORT_ATTR_NAME, "/"+getServiceName(document)+"/"+portType+"#wsdl.endpoint("+targetNameSpace+"#"+portType+")"); //$NON-NLS-1$ //$NON-NLS-1$ //$NON-NLS-1$ //$NON-NLS-1$ //$NON-NLS-1$
		}else if (WSDLConstants.SAP_EXTENSIONS_ELEM_NAME.equals(elementName)) {
			attrs.put(WSDLConstants.OMGUID_ATTR_NAME, getOMGuid(document));
			attrs.put(WSDLConstants.SVGUID_ATTR_NAME, getSWCVGuid(document));
		}
		return attrs;
	}

	/**
	 * @param document - {@link Document} DOM object of WSDL. Not null 
	 * @param elementName - name of the element. Not null
	 * 
	 * @return map of attribute name versus attribute value of the type element for input element 
	 */
	public static Map<String,String> getInputTypeAttributes(Document document, String elementName){
		Map<String,String> attrs = new HashMap<String, String>();
		if (document == null || elementName == null) return attrs;

		Element partElement = getPartElement(elementName, WSDLConstants.INPUT_ELEM_NAME, document);
		Element rootElement = getRootElement(partElement, document);
		attrs.put(WSDLConstants.NAME_ATTR_NAME, getSchemaName(rootElement));
		attrs.put(WSDLConstants.NAMESPACE_ATTR_NAME, getSchemaNameSpace(partElement, document)); 
		return attrs;
	}

	/**
	 * 
	 * @param document - {@link Document} DOM object of WSDL. Not null
	 * @param elementName - name of the element. Not null
	 * 
	 * @return map of attribute name versus attribute value of the type element for output element
	 */
	public static Map<String,String> getOutputTypeAttributes(Document document, String elementName){
		Map<String,String> attrs = new HashMap<String, String>();
		if (document == null || elementName == null) return attrs;

		Element partElement = getPartElement(elementName, WSDLConstants.OUTPUT_ELEM_NAME, document);
		Element rootElement = getRootElement(partElement, document);
		attrs.put(WSDLConstants.NAME_ATTR_NAME, getSchemaName(rootElement));
		attrs.put(WSDLConstants.NAMESPACE_ATTR_NAME, getSchemaNameSpace(partElement, document));
		return attrs;
	}

	/**
	 * @param document - {@link Document} DOM object of WSDL
	 * @return - value of the element - <wsdl:portType> in WSDL
	 */
	public static String getPortType(Document document){

		String portType = WSDLConstants.EMPTY_STRING;
		if (document == null) {
			return portType;
		} 
		NodeList portNodeList = document.getElementsByTagName(WSDLConstants.PORT_TYPE_ELEM_NAME); 
		Node portNode = portNodeList.item(0);
		if (portNode instanceof Element) {
			Element portTypeElement = (Element)portNode;
			if (portTypeElement != null) {
				return portTypeElement.getAttribute(WSDLConstants.NAME_ATTR_NAME); 
			}
		}
		return portType;
	}

	/**
	 * @param document- {@link Document} DOM object of WSDL
	 * @return - value of the attribute - targetNamespace for <wsdl:definitions> element in WSDL
	 */
	public static String getTargetNameSpace(Document document){
		String targetNamespace = WSDLConstants.EMPTY_STRING;
		if (document == null) {
			return targetNamespace;
		}
		NodeList definitionsNodeList = document.getElementsByTagName(WSDLConstants.DEFINITIONS_ELEM_NAME); 
		Node definitionNode = definitionsNodeList.item(0);
		if (definitionNode instanceof Element) {
			Element definitionElement = (Element)definitionNode;
			if (definitionElement != null) {
				return definitionElement.getAttribute(WSDLConstants.TARGETNAMESPACE_ATTR_NAME); 
			}
		}
		return targetNamespace;
	}

	/*
	 * @param document- DOM object of WSDL
	 * @return - value of the element - <ifw:guid>,child of  <ifw:ominfo> element in WSDL
	 */
	private static String getOMGuid(Document document){
		String opGuid = WSDLConstants.EMPTY_STRING;
		if (document == null) return opGuid;

		Element genPropsElem = getGenericProprtiesElement(document);
		if (genPropsElem == null) {
			return opGuid;
		}
		NodeList omInfoNodeList = genPropsElem.getElementsByTagName(WSDLConstants.OM_INFO_ELEM_NAME); 
		Node omInfoNode = omInfoNodeList.item(0);
		if (omInfoNode instanceof Element) {
			Element omInfoEle = (Element)omInfoNode;
			NodeList guidNodeList = omInfoEle.getElementsByTagName(WSDLConstants.GUID_ATTR_NAME);
			Node guidNode = guidNodeList.item(0);
			NodeList childNodes = guidNode.getChildNodes();
			Node guid = childNodes.item(0);
			if (guid != null) {
				return guid.getNodeValue();
			}
		}
		return opGuid;
	}

	/*
	 * @param document- {@link Document} DOM object of WSDL
	 * @return - value of the element - <ifw:guid>,child of  <ifw:swcvinfo> element in WSDL
	 */
	private static String getSWCVGuid(Document document){
		String svGuid = WSDLConstants.EMPTY_STRING;
		if (document == null) return svGuid;

		Element genPropsElem = getGenericProprtiesElement(document);
		if (genPropsElem == null) {
			return svGuid;
		}
		NodeList swcvNodeList = genPropsElem.getElementsByTagName(WSDLConstants.SWCV_INFO_ELEM_NAME); 
		Node swcvInfoNode = swcvNodeList.item(0);
		if (swcvInfoNode instanceof Element) {
			Element swcvInfoEle = (Element)swcvInfoNode;
			NodeList guidNodeList = swcvInfoEle.getElementsByTagName(WSDLConstants.GUID_ATTR_NAME); 
			Node guidNode = guidNodeList.item(0);
			NodeList childNodes = guidNode.getChildNodes();
			Node guid = childNodes.item(0);
			if (guid != null) {
				return guid.getNodeValue();
			}
		}
		return svGuid;
	}

	/*
	 * @param elementName - name of the element -i.e,type
	 * @param parentType - name of the parent i.e., input or output
	 * @param document - {@link Document} DOM object of WSDL
	 * @return Element -{@link Element} <part> element,child of <message> element in WSDL.
	 */
	private static Element getPartElement(String elementName,String parentType, Document document){
		if (document == null) {
			return null;
		}
		
		NodeList messageNodeList = document.getElementsByTagName(WSDLConstants.MESSAGE_ELEM_NAME);
		int noOfMessages = messageNodeList.getLength();
		for (int i = 0; i < noOfMessages; i++) {
			Node messageNode = messageNodeList.item(i);
			if (messageNode instanceof Element) {
				Element messageElement = (Element)messageNode;
				String messageName = messageElement.getAttribute(WSDLConstants.NAME_ATTR_NAME);
				NodeList partNodeList = messageElement.getElementsByTagName(WSDLConstants.PART_ELEM_NAME);
				Node partNode = partNodeList.item(0); //Assumption: Only one <part> would be there 
				if (partNode instanceof Element) {
					Element partElement = (Element)partNode;
					// a. If the specified elementName is "input" then schema name would be generated from WSDL Request message element
					// b. If the specified elementName is "output" then schema name would be generated from WSDL Response message element
					if ((WSDLConstants.TYPE_ELEM_NAME).equals(elementName) 
							&&
							((WSDLConstants.OM_REQUEST_MESSAGE.equals(messageName)&& WSDLConstants.INPUT_ELEM_NAME.equals(parentType)) 
							|| (WSDLConstants.OM_RESPONSE_MESSAGE.equals(messageName) && WSDLConstants.OUTPUT_ELEM_NAME.equals(parentType)))) {
						return partElement;
					}
				}
			}
		}
		
		return null;
	}
	
	/*
	 * 
	 * @param partElement - {@link Element} <part> element,child of <message> element in WSDL.
	 * @param document - {@link Document}- DOM object of WSDL
	 * @return Root Element
	 */
	private static Element getRootElement(Element partElement, Document document){
		if(partElement == null)return null;

		String partElementName = partElement.getAttribute(WSDLConstants.WSDL_MESSAGEPART_ATTRNAME);
		if(partElementName == null)return null;

		int prefixIndex = partElementName.indexOf(':'); //$NON-NLS-1$
		partElementName = partElementName.substring(prefixIndex+1);

		NodeList elementNodeList = document.getElementsByTagName(WSDLConstants.ELEMENT_ELEM_NAME);
		int noOfElements = elementNodeList.getLength();
		for (int j = 0; j <  noOfElements; j++) {
			Node elementNode = elementNodeList.item(j);
			if (elementNode instanceof Element) {
				Element element = (Element)elementNode;
				String elementName = element.getAttribute(WSDLConstants.NAME_ATTR_NAME);
				if (partElementName.equals(elementName)) {
					return element;
				}
			}
		}

		return null;
	}
	
	/*
	 * @param partElement {@link Element} <part> element,child of <message> element in WSDL.
	 * @return name of the schema for input/output
	 */
	private static String getSchemaName(Element partElement){
		if(partElement == null)return WSDLConstants.EMPTY_STRING;		
		return partElement.getAttribute(WSDLConstants.NAME_ATTR_NAME);
	}

	/*
	 * 
	 * @param elementName -name of the element -i.e,type
	 * @param parentType - name of the parent i.e., input or output
	 * @param document - {@link Document}- DOM object of WSDL
	 * @return namespace of the schema for input/output
	 */
	private static String getSchemaNameSpace(Element partElement, Document document){
		if(partElement == null)return WSDLConstants.EMPTY_STRING;

		NodeList schemaNodeList = document.getElementsByTagName(WSDLConstants.SCHEMA_ELEM_NAME);

		int noOfSchemas = schemaNodeList.getLength();
		for (int i = 0; i < noOfSchemas; i++) {
			Node schemaNode = schemaNodeList.item(i);
			if (schemaNode instanceof Element) {
				Element schemaElement = (Element)schemaNode;
				NodeList elementNodeList = schemaElement.getElementsByTagName(WSDLConstants.ELEMENT_ELEM_NAME);
				int noOfElements = elementNodeList.getLength();
				for (int j = 0; j <  noOfElements; j++) {
					Node elementNode = elementNodeList.item(j);
					// Get the target name space of the specified schema
					if (elementNode instanceof Element) {
						Element element = (Element)elementNode;
						String attribute = element.getAttribute(WSDLConstants.NAME_ATTR_NAME);

						String schemaName = partElement.getAttribute(WSDLConstants.WSDL_MESSAGEPART_ATTRNAME);
						int prefixIndex = schemaName.indexOf(':'); //$NON-NLS-1$
						schemaName = schemaName.substring(prefixIndex+1);
						
						if (schemaName.equals(attribute)) {
							if (schemaElement != null) {
								return schemaElement.getAttribute(WSDLConstants.TARGETNAMESPACE_ATTR_NAME);
							}
						}
					}
				}

			}
		}
		return WSDLConstants.EMPTY_STRING;
	}

	/*
	 * 
	 * @param pluginBuildInfo :  {@link IPluginBuildInfo} which contains build related information. Not null parameter
	 * @return {@link List} of all the WSDL files in src/wsdl folder
	 */
	private static List<File> getAllWSDLsInSrcWsdlFolder(IPluginBuildInfo pluginBuildInfo){
		List<File> wsdls = new  ArrayList<File>(0);
		if (pluginBuildInfo == null) {
			return wsdls;
		}
		List<File> srcDirs = pluginBuildInfo.getSourceDirsAsFiles();
		Iterator<File> srcDirsIt = srcDirs.iterator();
		File srcDir= null;

		// Get the src folder
		while(srcDirsIt.hasNext()){
			srcDir = srcDirsIt.next();
			if(srcDir.isDirectory()){
				String dirName = srcDir.getName();
				if(WSDLConstants.SRC_FOLDER.equals(dirName)){
					break;
				}
			}
		}

		// Get the wsdl folder
		File[] wsdlFolder = srcDir.listFiles(new FileFilter() {			
			@Override
			public boolean accept(File file) {
				if(file.isDirectory()){
					if (file.getName().equals(WSDLConstants.WSDL)) {
						return true;
					}
				}
				return false;
			}
		});

		// Get the files with ".wsdl" extension
		if(wsdlFolder != null && wsdlFolder.length == 1){
			File wsdlDir = wsdlFolder[0];

			if(wsdlDir != null && wsdlDir.exists()){
				File[] wsdlFiles = wsdlDir.listFiles();
				for (File wsdl : wsdlFiles) {
					if (wsdl.isFile()) {
						if (wsdl.getName().endsWith(WSDLConstants.WSDL_EXTENSION)) {
							wsdls.add(wsdl);
						}

					}
				}
			}

		}
		return wsdls;
	}

	/**
	 * 
	 * @param pluginBuildInfo: {@link IPluginBuildInfo} which contains build related information
	 * @return {@link Map} of DOM objects and WSDL name for all imported operation mapping. 
	 */
	public static Map<Document, String> getDOMObjectsForOperationMapping(IPluginBuildInfo pluginBuildInfo) {
		Map<Document, String> domVsWSDLName = new HashMap<Document, String>();
		if (pluginBuildInfo == null) return domVsWSDLName;


		List<File> wsdLs = getAllWSDLsInSrcWsdlFolder(pluginBuildInfo);
		for (File wsdl : wsdLs) {
			Document doc = loadWSDL(wsdl);
			if (doc == null) {
				continue;
			}
			String wsdlNameWithExn = wsdl.getName();
			String wsdlName = wsdlNameWithExn.substring(0, wsdlNameWithExn.lastIndexOf(WSDLConstants.WSDL_EXTENSION));
			String omGuid = getOMGuid(doc);
			if (omGuid != null && !omGuid.equals(WSDLConstants.EMPTY_STRING)) {
				domVsWSDLName.put(doc, wsdlName);
			}
		}
		return domVsWSDLName;
	}

	/*
	 * 
	 * @param wsdlFile - WSDL {@link File} which needs to be parsed 
	 * @return {@link Document} DOM object for the specified WSDL
	 */
	private static Document loadWSDL(File wsdlFile){
		Document doc = null;
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			doc = db.parse(wsdlFile);
			doc.getDocumentElement().normalize();
		} catch (ParserConfigurationException e) {
			Log.warn("ParserConfigurationException during loading wsdl"); //$NON-NLS-1$
		} catch (SAXException e) {
			Log.warn("SAXException during loading wsdl"); //$NON-NLS-1$
		} catch (IOException e) {
			Log.warn("IOException during loading wsdl"); //$NON-NLS-1$
		} 
		return doc;

	}

	/*
	 * @param Element : <ifw:genericProperties> element - child of  <ifw:properties element in WSDL
	 */
	private static Element getGenericProprtiesElement(Document doc){
		if (doc == null) return null;

		Element genPropsElem = null;
		NodeList propertiesNodeList = doc.getElementsByTagName(WSDLConstants.PROPERTIES_ELEM_NAME); 
		Node propertiesNode = propertiesNodeList.item(0);

		if (propertiesNode instanceof Element) { 
			Element propertiesElement = (Element) propertiesNode;

			NodeList genpropsNodeList = propertiesElement.getElementsByTagName(WSDLConstants.GENERIC_PROPS_ELEM_NAME); 
			Node genPropNode = genpropsNodeList.item(0);
			if (genPropNode instanceof Element) {
				return (Element)genPropNode;
			}
		}
		return genPropsElem;
	}
}


