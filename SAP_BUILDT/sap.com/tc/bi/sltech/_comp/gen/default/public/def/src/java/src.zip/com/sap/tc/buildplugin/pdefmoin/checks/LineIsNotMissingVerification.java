package com.sap.tc.buildplugin.pdefmoin.checks;

import java.util.Hashtable;
import java.util.List;

import com.sap.sld.api.std.sl.SLD_FunctionalEntity;
import com.sap.sld.api.std.soft.SLD_ProductVersion;
import com.sap.sld.api.std.soft.SLD_SoftwareComponentVersion;
import com.sap.sld.api.wbem.client.WBEMClient;
import com.sap.sld.api.wbem.exception.CIMException;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.buildplugin.util.BuildPluginException;

/**
 * Report warning if a ProductLine, SoftwareComponentLine or FunctionalEntityLine is missing
 * 
 */
public class LineIsNotMissingVerification implements VerificationClass
{
	private final WBEMClient				client;
	private final List<String>				messages;
	private final Hashtable<String, String>	properties;

	public LineIsNotMissingVerification(WBEMClient client, List<String> messages, Hashtable<String, String> properties)
	{
		this.client = client;
		this.messages = messages;
		this.properties = properties;
	}

	public boolean verify() throws BuildPluginException
	{
		boolean checkOK = true;

		try
		{
			List<SLD_ProductVersion> productVersions = SLD_ProductVersion.getAllProductVersions(client);
			for (SLD_ProductVersion productVersion : productVersions)
			{
				String allProducts = properties.get(VerificationProperties.ALL_PRODUCTS);
				if (VerificationProperties.ALL_PRODUCTS_NO.equals(allProducts))
				{
					String productName = properties.get(VerificationProperties.PRODUCT_NAME);
					String vendor = properties.get(VerificationProperties.VENDOR);
					String versions = properties.get(VerificationProperties.VERSION);

					if (!productVersion.getName().equals(productName) || !productVersion.getVersion().equals(vendor)
							|| !productVersion.getVendor().equals(versions))
					{
						continue;
					}
				}

				if (productVersion.getProduct() == null)
				{
					checkOK = false;
					messages.add("ProductLine does not exist for Product " + productVersion.toString());
					Log.warn("ProductLine does not exist for Product " + productVersion.toString());
				}
			}
			List<SLD_SoftwareComponentVersion> scVersions = SLD_SoftwareComponentVersion.getAllSoftwareComponentVersions(client, true);
			for (SLD_SoftwareComponentVersion scVersion : scVersions)
			{
				if (scVersion.getSoftwareComponent() == null)
				{
					checkOK = false;
					messages.add("SoftwareComponentLine does not exist for SoftwareComponent " + scVersion.toString());
					Log.warn("SoftwareComponentLine does not exist for SoftwareComponent " + scVersion.toString());
				}
			}
			List<SLD_FunctionalEntity> functionalEntityVersions = SLD_FunctionalEntity.getAllFunctionalEntitys(client, true);
			for (SLD_FunctionalEntity functionalEntity : functionalEntityVersions)
			{
				if (functionalEntity.getFunctionalEntityLine() == null)
				{
					checkOK = false;
					messages.add("FunctionalEntityLine does not exist for FunctionalEntity " + functionalEntity.toString());
					Log.warn("FunctionalEntityine does not exist for FunctionalEntity " + functionalEntity.toString());
				}
			}
		}
		catch (CIMException e)
		{
			messages.add("CIMException while testing if Line is missing for Products, SCs or FEs: " + e.getMessage());
		}

		return checkOK;
	}

	public boolean abortBuild()
	{
		return false;
	}

	public String getDescription()
	{
		return "Check if Line is missing for Products, SCs or FEs";
	}

	public boolean stopOtherVerifications()
	{
		return false;
	}
}
