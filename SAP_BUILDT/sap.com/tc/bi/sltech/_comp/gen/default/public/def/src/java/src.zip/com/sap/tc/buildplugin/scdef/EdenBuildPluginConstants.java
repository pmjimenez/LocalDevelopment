package com.sap.tc.buildplugin.scdef;

public class EdenBuildPluginConstants
{

	public static final String	ATTR_SLDATA_PACKDIR				= "sldata-packdir";
	public static final String	ATTR_SLDATA_TEMPDIR				= "sldata-tempdir";

	public static final String	MOIN_INPUT_FILENAME				= "slmodel.sldata";
	public static final String	CR_CONTENT_FILENAME				= "cr-content.zip";

	public static final String	NW_PRODUCTS_XML					= "nw_products.xml";

	public static final String	NW_PRODUCTS_EXTEND_XML			= "nw_products_extend.xml";
	public static final String	UT_DEF_XML						= "utdef.xml";
	public static final String	USAGES_DATA_XML					= "usages_data.xml";
	public static final String	ITSCENARIOS_XML					= "itscenarios.xml";
	public static final String	JEXCLUDE_XML					= "jexclude.xml";

	public static final String	CONTENT_NW_UTC					= "sap.com~sl.ut.content.nw.utc";

	public static final String	NW_PRODUCTS_XSD					= "nw_products.xsd";
	public static final String	ADDITIONAL_NODES_XML			= "additional_nodes.xml";
	public static final String	NW_PRODUCTS_EXTEND_XLS			= "nw_products_extend.xsl";
	public static final String	USAGES_DATA_XLS					= "usages_data.xsl";
	public static final String	UTDEF_XLS						= "utdef_transform.xsl";
	public static final String	FUNCTIONS_XLS					= "functions.xsl";
	public static final String	ITSCENARIOS_XSL					= "itscenarios.xsl";
	public static final String	JEXCLUDE_XSL					= "jexclude.xsl";

	public static final String	DC_ATTRIBUTE_COMPLETE_PRODUCT	= "complete_product_model";
	public static final String	GENERATE_NW_PRODUCTS			= "generate_nw_products";

	public static final String	VALID_FILE_SUFFIX_FOR_EMF_TASK	= ".sldata";

}
