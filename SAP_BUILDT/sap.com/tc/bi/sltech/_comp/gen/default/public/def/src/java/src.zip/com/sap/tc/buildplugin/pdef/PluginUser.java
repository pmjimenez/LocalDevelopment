/*
 * Created on 18.02.2008
 */
package com.sap.tc.buildplugin.pdef;

import com.sap.cim.api.security.CIMUser;

public class PluginUser extends CIMUser
{
  public PluginUser()
  {
  }

  @Override
  public void checkRole(String role)
  {
  }

  @Override
  public String getName()
  {
    return "plugin_user";
  }

  @Override
  public boolean isInRole(String role)
  {
    return true;
  }
}
