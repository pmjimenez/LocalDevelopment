 package com.sap.tc.buildplugin.scdef;
 
 import java.io.File;
 
 
 public final class Sdir {
 
     private File dir;
 
     public File getSdir( ) {
 
         return dir;
     }
 
     public void setSdir( File name ) {
 
         this.dir = name;
     }
 
     @Override
     public String toString( ) {
 
         return String.valueOf( dir );
     }
 }
