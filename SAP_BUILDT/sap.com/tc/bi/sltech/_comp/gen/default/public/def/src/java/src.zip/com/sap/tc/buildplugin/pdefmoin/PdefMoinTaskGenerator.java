package com.sap.tc.buildplugin.pdefmoin;

import com.sap.tc.buildplugin.pdef.PdefTaskGenerator;

public class PdefMoinTaskGenerator extends PdefTaskGenerator {
	
    @Override
	protected String getTaskName() {
    	return "PdefMoinGeneratorTask";
    }
}
