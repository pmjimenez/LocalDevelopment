package com.sap.tc.buildplugin.pdefmoin.checks;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

import com.sap.sld.api.std.sl.SLD_UsageType;
import com.sap.sld.api.std.soft.SLD_ProductVersion;
import com.sap.sld.api.wbem.client.WBEMClient;
import com.sap.sld.api.wbem.exception.CIMException;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.buildplugin.util.BuildPluginException;

/**
 * Check if the part-Id of all top level UsageTypes is unique.
 */
public class PartIdVerification implements VerificationClass
{
	private final WBEMClient	client;
	private final List<String>	messages;

	public PartIdVerification(WBEMClient client, List<String> messages, Hashtable<String, String> properties)
	{
		this.client = client;
		this.messages = messages;
	}

	public boolean verify() throws BuildPluginException
	{
		boolean checkOK = true;

		try
		{
			List<SLD_ProductVersion> productVersions = SLD_ProductVersion.getAllProductVersions(client);
			for (SLD_ProductVersion productVersion : productVersions)
			{
				List<SLD_UsageType> allTopLevelUsageTypes = productVersion.getAllUsageTypes();
				HashMap<String, SLD_UsageType> elementTypeIDs = new HashMap<String, SLD_UsageType>();
				for (SLD_UsageType usageType : allTopLevelUsageTypes)
				{
					String elementTypeID = usageType.getElementTypeID();
					if (elementTypeID != null)
					{
						if (elementTypeIDs.containsKey(elementTypeID))
						{
							SLD_UsageType usageTypeWithSameId = elementTypeIDs.get(elementTypeID);
							Log.error("Part-ID " + elementTypeID + " is not unique. Is is used for UsageType " + usageType.getName() + " and UsageType "
									+ usageTypeWithSameId.getName());
							messages.add("Part-ID " + elementTypeID + " is not unique. Is is used for UsageType " + usageType.getName() + " and UsageType "
									+ usageTypeWithSameId.getName());
							checkOK = false;
						}
						else
						{
							elementTypeIDs.put(elementTypeID, usageType);
						}
					}
				}
			}
		}
		catch (CIMException e)
		{
			throw new BuildPluginException("CIMException while cheking if UsageType part-id is unique. ", e);
		}

		return checkOK;
	}

	public boolean abortBuild()
	{
		return true;
	}

	public String getDescription()
	{
		return "Check if UsageType part-id is unique";
	}

	public boolean stopOtherVerifications()
	{
		return false;
	}
}
