package com.sap.tc.buildplugin.pdefmoin.checks;

import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;

import com.sap.sld.api.std.sl.SLD_FunctionalElement;
import com.sap.sld.api.std.sl.SLD_FunctionalEntity;
import com.sap.sld.api.std.sl.SLD_FunctionalUnit;
import com.sap.sld.api.std.soft.SLD_ProductVersion;
import com.sap.sld.api.std.soft.SLD_SoftwareComponentVersion;
import com.sap.sld.api.std.soft.SLD_SoftwareUnit;
import com.sap.sld.api.wbem.client.WBEMClient;
import com.sap.sld.api.wbem.exception.CIMException;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.buildplugin.util.BuildPluginException;

/**
 * check if FUNs only reference SCs available via Product - Feature - SC
 * 
 */
public class FunctionalUnitSCsVerification implements VerificationClass
{
	private final WBEMClient				client;
	private final List<String>				messages;
	private final Hashtable<String, String>	properties;

	public FunctionalUnitSCsVerification(WBEMClient client, List<String> messages, Hashtable<String, String> properties)
	{
		this.client = client;
		this.messages = messages;
		this.properties = properties;
	}

	public boolean verify() throws BuildPluginException
	{
		boolean checkOK = true;

		try
		{
			List<SLD_ProductVersion> productVersions = SLD_ProductVersion.getAllProductVersions(client);
			for (SLD_ProductVersion productVersion : productVersions)
			{
				String allProducts = properties.get(VerificationProperties.ALL_PRODUCTS);
				if (VerificationProperties.ALL_PRODUCTS_NO.equals(allProducts))
				{
					String productName = properties.get(VerificationProperties.PRODUCT_NAME);
					String vendor = properties.get(VerificationProperties.VENDOR);
					String versions = properties.get(VerificationProperties.VERSION);

					if (!productVersion.getName().equals(productName) || !productVersion.getVersion().equals(vendor)
							|| !productVersion.getVendor().equals(versions))
					{
						continue;
					}
				}

				HashSet<SLD_SoftwareComponentVersion> allSCs = new HashSet<SLD_SoftwareComponentVersion>();
				List<SLD_SoftwareUnit> softwareUnits = productVersion.getSoftwareUnits();
				for (SLD_SoftwareUnit softwareUnit : softwareUnits)
				{
					allSCs.addAll(softwareUnit.getSoftwareComponentVersions());
				}

				List<SLD_FunctionalElement> functionalElements = productVersion.getFunctionalElements(false);
				HashSet<SLD_FunctionalUnit> allFEs = new HashSet<SLD_FunctionalUnit>();
				for (SLD_FunctionalElement functionalElement : functionalElements)
				{
					addFunctionalElementAndAllMembers(functionalElement, allFEs);
					addFunctionalElementAndAllRequired(functionalElement, allFEs);
				}

				for (SLD_FunctionalUnit functionalElement : allFEs)
				{
					List<SLD_SoftwareComponentVersion> softwareComponents = functionalElement.getSoftwareComponents();
					for (SLD_SoftwareComponentVersion softwareComponentVersion : softwareComponents)
					{
						if (!allSCs.contains(softwareComponentVersion))
						{
							Log.warn("SoftwareComponent " + softwareComponentVersion.getName() + " is referenced from FUN " + functionalElement.getName()
									+ " but is not contained in product " + productVersion.getName());
							messages.add("SoftwareComponent " + softwareComponentVersion.getName() + " is referenced from FUN " + functionalElement.getName()
									+ " but is not contained in product " + productVersion.getName());
							checkOK = false;
						}
					}

				}
			}
		}
		catch (CIMException e)
		{
			throw new BuildPluginException("CIMException while cheking if FUNs reference only SCs available via product. ", e);
		}

		return checkOK;
	}

	private void addFunctionalElementAndAllMembers(SLD_FunctionalElement fe, HashSet<SLD_FunctionalUnit> allFEs) throws CIMException
	{
		if (fe instanceof SLD_FunctionalUnit)
			allFEs.add((SLD_FunctionalUnit) fe);

		List<SLD_FunctionalElement> allMembers = fe.getAllMembers(false);
		for (SLD_FunctionalElement functionalElement : allMembers)
		{
			addFunctionalElementAndAllMembers(functionalElement, allFEs);
		}
	}

	private void addFunctionalElementAndAllRequired(SLD_FunctionalElement fe, HashSet<SLD_FunctionalUnit> allFEs) throws CIMException
	{
		if (fe instanceof SLD_FunctionalUnit)
			allFEs.add((SLD_FunctionalUnit) fe);

		List<SLD_FunctionalEntity> locallyRequiredFEs = fe.getRequiredFEs();
		for (SLD_FunctionalEntity functionalEntity : locallyRequiredFEs)
		{
			if (functionalEntity instanceof SLD_FunctionalElement)
				addFunctionalElementAndAllRequired((SLD_FunctionalElement) functionalEntity, allFEs);
		}
	}

	public boolean abortBuild()
	{
		return false;
	}

	public String getDescription()
	{
		return "Check if FUNs reference only SCs available via Product";
	}

	public boolean stopOtherVerifications()
	{
		return false;
	}
}
