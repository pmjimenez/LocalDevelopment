package com.sap.glx.paradigmInterface.bpmn.compiler.helpers;

import com.sap.glx.ide.model.galaxy.task.Task;
import com.sap.glx.ide.model.galaxy.workflow.Collaboration;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.EmbeddedScope;
import com.sap.glx.ide.model.galaxy.workflow.Pool;
import com.sap.glx.ide.model.galaxy.workflow.Scope;
import com.sap.glx.ide.model.galaxy.workflow.ScopeObject;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;

public class WorkflowHelper {
    
    /**
     * Retrieves the active pool from a workflow. Kinda slow: O(#pools)
     * 
     * @param collaboration
     * @return
     */
    public static Pool getActivePool(Collaboration collaboration) {
        if (collaboration.getPools() != null)
            for (Pool pool : collaboration.getPools())
                if (pool.isActive())
                    return pool;

        return null;
    }
    
    public static boolean isTaskStatusDataObject(CompilerContext ctx, DataContainer object) {
        return (ctx.isTaskFlow() && object.getOriginalName().equals(CompilerConstants.SONDERLOCKE_TASKSTATUS));
    }
    

    public static Scope getRootScope(ScopeObject scopeObject) {
        Scope parent = scopeObject.getScope();
        if (parent instanceof Pool || parent instanceof Task) {
            return parent;
        } else if (parent instanceof EmbeddedScope) {
            return getRootScope((EmbeddedScope) parent);
        } else {
            throw new IllegalArgumentException();
        }
    }
}
