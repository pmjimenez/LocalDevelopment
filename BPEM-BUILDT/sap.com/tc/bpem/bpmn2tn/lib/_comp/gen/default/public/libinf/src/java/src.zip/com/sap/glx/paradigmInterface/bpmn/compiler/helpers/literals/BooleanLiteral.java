package com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals;


public class BooleanLiteral extends AbstractLiteral<Boolean> {

	public static BooleanLiteral FALSE = new BooleanLiteral(false);
	public static BooleanLiteral TRUE = new BooleanLiteral(true);
	
	private BooleanLiteral(boolean value) {
        super(value);
    }

}
