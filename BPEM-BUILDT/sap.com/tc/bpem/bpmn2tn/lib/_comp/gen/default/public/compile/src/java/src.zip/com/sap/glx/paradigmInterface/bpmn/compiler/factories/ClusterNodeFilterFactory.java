package com.sap.glx.paradigmInterface.bpmn.compiler.factories;

import com.sap.glx.ide.model.galaxy.core.ModelElement;
import com.sap.glx.ide.model.triggernet.GenericOperator;
import com.sap.glx.ide.model.triggernet.Subnet;
import com.sap.glx.paradigmInterface.facades.ITriggernetFacade;

public class ClusterNodeFilterFactory extends NodeFactory {

    private static final String NAME_PREFIX = "CLUSTER_FILTER"; //$NON-NLS-1$
    private static final String JAVA_CLASS = "com.sap.glx.core.kernel.trigger.node.ClusterNodeIdFilterNode"; //$NON-NLS-1$

    public ClusterNodeFilterFactory(ITriggernetFacade facade, Subnet subnet) {
        super(facade, subnet);
    }

    @Override
    protected String getNodePrefix() {
        return NAME_PREFIX;
    }

    @Override
    protected int getInputCount() {
        return 1;
    }

    @Override
    protected int getOutputCount() {
        return 2;
    }

    public GenericOperator generateClusterFilter(ModelElement artifact, String name, String operand) {
        GenericOperator generic = createElement(GenericOperator.class);
        prepareNode(generic, artifact, name);
        generic.setImplementationClass(JAVA_CLASS);
        generic.getParameters().add(operand);
        return generic;
    }
}
