package com.sap.glx.paradigmInterface.bpmn.compiler.stage;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.DataObject;
import com.sap.glx.ide.model.galaxy.workflow.MessageFlowObject;
import com.sap.glx.ide.model.galaxy.workflow.View;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.mapping.base.compiler.IMappingCompiler;
import com.sap.mapping.base.compiler.IMappingCompiler.Summary;
import com.sap.tc.esmp.mm.xsd1.XsdFeature;

/**
 * This stage determines which views are depending on which source Data Containers. Whereas the source Data Containers can be Data Objects
 * and Views. This stage requires to be executed <b>before</b> the compilation of artifacts.
 * 
 * @author d047434
 * @version $Id:
 *          //bpem/bpem.bp/dev/src/_com.sap.glx.bpmn2tn/java/com/sap/glx/paradigmInterface/bpmn/compiler/stage/DetermineDependingViewsStage
 *          .java#1 $
 */
public class DetermineDependingViewsStage implements CompilerStage {

    private SortedSet<DataContainer> allDataContainers;
    private SortedSet<View> allViews;

    public void execute(CompilerContext ctx) throws BPMNCompilerException {
        determineAllViewsAndDataContainers(ctx);
        determineViewMappings(ctx);

        for (DataContainer dataContainer : allDataContainers) {
            determineDependingViews(dataContainer, ctx);
        }
    }

    private void determineAllViewsAndDataContainers(CompilerContext ctx) {
        allDataContainers = new TreeSet<DataContainer>(ctx.getState().dataContainerComparator);
        allViews = new TreeSet<View>(ctx.getState().dataContainerComparator);
        
        LinkedHashSet<DataObject> dataobjects = ctx.getArtifacts(DataObject.class);
        LinkedHashSet<View> views = ctx.getArtifacts(View.class);

        SortedSet<DataContainer> objects = new TreeSet<DataContainer>(ctx.getState().dataContainerComparator);
        if (dataobjects == null) {
            dataobjects = new LinkedHashSet<DataObject>(0);
        }
        objects.addAll(dataobjects);

        if (views == null) {
            views = new LinkedHashSet<View>(0);
        }
        objects.addAll(views);

        allViews.addAll(views);
        allDataContainers.addAll(objects);
    }

    private void determineViewMappings(CompilerContext ctx) throws BPMNCompilerException {
        for (View view : allViews) {
            Pair<Summary, String> compiledMapping = ctx.getMappingHelper().getCompiledMapping(view.getMapping());
            ctx.getState().addViewMapping(view, compiledMapping);
        }
    }

    private void determineDependingViews(DataContainer dataContainer, CompilerContext ctx) {

        SortedSet<View> dependingViews = ctx.getState().getDependingViews(dataContainer);
        // don't traverse dependencies, if this was already done for this data container
        if (dependingViews != null) {
            return;
        }

        for (View view : allViews) {
            Pair<Summary, String> viewMapping = ctx.getState().getViewMapping(view);
            SortedSet<DataContainer> sourceContainers = identifySourceDataObjects(ctx, viewMapping.first);

            if (sourceContainers.contains(dataContainer)) {
                ctx.getState().addDependingView(dataContainer, view);
                ctx.getState().addReverseViewDependencies(view, sourceContainers);
                // traverse search for views depending on views
                determineDependingViews(view, ctx);
            }
        }
    }

    private SortedSet<DataContainer> identifySourceDataObjects(CompilerContext ctx, IMappingCompiler.Summary summary) {
        Set<XsdFeature> elements = summary.getSourceFeatureSet();
        SortedSet<DataContainer> result = new TreeSet<DataContainer>(ctx.getState().dataContainerComparator);

        for (MessageFlowObject object : allDataContainers) {
            DataContainer data = (DataContainer) object;
            if (elements.contains(data.getXsdElementDeclaration()))
                result.add(data);
        }
        return result;
    }

}
