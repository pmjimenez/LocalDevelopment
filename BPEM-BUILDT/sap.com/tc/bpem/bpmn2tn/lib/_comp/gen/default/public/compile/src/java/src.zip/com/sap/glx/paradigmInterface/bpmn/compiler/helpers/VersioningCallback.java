package com.sap.glx.paradigmInterface.bpmn.compiler.helpers;

public interface VersioningCallback {
	
	void incorporateVersionIdentifier(String version_id);
}
