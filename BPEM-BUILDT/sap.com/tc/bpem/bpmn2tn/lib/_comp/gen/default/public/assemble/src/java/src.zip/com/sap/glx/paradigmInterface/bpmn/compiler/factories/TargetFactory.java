package com.sap.glx.paradigmInterface.bpmn.compiler.factories;

import com.sap.glx.ide.model.actions.ScriptedAction;
import com.sap.glx.ide.model.galaxy.core.ModelElement;
import com.sap.glx.ide.model.triggernet.Subnet;
import com.sap.glx.ide.model.triggernet.Target;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ScriptVersioningCallback;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.Script;
import com.sap.glx.paradigmInterface.facades.ITriggernetFacade;

public class TargetFactory extends NodeFactory {
    
    private static final String JAVA_TARGET_CLASS = "com.sap.glx.core.kernel.trigger.node.DestinationNode"; //$NON-NLS-1$

    protected CompilerContext ctx;

    public TargetFactory(ITriggernetFacade facade, Subnet subnet, CompilerContext ctx) {
        super(facade, subnet);
        this.ctx = ctx;
    }

    @Override
    protected String getNodePrefix() {
        return "TARGET"; //$NON-NLS-1$
    }

    @Override
    protected int getInputCount() {
        return 1;
    }

    @Override
    protected int getOutputCount() {
        return 0;
    }

    public Target generateTarget(ModelElement artifact, String name) {
        Target target = createElement(Target.class);
        prepareNode(target, artifact, name);
        target.setImplementationClass(JAVA_TARGET_CLASS);
        return target;
    }

    public Target generateTarget(ModelElement modelElement, String name, String implementationClass) {
        Target target = generateTarget(modelElement, name);
        target.setImplementationClass(implementationClass);
        return target;
        
    }
    
    public Target generateTarget(ModelElement artifact) {
        return generateTarget(artifact, null);
    }

    /**
     * Sets a transition script consisting of its header and body on a given target node.
     * 
     * @param target
     *            the target node to set the transition script on
     * @param header
     *            the script's header
     * @param body
     *            the script's body
     * @param priority
     *            the priority to schedule the transition with
     */
    public void setScript(Target target, String header, String body, int priority) {
        ScriptedAction script = createElement(ScriptedAction.class);
        script.setPriority(priority);
        script.setScriptText(header + " " + body);
        ctx.getVersioningHelper().registerVersioningCallback(new ScriptVersioningCallback((ScriptedAction) script));
        target.setAction(script);
    }

    public void setScript(Target target, String header, String body) {
        setScript(target, header, body, CompilerConstants.PRIORITY_NORMAL);
    }

    public void setScript(Target target, Script script, int priority) {
        setScript(target, script.getHeader(), "{" + script.getBody() + "}", priority);
    }

}
