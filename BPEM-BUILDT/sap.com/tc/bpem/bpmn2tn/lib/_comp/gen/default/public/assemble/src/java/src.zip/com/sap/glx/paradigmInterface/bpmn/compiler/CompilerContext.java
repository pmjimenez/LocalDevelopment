package com.sap.glx.paradigmInterface.bpmn.compiler;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

import com.sap.glx.ide.model.classes.SimpleType;
import com.sap.glx.ide.model.classes.SimpleTypesEnum;
import com.sap.glx.ide.model.galaxy.core.ModelElement;
import com.sap.glx.ide.model.galaxy.task.Task;
import com.sap.glx.ide.model.galaxy.workflow.Collaboration;
import com.sap.glx.ide.model.galaxy.workflow.MessageFlowObject;
import com.sap.glx.ide.model.galaxy.workflow.Pool;
import com.sap.glx.ide.model.galaxy.workflow.PrincipalPropagationBehaviorEnum;
import com.sap.glx.ide.model.galaxy.workflow.Scope;
import com.sap.glx.ide.model.triggernet.Subnet;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.ClassFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.ClusterNodeFilterFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.ConfigurationFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.ConstantFilterFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.DBCorrelationFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.ExecutionFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.JoinFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.LockFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.ModificationsComparatorFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.ParameterFilterFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.SourceFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.SwitchFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.SwizzleFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.TargetFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ClassHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ContextHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.DependencyHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.IdentifierHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.MappingHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ValidationHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.VersioningHelper;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost;
import com.sap.glx.paradigmInterface.facades.ITriggernetFacade;
import com.sap.glx.paradigmInterface.facades.TriggernetModelException;
import com.sap.mapping.base.compiler.IMappingCompiler;
import com.sap.mapping.base.compiler.MappingCompiler;
import com.sap.tc.buildplugin.BuildSessionManager;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.pp.api.IDCProperty;
import com.sap.tc.buildplugin.pp.api.IDCProperty.Attribute;
import com.sap.tc.moin.repository.Connection;
import com.sap.tc.moin.repository.Partitionable;

/**
 * The compiler context used by the BPMN2TN compiler. It holds all available factories that can and need to be used to generate nodes in the
 * target trigger network as well as the source model representation. Apart from that the context also provides a reference to the
 * compiler's state ( {@link CompilerContext}), which holds the non-static compiler state that changes during the compilation process.
 * 
 * @author Thilo-Alexander Ginkel
 * @author Philipp Sommer
 * 
 * @version $Id:
 *          //bpem/bpem.bp/nwed003_stream/src/SCs/sap.com/BPEM-BUILDT/DCs/sap.com/tc/bpem/bpmn2tn/lib/_comp/src/com/sap/glx/paradigmInterface
 *          /bpmn/compiler/CompilerContext.java#5 $
 */
public class CompilerContext {

    private static final String SUNBEAM_JVM_SWITCH = "com.sap.glx.compiler.sunbeam.correlation.disabled";
    private static final String ITF_DECOUPLING = "itf_decoupling";
    private static final String GALAXY = "galaxy";
    private static final String SUNBEAM_CONDITIONAL_START_DC_SWITCH_ATTRIBUTE_NAME = "compileConditionalStartWithoutSunbeam";

    private final IBuilderHost host;

    private final ClassHelper replicator;
    private final MappingHelper mappingHelper;
    private final DependencyHelper dependencyHelper;
    private final IdentifierHelper identifierHelper;
    private final VersioningHelper versioningHelper;
    private final ContextHelper contextHelper;
    private final ValidationHelper validator;

    private final ClassFactory classFactory;
    private final ConfigurationFactory configFactory;
    private final JoinFactory joinFactory;
    private final ConstantFilterFactory constantFilterFactory;
    private final ParameterFilterFactory parameterFilterFactory;
    private final TargetFactory targetFactory;
    private final ExecutionFactory executionFactory;
    private final SourceFactory sourceFactory;
    private final SwitchFactory switchFactory;
    private final SwizzleFactory swizzleFactory;
    private final LockFactory lockFactory;
    private final ModificationsComparatorFactory modificationFactory;
    private final DBCorrelationFactory dbCorrelationFactory;
    private final ClusterNodeFilterFactory clusterNodeFilterFactory;
    private final boolean useITFDecoupling;

    private final CompilerState compilerState;
    private final Scope rootScope;
    private final Connection connection;

    private final IMappingCompiler yves = MappingCompiler.INSTANCE;

    private final Map<Class<? extends MessageFlowObject>, LinkedHashSet<MessageFlowObject>> artifacts = new HashMap<Class<? extends MessageFlowObject>, LinkedHashSet<MessageFlowObject>>();

    private final SimpleTypes simpleTypes;

    public class SimpleTypes {
        public final SimpleType INTEGER;
        public final SimpleType LONG;
        public final SimpleType STRING;
        public final SimpleType FLOAT;
        public final SimpleType DOUBLE;
        public final SimpleType BOOLEAN;
        public final SimpleType IDENTITY;
        public final SimpleType STREAM;
        public final SimpleType PARASITE;
        public final SimpleType REFERENCE;
        public final SimpleType SDO;
        public final SimpleType VOID = null;
        public final SimpleType ANY = null;

        private SimpleTypes(final ITriggernetFacade triggernetFacade) throws BPMNCompilerException {
            try {
                BOOLEAN = triggernetFacade.getSimpleType(SimpleTypesEnum.BOOLEAN);
                DOUBLE = triggernetFacade.getSimpleType(SimpleTypesEnum.DOUBLE);
                FLOAT = triggernetFacade.getSimpleType(SimpleTypesEnum.FLOAT);
                IDENTITY = triggernetFacade.getSimpleType(SimpleTypesEnum.IDENTITY);
                INTEGER = triggernetFacade.getSimpleType(SimpleTypesEnum.INTEGER);
                LONG = triggernetFacade.getSimpleType(SimpleTypesEnum.LONG);
                STRING = triggernetFacade.getSimpleType(SimpleTypesEnum.STRING);
                STREAM = triggernetFacade.getSimpleType(SimpleTypesEnum.STREAM);
                PARASITE = triggernetFacade.getSimpleType(SimpleTypesEnum.PARASITE);
                REFERENCE = triggernetFacade.getSimpleType(SimpleTypesEnum.REFERENCE);
                SDO = triggernetFacade.getSimpleType(SimpleTypesEnum.SDO);
            } catch (final TriggernetModelException e) {
                throw new BPMNCompilerException("Cannot access atomic types in the target trigger network.", e); //$NON-NLS-1$
            }
        }
    }

    protected CompilerContext(final ITriggernetFacade triggernetFacade, final Scope scope, final Subnet subnet, final DependencyHelper dependencies,
            final IBuilderHost host) throws BPMNCompilerException {
        this.host = host;
        this.dependencyHelper = dependencies;
        this.rootScope = scope;
        this.connection = ((Partitionable) scope).get___Connection();
        this.simpleTypes = new SimpleTypes(triggernetFacade);
        this.contextHelper = new ContextHelper();
        this.versioningHelper = new VersioningHelper();
        this.validator = new ValidationHelper(scope, host.getWarnable());

        this.compilerState = new CompilerState(this);

        this.classFactory = new ClassFactory(subnet, versioningHelper);
        this.configFactory = new ConfigurationFactory(subnet, this);
        this.joinFactory = new JoinFactory(triggernetFacade, subnet);
        this.constantFilterFactory = new ConstantFilterFactory(triggernetFacade, subnet, this);
        this.parameterFilterFactory = new ParameterFilterFactory(triggernetFacade, subnet);
        this.targetFactory = new TargetFactory(triggernetFacade, subnet, this);
        this.executionFactory = new ExecutionFactory(triggernetFacade, subnet, this);
        this.sourceFactory = new SourceFactory(triggernetFacade, subnet);
        this.switchFactory = new SwitchFactory(triggernetFacade, subnet);
        this.swizzleFactory = new SwizzleFactory(triggernetFacade, subnet);
        this.lockFactory = new LockFactory(triggernetFacade, subnet);
        this.modificationFactory = new ModificationsComparatorFactory(triggernetFacade, subnet);
        this.dbCorrelationFactory = new DBCorrelationFactory(this, triggernetFacade, subnet);
        this.clusterNodeFilterFactory = new ClusterNodeFilterFactory(triggernetFacade, subnet);

        this.replicator = new ClassHelper(this);
        this.identifierHelper = new IdentifierHelper();
        this.mappingHelper = new MappingHelper(this);

        this.compilerState.initialize();
        this.useITFDecoupling = retrieveUseITF_DecouplingPropertyValue();
    }

    /**
     * Determines whether this is a pool or task and returns the collaboration or task entity.
     * 
     * @return a Collaboration or Task entity.
     */
    public ModelElement getTopLevelEntity() {
        if (rootScope instanceof Pool) {
            return ((Pool) rootScope).getCollaboration();
        } else {
            return rootScope;
        }
    }

    public boolean isTaskFlow() {
        return rootScope instanceof Task;
    }

    public boolean isPrincipalPropagationActive() {
        if (getTopLevelEntity() instanceof Collaboration) {
            final Collaboration collaboration = (Collaboration) getTopLevelEntity();
            return (collaboration.getPrincipalPropagationBehavior() == PrincipalPropagationBehaviorEnum.NONE) ? false : true;
        }
        return false;
    }

    public boolean isMicrobusEnabled() {
        final String DC_VENDOR = "sap.com";
        final String DC_NAME = "tc/bi/mctech";
        return !host.isDependencyAvailable(DC_VENDOR, DC_NAME, IBuilderHost.DEP_TYPES.BUILDTIME);
    }

    public IBuilderHost getHost() {
        return host;
    }

    public ClassHelper getReplicator() {
        return replicator;
    }

    public VersioningHelper getVersioningHelper() {
        return versioningHelper;
    }

    public DependencyHelper getDependencyHelper() {
        return dependencyHelper;
    }

    public MappingHelper getMappingHelper() {
        return mappingHelper;
    }

    public Map<Class<? extends MessageFlowObject>, LinkedHashSet<MessageFlowObject>> getArtifacts() {
        return artifacts;
    }

    @SuppressWarnings("unchecked")
    public <T extends MessageFlowObject> LinkedHashSet<T> getArtifacts(final Class<T> clazz) {
        return (LinkedHashSet<T>) artifacts.get(clazz);
    }

    public ValidationHelper getValidator() {
        return validator;
    }

    public ConfigurationFactory getConfigFactory() {
        return configFactory;
    }

    public JoinFactory getJoinFactory() {
        return joinFactory;
    }

    public ClassFactory getClassFactory() {
        return classFactory;
    }

    public ConstantFilterFactory getConstantFilterFactory() {
        return constantFilterFactory;
    }

    public ParameterFilterFactory getParameterFilterFactory() {
        return parameterFilterFactory;
    }

    public TargetFactory getTargetFactory() {
        return targetFactory;
    }

    public ExecutionFactory getExecutionFactory() {
        return executionFactory;
    }

    public SourceFactory getSourceFactory() {
        return sourceFactory;
    }

    public SwitchFactory getSwitchFactory() {
        return switchFactory;
    }

    public SwizzleFactory getSwizzleFactory() {
        return swizzleFactory;
    }

    public LockFactory getLockFactory() {
        return lockFactory;
    }

    public ModificationsComparatorFactory getModificationsComparatorFactory() {
        return modificationFactory;
    }

    public DBCorrelationFactory getDBCorrelationFactory() {
        return dbCorrelationFactory;
    }

    public ClusterNodeFilterFactory getClusterNodeFilterFactory() {
        return clusterNodeFilterFactory;
    }

    public CompilerState getState() {
        return compilerState;
    }

    public Scope getRootScope() {
        return rootScope;
    }

    public IMappingCompiler getMappingCompiler() {
        return yves;
    }

    public ContextHelper getContextHelper() {
        return contextHelper;
    }

    public SimpleTypes getSimpleTypes() {
        return simpleTypes;
    }

    public IdentifierHelper getIdentifierHelper() {
        return identifierHelper;
    }

    public Connection getConnection() {
        return connection;
    }

    /**
     * The sunbeam compiler switch. When this method returns <b>true</b>, use the Sunbeam trigger net fragments, otherwise the common
     * trigger net fragments.
     * 
     * @return
     * 
     *         <tt>false<tt/> when variable com.sap.glx.compiler.sunbeam.correlation.disabled is set to true in the SapNetweaverDeveloperStudio.ini file 
	 *         <tt>true<tt/> otherwise
     */
    public boolean useSunbeamNonConditionalStart() {
        if (Boolean.getBoolean(SUNBEAM_JVM_SWITCH)) {
            return false;
        }
        return !getState().isSharedStart();
    }

    public boolean useLegacyConditionalStart() {
        final boolean sunbeamConditionalStartIsDisabledOnDCLevel = retrieveBooleanPropertyValue(SUNBEAM_CONDITIONAL_START_DC_SWITCH_ATTRIBUTE_NAME,
                GALAXY, false);
        return getState().isSharedStart() && sunbeamConditionalStartIsDisabledOnDCLevel;
    }

    public boolean useSunbeamConditionalStart() {
        final boolean sunbeamConditionalStartIsDisabledOnDCLevel = retrieveBooleanPropertyValue(SUNBEAM_CONDITIONAL_START_DC_SWITCH_ATTRIBUTE_NAME,
                GALAXY, false);
        return getState().isSharedStart() && !sunbeamConditionalStartIsDisabledOnDCLevel;
    }

    /*
     * Try to read the DC Property for ITF compiler switch
     */
    private boolean retrieveUseITF_DecouplingPropertyValue() {
        return retrieveBooleanPropertyValue(ITF_DECOUPLING, GALAXY, true);
    }

    /**
     * Retrieves the value of a DC property. If no DC property for the given {@code attributeName} and {@code dcPropertyName} is found, the
     * {@code defaultValue} will be returned.
     */
    private boolean retrieveBooleanPropertyValue(final String attributeName, final String dcPropertyName, final boolean defaultValue) {
        final IPluginBuildInfo pbi = (IPluginBuildInfo) BuildSessionManager.getFromBuildSession(IPluginBuildInfo.class.getName());
        for (final IDCProperty dcProperty : pbi.getCurrentDevelopmentComponent().getProperties()) {
            if (dcProperty.getName().equalsIgnoreCase(dcPropertyName)) {
                List<Attribute> attributes = dcProperty.getAttributes();
                for (Attribute attribute : attributes) {
                    if (attribute.getName().equalsIgnoreCase(attributeName)) {
                        return Boolean.valueOf(dcProperty.getAttributeValue(attributeName));
                    }
                }
            }
        }
        return defaultValue;
    }

    /**
     * The ITF Decoupling compiler switch. When this method returns <b>true</b>, the trigger net fragments for decoupled ITF will be used.
     * 
     * @return true if the switch is on.
     */
    public boolean useITF_Decoupling() {
        return useITFDecoupling;
    }
}
