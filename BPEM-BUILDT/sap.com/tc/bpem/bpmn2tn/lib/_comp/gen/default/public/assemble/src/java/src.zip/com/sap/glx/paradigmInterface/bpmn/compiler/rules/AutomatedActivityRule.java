package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;

import javax.xml.namespace.QName;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.workflow.AutomatedActivity;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.Pool;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.Swizzle;
import com.sap.glx.ide.model.triggernet.Target;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.Triple;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.SDOHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.WSDLHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.eventlog.EventLogHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.eventlog.EventTypeIds;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.ProjectionNode;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.AdvancedScript;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.IntegerLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptName;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptVariable;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.StringLiteral;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.ide.es.config.mc.model.mc.servicereferences.ServiceReference;
import com.sap.mapping.base.compiler.IMappingCompiler;
import com.sap.tc.esmp.mm.wsdl2.Interface;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;

/**
 * A compiler rule for automated activity artifacts.
 * 
 * @author Sören Balko
 * @author Thilo-Alexander Ginkel
 * @version $Id:
 *          //bpem/bpem.tools/dev/src/_com.sap.glx.bpmn2tn/java/com/sap/glx/paradigmInterface/bpmn/compiler/rules/AutomatedActivityRule.
 *          java#6 $
 */
public class AutomatedActivityRule extends BaseCompilerRule<com.sap.glx.ide.model.galaxy.workflow.AutomatedActivity> implements
        CompilerRule<com.sap.glx.ide.model.galaxy.workflow.AutomatedActivity> {

    private static final String XI_CONNECTIVITY_TYPE = "XI";
    private static final String XI_DESTINATION_NODE_IMPL = "com.sap.glx.core.kernel.trigger.node.ExternalTransactionDestinationNode";

    /*
     * @see com.sap.glx.paradigmInterface.bpmn.compiler.rules.CompilerRule#getSupportedArtifact()
     */
    public Class<AutomatedActivity> getSupportedArtifact() {
        return AutomatedActivity.class;
    }

    public void compile(AutomatedActivity activity, CompilerContext ctx) throws BPMNCompilerException {
        ctx.getValidator().validateConnectors(activity, 1, 1);

        ctx.getValidator().validate(activity.getLogicalDestination() != null || activity.getServiceReference() != null,
                "BPM.rt_c_bpmn.000016", "Service reference or logical destination of automated activity '%s' must be set.", //$NON-NLS-1$ //$NON-NLS-2$
                activity.getOriginalName());
        ctx.getValidator().validateOperation(activity, activity.getOperation());

        // generate call class + config
        GalaxyClass call_class = ctx.getReplicator().generateCallClass(activity);
        ctx.getConfigFactory().generateCallConfiguration(ctx, call_class, activity);

        // compile the mappings
        Pair<IMappingCompiler.Summary, String> input_mapping = ctx.getMappingHelper().compile(activity.getInputMapping());
        Pair<IMappingCompiler.Summary, String> output_mapping = ctx.getMappingHelper().compile(activity.getOutputMapping());

        Pair<Set<DataContainer>, Set<DataContainer>> input_context = identifyInOutDataObjects(ctx, input_mapping.first, Direction.IN);
        Pair<Set<DataContainer>, Set<DataContainer>> output_context = identifyInOutDataObjects(ctx, output_mapping.first, Direction.INOUT);

        @SuppressWarnings("unchecked")
        Set<DataContainer> used_context = union(input_context.first, input_context.second, output_context.first, output_context.second);

        // add depending views and their dependencies to script header (for optimized view update)
        SortedSet<DataContainer> allViewDependencies = ctx.getState().getAllViewDependencies(output_context.second);
        used_context.addAll(allViewDependencies);

        // create transitions
        Target target = generateAutomatedActivityTransition(ctx, activity, input_context.first, input_context.second, output_context.first,
                output_context.second, used_context, input_mapping.second, output_mapping.second, call_class);

        int stateInTokenSwitch = ctx.getState().getBeforeTokenSwitchExit(activity);

        if (used_context.isEmpty()) {
            NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), stateInTokenSwitch, target, 0);
        } else {
            ProjectionNode projectionSwizzle = buildContextProjectionNode(ctx, activity.getScope(), activity, null, used_context);
            if (ctx.getRootScope().equals(activity.getScope())) {
                // is root scope, projection only contains data objects
                // instance=do.owner
                Join context_join = ctx.getJoinFactory().generateJoin(activity, "context_join", "0/1/-1", "1/0/0");
                NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), stateInTokenSwitch, context_join, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, context_join, 1);
                NodeFactory.connectNodes(context_join, 0, target, 0);
            } else {
                // is in embedded scope, projection contains frame object as first element
                // token.frame=frame
                Join context_join = ctx.getJoinFactory().generateJoin(activity, "context_join", "0/0/2", "1/0/-1");
                NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), stateInTokenSwitch, context_join, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, context_join, 1);
                // for the target node the frame has to be removed now
                List<Integer> usedIndexes = new ArrayList<Integer>();
                // token and instance
                usedIndexes.add(0);
                usedIndexes.add(1);
                // ignore frame
                int runningIndex = 3;
                // data objects
                for (int i = 1; i <= projectionSwizzle.getLastIndex(); i++) {
                    usedIndexes.add(runningIndex++);
                }
                Swizzle noFrameSwizzle = ctx.getSwizzleFactory().generateSwizzle(activity, "context_no_frame_projection",
                        usedIndexes.toArray(new Integer[usedIndexes.size()]));
                NodeFactory.connectNodes(context_join, 0, noFrameSwizzle, 0);
                NodeFactory.connectNodes(noFrameSwizzle, 0, target, 0);
            }
        }
    }

    private Target generateAutomatedActivityTransition(CompilerContext ctx, AutomatedActivity activity,
            Set<DataContainer> input_context_in, Set<DataContainer> input_context_out, Set<DataContainer> output_context_in,
            Set<DataContainer> output_context_out, Set<DataContainer> used_context, String input_mapping_id, String output_mapping_id,
            GalaxyClass call_class) throws BPMNCompilerException {

        AdvancedScript script = new AdvancedScript(ctx, ScriptName.AUTOMATED_ACTIVITY, activity);
        ScriptVariable varToken = script.addParameter(ScriptVariable.TOKEN, ctx.getState().getTokenClass());
        ScriptVariable varInstance = script.addParameter(ScriptVariable.INSTANCE, ctx.getState().getInstanceClass());
        List<ScriptVariable> varContext = new ArrayList<ScriptVariable>(used_context.size());
        for (DataContainer container : used_context) {
            varContext.add(script.addParameter(ctx.getState().getContextVariable(container), ctx.getContextHelper().getClassByDataObject(
                    container)));
        }

        script.generateDebugCode(varInstance, varToken);
        script.generateScopeCode(varToken);

        // type scope instantiation
        String scopeId = ctx.getHost().getVersionId(ctx.getDependencyHelper().getScope(activity.getOperation()), CompilerType.TYPECOMPILER);
        GalaxyClass clsScope = ctx.getDependencyHelper().getScopeClassOld(ctx.getDependencyHelper().getScope(activity.getOperation()));
        ScriptVariable varCallscope = script.generateNewCommand(ScriptVariable.CALLSCOPE, clsScope, varInstance);

        // create service call object and set the principal
        ScriptVariable varCall = script.generateNewCommand(ScriptVariable.CALL, call_class, varCallscope);
        if (ctx.isPrincipalPropagationActive()) {
            ScriptVariable varPPUser = script.generateAssignCommand(ScriptVariable.PP_USERNAME, varToken,
                    CompilerConstants.ATTRIBUTE_PP_USERNAME);
            ScriptVariable varPPHash = script.generateAssignCommand(ScriptVariable.PP_HASH, varToken, CompilerConstants.ATTRIBUTE_PP_HASH);
            script.generateInvocationCommand(varCall, "setPrincipal", varPPHash, varPPUser, varToken);
        }

        ScriptVariable msgId = script.generateAssignCommand(ScriptVariable.MESSAGE_ID, varCall, "messageId");

        ServiceReference serviceReference = activity.getServiceReference();
        boolean isXIConnectivity = serviceReference != null ? XI_CONNECTIVITY_TYPE.equals(serviceReference.getBindingType()) : false;

        // write event log entry for automated activity started
        if (isXIConnectivity) {
            /* OCL constraint 'AutomatedActivityOperation' assures that activity.getOperation() != null */
            validateInterface(activity.getOperation().getServiceInterface());
            EventLogHelper.addEventWithMsgContext(script, ctx.getState().getEventLoggerClass(), EventTypeIds.SERVICE_TASK_STARTED,
                    ((Pool) ctx.getRootScope()).refMofId(), varInstance, activity.refMofId(), msgId, msgId, activity.getOperation()
                            .getServiceInterface().getNamespace(), activity.getOperation().getServiceInterface().getName());
        } else {
            EventLogHelper.addEvent(script, ctx.getState().getEventLoggerClass(), EventTypeIds.SERVICE_TASK_STARTED, ((Pool) ctx
                    .getRootScope()).refMofId(), varInstance, activity.refMofId(), msgId);
        }

        // create the request for the service call
        XsdElementDeclaration request = WSDLHelper.getRequestElement(activity.getOperation());
        QName requestName = SDOHelper.generateSDOName(request);
        QName requestType = SDOHelper.generateSDOName(WSDLHelper.getElementType(request));
        ScriptVariable varRequest = script.generateInvocationCommand(ScriptVariable.REQUEST, varCallscope, "instantiate",
                new StringLiteral(requestType.getNamespaceURI()), new StringLiteral(requestType.getLocalPart()));
        script.generateMappingCode(input_mapping_id, input_context_in, input_context_out, null,
                new Triple<ScriptVariable, XsdElementDeclaration, String>(varRequest, request, scopeId));
        script.generateInvocationCommand(varCall, "setInputData", new StringLiteral(requestName.getNamespaceURI()), new StringLiteral(
                requestName.getLocalPart()), varRequest);

        XsdElementDeclaration response = WSDLHelper.getResponseElement(activity.getOperation());
        if (response != null) {
            // create the response for the service call
            QName responseName = SDOHelper.generateSDOName(response);
            QName responseType = SDOHelper.generateSDOName(WSDLHelper.getElementType(response));
            ScriptVariable varResponse = script.generateInvocationCommand(ScriptVariable.RESPONSE, varCallscope, "instantiate",
                    new StringLiteral(responseType.getNamespaceURI()), new StringLiteral(responseType.getLocalPart()));
            script.generateInvocationCommand(varCall, "setOutputData", new StringLiteral(responseName.getNamespaceURI()),
                    new StringLiteral(responseName.getLocalPart()), varResponse);

            // invoke the service and do the output mapping
            script.generateInvocationCommand(varCall, "invoke");
            varResponse = script.generateInvocationCommand(varResponse, varCall, "getOutputData", new StringLiteral(responseName
                    .getNamespaceURI()), new StringLiteral(responseName.getLocalPart()));
            script.generateMappingCode(output_mapping_id, output_context_in, output_context_out,
                    new Triple<ScriptVariable, XsdElementDeclaration, String>(varResponse, response, scopeId), null);
        } else {
            // invoke the service and do the output mapping
            script.generateInvocationCommand(varCall, "invoke");
            script.generateMappingCode(output_mapping_id, output_context_in, output_context_out, null, null);
        }

        // write event log entry for automated activity completed
        if (isXIConnectivity) {
            EventLogHelper.addEventWithMsgContext(script, ctx.getState().getEventLoggerClass(), EventTypeIds.SERVICE_TASK_COMPLETED,
                    ((Pool) ctx.getRootScope()).refMofId(), varInstance, activity.refMofId(), msgId, msgId, activity.getOperation()
                            .getServiceInterface().getNamespace(), activity.getOperation().getServiceInterface().getName());
        } else {
            EventLogHelper.addEvent(script, ctx.getState().getEventLoggerClass(), EventTypeIds.SERVICE_TASK_COMPLETED, ((Pool) ctx
                    .getRootScope()).refMofId(), varInstance, activity.refMofId(), msgId);
        }

        script.generateDeleteCommand(varCall);
        script.generateDeleteCommand(varCallscope);
        int nextState = ctx.getState().getAfterTokenLabel(activity);
        script.generateUpdateCommand(varToken, "state", new IntegerLiteral(nextState));

        if (isXIConnectivity && !WSDLHelper.isSynchronous(activity.getOperation())) {
            return script.getTarget(XI_DESTINATION_NODE_IMPL);
        } else {
            return script.getTarget();
        }
    }

    private void validateInterface(Interface serviceInterface) throws BPMNCompilerException {
        if (serviceInterface == null || serviceInterface.getNamespace() == null || serviceInterface.getName() == null) {
            new BPMNCompilerException("BPM.rt_c_bpmn.00086", "Service interface must be set"); //$NON-NLS-1$ //$NON-NLS-2$
        }
    }
}
