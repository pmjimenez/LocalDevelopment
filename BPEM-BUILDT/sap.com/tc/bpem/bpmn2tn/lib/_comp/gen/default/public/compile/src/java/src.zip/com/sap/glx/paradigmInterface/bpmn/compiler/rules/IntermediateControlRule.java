package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;

import com.sap.glx.ide.model.classes.Attribute;
import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.rule.Expression;
import com.sap.glx.ide.model.galaxy.rule.FunctionInvocation;
import com.sap.glx.ide.model.galaxy.rule.Literal;
import com.sap.glx.ide.model.galaxy.rule.Reference;
import com.sap.glx.ide.model.galaxy.rule.Step;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.IntermediateCatchEvent;
import com.sap.glx.ide.model.galaxy.workflow.MessageEventDefinition;
import com.sap.glx.ide.model.triggernet.ConstantFilter;
import com.sap.glx.ide.model.triggernet.GenericOperator;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.Node;
import com.sap.glx.ide.model.triggernet.Source;
import com.sap.glx.ide.model.triggernet.Swizzle;
import com.sap.glx.ide.model.triggernet.Target;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.Triple;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.ClassFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.NormalizationHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.OperationHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.SDOHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ScriptHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.VersioningHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.WSDLHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.IntegerLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.NullLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.StringLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.Variable;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.ProjectionNode;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.mapping.base.compiler.IMappingCompiler;
import com.sap.tc.esmp.mm.wsdl2.Operation;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;

/**
 * A compiler rule for intermediate catch events with a message trigger.
 * 
 * @author Sören Balko
 * @author Thilo-Alexander Ginkel
 * @author Philipp Sommer
 * @version $Id:
 *          //bpem/bpem.tools/dev/src/_com.sap.glx.bpmn2tn/java/com/sap/glx/paradigmInterface/bpmn/compiler/rules/IntermediateControlRule
 *          .java#11 $
 */
public class IntermediateControlRule extends CatchEventMessageRule<IntermediateCatchEvent> implements CompilerRule<IntermediateCatchEvent> {

    private static final String NS_XSD = "http://www.w3.org/2001/XMLSchema";
    private final Map<String, GenericOperator> joinNodes = new HashMap<String, GenericOperator>();
    private final Map<String, GenericOperator> lockNodes = new HashMap<String, GenericOperator>();

    // used only for tasks
    protected Join event_cleanup_join = null;

    public Class<IntermediateCatchEvent> getSupportedArtifact() {
        throw new IllegalStateException("Should be never called. Creation through dispather rule.");
    }

    protected String generateTaskEventScriptHeader(final CompilerContext ctx, final IntermediateCatchEvent intermediate_control) {
        final StringBuilder sb = new StringBuilder(ScriptHelper.generateHeaderPrefix(ctx.getRootScope(),
                CompilerConstants.TARGET_CREATE_TASK_EVENT, intermediate_control));
        sb.append(ScriptHelper.generateClassDeclaration(ctx.getState().getTaskSource().getGalaxyClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_TASK)));
        sb.append(") ");
        return sb.toString();
    }

    protected String generateTaskEventScriptBody(final CompilerContext ctx, final IntermediateCatchEvent intermediate_control,
            final GalaxyClass event_class, final GenericOperator target) {
        final StringBuilder sb = new StringBuilder(ScriptHelper.generateBodyPrefix(ctx.getState().getExitClass(),
                CompilerConstants.BITMASK_NO_CALLBACK, intermediate_control, target, new Variable(CompilerConstants.SCRIPT_VARIABLE_TASK)));

        // parent=task:owner;
        sb.append(ScriptHelper.generateAssignCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_TASK), CompilerConstants.ATTRIBUTE_OWNER));

        // scoping code
        sb.append(ScriptHelper.generateScopeCode(ctx.getState().getControllerClass(),
                new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));

        // new Event(task,parent);
        sb.append(ScriptHelper.generateNewCommand(null, event_class, new Variable(CompilerConstants.SCRIPT_VARIABLE_TASK),
                NullLiteral.NULL, NullLiteral.NULL, new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));

        sb.append("}");
        return sb.toString();
    }

    protected String generateConsumeTaskEventScriptHeader(final IntermediateCatchEvent intermediate_control, final GalaxyClass event_class,
            final GalaxyClass subscription_class, final Collection<DataContainer> used_context, final CompilerContext ctx) {
        final StringBuilder sb = new StringBuilder(ScriptHelper.generateHeaderPrefix(ctx.getRootScope(),
                CompilerConstants.TARGET_CONSUME_TASK_EVENT, intermediate_control));
        sb.append(ScriptHelper.generateClassDeclaration(event_class, new Variable(CompilerConstants.SCRIPT_VARIABLE_EVENT)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(subscription_class, new Variable(CompilerConstants.SCRIPT_VARIABLE_SUBSCRIPTION)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(ctx.getState().getTokenClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_TOKEN)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(ctx.getState().getInstanceSource().getGalaxyClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_PARENT)));

        for (final DataContainer container : used_context) {
            sb.append(", ");
            sb.append(ScriptHelper.generateClassDeclaration(ctx.getContextHelper().getClassByDataObject(container), new Variable(ctx
                    .getState().getContextVariableName(container))));
        }
        sb.append(") ");
        return sb.toString();
    }

    protected String generateConsumeTaskEventScriptBody(final IntermediateCatchEvent intermediate_control, final GalaxyClass event_class,
            final GalaxyClass subscription_class, final String mapping_id, final Set<DataContainer> used_context,
            final Set<DataContainer> context_in, final Set<DataContainer> context_out, final Target target, final CompilerContext ctx)
            throws BPMNCompilerException {
        final List<Variable> parameters = new ArrayList<Variable>(used_context.size() + 4);
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_EVENT));
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_SUBSCRIPTION));
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN));
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT));
        for (final DataContainer container : used_context) {
            parameters.add(new Variable(ctx.getState().getContextVariableName(container)));
        }

        final StringBuilder sb = new StringBuilder(ScriptHelper.generateBodyPrefix(ctx.getState().getExitClass(),
                CompilerConstants.BITMASK_ON_ACTIVATION, intermediate_control, target, parameters));

        // scope code
        sb.append(ScriptHelper
                .generateScopeCode(ctx.getState().getControllerClass(), new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN)));

        // delete event;
        sb.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_EVENT)));

        // token:state=<next>;
        sb.append(ScriptHelper.generateUpdateCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN), "state", new IntegerLiteral(ctx
                .getState().getAfterTokenLabel(intermediate_control))));

        // mapping
        sb.append(ScriptHelper.generateMappingCode(ctx, mapping_id, context_in, context_out, null, null));

        sb.append("}");
        return sb.toString();
    }

    protected Pair<Integer, String> generateFilterConfiguration(final IntermediateCatchEvent intermediate_control,
            final FunctionInvocation invocation, final CompilerContext ctx) throws BPMNCompilerException {
        Integer taskStatusIndex = null;
        String taskStatusValue = null;

        final String namespace = NormalizationHelper.getEqualalityComparison(invocation.getFunctionInterface());
        if (namespace == null || invocation.getParameterMapping().getActiveMappingParts().size() != 2) {
            throw ctx.getValidator().error("BPM.rt_c_bpmn.000032",
                    "Intra-task correlation condition of event '%s' is invalid. It does not have a valid comparison operator.",
                    intermediate_control.getOriginalName());
        }

        for (int i = 0; i < invocation.getParameterMapping().getActiveMappingParts().size(); i++) {
            final Expression expression = invocation.getParameterMapping().getActiveMappingParts().get(i).getExpression();
            if (i == 0) { // expression that points to TaskStatus/xyz
                if (expression.getSteps().size() == 2) {
                    if (expression.getSteps().get(0) instanceof Reference
                            && ((Reference) expression.getSteps().get(0)).getXsdFeature().getName().equals(
                                    CompilerConstants.SONDERLOCKE_TASKSTATUS)) {
                        if (expression.getSteps().get(1) instanceof Reference) {
                            final Reference reference = (Reference) expression.getSteps().get(1);
                            taskStatusIndex = ClassFactory.getAttributeIndex(ctx.getState().getTaskSource().getGalaxyClass(), SDOHelper
                                    .generateSDOName(reference.getXsdFeature()).getLocalPart());
                            if (taskStatusIndex == -1) {
                                throw ctx
                                        .getValidator()
                                        .error(
                                                "BPM.rt_c_bpmn.000033",
                                                "Intra-task correlation condition of event '%s' is invalid. It contains an unknown attribute '%s'.",
                                                intermediate_control.getOriginalName(), reference.getXsdFeature().getName());
                            }
                        } else {
                            throw ctx
                                    .getValidator()
                                    .error(
                                            "BPM.rt_c_bpmn.000034",
                                            "Intra-task correlation condition of event '%s' is invalid. It has no reference to a XSD element as second step.",
                                            intermediate_control.getOriginalName());
                        }
                    } else {
                        throw ctx
                                .getValidator()
                                .error(
                                        "BPM.rt_c_bpmn.000035",
                                        "Intra-task correlation condition of event '%s' is invalid. It does reference the task status as a first step.",
                                        intermediate_control.getOriginalName());
                    }
                } else {
                    throw ctx
                            .getValidator()
                            .error(
                                    "BPM.rt_c_bpmn.000036",
                                    "Intra-task correlation condition of event '%s' is invalid. It does not reference a direct child of the task status.",
                                    intermediate_control.getOriginalName());
                }
            } else { // expression that points to the literal
                if (expression.getSteps().size() == 1 && expression.getSteps().get(0) instanceof Literal) {
                    final Literal literal = (Literal) expression.getSteps().get(0);
                    if (NormalizationHelper.isFiniteIntegerEqualityComparison(invocation.getFunctionInterface())) {
                        if (literal.getSimpleDataType().getNamespace().equals(NS_XSD)
                                && (literal.getSimpleDataType().getName().equals("decimal"))) {
                            taskStatusValue = "INTEGER:" + Integer.valueOf(literal.getValue()).toString();
                        } else {
                            throw ctx
                                    .getValidator()
                                    .error(
                                            "BPM.rt_c_bpmn.000037",
                                            "Intra-task correlation condition of event '%s' is invalid. Integer comparison does does not compare decimals.",
                                            intermediate_control.getOriginalName());
                        }
                    } else if (NormalizationHelper.isBooleanEqualityComparison(invocation.getFunctionInterface())) {
                        if (literal.getSimpleDataType().getNamespace().equals(NS_XSD)
                                && (literal.getSimpleDataType().getName().equals("boolean"))) {
                            taskStatusValue = "BOOLEAN:" + Boolean.valueOf(literal.getValue()).toString();
                        } else {
                            throw ctx
                                    .getValidator()
                                    .error(
                                            "BPM.rt_c_bpmn.000038",
                                            "Intra-task correlation condition of event '%s' is invalid. Boolean comparison does does not compare booleans.",
                                            intermediate_control.getOriginalName());
                        }
                    } else if (literal.getSimpleDataType().getNamespace().equals(NS_XSD)
                            && (literal.getSimpleDataType().getName().equals("string"))) {
                        taskStatusValue = "STRING:" + literal.getValue().toString();
                    } else {
                        throw ctx
                                .getValidator()
                                .error(
                                        "BPM.rt_c_bpmn.000039",
                                        "Intra-task correlation condition of event '%s' is invalid. String comparison does does not compare strings.",
                                        intermediate_control.getOriginalName());
                    }
                } else {
                    throw ctx.getValidator().error("BPM.rt_c_bpmn.000040",
                            "Intra-task correlation condition of event '%s' is invalid. Second parameter must be a literal.",
                            intermediate_control.getOriginalName());
                }
            }
        }

        return new Pair<Integer, String>(taskStatusIndex, taskStatusValue);
    }

    protected ConstantFilter generateTaskStatusFilter(final IntermediateCatchEvent event, final CompilerContext ctx)
            throws BPMNCompilerException {
        final ConstantFilter taskStatusFilter = ctx.getConstantFilterFactory().generateFilter(event, "task_status");

        // validate the correlation expression of a local event
        final List<Step> steps = event.getExpression().getSteps();
        ctx.getValidator().validate(steps.size() == 2, "BPM.rt_c_bpmn.000041",
                "Intra-task correlation condition of event '%s' is invalid. It contains not exactly two steps.", event.getOriginalName());
        ctx.getValidator().validate(steps.get(0) instanceof FunctionInvocation, "BPM.rt_c_bpmn.000042",
                "Intra-task correlation condition of event '%s' is invalid. It does not contain a comparison function.",
                event.getOriginalName());
        ctx
                .getValidator()
                .validate(
                        steps.get(1) instanceof Reference,
                        "BPM.rt_c_bpmn.000043",
                        "Intra-task correlation condition of event '%s' is invalid. It does not contain descending reference to comparison result.",
                        event.getOriginalName());

        final FunctionInvocation invocation = (FunctionInvocation) steps.get(0);
        final Pair<Integer, String> config = generateFilterConfiguration(event, invocation, ctx);
        ctx.getConstantFilterFactory().addFilterTerm(taskStatusFilter, "0/0/" + config.first, config.second, "==");
        return taskStatusFilter;
    }

    @Override
    public void preprocess(final CompilerContext ctx) throws BPMNCompilerException {
        if (ctx.isTaskFlow()) {
            // task=event.owner
            event_cleanup_join = ctx.getJoinFactory().generateJoin(ctx.getTopLevelEntity(), "task_event_cleanup", "0/0/-1", "1/0/0");
            NodeFactory.connectNodes(ctx.getState().getTaskSource(), 0, event_cleanup_join, 0);
            NodeFactory.connectNodes(event_cleanup_join, 2, ctx.getReplicator().getBlackHole(), 0);
        } else {
            final Set<IntermediateCatchEvent> events = ctx.getArtifacts(IntermediateCatchEvent.class);
            for (final IntermediateCatchEvent event : events) {
                if (event.getTrigger() instanceof MessageEventDefinition) {

                    // get validated endpoint and compare it to the one of the start event
                    final Triple<String, String, Operation> endpoint = getEndpoint(ctx, event);
                    ctx.getValidator().validate(!WSDLHelper.isSynchronous(endpoint.third), "BPM.rt_c_bpmn.000044", //$NON-NLS-1$
                            "Synchronous operation is not allowed on intermediate message event '%s'.", event.getOriginalName()); //$NON-NLS-1$
                    ctx
                            .getValidator()
                            .validate(
                                    OperationHelper.isModelledEndpoint(event.getTrigger()),
                                    "BPM.rt_c_bpmn.000085", //$NON-NLS-1$
                                    "Intermediate message event '%s' must refer to an explicitly modeled message trigger.", event.getOriginalName());//$NON-NLS-1$

                    // create event and subscription class in case there is no existing one for the endpoint
                    GalaxyClass clsEvent = ctx.getState().getEvent(endpoint.second);
                    if (clsEvent == null) {
                        // create the event class
                        clsEvent = ctx.getReplicator().generateEventClass(event);

                        // delete event asynchronously as soon as there is no locking anymore
                        final Source eventSource = ctx.getSourceFactory().getSource4Class(clsEvent);
                        NodeFactory.connectNodes(eventSource, 0, ctx.getReplicator().getBlackHole(), 0);

                        // configuration of the event, the request classes and its generator rules for ppUsername and ppHash
                        configureEndpoint(ctx, event, clsEvent);

                        // subscription creation
                        final GalaxyClass clsSubscription = ctx.getReplicator().generateSubscriptionClass(event);
                        ctx.getState().addEventSubscription(endpoint.second, clsEvent, clsSubscription);

                        // triggernet fragment for request and event join
                        final Join requestEventJoin = generateRequestEventJoin(ctx, ctx.getState().getUCRequest(), eventSource,
                                endpoint.second, endpoint.third.getName());
                        final Source subscriptionSource = ctx.getSourceFactory().getSource4Class(clsSubscription);

                        // triggernet fragment for persistent join node
                        final String nodeId = VersioningHelper.computeVersion(endpoint.second);
                        final GenericOperator join = ctx.getDBCorrelationFactory().generateCorrelationJoin(clsSubscription, nodeId,
                                "correlation_join"); //$NON-NLS-1$
                        joinNodes.put(endpoint.second, join);
                        NodeFactory.connectNodes(requestEventJoin, 0, join, 0);
                        NodeFactory.connectNodes(subscriptionSource, 0, join, 1);
                        if (isShared(ctx, event)) {
                            ctx.getState().setSharedPersistentJoin(join);
                        }

                        // triggernet fragment for match lock node
                        final GenericOperator lock = ctx.getLockFactory().generateLock(clsEvent, "correlation_lock", 2); //$NON-NLS-1$
                        lockNodes.put(endpoint.second, lock);
                        NodeFactory.connectNodes(join, 0, lock, 0);

                    } else {
                        ctx.getConfigFactory().generateEventConfigurationAddition(clsEvent, event);
                    }
                }
            }
        }
    }

    /*
     * @see com.sap.glx.paradigmInterface.bpmn.compiler.rules.CompilerRule#compile(com.sap.glx.ide.model.galaxy.core.ModelElement,
     * com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext)
     */
    public void compile(final IntermediateCatchEvent event, final CompilerContext ctx) throws BPMNCompilerException {
        ctx.getValidator().validateConnectors(event, 1, 1);
        ctx.getValidator().validate(event.getScope() == ctx.getRootScope(), "BPM.rt_c_bpmn.000045",
                "Intermediate events in embedded subflows are not supported.");

        Node eventSubscriptionNode;
        String subscriptionOwner;
        Target consumeEventTarget;
        GalaxyClass clsEvent;
        GalaxyClass clsSubscription;

        // collect the data objects needed for mapping
        final Pair<IMappingCompiler.Summary, String> outputMapping = ctx.getMappingHelper().compile(event.getOutputMapping());
        final Pair<Set<DataContainer>, Set<DataContainer>> context = identifyInOutDataObjects(ctx, outputMapping.first, Direction.INOUT);

        @SuppressWarnings("unchecked")
        final Set<DataContainer> usedContext = union(context.first, context.second);

        // handling for depending views
        final SortedSet<DataContainer> allViewDependencies = ctx.getState().getAllViewDependencies(usedContext);
        usedContext.addAll(allViewDependencies);

        if (ctx.isTaskFlow()) {
            // task flow Sonderlocke

            /* (1) event creation */

            // fetch event class of this intermediate control and add a "owner" attribute
            clsEvent = ctx.getState().control2subscription_event.get(event).second;
            ctx.getClassFactory().addAttribute(clsEvent, CompilerConstants.ATTRIBUTE_OWNER, ctx.getSimpleTypes().REFERENCE);

            // create filter for correlation condition
            final ConstantFilter task_status_filter = generateTaskStatusFilter(event, ctx);
            NodeFactory.connectNodes(ctx.getState().getTaskSource(), 0, task_status_filter, 0);

            // generate event when correlation condition holds
            final GenericOperator event_creation_target = ctx.getExecutionFactory().generateExecution(event, "create_task_status_event");
            NodeFactory.connectNodes(task_status_filter, 0, event_creation_target, 0);
            ctx.getExecutionFactory().setScript(event_creation_target, generateTaskEventScriptHeader(ctx, event),
                    generateTaskEventScriptBody(ctx, event, clsEvent, event_creation_target));

            /* (2) correlation network */

            // correlate events that fit to the current task flow: event.owner = subscription.owner
            eventSubscriptionNode = ctx.getJoinFactory().generateJoin(event, "event_subscription", "0/0/3", "1/0/0");
            NodeFactory.connectNodes(ctx.getSourceFactory().getSource4Class(clsEvent), 0, eventSubscriptionNode, 0);
            clsSubscription = ctx.getState().control2subscription_event.get(event).first;
            NodeFactory.connectNodes(ctx.getSourceFactory().getSource4Class(clsSubscription), 0, eventSubscriptionNode, 1);
            subscriptionOwner = "0/1/0";

            // delete events once the task (owner) has gone
            NodeFactory.connectNodes(ctx.getSourceFactory().getSource4Class(clsEvent), 0, event_cleanup_join, 1);

            // create the target node
            consumeEventTarget = ctx.getTargetFactory().generateTarget(event, "consume_intermediate_event");
            ctx.getTargetFactory().setScript(
                    consumeEventTarget,
                    generateConsumeTaskEventScriptHeader(event, clsEvent, clsSubscription, usedContext, ctx),
                    generateConsumeTaskEventScriptBody(event, clsEvent, clsSubscription, outputMapping.second, usedContext, context.first,
                            context.second, consumeEventTarget, ctx));

        } else {
            final Triple<String, String, Operation> endpoint = getEndpoint(ctx, event);

            final XsdElementDeclaration requestElement = WSDLHelper.getRequestElement(endpoint.third);
            final Expression expression = event.getExpression();

            // normalize the correlation expressions into a conjunction of equality operations
            final NormalizationHelper helper = new NormalizationHelper(ctx);
            List<Triple<String, Expression, Expression>> equalities;
            equalities = helper.normalize(expression, requestElement);

            // create event and subscription attribute and its triggernet for updating
            clsEvent = ctx.getState().getEvent(endpoint.second);
            clsSubscription = ctx.getState().getSubscription(endpoint.second);
            final ArrayList<Pair<Attribute, Attribute>> conjuction = new ArrayList<Pair<Attribute, Attribute>>(equalities.size());
            for (final Triple<String, Expression, Expression> equality : equalities) {
                // for each equality comparison add an attribute to the message and event and create the update mechanism
                final Attribute attEvent = addEventAttribute(endpoint.first, endpoint.second, endpoint.third, clsEvent, equality, ctx);
                final Attribute attSubscription = addSubscriptionAttribute(event, clsSubscription, equality, ctx);
                conjuction.add(new Pair<Attribute, Attribute>(attEvent, attSubscription));
            }

            // generate configurations for the filter and persistent join
            int i = 0;
            final StringBuilder left = new StringBuilder();
            final StringBuilder rightJoin = new StringBuilder();
            final StringBuilder rightFilter = new StringBuilder();
            final StringBuilder comparators = new StringBuilder();
            for (final Pair<Attribute, Attribute> equality : conjuction) {
                left.append("0/1/");
                left.append(clsEvent.getAttribute().indexOf(equality.first));
                rightJoin.append("1/0/");
                rightJoin.append(clsSubscription.getAttribute().indexOf(equality.second));
                rightFilter.append("0/2/");
                rightFilter.append(clsSubscription.getAttribute().indexOf(equality.second));
                comparators.append("==");
                if (i < (conjuction.size() - 1)) {
                    left.append("&");
                    rightJoin.append("&");
                    rightFilter.append("&");
                    comparators.append("&");
                }
                i++;
            }

            // configure the persistent join node
            final GenericOperator join = joinNodes.get(endpoint.second);
            ctx.getDBCorrelationFactory().addConjuction(join, left.toString(), rightJoin.toString());

            // create a filter node to get only those event/subscription with a matching correlation
            final Node filter = ctx.getParameterFilterFactory().generateFilter(event, null, left.toString(), rightFilter.toString(),
                    comparators.toString());
            final Node lock = lockNodes.get(endpoint.second);
            NodeFactory.connectNodes(lock, 0, filter, 0);

            // the source node with the request, event and subscription node
            eventSubscriptionNode = filter;
            subscriptionOwner = "0/2/0";

            // create the target node
            consumeEventTarget = ctx.getTargetFactory().generateTarget(event, "consume_intermediate_event");
            ctx.getTargetFactory().setScript(
                    consumeEventTarget,
                    generateConsumeEventScriptHeader(event, clsEvent, clsSubscription, usedContext, ctx),
                    generateConsumeEventScriptBody(event, endpoint.third, outputMapping.second, usedContext, context.first, context.second,
                            consumeEventTarget, ctx));

        }

        final int tokenChannel = ctx.getState().getBeforeTokenSwitchExit(event);

        if (usedContext.isEmpty()) {
            // join subscription.owner=instance
            final Join event_sub_token_instance_join = ctx.getJoinFactory().generateJoin(event, "subscription_instance", subscriptionOwner,
                    "1/1/-1");
            NodeFactory.connectNodes(eventSubscriptionNode, 0, event_sub_token_instance_join, 0);
            NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), tokenChannel, event_sub_token_instance_join, 1);
            NodeFactory.connectNodes(event_sub_token_instance_join, 0, consumeEventTarget, 0);
        } else {
            final ProjectionNode projectionSwizzle = buildContextProjectionNode(ctx, event.getScope(), event, null, usedContext);
            if (ctx.getRootScope().equals(event.getScope())) {
                // is root scope, projection only contains data objects
                // join instance, token and context: instance=ctx.owner
                final Join contextJoin = ctx.getJoinFactory().generateJoin(event, "context", "0/1/-1", "1/0/0");
                NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), tokenChannel, contextJoin, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, contextJoin, 1);
                // join subscription.owner=instance
                final Join event_sub_token_instance_context_join = ctx.getJoinFactory().generateJoin(event, "subscription_instance",
                        subscriptionOwner, "1/1/-1");
                NodeFactory.connectNodes(eventSubscriptionNode, 0, event_sub_token_instance_context_join, 0);
                NodeFactory.connectNodes(contextJoin, 0, event_sub_token_instance_context_join, 1);

                NodeFactory.connectNodes(event_sub_token_instance_context_join, 0, consumeEventTarget, 0);
            } else {
                // is in embedded scope, projection contains frame object as first element
                // token.frame=frame
                final Join contextJoin = ctx.getJoinFactory().generateJoin(event, "context", "0/0/2", "1/0/-1");
                NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), tokenChannel, contextJoin, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, contextJoin, 1);

                // for the target node the frame has to be removed now
                final List<Integer> usedIndexes = new ArrayList<Integer>();
                // token and instance
                usedIndexes.add(0);
                usedIndexes.add(1);
                // ignore frame
                int runningIndex = 3;
                // data objects
                for (int i = 1; i <= projectionSwizzle.getLastIndex(); i++) {
                    usedIndexes.add(runningIndex++);
                }
                final Swizzle noFrameSwizzle = ctx.getSwizzleFactory().generateSwizzle(event, "context_no_frame_projection",
                        usedIndexes.toArray(new Integer[usedIndexes.size()]));
                NodeFactory.connectNodes(contextJoin, 0, noFrameSwizzle, 0);

                // join subscription.owner=instance
                final Join event_sub_token_instance_context_join = ctx.getJoinFactory().generateJoin(event, "subscription_instance",
                        subscriptionOwner, "1/1/-1");
                NodeFactory.connectNodes(eventSubscriptionNode, 0, event_sub_token_instance_context_join, 0);
                NodeFactory.connectNodes(noFrameSwizzle, 0, event_sub_token_instance_context_join, 1);

                NodeFactory.connectNodes(event_sub_token_instance_context_join, 0, consumeEventTarget, 0);
            }
        }
    }

    protected String generateConsumeEventScriptHeader(final IntermediateCatchEvent event, final GalaxyClass clsEvent,
            final GalaxyClass clsSubscription, final Collection<DataContainer> usedContext, final CompilerContext ctx) {
        final StringBuilder sb = new StringBuilder(ScriptHelper.generateHeaderPrefix(ctx.getRootScope(),
                "TRIGGER_INTERMEDIATE_MESSAGE_EVENT", event));
        sb.append(ScriptHelper.generateClassDeclaration(CompilerConstants.ADAPTER_UC, CompilerConstants.GALAXY_REQUEST, new Variable(
                CompilerConstants.SCRIPT_VARIABLE_REQUEST)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(clsEvent, new Variable(CompilerConstants.SCRIPT_VARIABLE_EVENT)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(clsSubscription, new Variable(CompilerConstants.SCRIPT_VARIABLE_SUBSCRIPTION)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_GHOST)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(ctx.getState().getTokenClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_TOKEN)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(ctx.getState().getInstanceSource().getGalaxyClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_PARENT)));

        for (final DataContainer container : usedContext) {
            sb.append(", ");
            sb.append(ScriptHelper.generateClassDeclaration(ctx.getContextHelper().getClassByDataObject(container), new Variable(ctx
                    .getState().getContextVariableName(container))));
        }
        sb.append(") ");
        return sb.toString();
    }

    protected String generateConsumeEventScriptBody(final IntermediateCatchEvent event, final Operation operation, final String mapping,
            final Set<DataContainer> usedContext, final Set<DataContainer> inputContext, final Set<DataContainer> outputContext,
            final Target target, final CompilerContext ctx) throws BPMNCompilerException {
        final List<Variable> parameters = new ArrayList<Variable>(usedContext.size() + 5);
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_REQUEST));
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_EVENT));
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_SUBSCRIPTION));
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_GHOST));
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN));
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT));
        for (final DataContainer container : usedContext) {
            parameters.add(new Variable(ctx.getState().getContextVariableName(container)));
        }

        final StringBuilder sb = new StringBuilder(ScriptHelper.generateBodyPrefix(ctx.getState().getExitClass(),
                CompilerConstants.BITMASK_ON_ACTIVATION, event, target, parameters));

        // scope code
        sb.append(ScriptHelper
                .generateScopeCode(ctx.getState().getControllerClass(), new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN)));

        // delete ghost;
        sb.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_GHOST)));

        appendTokenAdvanceScript(ctx, event, sb);

        // message=request:getData();
        sb.append(ScriptHelper.generateInvocationCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_MESSAGE), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_REQUEST), "getData"));

        // mapping script
        final XsdElementDeclaration request = WSDLHelper.getRequestElement(operation);
        sb.append(ScriptHelper.generateMappingCode(ctx, mapping, inputContext, outputContext,
                new Triple<XsdElementDeclaration, Variable, StringLiteral>(request,
                        new Variable(CompilerConstants.SCRIPT_VARIABLE_MESSAGE), new StringLiteral(ctx.getHost().getVersionId(
                                ctx.getDependencyHelper().getScope(operation), CompilerType.TYPECOMPILER))), null));

        sb.append("}");
        return sb.toString();
    }

    private void appendTokenAdvanceScript(final CompilerContext ctx, final IntermediateCatchEvent event, final StringBuilder sb)
            throws BPMNCompilerException {
        final int currentState = ctx.getState().getBeforeTokenLabel(event);
        final int nextState = ctx.getState().getAfterTokenLabel(event);
        final Variable varToken = new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN);

        if (nextState == currentState) {
            /**
             * See Note 2052360 - We have to ensure that timers after event-based gateways are cleaned up and recreated
             */
            // frame=token:frame
            final Variable varFrame = new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME);
            sb.append(ScriptHelper.generateAssignCommand(varFrame, varToken, CompilerConstants.ATTRIBUTE_FRAME));
            // tokenCopy = new Token(parent, nextTokenState, frame)
            final Variable varTokenCopy = new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN + "Copy");
            final GalaxyClass tokenClass = ctx.getState().getTokenSource().getGalaxyClass();
            sb.append(ScriptHelper.generateNewCommand(varTokenCopy, tokenClass, new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT),
                    new IntegerLiteral(nextState), varFrame));
            appendPrinciplePropagationScript(ctx, sb, varTokenCopy);
            // delete old token object
            sb.append(ScriptHelper.generateDeleteCommand(varToken));
        } else {
            appendPrinciplePropagationScript(ctx, sb, varToken);
            // token:state=<next>;
            sb.append(ScriptHelper.generateUpdateCommand(varToken, CompilerConstants.ATTRIBUTE_STATE, new IntegerLiteral(nextState)));
        }
    }

    private void appendPrinciplePropagationScript(final CompilerContext ctx, final StringBuilder sb, final Variable varToken) {
        // propagate principal from event to token
        if (ctx.isPrincipalPropagationActive()) {
            sb.append(ScriptHelper.generateInvocationCommand(null, varToken, CompilerConstants.METHOD_TOKEN_COPY_PRINCIPAL_FROM_EVENT,
                    new Variable(CompilerConstants.SCRIPT_VARIABLE_EVENT)));
        }
    }
}
