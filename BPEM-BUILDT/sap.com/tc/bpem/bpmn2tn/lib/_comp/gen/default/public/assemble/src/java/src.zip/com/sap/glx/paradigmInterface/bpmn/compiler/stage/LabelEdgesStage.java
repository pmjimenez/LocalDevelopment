package com.sap.glx.paradigmInterface.bpmn.compiler.stage;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.workflow.Activity;
import com.sap.glx.ide.model.galaxy.workflow.ConditionalSequenceConnector;
import com.sap.glx.ide.model.galaxy.workflow.EmbeddedScope;
import com.sap.glx.ide.model.galaxy.workflow.EndEvent;
import com.sap.glx.ide.model.galaxy.workflow.ErrorEventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.Event;
import com.sap.glx.ide.model.galaxy.workflow.ExclusiveEventSplitGateway;
import com.sap.glx.ide.model.galaxy.workflow.HumanActivity;
import com.sap.glx.ide.model.galaxy.workflow.LoopCharacteristics;
import com.sap.glx.ide.model.galaxy.workflow.MessageFlowObject;
import com.sap.glx.ide.model.galaxy.workflow.PoolReference;
import com.sap.glx.ide.model.galaxy.workflow.Scope;
import com.sap.glx.ide.model.galaxy.workflow.ScopeObject;
import com.sap.glx.ide.model.galaxy.workflow.ScopeReference;
import com.sap.glx.ide.model.galaxy.workflow.SequenceConnector;
import com.sap.glx.ide.model.galaxy.workflow.ThrowEvent;
import com.sap.glx.ide.model.galaxy.workflow.UncontrolledJoinGateway;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;

/**
 * A compiler stage that walks the list of all edges and assigns unique labels to each of them.
 * 
 * @author Sören Balko
 * @author Thilo-Alexander Ginkel
 * 
 * @version $Id:
 *          //bpem/bpem.tools/dev/src/_com.sap.glx.bpmn2tn/java/com/sap/glx/paradigmInterface/bpmn/compiler/stage/LabelEdgesStage.java#1 $
 */
public class LabelEdgesStage implements CompilerStage {
    
    public class MessageFlowObjectComparator implements Comparator<MessageFlowObject>{
        public int compare(MessageFlowObject o1, MessageFlowObject o2) {
            return o1 == o2 ? 0 : o1 == null ? -1 : o2 == null ? 1 : o1.refMofId().compareTo(o2.refMofId());
        }  
    }
    
    public void execute(CompilerContext ctx) throws BPMNCompilerException {
        // the galaxy class for the token
        GalaxyClass clsToken = ctx.getState().getTokenSource().getGalaxyClass();
        
        // initially put all sequence connectors into a joint set to guarantee deterministic ordering (by MOFID)
        SortedSet<SequenceConnector> connectors = new TreeSet<SequenceConnector>(new MessageFlowObjectComparator());

        // add all connectors in the scope to the sorted set
        Set<SequenceConnector> sequenceConnectors = ctx.getArtifacts(SequenceConnector.class);
        if (sequenceConnectors != null)
            connectors.addAll(sequenceConnectors);
        Set<ConditionalSequenceConnector> conditionalConnectors = ctx.getArtifacts(ConditionalSequenceConnector.class);
        if (conditionalConnectors != null)
            connectors.addAll(conditionalConnectors);

        ctx.getValidator().validate(connectors.size() > 0, "BPM.rt_c_bpmn.000067", 
                "Scope '%s' does not contain any control flow connectors.", ctx.getRootScope().getOriginalName());

        // sorted map for the domination relationship
        SortedMap<SequenceConnector, SequenceConnector> dominant = new TreeMap<SequenceConnector, SequenceConnector>(new Comparator<MessageFlowObject>() {
            public int compare(MessageFlowObject o1, MessageFlowObject o2) {
                return o1 == o2 ? 0 : o1 == null ? -1 : o2 == null ? 1 : o1.refMofId().compareTo(o2.refMofId());
            }
        });
        
        LabelEdgesResult result = new LabelEdgesResult(ctx);
        
        for (SequenceConnector connector : connectors) {
            ctx.getValidator().validateConnector(connector);
            ScopeObject source = connector.getSource();
            ScopeObject target = connector.getTarget();

            if (source instanceof ExclusiveEventSplitGateway) {
                // special handling of exclusive event split gateways
            	ctx.getValidator().validateConnectors(source, 1, 1, 2, Integer.MAX_VALUE);
            	dominant.put(connector, source.getIncomingConnectors().iterator().next());
            } else if (target instanceof UncontrolledJoinGateway) {
                // special handling of uncontrolled join gateways
            	ctx.getValidator().validateConnectors(target, 2, Integer.MAX_VALUE, 1, 1);
            	dominant.put(connector, target.getOutgoingConnectors().iterator().next());
            } else {
                // notice that a connector can not connect an exclusive event split with an 
            	// uncontrolled join gateway (c.f. BPMN specification)
                result.addConnectorLabel(connector);
            }
        }

        for (SequenceConnector dominated : dominant.keySet()) {
            SequenceConnector dominating = dominant.get(dominated);
            while (!result.isLabeled(dominating)) {
            	dominating = dominant.get(dominating);
                ctx.getValidator().validate(dominating != null, "BPM.rt_c_bpmn.000083", //$NON-NLS-1$
                        "Token labeling neither found a label nor a dominating connector."); //$NON-NLS-1$
            }
            result.addDominatingConnectorLabel(dominating, dominated);
        }

        for (SequenceConnector connector : result.connectorLabel.keySet()) {
            ctx.getConfigFactory().generateConnectorConfiguration(clsToken, connector, result.connectorLabel.get(connector));
        }
        
        Set<PoolReference> subflows = ctx.getArtifacts(PoolReference.class);
        if (subflows != null) {
            for (PoolReference subflow : subflows) {
                int label = result.addActivityLabel(subflow);
                ctx.getConfigFactory().generateSubflowConfiguration(clsToken, subflow, label);
            }
        }

        Set<HumanActivity> activities = ctx.getArtifacts(HumanActivity.class);
        if (activities != null) {
            for (HumanActivity activity : activities) {
                int label = result.addActivityLabel(activity);
                ctx.getConfigFactory().generateHumanActivityConfiguration(clsToken, activity, label);
            }
        }

        Set<ThrowEvent> throwEvents = ctx.getArtifacts(ThrowEvent.class);
        if (throwEvents != null) {
            for (ThrowEvent throwEvent : throwEvents) {
                if (throwEvent instanceof EndEvent && throwEvent.getEventDefinition() instanceof ErrorEventDefinition) {
                    result.addEventLabel((EndEvent) throwEvent);
                }
            }
        }

        Set<EmbeddedScope> embeddedScopes = ctx.getArtifacts(EmbeddedScope.class);
        if(embeddedScopes != null){
            SortedSet<EmbeddedScope> sortedEmbeddedScopes = new TreeSet<EmbeddedScope>(new MessageFlowObjectComparator());
            sortedEmbeddedScopes.addAll(embeddedScopes);
            for(EmbeddedScope embeddedScope : sortedEmbeddedScopes){
                //fill also channel and label map as other algorithms rely on that *sigh*
                result.addFrameEndLabel(embeddedScope);
                LoopCharacteristics loopCharacteristics = embeddedScope.getLoopCharacteristics(); 
                if(loopCharacteristics != null){
                    result.addLoopWaitingLabel(embeddedScope);
                }
            }
        }
        
        ctx.getState().setLabelEdgesResult(result);
    }
    
    public class LabelEdgesResult {

        private CompilerContext ctx;

        private Map<SequenceConnector, Integer> connectorLabel = new HashMap<SequenceConnector, Integer>();
        private Map<Activity, Integer> activityLabel = new HashMap<Activity, Integer>();
        private Map<Event, Integer> eventLabel = new HashMap<Event, Integer>();
        private Map<Scope, Integer> frameEndLabel = new HashMap<Scope, Integer>();
        private Map<Scope, Integer> loopCycleWaitingLabel = new HashMap<Scope, Integer>();

        private int currentLabel = 0;

        private LabelEdgesResult(CompilerContext ctx) {
            this.ctx = ctx;
        }

        private int addConnectorLabel(SequenceConnector connector) {
            connectorLabel.put(connector, currentLabel);
            return currentLabel++;
        }

        private int addDominatingConnectorLabel(SequenceConnector dominating, SequenceConnector dominated) {
            int label = connectorLabel.get(dominating);
            connectorLabel.put(dominated, label);
            return label;
        }

        private int addActivityLabel(ScopeReference reference) {
            activityLabel.put(reference, currentLabel);
            return currentLabel++;
        }

        private int addEventLabel(EndEvent endEvent) {
            eventLabel.put(endEvent, currentLabel);
            return currentLabel++;
        }

        private int addFrameEndLabel(Scope scope) {
            frameEndLabel.put(scope, currentLabel);
            return currentLabel++;
        }

        private int addLoopWaitingLabel(Scope scope) {
            loopCycleWaitingLabel.put(scope, currentLabel);
            return currentLabel++;
        }

        private boolean isLabeled(SequenceConnector connector) {
            return connectorLabel.keySet().contains(connector);
        }

        public int getTokenLabel(SequenceConnector connector) throws BPMNCompilerException {
            Integer label = connectorLabel.get(connector);
            ctx.getValidator().validate(label != null, "BPM.rt_c_bpmn.000069", //$NON-NLS-1$ 
                    "Given sequence connector '%s' was never labelled.", connector.getOriginalName()); //$NON-NLS-1$ 
            return connectorLabel.get(connector);
        }

        public int getTokenLabel(ScopeReference reference) throws BPMNCompilerException {
            Integer label = activityLabel.get(reference);
            ctx.getValidator().validate(label != null, "BPM.rt_c_bpmn.000071", //$NON-NLS-1$
                    "Given scope reference '%s' was never labelled.", reference.getOriginalName()); //$NON-NLS-1$
            return label;
        }

        public int getTokenLabel(EndEvent endEvent) throws BPMNCompilerException {
            Integer label = eventLabel.get(endEvent);
            ctx.getValidator().validate(label != null, "BPM.rt_c_bpmn.000081", //$NON-NLS-1$
                    "Given event '%s' was never labelled.", endEvent.getOriginalName()); //$NON-NLS-1$
            return label;
        }

        public int getTokenLabelFrameEnd(Scope scope) throws BPMNCompilerException {
            Integer label = frameEndLabel.get(scope);
            ctx.getValidator().validate(label != null, "BPM.rt_c_bpmn.000083", //$NON-NLS-1$
                    "Given scope '%s' was never labelled.", scope.getOriginalName()); //$NON-NLS-1$
            return label;

        }

        public int getTokenLabelLoopCycleWaiting(Scope scope) throws BPMNCompilerException {
            Integer label = loopCycleWaitingLabel.get(scope);
            ctx.getValidator().validate(label != null, "BPM.rt_c_bpmn.000084", //$NON-NLS-1$
                    "Given scope '%s' was never labelled.", scope.getOriginalName()); //$NON-NLS-1$
            return label;
        }

        public int getNumberOfTokenLabels() {
            return currentLabel;
        }
    }
}
