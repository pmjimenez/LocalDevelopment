package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import com.sap.glx.ide.model.galaxy.workflow.EndEvent;
import com.sap.glx.ide.model.galaxy.workflow.ThrowEvent;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.Source;
import com.sap.glx.ide.model.triggernet.Target;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.AdvancedScript;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptName;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptVariable;

public class ErrorEndControlRule extends RaiseEventionRule {
	
    @SuppressWarnings("unchecked")
    public Class getSupportedArtifact() {
		return EndEvent.class;
	}

	public void compile(EndEvent endEvent, CompilerContext ctx) throws BPMNCompilerException {
        super.compile(endEvent, ctx);
        
        //transition only triggers, when the exception has been handled
        //generate an exception join and connect the exception and the token switch with state error_end, join on exception.origin=token
        Source exceptionSource = ctx.getSourceFactory().generateSource(CompilerConstants.ADAPTER_EXCEPTION, CompilerConstants.GALAXY_EXCEPTION);
        Join exceptionJoin = ctx.getJoinFactory().generateJoin(endEvent, "exception_handled", "0/0/0", "1/0/-1");
        NodeFactory.connectNodes(exceptionSource, 0, exceptionJoin, 0);
        NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), ctx.getState().getTokenSwitchExit(endEvent), exceptionJoin, 1);
        
        //connect an asynchronous target to the right inhibitor of the exception join (exception has been handled) which deletes the token 
        Target tokenRemovalTarget = generateTokenRemovalTransition(ctx, endEvent);
        NodeFactory.connectNodes(exceptionJoin, 2, tokenRemovalTarget, 0);
    }   
    
    private Target generateTokenRemovalTransition(CompilerContext ctx, EndEvent endEvent) {
        AdvancedScript script = new AdvancedScript(ctx, ScriptName.END_EVENT_ERROR_TOKEN_REMOVAL, endEvent);
        ScriptVariable varToken = script.addParameter(ScriptVariable.TOKEN, ctx.getState().getTokenClass());
        ScriptVariable varInstance = script.addParameter(ScriptVariable.INSTANCE, ctx.getState().getInstanceClass());
        
        script.generateScopeCode(varToken);
        script.generateDeleteCommand(varToken);
        if (endEvent.isTerminate()) {
            // terminating end events delete the instance
            script.generateDeleteCommand(varInstance);
        }
        
        return script.getTarget(getTransitionPriority(endEvent));
    }
    
    protected String tokenHandling(CompilerContext ctx, ThrowEvent event) throws BPMNCompilerException {
        return tokenHandlingWaitingState(ctx, event);
    }
}
