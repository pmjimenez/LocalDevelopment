package com.sap.glx.paradigmInterface.bpmn.compiler.stage;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.sap.glx.ide.model.galaxy.workflow.MessageFlowObject;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.rules.AutomatedActivityRule;
import com.sap.glx.paradigmInterface.bpmn.compiler.rules.BoundaryEventRule;
import com.sap.glx.paradigmInterface.bpmn.compiler.rules.CompilerRule;
import com.sap.glx.paradigmInterface.bpmn.compiler.rules.DataObjectRule;
import com.sap.glx.paradigmInterface.bpmn.compiler.rules.EmbeddedScopeRule;
import com.sap.glx.paradigmInterface.bpmn.compiler.rules.IntermediateCatchEventRule;
import com.sap.glx.paradigmInterface.bpmn.compiler.rules.MappingActivityRule;
import com.sap.glx.paradigmInterface.bpmn.compiler.rules.NotificationActivityRule;
import com.sap.glx.paradigmInterface.bpmn.compiler.rules.ParallelJoinRule;
import com.sap.glx.paradigmInterface.bpmn.compiler.rules.ParallelSplitRule;
import com.sap.glx.paradigmInterface.bpmn.compiler.rules.PickSplitRule;
import com.sap.glx.paradigmInterface.bpmn.compiler.rules.ReportingActivityRule;
import com.sap.glx.paradigmInterface.bpmn.compiler.rules.StartControlRule;
import com.sap.glx.paradigmInterface.bpmn.compiler.rules.SubflowRule;
import com.sap.glx.paradigmInterface.bpmn.compiler.rules.TaskReferenceRule;
import com.sap.glx.paradigmInterface.bpmn.compiler.rules.ThrowEventRule;
import com.sap.glx.paradigmInterface.bpmn.compiler.rules.ViewRule;
import com.sap.glx.paradigmInterface.bpmn.compiler.rules.XORJoinRule;
import com.sap.glx.paradigmInterface.bpmn.compiler.rules.XORSplitRule;

/**
 * Compiles all artifacts into their trigger net equivalent. Depending on the artifacts collected by
 * the {@link CollectArtifactsStage} rules are instantiated to compile the collected artifacts.
 * 
 * @author Thilo-Alexander Ginkel
 * @author Philipp Sommer
 * 
 * @version $Id:
 *          //bpem/bpem.tools/dev/src/_com.sap.glx.bpmn2tn/java/com/sap/glx/paradigmInterface/bpmn/compiler/stage/CompileArtifactsStage.java#2 $
 */
public class CompileArtifactsStage implements CompilerStage {

	
    /**
     * An enumeration of compiler rules for general model elements which includes data 
     * handling and scoping. They will be processed in the provided order. 
     * Known dependencies:
     *  
     *  - ...
     */
    @SuppressWarnings("unchecked")
    private static final Class<CompilerRule<? extends MessageFlowObject>>[] GENERAL_RULES = new Class[] { 
    		DataObjectRule.class, ViewRule.class};
	
	/**
     * An enumeration of compiler rules for model elements which participate
     * in the sequence flow of a pool. They will be processed in the provided order. 
     * Known dependencies:
     *  
     *  - IntermediateCatchEventRule must be executed before the StartControlRule
     *    because the construction of the subscription classes must be finished. 
     *  - ThrowEventDispatcherRule must be executed before the StartControlRule
     *    because in case of synchronous provisioning the end event generates 
     *    the galaxy class for the bridge. 
     */
    @SuppressWarnings("unchecked")
    private static final Class<CompilerRule<? extends MessageFlowObject>>[] FLOW_OBJECT_RULES = new Class[] { 
    		EmbeddedScopeRule.class, ThrowEventRule.class, BoundaryEventRule.class, IntermediateCatchEventRule.class, 
    		StartControlRule.class, ParallelJoinRule.class, ParallelSplitRule.class, AutomatedActivityRule.class, 
    		MappingActivityRule.class, TaskReferenceRule.class, ReportingActivityRule.class, NotificationActivityRule.class,
    		PickSplitRule.class, SubflowRule.class, XORJoinRule.class, XORSplitRule.class, };

    /**
     * Creates and invoke compiler rules according to the artifacts collected by the 
     * {@link CollectArtifactsStage}.
     */
    public void execute(CompilerContext ctx) throws BPMNCompilerException {
    	// general rule processing for data objects, views and scopes
    	List<CompilerRule<? extends MessageFlowObject>> rules = createRules(ctx, GENERAL_RULES);
    	executeRules(ctx, rules);
    	
    	// rule processing for BPMN flow objects
    	rules = createRules(ctx, FLOW_OBJECT_RULES);
    	executeRules(ctx, rules);
    }

    /**
     * Processes the passes list of compiler rules. First the 
     * {@link CompilerRule#preprocess(CompilerContext)} is executed on each rule. 
     * Then the artifacts of each rule are compiled. Finally the 
     * {@link CompilerRule#postprocess(CompilerContext)} method is called on each rule.
     */
    private void executeRules(CompilerContext ctx, List<CompilerRule<? extends MessageFlowObject>> rules) throws BPMNCompilerException {
    	for (CompilerRule<? extends MessageFlowObject> rule : rules) {
			rule.preprocess(ctx);
		}
    	for (CompilerRule<? extends MessageFlowObject> rule : rules) {
    		compile(ctx, rule);
    	}
    	for (CompilerRule<? extends MessageFlowObject> rule : rules) {
			rule.postprocess(ctx);
		}
    }
    
    /**
     * Compiles all supported artifacts of a rule.
     */
    private <T extends MessageFlowObject> void compile(CompilerContext ctx, CompilerRule<T> rule) throws BPMNCompilerException {
		Set<T> artifacts = ctx.getArtifacts(rule.getSupportedArtifact());
        for (T artifact : artifacts) {
        	rule.compile(artifact, ctx);
        }
	}
    
    
    /**
     * Create a list of rules out of an array of classes. Only rules for artifacts which are
     * contained in the collection of the {@link CollectArtifactsStage} are instantiated.
     */
    private List<CompilerRule<? extends MessageFlowObject>> createRules(CompilerContext ctx, Class<CompilerRule<? extends MessageFlowObject>>[] ruleClasses) throws BPMNCompilerException {
		List<CompilerRule<? extends MessageFlowObject>> rules = new ArrayList<CompilerRule<? extends MessageFlowObject>>(ruleClasses.length);
    	for (Class<CompilerRule<? extends MessageFlowObject>> ruleClass : ruleClasses) {
            CompilerRule<? extends MessageFlowObject> rule;
			try {
				rule = ruleClass.newInstance();
			} catch (Exception e) {
				throw new BPMNCompilerException("Unable to instantiate the compiler rule '" + ruleClass.getSimpleName() + "'.", e);
			}
			Set<? extends MessageFlowObject> artifacts = ctx.getArtifacts(rule.getSupportedArtifact());
            if (artifacts != null) {
            	rules.add(rule);
            }
    	}
    	return rules;
    }
}
