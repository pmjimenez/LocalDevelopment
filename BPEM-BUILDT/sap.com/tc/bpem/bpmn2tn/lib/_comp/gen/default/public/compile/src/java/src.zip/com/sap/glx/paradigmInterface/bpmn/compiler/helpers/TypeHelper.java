package com.sap.glx.paradigmInterface.bpmn.compiler.helpers;

import com.sap.glx.ide.model.classes.SimpleType;
import com.sap.glx.ide.model.classes.SimpleTypesEnum;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.guid.GUID;

public class TypeHelper {
    
    public static Object parseTypedConstant(String constant, SimpleType type) throws BPMNCompilerException {
        try {
            if (type.getType().equals(SimpleTypesEnum.BOOLEAN))
                return new Boolean(constant);
            if (type.getType().equals(SimpleTypesEnum.DOUBLE))
                return new Double(constant);
            if (type.getType().equals(SimpleTypesEnum.FLOAT))
                return new Float(constant);
            if (type.getType().equals(SimpleTypesEnum.INTEGER))
                return new Integer(constant);
            if (type.getType().equals(SimpleTypesEnum.LONG))
                return new Long(constant);
            if (type.getType().equals(SimpleTypesEnum.IDENTITY))
                return new GUID(constant);
            if (type.getType().equals(SimpleTypesEnum.STRING))
                return constant;
            throw new BPMNCompilerException("Constants of type PARASITE or STREAM cannot be parsed.");
        } catch (Exception e) {
            throw new BPMNCompilerException("Constant in predicate does not match the expected type.", e);
        }
    }
    
    public static String renderTypeString(Object value) throws BPMNCompilerException {
        if (value instanceof Boolean)
            return "BOOLEAN:"+value.toString();
        if (value instanceof Double)
            return "DOUBLE:"+value.toString();
        if (value instanceof Float)
            return "FLOAT:"+value.toString();
        if (value instanceof Integer)
            return "INTEGER:"+value.toString();
        if (value instanceof Long)
            return "LONG:"+value.toString();
        if (value instanceof String)
            return "STRING:"+value.toString();
        throw new BPMNCompilerException("Constants of type IDENTITY, PARASITE or STREAM cannot be used in filter predicates.");
    }
}
