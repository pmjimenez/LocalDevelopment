package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import com.sap.glx.ide.model.galaxy.workflow.ExclusiveEventSplitGateway;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;

/**
 * Compiles a pick-split artifact.
 * 
 * @author Sören Balko
 * @author Thilo-Alexander Ginkel
 * 
 * @version $Id: //bpem/bpem.bp/NW731EXT_17_REL/src/SCs/sap.com/BPEM-BUILDT/DCs/sap.com/tc/bpem/bpmn2tn/lib/_comp/src/com/sap/glx/paradigmInterface/bpmn/compiler/rules/PickSplitRule.java#1 $
 */
public class PickSplitRule extends BaseCompilerRule<ExclusiveEventSplitGateway> implements CompilerRule<ExclusiveEventSplitGateway> {

    /*
     * @see com.sap.glx.paradigmInterface.bpmn.compiler.rules.CompilerRule#getSupportedArtifact()
     */
    public Class<ExclusiveEventSplitGateway> getSupportedArtifact() {
        return ExclusiveEventSplitGateway.class;
    }

    /*
     * @see com.sap.glx.paradigmInterface.bpmn.compiler.rules.CompilerRule#compile(com.sap.glx.ide.model.galaxy.core.ModelElement,
     *      com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext)
     */
    public void compile(ExclusiveEventSplitGateway pick_split, CompilerContext ctx) throws BPMNCompilerException {
        ctx.getValidator().validateConnectors(pick_split, 1, 1, 2, Integer.MAX_VALUE);
        // Porky Pick says: "Th-th-th-that's all folks!"
    }
}
