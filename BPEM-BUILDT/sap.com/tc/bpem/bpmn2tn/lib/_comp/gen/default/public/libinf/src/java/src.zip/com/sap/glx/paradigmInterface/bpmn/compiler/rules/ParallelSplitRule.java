package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import com.sap.glx.ide.model.galaxy.workflow.ParallelSplitGateway;
import com.sap.glx.ide.model.triggernet.Node;
import com.sap.glx.ide.model.triggernet.Target;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ScriptHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.IntegerLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.Variable;

/**
 * Compiles parallel split gateways.
 * 
 * @author Sören Balko
 * @author Thilo-Alexander Ginkel
 * 
 * @version $Id: //bpem/bpem.bp/NW731EXT_17_REL/src/SCs/sap.com/BPEM-BUILDT/DCs/sap.com/tc/bpem/bpmn2tn/lib/_comp/src/com/sap/glx/paradigmInterface/bpmn/compiler/rules/ParallelSplitRule.java#1 $
 */
public class ParallelSplitRule extends BaseCompilerRule<ParallelSplitGateway> implements CompilerRule<ParallelSplitGateway> {

    /*
     * @see com.sap.glx.paradigmInterface.bpmn.compiler.rules.CompilerRule#getSupportedArtifact()
     */
    public Class<ParallelSplitGateway> getSupportedArtifact() {
        return ParallelSplitGateway.class;
    }

    public void compile(ParallelSplitGateway parallelSplitGateway, CompilerContext ctx) throws BPMNCompilerException {
        // exactly one incoming connector and two or more outgoing connectors
    	ctx.getValidator().validateConnectors(parallelSplitGateway, 1, 1, 2, Integer.MAX_VALUE);
    	
        // create target node
        Target target = ctx.getTargetFactory().generateTarget(parallelSplitGateway);
        ctx.getTargetFactory().setScript(target, 
        		generateScriptHeader(ctx, parallelSplitGateway), 
        		generateScriptBody(ctx, parallelSplitGateway, target));

        // connect target node to the token switch
        NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), ctx.getState().getBeforeTokenSwitchExit(parallelSplitGateway), target, 0);
    }

    private String generateScriptHeader(CompilerContext ctx, ParallelSplitGateway parallelSplitGateway) {
        return generateSimpleScriptHeader(ctx, CompilerConstants.TARGET_TARGET_AND_SPLIT, parallelSplitGateway);
    }

    private String generateScriptBody(CompilerContext ctx, ParallelSplitGateway parallelSplitGateway, Node target) throws BPMNCompilerException {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateBodyPrefix(ctx.getState().getExitClass(),
                CompilerConstants.BITMASK_ON_ACTIVATION, parallelSplitGateway, target, new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN),
                new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));

        sb.append(ScriptHelper.generateScopeCode(ctx.getState().getControllerClass(), new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN)));
        
        //frame=token:frame
        sb.append(ScriptHelper.generateAssignCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN), 
                CompilerConstants.ATTRIBUTE_FRAME));
        
        // special handling of first outgoing connector
        sb.append(ScriptHelper.generateUpdateCommand(
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN), 
        		"state", 
        		new IntegerLiteral(ctx.getState().getTokenLabel(parallelSplitGateway.getOutgoingConnectors().get(0)))));
        
        for (int i = 1; i<parallelSplitGateway.getOutgoingConnectors().size(); i++) {
            // create new tokens for other outgoing connectors
            Variable varToken = new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN + i);
        	sb.append(ScriptHelper.generateNewCommand(
        			varToken,
            		ctx.getState().getTokenSource().getGalaxyClass(),
            		new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT), 
            		new IntegerLiteral(ctx.getState().getTokenLabel(parallelSplitGateway.getOutgoingConnectors().get(i))),
            		new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME)));
            if (ctx.isPrincipalPropagationActive()) {
	        	sb.append(ScriptHelper.generateInvocationCommand(
	            		null, 
	            		varToken, 
	            		CompilerConstants.METHOD_TOKEN_COPY_PRINCIPAL_FROM_TOKEN, 
	            		new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN)));
            }
        }

        sb.append("}");
        return sb.toString();
    }
}