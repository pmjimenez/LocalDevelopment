package com.sap.glx.paradigmInterface.bpmn.compiler.scripts;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.workflow.EndEvent;
import com.sap.glx.ide.model.triggernet.Target;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;

public class ScriptGenerator {

    public static Target generateBeamingTransition(CompilerContext ctx, EndEvent endEvent, GalaxyClass clsPulsar)
            throws BPMNCompilerException {
        Script script = new Script(ctx, ScriptName.BEAM_ME_UP, endEvent);
        ScriptVariable varBridge = script.addParameter(ScriptVariable.BRIDGE, ctx.getState().getBridgeClass());
        script.addParameter(ScriptVariable.TOKEN, ctx.getState().getTokenClass());
        script.addParameter(ScriptVariable.INSTANCE, ctx.getState().getInstanceClass());
        script.addParameter(ScriptVariable.PULSAR, clsPulsar);

        script.generateInvocationCommand(varBridge, "beamMeUp");

        Target target = ctx.getTargetFactory().generateTarget(endEvent);
        ctx.getTargetFactory().setScript(target, script, getTransitionPriority(endEvent));
        return target;
    }

    public static Target generateCreateCleanupTransition(CompilerContext ctx, EndEvent endEvent, GalaxyClass clsPulsar)
            throws BPMNCompilerException {
        Script script = new Script(ctx, ScriptName.BEAM_CREATE_TIMEOUT, endEvent);
        ScriptVariable varBridge = script.addParameter(ScriptVariable.BRIDGE, ctx.getState().getBridgeClass());
        script.addParameter(ScriptVariable.TOKEN, ctx.getState().getTokenClass());
        ScriptVariable varInstance = script.addParameter(ScriptVariable.INSTANCE, ctx.getState().getInstanceClass());

        ScriptVariable varDuration = script.generateInvocationCommand(ScriptVariable.DURATION, varBridge, "getTimeout");
        script.generateNewCommand(null, clsPulsar, new LongLiteral(0l), new LongLiteral(1l), varDuration, Literal.NULL, varInstance);

        Target target = ctx.getTargetFactory().generateTarget(endEvent);
        ctx.getTargetFactory().setScript(target, script, getTransitionPriority(endEvent));
        return target;
    }

    public static Target generateDoCleanupTransition(CompilerContext ctx, EndEvent endEvent, GalaxyClass clsPulsar)
            throws BPMNCompilerException {
        Script script = new Script(ctx, ScriptName.BEAM_TIMEOUT, endEvent);
        ScriptVariable varBridge = script.addParameter(ScriptVariable.BRIDGE, ctx.getState().getBridgeClass());
        ScriptVariable varToken = script.addParameter(ScriptVariable.TOKEN, ctx.getState().getTokenClass());
        ScriptVariable varInstance = script.addParameter(ScriptVariable.INSTANCE, ctx.getState().getInstanceClass());
        script.addParameter(ScriptVariable.PULSAR, clsPulsar);

        script.generateInvocationCommand(varInstance, "suspendWithChildren");
        script.generateInvocationCommand(varBridge, "logTimeout");
        script.generateDeleteCommand(varToken);

        Target target = ctx.getTargetFactory().generateTarget(endEvent);
        ctx.getTargetFactory().setScript(target, script, getTransitionPriority(endEvent));
        return target;
    }

    private static int getTransitionPriority(EndEvent endEvent) {
        if (endEvent.isTerminate()) {
            return CompilerConstants.PRIORITY_CANCEL;
        } else {
            return CompilerConstants.PRIORITY_NORMAL;
        }
    }
}
