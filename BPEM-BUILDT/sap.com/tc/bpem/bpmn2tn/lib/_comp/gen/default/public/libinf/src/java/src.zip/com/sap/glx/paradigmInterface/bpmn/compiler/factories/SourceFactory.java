package com.sap.glx.paradigmInterface.bpmn.compiler.factories;

import java.util.HashMap;
import java.util.Map;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.triggernet.LocalSource;
import com.sap.glx.ide.model.triggernet.RemoteSource;
import com.sap.glx.ide.model.triggernet.Subnet;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.facades.ITriggernetFacade;

/**
 * This class is provides functionality to retrieve and create source nodes, both remote and local.
 * 
 * @author Philipp Sommer
 * 
 */
public class SourceFactory extends NodeFactory {

    // Maps any used class to its respective source node.
    private Map<GalaxyClass, LocalSource> localSources = new HashMap<GalaxyClass, LocalSource>();
    private Map<Pair<String, String>, RemoteSource> remoteSources = new HashMap<Pair<String, String>, RemoteSource>();

    public SourceFactory(ITriggernetFacade facade, Subnet subnet) {
        super(facade, subnet);
    }

    @Override
    protected String getNodePrefix() {
        return "SOURCE"; //$NON-NLS-1$
    }

    @Override
    protected int getInputCount() {
        return 0;
    }

    @Override
    protected int getOutputCount() {
        return 1;
    }

    /**
     * Generates a source node for triggernet local galaxy class definitions. In case a previous invocation of the method already created a
     * source node the existing node is returned.
     * 
     * @param cls
     *            the class instance
     * @return the source node for the given class
     */
    public LocalSource generateSource(GalaxyClass cls) {
        LocalSource source = localSources.get(cls);

        if (source == null) {
            source = createElement(LocalSource.class);
            prepareNode(source, cls, null);
            source.setGalaxyClass(cls);
            localSources.put(cls, source);
        }

        return source;
    }

    /**
     * Generates a source node for triggernet remote galaxy class definitions. In case a previous invocation of the method already created a
     * source node the existing node is returned.
     * 
     * @param cls
     *            the class instance
     * @return the source node for the given class
     */
    public RemoteSource generateSource(String adapterName, String className) {
        Pair<String, String> cls = new Pair<String, String>(adapterName, className);
        RemoteSource source = remoteSources.get(cls);

        if (source == null) {
            source = createElement(RemoteSource.class);
            prepareNode(source, cls, null);
            source.setAdapterName(adapterName);
            source.setClassName(className);
            remoteSources.put(cls, source);
        }

        return source;
    }

    /**
     * Please use {@link SourceFactory#generateSource(GalaxyClass)} instead.
     */
    public LocalSource getSource4Class(GalaxyClass cls) {
        return localSources.get(cls);
    }
}
