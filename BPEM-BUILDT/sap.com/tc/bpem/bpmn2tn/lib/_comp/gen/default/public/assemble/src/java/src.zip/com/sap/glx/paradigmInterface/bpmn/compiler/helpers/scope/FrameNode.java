package com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope;

import java.util.ArrayList;
import java.util.List;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.workflow.Scope;

/**
 * FrameNode is a helper structure for a scope which holds information like hierarchy or the corresponding GalaxyClass
 */
public class FrameNode {

    private final Scope m_scope;
    private final FrameNode m_parent;
    private List<FrameNode> m_children = new ArrayList<FrameNode>();
    // assigned during CollectArtifactStage in the initialization in DonFrame
    private GalaxyClass m_frameClass = null;
    // assigned during postprocess of DataObjectRule
    private ProjectionNode m_projectionNode = null;

    public FrameNode(Scope scope, FrameNode parent) {
        m_scope = scope;
        m_parent = parent;
    }

    public Scope getScope() {
        return m_scope;
    }

    public FrameNode addChild(Scope scope) {
        FrameNode child = new FrameNode(scope, this);
        m_children.add(child);
        return child;
    }

    /**
     * assigns the GalaxyClass for this frame
     * @param frameClass
     */
    public void setGalaxyClass(GalaxyClass frameClass) {
        m_frameClass = frameClass;
    }

    public FrameNode getParent() {
        return m_parent;
    }

    public List<FrameNode> getChildren() {
        return m_children;
    }

    public boolean hasChildren() {
        return m_children.isEmpty() ? false : true;
    }

    public GalaxyClass getGalaxyClass() {
        return m_frameClass;
    }

    /**
     * assigns the ProjectionNode for this Frame the ProjectionNode is connected with all DataContainers of this Frame as well as those of
     * its parents
     * @param projectionNode
     */
    public void setProjectionNode(ProjectionNode projectionNode) {
        m_projectionNode = projectionNode;
    }

    public ProjectionNode getProjectionNode() {
        return m_projectionNode;
    }

}
