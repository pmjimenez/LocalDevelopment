package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;

import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.MappingActivity;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.Swizzle;
import com.sap.glx.ide.model.triggernet.Target;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ScriptHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.IntegerLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.Variable;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.ProjectionNode;
import com.sap.mapping.base.compiler.IMappingCompiler;

public class MappingActivityRule extends BaseCompilerRule<MappingActivity> implements CompilerRule<MappingActivity> {

    public Class<MappingActivity> getSupportedArtifact() {
        return MappingActivity.class;
    }

    @SuppressWarnings("unchecked")
    public void compile(MappingActivity activity, CompilerContext ctx) throws BPMNCompilerException {
        ctx.getValidator().validateConnectors(activity, 1, 1, 1, 1);

        ctx.getValidator().validate(activity.getOutputMapping() != null, "BPM.rt_c_bpmn.000046", "No mapping was defined for mapping activity '%s'.",
                activity.getOriginalName());

        Pair<IMappingCompiler.Summary, String> mapping = ctx.getMappingHelper().compile(activity.getOutputMapping());

        Pair<Set<DataContainer>, Set<DataContainer>> in_out_context = identifyInOutDataObjects(ctx, mapping.first, Direction.INOUT);
        Set<DataContainer> used_context = union(in_out_context.first, in_out_context.second);
        
        // handling for depending views
        SortedSet<DataContainer> allViewDependencies = ctx.getState().getAllViewDependencies(used_context);
        used_context.addAll(allViewDependencies);

        Target target = ctx.getTargetFactory().generateTarget(activity, activity.getOriginalName());
        
        int tokenChannel = ctx.getState().getBeforeTokenSwitchExit(activity);
        if(used_context.isEmpty()){
        	NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), tokenChannel, target, 0);
        }else{
        	ProjectionNode projectionSwizzle = buildContextProjectionNode(ctx, activity.getScope(), activity, null, used_context);
        	if(ctx.getRootScope().equals(activity.getScope())){
            	//is root scope, projection only contains data objects
        		// Instance=Context0.owner
                Join context_join = ctx.getJoinFactory().generateJoin(activity, "join_context", "0/1/-1", "1/0/0");
                NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), tokenChannel, context_join, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, context_join, 1);
                NodeFactory.connectNodes(context_join, 0, target, 0);
            }else{
            	//is in embedded scope, projection contains frame object as first element
            	//token.frame=frame
                Join context_join = ctx.getJoinFactory().generateJoin(activity, "join_context", "0/0/2", "1/0/-1");
                NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), tokenChannel, context_join, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, context_join, 1);
                
           		//for the target node the frame has to be removed now
        		List<Integer> usedIndexes = new ArrayList<Integer>();
        		//token and instance
        		usedIndexes.add(0);
        		usedIndexes.add(1);
        		//ignore frame
        		int runningIndex = 3;
        		//data objects
        		for(int i = 1; i<=projectionSwizzle.getLastIndex(); i++){
        			usedIndexes.add(runningIndex++);
        		}
        		Swizzle noFrameSwizzle = ctx.getSwizzleFactory().generateSwizzle(activity, "context_no_frame_projection", usedIndexes.toArray(new Integer[usedIndexes.size()]));
        		NodeFactory.connectNodes(context_join, 0, noFrameSwizzle, 0);
        		NodeFactory.connectNodes(noFrameSwizzle, 0, target, 0);
            }
        }
        
        ctx.getTargetFactory().setScript(target, generateScriptHeader(ctx, activity, used_context),
                generateScriptBody(ctx, activity, in_out_context.first, in_out_context.second, used_context, target, mapping.second));
    }

    private String generateScriptHeader(CompilerContext ctx, MappingActivity activity, Set<DataContainer> used_context) {
        return generateSimpleScriptHeader(ctx, CompilerConstants.TARGET_MAPPING_ACTIVITY, activity, used_context);
    }

    private String generateScriptBody(CompilerContext ctx, MappingActivity activity, Set<DataContainer> context_in, Set<DataContainer> context_out,
            Set<DataContainer> used_context, Target target, String mapping_id) throws BPMNCompilerException {

        List<Variable> parameters = new ArrayList<Variable>(2 + context_in.size() + context_out.size());
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN));
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT));
        for (DataContainer obj : used_context) {
            parameters.add(new Variable(ctx.getState().getContextVariableName(obj)));
        }

        StringBuilder sb = new StringBuilder(ScriptHelper.generateBodyPrefix(ctx.getState().getExitClass(), CompilerConstants.BITMASK_ON_ACTIVATION, activity,
                target, parameters));

        sb.append(ScriptHelper.generateScopeCode(ctx.getState().getControllerClass(), new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN)));

        // mapping
        sb.append(ScriptHelper.generateMappingCode(ctx, mapping_id, context_in, context_out, null, null));

        // token:state=<next>;
        int nextState = ctx.getState().getAfterTokenLabel(activity);
        sb.append(ScriptHelper.generateUpdateCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN), "state", new IntegerLiteral(nextState)));

        sb.append("}");
        return sb.toString();
    }
}
