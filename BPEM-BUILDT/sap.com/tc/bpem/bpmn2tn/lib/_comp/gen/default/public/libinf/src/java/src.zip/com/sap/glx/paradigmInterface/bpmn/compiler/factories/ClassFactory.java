package com.sap.glx.paradigmInterface.bpmn.compiler.factories;

import java.util.HashMap;
import java.util.Map;

import com.sap.glx.ide.model.classes.Attribute;
import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.classes.Method;
import com.sap.glx.ide.model.classes.Parameter;
import com.sap.glx.ide.model.classes.Type;
import com.sap.glx.ide.model.galaxy.core.ModelElement;
import com.sap.glx.ide.model.triggernet.Subnet;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.IdentifierHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.VersioningHelper;

public class ClassFactory extends BaseFactory {

    private VersioningHelper versioningHelper;
    private Map<String, Integer> classIds = new HashMap<String, Integer>();

    public ClassFactory(Subnet subnet, VersioningHelper versioningHelper) {
        super(subnet);
        this.versioningHelper = versioningHelper;
    }

    public static int getAttributeIndex(GalaxyClass cls, String attribute_name) {
        for (int i = 0; i < cls.getAttribute().size(); i++) {
            if (cls.getAttribute().get(i).getName().equals(attribute_name))
                return i;
        }
        return -1;
    }

    /**
     * Generates a valid class name based on a Model element and a prefix. It is ensured that this name is unique even if the model element
     * and the prefix are the same.
     * 
     * @param anchorName the name (of the model element) which will get part of the valid class name
     * @param name must be a valid identifier in terms of the script syntax
     */
    private String calculateClassName(String anchorName, String name) {
        int classId = 0;
        if (classIds.containsKey(name))
            classId = classIds.get(name) + 1;
        classIds.put(name, classId);
        return IdentifierHelper.createIdentifier(name, classId, anchorName);
    }

    public GalaxyClass generateClass(ModelElement artifact, String name, String adapter) throws BPMNCompilerException {
        GalaxyClass cls = createElement(GalaxyClass.class);
        cls.setName(calculateClassName(artifact.getOriginalName(), name));
        cls.setAdapter(adapter);
        subnet.getGalaxyClass().add(cls);

        // any newly generated class must be versioned in order to properly interact with the kernel's linking mechanism
        versioningHelper.registerClassVersioningCallback(cls);
        return cls;
    }
    
    public GalaxyClass generateClass(String artifactName, String name, String adapter) throws BPMNCompilerException {
        GalaxyClass cls = createElement(GalaxyClass.class);
        cls.setName(calculateClassName(artifactName, name));
        cls.setAdapter(adapter);
        subnet.getGalaxyClass().add(cls);

        // any newly generated class must be versioned in order to properly interact with the kernel's linking mechanism
        versioningHelper.registerClassVersioningCallback(cls);
        return cls;
    }
    

    public GalaxyClass generateRoot(ModelElement artifact, String name, String adapter) throws BPMNCompilerException {
        GalaxyClass cls = generateClass(artifact, name, adapter);
        cls.setEvictable(true);
        return cls;
    }

    public GalaxyClass generateImmutable(ModelElement artifact, String name, String adapter) throws BPMNCompilerException {
        GalaxyClass cls = generateClass(artifact, name, adapter);
        cls.setImmutable(true);
        return cls;
    }

    public Attribute addAttribute(GalaxyClass cls, String name, Type type) {
        Attribute attribute = createElement(Attribute.class);
        attribute.setName(name);
        attribute.setAttributeType(type);
        cls.getAttribute().add(attribute);
        return attribute;
    }

    public Method addMethod(GalaxyClass cls, String name, Type return_type, Type... parameter_types) {
        return addMethod(cls, name, false, return_type, parameter_types);
    }

    public Method addMethod(GalaxyClass cls, String name, boolean constant, Type return_type, Type... parameter_types) {
        Method method = createElement(Method.class);
        method.setName(name);
        method.setConstant(false);
        method.setResultType(return_type);
        cls.getMethod().add(method);
        for (int i = 0; i < parameter_types.length; i++) {
            Parameter parameter = createElement(Parameter.class);
            parameter.setType(parameter_types[i]);
            method.getParameter().add(parameter);
        }
        return method;
    }
}
