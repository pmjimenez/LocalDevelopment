package com.sap.glx.paradigmInterface.bpmn.compiler.helpers.eventlog;

import java.util.ArrayList;
import java.util.List;

public enum EventTypeIds {

    // event names are supposed to match the events as
    // BPEM-CORE/dev/active/DCs/sap.com/tc/bpem/process/ejb/_comp/ejbModule/com/sap/glx/process/util/bpmn2/transformation/PVMonitoringExtensionsTransformation.xsl
    // creates them

    START_TRIGGERED(1, "Triggered"),
    END_TRIGGERED(2, "Triggered"),
    USER_TASK_CREATED(101, "Created"),
    USER_TASK_COMPLETED(102, "Completed"),
    USER_TASK_CLAIMED(103, "Claimed"),
    USER_TASK_REVOKED(104), // "Revoked"),
    USER_TASK_DELEGATED(105), // "Delegated"),
    USER_TASK_NOMINATED(106), // "Nominated"),
    USER_TASK_ESCALATED(107), // "Escalated"),
    SERVICE_TASK_STARTED(201, "Started"),
    SERVICE_TASK_COMPLETED(202, "Completed"),
    INTERMEDIATE_EVENT_TRIGGERED(301), // "Triggered"),
    CALL_ACTIVITY(400),
    CALL_ACTIVITY_STARTED(401, "Started"),
    CALL_ACTIVITY_COMPLETED(402, "Completed"),
    SUB_PROCESS_STARTED(501),
    SUB_PROCESS_COMPLETED(502),
    DATA_OBJECT_PERSISTED(600, "Persisted");

    private final int id;
    private final String eventName;

    private final boolean inUse;

    private EventTypeIds(final int id, final String eventName) {
        this.id = id;
        this.eventName = eventName;
        this.inUse = true;
    }

    private EventTypeIds(final int id) {
        this.id = id;
        this.eventName = null;
        this.inUse = false;
    }

    public int getId() {
        return id;
    }

    public String getEventName() {
        return eventName;
    }

    /*
     * returns whether the event type is one the runtime/the compiler corresponding to the runtime is supposed to provide
     */
    public boolean isInUse() {
        return inUse;
    }

    public static EventTypeIds get(final int id) {
        for (final EventTypeIds eventTypeId : EventTypeIds.values()) {
            if (eventTypeId.getId() == id) {
                return eventTypeId;
            }
        }
        throw new IllegalArgumentException(String.format("Id %d not found!", id));
    }

    public static EventTypeIds[] getEventTypeIdsInUse() {
        final List<EventTypeIds> result = new ArrayList<EventTypeIds>();
        final EventTypeIds[] allIds = EventTypeIds.values();
        for (final EventTypeIds eventTypeId : allIds) {
            if (eventTypeId.isInUse()) {
                result.add(eventTypeId);
            }
        }
        return result.toArray(new EventTypeIds[result.size()]);
    }
}
