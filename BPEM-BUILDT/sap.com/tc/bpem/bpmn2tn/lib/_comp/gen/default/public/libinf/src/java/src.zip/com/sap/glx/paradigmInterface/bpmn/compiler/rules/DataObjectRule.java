package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.sap.glx.constants.DataContainerConstants;
import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.classes.Type;
import com.sap.glx.ide.model.galaxy.core.ModelElement;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.DataObject;
import com.sap.glx.ide.model.galaxy.workflow.EmbeddedScope;
import com.sap.glx.ide.model.galaxy.workflow.LoopCharacteristics;
import com.sap.glx.ide.model.galaxy.workflow.MultiInstanceLoopCharacteristics;
import com.sap.glx.ide.model.galaxy.workflow.Scope;
import com.sap.glx.ide.model.triggernet.ConstantFilter;
import com.sap.glx.ide.model.triggernet.GenericOperator;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.Node;
import com.sap.glx.ide.model.triggernet.ParameterFilter;
import com.sap.glx.ide.model.triggernet.Source;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerState;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ContextHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ScriptHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.WSDLHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.WorkflowHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.IntegerLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.StringLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.Variable;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.ContextCascadeNode;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.DonFrame;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.FrameNode;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.ProjectionNode;

/**
 * A compiler rule for data objects.
 * 
 * @author Thilo-Alexander Ginkel
 * 
 * @version $Id: //bpem/bpem.bp/NW731EXT_17_REL/src/SCs/sap.com/BPEM-BUILDT/DCs/sap.com/tc/bpem/bpmn2tn/lib/_comp/src/com/sap/glx/paradigmInterface/bpmn/compiler/rules/DataObjectRule.java#1 $
 */
public class DataObjectRule extends BaseCompilerRule<DataContainer> implements CompilerRule<DataContainer> {
    private Join m_container_cleanup_join;
    private Join m_instance_task_listener_join;
    private Join m_instance_task_context_join;
    private Join m_instance_listener_join;
    private Join m_instance_context_join;
    private Map<GalaxyClass, Join> m_frame_context_cleanup_joins = new HashMap<GalaxyClass, Join>();
    
    
    /*
     * @see com.sap.glx.paradigmInterface.bpmn.compiler.rules.CompilerRule#getSupportedArtifact()
     */
    @SuppressWarnings("unchecked")
    public Class getSupportedArtifact() {
        return DataObject.class;
    }

    /*
     * @see com.sap.glx.paradigmInterface.bpmn.compiler.rules.BaseCompilerRule#preprocess(com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext)
     */
    @Override
    public void preprocess(CompilerContext ctx) throws BPMNCompilerException {
        
        //assigns index / variable names for scripts -> move indexing to join cascade
        //assignVariableNames(ctx);
                
        if (ctx.isTaskFlow()) {
            // task=listener.target
            m_instance_task_listener_join = ctx.getJoinFactory().generateJoin(ctx.getRootScope(), "instance_task_listener", "0/1/-1", "1/0/1");
            NodeFactory.connectNodes(ctx.getState().getInstanceTaskJoin(), 0, m_instance_task_listener_join, 0);
            NodeFactory.connectNodes(ctx.getState().getListenerSource(), 0, m_instance_task_listener_join, 1);
            
            // instance=context.owner
            m_instance_task_context_join = ctx.getJoinFactory().generateJoin(ctx.getRootScope(), "instance_task_context", "0/0/-1", "1/0/0");
            NodeFactory.connectNodes(m_instance_task_listener_join, 1, m_instance_task_context_join, 0);

            // remove listener once the task has gone
            if (this instanceof ViewRule) {
                NodeFactory.connectNodes(m_instance_task_listener_join, 2, ctx.getReplicator().getSingularity(), 0);
            } else {
                NodeFactory.connectNodes(m_instance_task_listener_join, 2, ctx.getReplicator().getBlackHole(), 0);
            }

            // create a listener if none exists for this instance, task, container
            GenericOperator task_listener_creation_target = ctx.getExecutionFactory().generateExecution(ctx.getRootScope(), "create_task_listener");
            ctx.getExecutionFactory().setScript(task_listener_creation_target, generateTaskListenerCreationScriptHeader(ctx), generateTaskListenerCreationScriptBody(ctx, task_listener_creation_target));
            NodeFactory.connectNodes(m_instance_task_context_join, 0, task_listener_creation_target, 0);
        } else {
            // instance=listener.target
            m_instance_listener_join = ctx.getJoinFactory().generateJoin(ctx.getRootScope(), "instance_listener", "0/0/-1","1/0/1");
            NodeFactory.connectNodes(ctx.getState().getInstanceSource(), 0, m_instance_listener_join, 0);
            NodeFactory.connectNodes(ctx.getState().getListenerSource(), 0, m_instance_listener_join, 1);
            
            // instance=context.owner
            m_instance_context_join = ctx.getJoinFactory().generateJoin(ctx.getRootScope(), "instance_context", "0/0/-1", "1/0/0");
            NodeFactory.connectNodes(m_instance_listener_join, 1, m_instance_context_join, 0);
            
            // remove listener once the instance has gone
            if (this instanceof ViewRule) {
                NodeFactory.connectNodes(m_instance_listener_join, 2, ctx.getReplicator().getSingularity(), 0);
            } else {
                NodeFactory.connectNodes(m_instance_listener_join, 2, ctx.getReplicator().getBlackHole(), 0);
            }
            
            GenericOperator instance_listener_creation_target = ctx.getExecutionFactory().generateExecution(ctx.getRootScope(), "create_instance_listener");
            ctx.getExecutionFactory().setScript(instance_listener_creation_target, generateInstanceListenerCreationScriptHeader(ctx), generateInstanceListenerCreationScriptBody(ctx,instance_listener_creation_target));
            NodeFactory.connectNodes(m_instance_context_join, 0, instance_listener_creation_target, 0);         
        }

     }
 
    protected String generateInstanceUpdateScriptHeader(CompilerContext ctx, DataContainer container) throws BPMNCompilerException {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateHeaderPrefix(ctx.getRootScope(), CompilerConstants.TARGET_UPDATE_INSTANCE, container));
        sb.append(ScriptHelper.generateClassDeclaration(ctx.getState().getInstanceSource().getGalaxyClass(), new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(ctx.getState().getListenerSource().getGalaxyClass(), new Variable(CompilerConstants.SCRIPT_VARIABLE_LISTENER)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(ctx.getContextHelper().getClassByDataObject(container), new Variable(CompilerConstants.SCRIPT_VARIABLE_CONTEXT)));
        sb.append(") ");
        return sb.toString();
    }
    
    protected String generateInstanceUpdateScriptBody(CompilerContext ctx, DataContainer container, GenericOperator target) {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateBodyPrefix(
                ctx.getState().getExitClass(), 
                CompilerConstants.BITMASK_NO_CALLBACK, 
                null, 
                target, 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_LISTENER), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_CONTEXT)));
        
        sb.append(ScriptHelper.generateScopeCode(
                ctx.getState().getControllerClass(), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));
        
        // modifications=context:modifications;
        sb.append(ScriptHelper.generateAssignCommand(
                new Variable(CompilerConstants.SCRIPT_VARIABLE_MODIFICATIONS), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_CONTEXT),
                CompilerConstants.ATTRIBUTE_MODIFICATIONS));
        
        // listener:modifications=modifications;
        sb.append(ScriptHelper.generateUpdateCommand(
                new Variable(CompilerConstants.SCRIPT_VARIABLE_LISTENER), 
                CompilerConstants.ATTRIBUTE_MODIFICATIONS, 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_MODIFICATIONS)));
        
        // instance:updateContainerObject(<ctx name>, ctx)
        sb.append(ScriptHelper.generateInvocationCommand(
                null, 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT), 
                "updateContainerObject", 
                new StringLiteral(container.getOriginalName()),
                new Variable(CompilerConstants.SCRIPT_VARIABLE_CONTEXT)));    
        sb.append("}");
        return sb.toString();
    }

    protected String generateTaskUpdateScriptHeader(CompilerContext ctx, DataContainer container) throws BPMNCompilerException {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateHeaderPrefix(
                ctx.getRootScope(), 
                CompilerConstants.TARGET_UPDATE_TASK, 
                container));
        sb.append(ScriptHelper.generateClassDeclaration(
                ctx.getState().getInstanceSource().getGalaxyClass(), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(
                ctx.getState().getTaskSource().getGalaxyClass(),
                new Variable(CompilerConstants.SCRIPT_VARIABLE_TASK)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(
                ctx.getState().getListenerSource().getGalaxyClass(), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_LISTENER)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(
                ctx.getContextHelper().getClassByDataObject(container), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_CONTEXT)));
        sb.append(") ");
        return sb.toString();
    }
    
    protected String generateTaskUpdateScriptBody(CompilerContext ctx, DataContainer container, GenericOperator target) {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateBodyPrefix(
                ctx.getState().getExitClass(), 
                CompilerConstants.BITMASK_NO_CALLBACK, 
                null, 
                target, 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_CONTEXT), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_TASK), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_LISTENER)));
        
        sb.append(ScriptHelper.generateScopeCode(
                ctx.getState().getControllerClass(), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));
        
        // modifications=context:modifications;
        sb.append(ScriptHelper.generateAssignCommand(
                new Variable(CompilerConstants.SCRIPT_VARIABLE_MODIFICATIONS), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_CONTEXT), 
                CompilerConstants.ATTRIBUTE_MODIFICATIONS));
        
        // listener:modifications=modifications;
        sb.append(ScriptHelper.generateUpdateCommand(
                new Variable(CompilerConstants.SCRIPT_VARIABLE_LISTENER), 
                CompilerConstants.ATTRIBUTE_MODIFICATIONS, 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_MODIFICATIONS)));
        
        // task:updateContainerObject(<ctx name>, ctx)
        sb.append(ScriptHelper.generateInvocationCommand(
                null, 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_TASK),
                "updateContainerObject",
                new StringLiteral(container.getOriginalName()),
                new Variable(CompilerConstants.SCRIPT_VARIABLE_CONTEXT)));    
        sb.append("}");
        return sb.toString();
    }

    protected String generateInstanceListenerCreationScriptHeader(CompilerContext ctx) {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateHeaderPrefix(
                ctx.getRootScope(), 
                CompilerConstants.TARGET_CREATE_LISTENER, 
                null));
        sb.append(ScriptHelper.generateClassDeclaration(
                ctx.getState().getInstanceSource().getGalaxyClass(), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(
                null, 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_CONTEXT)));
        sb.append(") ");
        return sb.toString();
    }
    
    protected String generateInstanceListenerCreationScriptBody(CompilerContext ctx, GenericOperator target) throws BPMNCompilerException {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateBodyPrefix(
                ctx.getState().getExitClass(), 
                CompilerConstants.BITMASK_NO_CALLBACK, 
                null, 
                target, 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_CONTEXT)));
        
        sb.append(ScriptHelper.generateScopeCode(
                ctx.getState().getControllerClass(), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));
        
        // new BPMNAdapter:Listener(context,parent,0);
        sb.append(ScriptHelper.generateNewCommand(
                null, 
                ctx.getState().getListenerSource().getGalaxyClass(), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_CONTEXT),
                new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT), 
                new IntegerLiteral(0)));

        sb.append("}");
        return sb.toString();
    }

    protected String generateTaskListenerCreationScriptHeader(CompilerContext ctx) {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateHeaderPrefix(
                ctx.getRootScope(), 
                CompilerConstants.TARGET_CREATE_LISTENER, 
                null));
        sb.append(ScriptHelper.generateClassDeclaration(
                ctx.getState().getInstanceSource().getGalaxyClass(), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(
                ctx.getState().getTaskSource().getGalaxyClass(), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_TASK)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(
                null, 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_CONTEXT)));
        sb.append(") ");
        return sb.toString();
    }
    
    protected String generateTaskListenerCreationScriptBody(CompilerContext ctx, GenericOperator target) throws BPMNCompilerException {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateBodyPrefix(
                ctx.getState().getExitClass(), 
                CompilerConstants.BITMASK_NO_CALLBACK, 
                null, 
                target, 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_TASK), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_CONTEXT)));
        
        sb.append(ScriptHelper.generateScopeCode(
                ctx.getState().getControllerClass(), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));
        
        // new BPMNAdapter:Listener(context,task,0);
        sb.append(ScriptHelper.generateNewCommand(
                null, 
                ctx.getState().getListenerSource().getGalaxyClass(), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_CONTEXT), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_TASK),
                new IntegerLiteral(0)));

        sb.append("}");
        return sb.toString();
    }

//    @SuppressWarnings("unchecked")
//    protected void assignVariableNames(CompilerContext ctx) {
//        Collection<DataContainer> containers = ctx.getArtifacts(getSupportedArtifact());
//        if (containers != null) {
//            Map<DataContainer, Integer> globalContextIndex = ctx.getState().getGlobalContextIndex();
//            Map<DataContainer, String> globalContextVarNames = ctx.getState().getGlobalContextVarNames();
//            int ii = globalContextIndex.size();
//
//            for (DataContainer container : containers) {
//                globalContextIndex.put(container, ii);
//                if (ctx.getPropertyAsBoolean(CompilerConstants.PROPERTY_COMPRESS_VARIABLE_NAMES, false)) {
//                    // compress variable names to save memory
//                    globalContextVarNames.put(container, ctx.getIdentifierHelper().generateShortScriptVariable());
//                } else {
//                    globalContextVarNames.put(container, WorkflowHelper.isTaskStatusDataObject(ctx, container) ? "task" : (container instanceof DataObject ? "context" : container instanceof ProcessRole ? "role" : "view") + "_" + ii);
//                }
//                ii++;
//            }
//
//        }
//    }

    /*
     * @see com.sap.glx.paradigmInterface.bpmn.compiler.rules.CompilerRule#compile(com.sap.glx.ide.model.galaxy.workflow.FlowObject,
     *      com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext)
     */
    public void compile(DataContainer dataObject, CompilerContext ctx) throws BPMNCompilerException {
        ctx.getValidator().validate(dataObject.getXsdElementDeclaration() != null, "BPM.rt_c_bpmn.000023",
                "No element was associated to data object '%s'.", dataObject.getOriginalName());

        if (isDataObjectFiltered(dataObject, ctx)) {
            return;
        }
        CompilerState state = ctx.getState();
        Scope dataObjectScope = dataObject.getScope();
        
        //assigns a static context variable name (for use in scripts) for each given data object 
        state.assignContextVariableName(dataObject);
  
        DonFrame derDon = state.getDonFrame();
        FrameNode frameNode = derDon.getFrameNode4Scope(dataObjectScope);
        //for generating the class declaration
        GalaxyClass ownerClass = frameNode.getGalaxyClass();
        Type ownerType = ownerClass;
        //for use in state.getDataContainer4Frame
        FrameNode ownerFrameNode = frameNode;
        
        if (WorkflowHelper.isTaskStatusDataObject(ctx, dataObject)) {
            ctx.getContextHelper().addContextVariable(dataObject, ctx.getState().getTaskSource().getGalaxyClass(), ctx.getDependencyHelper().getScopeClassOld(ctx.getDependencyHelper().getScopeOld(dataObject)));
        } else {
            //special loop handling, currentCollectionItem and numberOfCompletedItems DataContainers
            boolean isLoopCurrentCollectionItem = false;
            boolean isLoopCompletedIterations = false;
            if(dataObjectScope instanceof EmbeddedScope ){
                EmbeddedScope embeddedDataScope = (EmbeddedScope)dataObjectScope;
                LoopCharacteristics loopCharacteristics = embeddedDataScope.getLoopCharacteristics();
                if(loopCharacteristics!=null && loopCharacteristics instanceof MultiInstanceLoopCharacteristics){
                    DataContainer dataLoopCurrentCollectionItem = ((MultiInstanceLoopCharacteristics)loopCharacteristics).getCurrentCollectionItemDo();
                    DataContainer dataLoopNumberOfCompleted = ((MultiInstanceLoopCharacteristics)loopCharacteristics).getNumberOfCompletedIterationsDo();
                    if(dataObject.equals(dataLoopCurrentCollectionItem)){
                        isLoopCurrentCollectionItem = true;
                        ownerType = ctx.getSimpleTypes().REFERENCE;
                    }else if(dataObject.equals(dataLoopNumberOfCompleted)){
                        isLoopCompletedIterations = true;
                        ownerFrameNode = frameNode.getParent();
                        ownerClass = frameNode.getParent().getGalaxyClass();
                        ownerType = ownerClass;
                    }
                }   
            }
            
            GalaxyClass containerClass = ctx.getReplicator().generateContainerClass(    
                    dataObject, 
                    ownerType,
                    ctx.getDependencyHelper().getScopeClassOld(ctx.getDependencyHelper().getScopeOld(dataObject)));
            ctx.getValidator().validate(WSDLHelper.getElementType(dataObject.getXsdElementDeclaration()) != null, 
                    "BPM.rt_c_bpmn.000024", "The data object '%s' does not have any type assigned to it", dataObject.getOriginalName());
            
            //add additional methods for the generated loop data objects   
            if(isLoopCurrentCollectionItem){
                //cloneForEach(DOList)
                ctx.getClassFactory().addMethod(containerClass, CompilerConstants.METHOD_LOOP_CONTEXT_SPLIT_LIST, ctx.getSimpleTypes().VOID, ctx.getSimpleTypes().ANY);     
            }else if(isLoopCompletedIterations){
                //do_#.increment()
                ctx.getClassFactory().addMethod(containerClass, CompilerConstants.METHOD_LOOP_CONTEXT_INCREMENT_COUNTER, ctx.getSimpleTypes().VOID);
                //do_#.initialize()
                ctx.getClassFactory().addMethod(containerClass, CompilerConstants.METHOD_LOOP_CONTEXT_INITIALIZE_COUNTER, ctx.getSimpleTypes().VOID);
            }         
           
            Source dataObjectSource = ctx.getSourceFactory().getSource4Class(containerClass);
            
            //TODO clarify
            ctx.getConfigFactory().generateDataContainerConfiguration(containerClass, dataObject);
            ctx.getContextHelper().addContextVariable(dataObject, containerClass, ctx.getDependencyHelper().getScopeClassOld(ctx.getDependencyHelper().getScopeOld(dataObject)));
            
            
            // notify task whenever context object is updated
            if (ctx.isTaskFlow()) {
                //task flow does not have nested scopes, all data objects reside on root level
                // connect this context variable to the global join
                NodeFactory.connectNodes(dataObjectSource, 0, m_instance_task_context_join, 1);
                
                // listener.source=context
                Join instance_task_listener_context_join = ctx.getJoinFactory().generateJoin(dataObject, "instance_task_listener_context", "0/2/0", "1/0/-1");
                NodeFactory.connectNodes(m_instance_task_listener_join, 0, instance_task_listener_context_join, 0);
                NodeFactory.connectNodes(dataObjectSource, 0, instance_task_listener_context_join, 1);
                               
                GenericOperator task_update_target = ctx.getExecutionFactory().generateExecution(dataObject, "update_task");
                ctx.getExecutionFactory().setScript(task_update_target, generateTaskUpdateScriptHeader(ctx, dataObject), generateTaskUpdateScriptBody(ctx, dataObject, task_update_target));
                
                // listener.modifications = context.modifications
                ParameterFilter listener_filter = ctx.getParameterFilterFactory().generateFilter(ctx.getRootScope(), "task_listener_modifications", "0/2/2", "0/3/2", "!=");
                NodeFactory.connectNodes(instance_task_listener_context_join, 0, listener_filter, 0);
                NodeFactory.connectNodes(listener_filter, 0, task_update_target, 0);
            } else {
                if(isDataObjectOfSpecialInterest(dataObject)){
                    //it is assumed that data objects of special interest always reside on the root level
                    NodeFactory.connectNodes(dataObjectSource, 0, m_instance_context_join, 1);
                    // listener.source=context
                    Join instance_listener_context_join = ctx.getJoinFactory().generateJoin(dataObject, "instance_listener_context", "0/1/0", "1/0/-1");
                    NodeFactory.connectNodes(m_instance_listener_join, 0, instance_listener_context_join, 0);
                    NodeFactory.connectNodes(dataObjectSource, 0, instance_listener_context_join, 1);
                    
                    GenericOperator instance_update_target = ctx.getExecutionFactory().generateExecution(dataObject, "update_instance");
                    ctx.getExecutionFactory().setScript(instance_update_target, generateInstanceUpdateScriptHeader(ctx,dataObject), generateInstanceUpdateScriptBody(ctx,dataObject,instance_update_target));
                
                    ParameterFilter listener_filter = ctx.getParameterFilterFactory().generateFilter(ctx.getRootScope(), "instance_listener_modifications", "0/1/2", "0/2/2", "!=");
                    NodeFactory.connectNodes(instance_listener_context_join, 0, listener_filter, 0);
                    NodeFactory.connectNodes(listener_filter, 0, instance_update_target, 0);
                }
            }
            /**
             * deletion
             */
            if (ctx.getRootScope().equals(dataObjectScope)) {
                // is global data object
                if (m_container_cleanup_join == null) {
                    // only create once if needed
                    m_container_cleanup_join = ctx.getJoinFactory()
                            .generateJoin(ctx.getRootScope(), "container_cleanup", "0/0/-1", "1/0/0");
                    NodeFactory.connectNodes(ctx.getState().getInstanceSource(), 0, m_container_cleanup_join, 0);
                    NodeFactory.connectNodes(m_container_cleanup_join, 2, ctx.getReplicator().getDrain(), 0);
                }
                NodeFactory.connectNodes(ctx.getSourceFactory().getSource4Class(containerClass), 0, m_container_cleanup_join, 1);
            } else {
                // frame data object
                if (isLoopCurrentCollectionItem) {
                    /*
                     * scope has loop characteristics, this is the current collection item DO special deletion handling for
                     * numberOfCompletedItems and currentCollectionItem in order to guarantee loop cycle starts deletion will be handled in
                     * the EmbeddedScopeRule
                     */
                } else {
                    Join cleanup = m_frame_context_cleanup_joins.get(ownerClass);
                    if (cleanup == null) {
                        cleanup = ctx.getJoinFactory().generateJoin(ownerClass, "frame_context_cleanup", "0/0/-1", "1/0/0");
                        Source frameSource = ctx.getSourceFactory().getSource4Class(ownerClass);
                        NodeFactory.connectNodes(frameSource, 0, cleanup, 0);
                        NodeFactory.connectNodes(cleanup, 2, ctx.getReplicator().getDrain(), 0);
                        m_frame_context_cleanup_joins.put(ownerClass, cleanup);
                    }
                    NodeFactory.connectNodes(dataObjectSource, 0, cleanup, 1);
                }
            }
        }

        // add DataObjects as well as Views
        state.addDataContainer4Frame(ownerFrameNode, dataObject);
    }

    /*
     * @see com.sap.glx.paradigmInterface.bpmn.compiler.rules.BaseCompilerRule#postprocess(com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext)
     */
    @Override
    public void postprocess(CompilerContext ctx) throws BPMNCompilerException {
        CompilerState state = ctx.getState();
        DonFrame derDon = state.getDonFrame();
        FrameNode rootFrame = derDon.getRootFrameNode();
        this.buildContextJoinCascades(ctx, state, rootFrame, derDon);
        state.contextCascadeIsCreated();
    }
    
//    /**
//     * assigns a static context variable name (for use in scripts) for each given data object with use of a running index 
//     * @param ctx
//     * @param containers
//     * @throws BPMNCompilerException
//     */
//    protected void assignScriptVariableNames(CompilerContext ctx, Set<? extends DataContainer> containers) throws BPMNCompilerException{
//      if(containers==null || containers.isEmpty()){
//          return;
//      }
//      Map<DataContainer, String> globalVarNames = ctx.getState().getGlobalContextVarNames();
//      int runningIndex = globalVarNames.size();
//      for(DataContainer container : containers){
//          if(!globalVarNames.containsKey(container)){
//              runningIndex++;
//              globalVarNames.put(container, WorkflowHelper.isTaskStatusDataObject(ctx, container) ? "task" : (container instanceof DataObject ? "context" : container instanceof ProcessRole ? "role" : "view") + "_" + runningIndex);
//          }
//      }
//    }
   
    
     
    private boolean isDataObjectOfSpecialInterest(DataContainer dataObject){
        String originalName = dataObject.getOriginalName();
        return DataContainerConstants.isDefinedAsConstant(originalName);
    }
    
  
    
    
    /**
     * the mighty projection node constructor
     * traverses all scope hierarchies and creates projection nodes for each scope which can be used for mappings etc 
     * @param ctx
     * @param state
     * @param currentFrame
     * @throws BPMNCompilerException
     */
    private void buildContextJoinCascades(CompilerContext ctx, CompilerState state, FrameNode currentFrame, DonFrame derDon) throws BPMNCompilerException{
        
        Scope currentScope = currentFrame.getScope()!=null?currentFrame.getScope():ctx.getRootScope();
        Set<DataContainer> currentDataObjects = state.getDataContainer4Frame(currentFrame);
        ContextHelper ctxHelper = ctx.getContextHelper();
        
        //construct a context join cascade with the given data containers
        //null if scope contains no data objects
        ContextCascadeNode currentLevelJoinCascade = buildContextJoinCascadeNetwork(ctx, currentScope, currentDataObjects);
        
        if(derDon.isRootScope(currentFrame)){
            //is root scope -> use this as projection
            ProjectionNode projectionNode = null;
            if(currentLevelJoinCascade == null){
                ctx.getValidator().warning("No data objects could be found in root scope, not possible to build data object cascade.");
            }else{
                projectionNode = new ProjectionNode(currentLevelJoinCascade.getCascadeNode());
                //projection node has to be configured with incoming data objects and their index
                int projectionIndex = -1;
                Enumeration<DataContainer> dataEnum = currentLevelJoinCascade.getOrderedDataContainer(); 
                while(dataEnum.hasMoreElements()){
                    projectionIndex++;
                    DataContainer data = dataEnum.nextElement();
                    projectionNode.addObjectIndex(ctxHelper.getClassByDataObject(data), projectionIndex);
                }
                projectionNode.setLastIndex(projectionIndex);   
            }   
            currentFrame.setProjectionNode(projectionNode);
        }else{
            //current scope is an embedded scope
            //get corresponding frame source
            GalaxyClass frameClass = currentFrame.getGalaxyClass();
            if(frameClass == null){
                throw new BPMNCompilerException("Could not resolve galaxy class for embedded scope of data object.");
            }
            Source frameSource = ctx.getSourceFactory().getSource4Class(frameClass);
            
            //join with cascade of owned data objects or use only frame if there are no data objects 
            //cascade node is used to connect to the projection node
            Node cascadeFrameNode = null;
            Enumeration<DataContainer> dataEnum;
            if(currentLevelJoinCascade == null){
                cascadeFrameNode = frameSource;
                dataEnum = Collections.enumeration(new ArrayList<DataContainer>());
            }else{
                cascadeFrameNode = ctx.getJoinFactory().generateJoin(ctx.getRootScope(), "frame_context_cascade_join", "0/0/-1", "1/0/0");
                NodeFactory.connectNodes(frameSource, 0, cascadeFrameNode, 0);
                NodeFactory.connectNodes(currentLevelJoinCascade.getCascadeNode(), 0, cascadeFrameNode, 1);
                dataEnum = currentLevelJoinCascade.getOrderedDataContainer();
            }
            
            //build the projection
            //get parent projection join and connect
            FrameNode parentForProjection = currentFrame.getParent();
            ProjectionNode parentProjection = parentForProjection.getProjectionNode();
            
            if(parentProjection == null){
                if(ctx.getRootScope().equals(parentForProjection.getScope())){
                    //parent is the root scope and it has no data objects - should be very rare if not impossible
                    //use no parent projection
                    ProjectionNode projectionNode = new ProjectionNode(cascadeFrameNode);
                    int projectionIndex = 0;
                    projectionNode.addObjectIndex(currentFrame.getGalaxyClass(), projectionIndex);
                    while(dataEnum.hasMoreElements()){
                        projectionIndex++;
                        DataContainer data = dataEnum.nextElement();
                        projectionNode.addObjectIndex(ctxHelper.getClassByDataObject(data), projectionIndex);
                    }
                    projectionNode.setLastIndex(projectionIndex);
                    currentFrame.setProjectionNode(projectionNode);
                }else{
                    //this should never happen
                    throw new BPMNCompilerException("Data object handling: parent of embedded scope has no projection join node.");
                }
            }else{
                //parent projection not null
                Join frameProjectionJoin = null;
                if(ctx.getRootScope().equals(parentForProjection.getScope())){
                    //parent for projection is root scope - use different join condition
                    //rootdataobject:owner = frame:parent
                    frameProjectionJoin = ctx.getJoinFactory().generateJoin(currentScope, "frame_top_context_projection_join", "0/0/0", "1/0/0");
                }else{
                    //parent is a frame
                    //frameA = frameB:parent
                    //parent frame(A): get index of frame from projection node of parent
                    int parentFrameIndex = parentProjection.getIndexOfObject(parentForProjection.getGalaxyClass());
                    if(parentFrameIndex<0){
                        throw new BPMNCompilerException("Data object handling: parent of embedded scope could not be resolved to an index.");
                    }
                    frameProjectionJoin = ctx.getJoinFactory().generateJoin(currentScope, "frame_context_projection_join", "0/"+parentFrameIndex+"/-1", "1/0/0");
                }
                NodeFactory.connectNodes(parentProjection.getProjectionNode(), 0, frameProjectionJoin, 0);
                NodeFactory.connectNodes(cascadeFrameNode, 0, frameProjectionJoin, 1);
                
                ProjectionNode projectionNode = new ProjectionNode(frameProjectionJoin);
                //populate with parent objects
                Map<GalaxyClass, Integer> parentIndexedObjects = parentProjection.getAllIndexedObjects();
                for(Map.Entry<GalaxyClass, Integer> parentIndexedObject : parentIndexedObjects.entrySet()){
                    projectionNode.addObjectIndex(parentIndexedObject.getKey(), parentIndexedObject.getValue());
                }
                int projectionIndex = parentProjection.getLastIndex(); 
                projectionIndex++;
                projectionNode.addObjectIndex(currentFrame.getGalaxyClass(), projectionIndex);
                while(dataEnum.hasMoreElements()){
                    projectionIndex++;
                    DataContainer data = dataEnum.nextElement();
                    projectionNode.addObjectIndex(ctxHelper.getClassByDataObject(data), projectionIndex);
                }
                projectionNode.setLastIndex(projectionIndex);
                currentFrame.setProjectionNode(projectionNode);
            }
        }   
 
        //traverse through children frames recursively
        if(currentFrame.hasChildren()){
            List<FrameNode> childFrames = currentFrame.getChildren();
            for(FrameNode childFrame : childFrames){
                this.buildContextJoinCascades(ctx, state, childFrame, derDon);
            }
        }
    }
    

    
    /**
     * build a JoinCascadeNetwork with the given data objects
     * return null if no data objects given
     * @param ctx
     * @param artifact
     * @param objects
     * @return
     * @throws BPMNCompilerException
     */
    private ContextCascadeNode buildContextJoinCascadeNetwork(CompilerContext ctx, ModelElement artifact, Collection<DataContainer> objects) throws BPMNCompilerException {
        if(objects == null || objects.size() == 0){
            return null;
        }
        Node last = null;
        LinkedList<DataContainer> orderedDataObjects = new LinkedList<DataContainer>();
        if (objects != null){
            for (DataContainer object : objects) {
                orderedDataObjects.add(object);
                if (last == null)
                    last = getFilteredDataObjectSource(ctx, object);
                else {
                    Join join = ctx.getJoinFactory().generateJoin(artifact, object.getOriginalName(), "0/0/0", "1/0/0");
                    NodeFactory.connectNodes(last, 0, join, 0);
                    NodeFactory.connectNodes(getFilteredDataObjectSource(ctx, object), 0, join, 1);
                    last = join;
                }
            }
        }
        if(last==null){
            return null;
        }
        ContextCascadeNode node = new ContextCascadeNode(last);
        node.appendDataContainers(orderedDataObjects);
        return node;
    }
    /**
     * Retrieves a source for a data object, which checks whether the data object's owner still exists.
     */
    private Node getFilteredDataObjectSource(CompilerContext ctx, DataContainer object) throws BPMNCompilerException {
        Source dataSource = ctx.getSourceFactory().getSource4Class(ctx.getContextHelper().getClassByDataObject(object));
        ConstantFilter ownerAlive = ctx.getConstantFilterFactory().generateFilter(object, "owner_alive", "0/0/0", "NULL", "!=");
        NodeFactory.connectNodes(dataSource, 0, ownerAlive, 0);
        return ownerAlive;
    }
    
    private boolean isDataObjectFiltered(DataContainer dataObject, CompilerContext ctx) {
        String originalName = dataObject.getOriginalName();
        if (originalName != null && originalName.equalsIgnoreCase(CompilerConstants.CUSTOM_ATTRIBUTES) && !ctx.isTaskFlow()) {
            return true;
        }
        return false;
    }
    
    
}
