package com.sap.glx.paradigmInterface.bpmn.compiler;

public enum Comparators {
    EQUAL {
        public String toString() {
            return "=="; 							//$NON-NLS-1$
        }
    },
    NOT_EQUAL {
        public String toString() {
            return "!=";							//$NON-NLS-1$
        }
    },
    GREATER {
        public String toString() {
            return ">";								//$NON-NLS-1$
        }
    },
    LESS {
        public String toString() {
            return "<";								//$NON-NLS-1$
        }
    },
    GREATER_OR_EQUAL {
        public String toString() {
            return ">=";							//$NON-NLS-1$
        }
    },
    LESS_OR_EQUAL {
        public String toString() {
            return "<=";							//$NON-NLS-1$
        }
    };
    
    public static Comparators parseComparator(String s) {
        if (s.equals("=") || s.equals("=="))		//$NON-NLS-1$ //$NON-NLS-2$
            return EQUAL;
        if (s.equals("!=") || s.equals("<>"))		//$NON-NLS-1$ //$NON-NLS-2$
            return NOT_EQUAL;
        if (s.equals(">"))							//$NON-NLS-1$
            return GREATER;
        if (s.equals(">="))							//$NON-NLS-1$
            return GREATER_OR_EQUAL;
        if (s.equals("<"))							//$NON-NLS-1$
            return LESS;
        if (s.equals("<="))							//$NON-NLS-1$
            return LESS_OR_EQUAL;
        return null;
    }
    
    /**
     * Very simple parsing facility for atomic predicates that take the form:
     * <left operand> <comparator> <right operand>, where <comparator> is from
     * {==, =, !=, <>, >=, <=, >, <} and neither left operand nor right operand 
     * contain a comparator symbol.
     * 
     * @param s is the atomic predicate
     * @return s split off into a left operand, a right operand and the comparator in between.
     */
    public static Triple<String,Comparators,String> splitAtomicPredicate(String s) {
        String[] symbols = {"==","!=","<>","<=",">=","=","<",">"};        //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$//$NON-NLS-4$//$NON-NLS-5$//$NON-NLS-6$//$NON-NLS-7$//$NON-NLS-8$
        
        for (String symbol: symbols) {
            int position = s.indexOf(symbol);
            if (position>=0) {
                return new Triple<String,Comparators,String>(s.substring(0,position).trim(),parseComparator(symbol),s.substring(position+symbol.length()).trim());
            }
        }
        return null;
    }
    
    public static Comparators reverseComparator(Comparators c) {
        switch(c) {
        case EQUAL: return NOT_EQUAL;
        case NOT_EQUAL: return EQUAL;
        case GREATER: return LESS_OR_EQUAL;
        case GREATER_OR_EQUAL: return LESS;
        case LESS: return GREATER_OR_EQUAL;
        case LESS_OR_EQUAL: return GREATER;
        }
        return null;
    }
    

}
