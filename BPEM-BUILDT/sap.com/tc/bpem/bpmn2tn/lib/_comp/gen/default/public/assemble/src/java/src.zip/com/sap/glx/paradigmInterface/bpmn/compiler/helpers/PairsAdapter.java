package com.sap.glx.paradigmInterface.bpmn.compiler.helpers;

import java.util.ArrayList;
import java.util.Collection;

import com.sap.mapping.base.compiler.helpers.Pair;

/**
 * Utility for adapting {@link com.sap.glx.paradigmInterface.bpmn.compiler.Pair} to {@link Pair} and vice versa 
 * @author I030720
 */
public class PairsAdapter<T1, T2>
{
	public Collection<com.sap.glx.paradigmInterface.bpmn.compiler.Pair<T1, T2>> toBpmnPairs(final Collection<Pair<T1, T2>> mappingPairs)
	{
		final Collection<com.sap.glx.paradigmInterface.bpmn.compiler.Pair<T1, T2>> result = new ArrayList<com.sap.glx.paradigmInterface.bpmn.compiler.Pair<T1,T2>>();
		for(Pair<T1, T2> p : mappingPairs)
		{
			result.add(toBpmnPair(p));
		}
		
		return result;
	}
	
	public com.sap.glx.paradigmInterface.bpmn.compiler.Pair<T1, T2> toBpmnPair(final Pair<T1, T2> mappingPair)
	{
		return new com.sap.glx.paradigmInterface.bpmn.compiler.Pair<T1, T2>(mappingPair.first, mappingPair.second);
	}
	
}
