package com.sap.glx.paradigmInterface.bpmn.compiler.helpers;

import java.util.regex.Pattern;

import com.sap.glx.ide.model.galaxy.core.ModelElement;
import com.sap.glx.ide.model.galaxy.workflow.Scope;

/**
 * Helper class to create valid identifiers for galaxy classes and script names.
 */
public class IdentifierHelper {

    private static Pattern NON_WORD_CHAR = Pattern.compile("\\W");
    
    private static String replaceNonWordCharacters(String input) {
        return NON_WORD_CHAR.matcher(input).replaceAll("_");
    }
    
    
    /**
     * Constructs a legal script or class name out of an arbitrary given name.
     * 
     * @param prefix The prefix is not allowed to be null.
     * @param names names which should be part of the constructed identifier. They are concatenated with '_' and any invalid characters are
     * replaced with '_'.
     * @return A valid identifier.
     */
    public static String createIdentifier(String prefix, Object... names) {
        StringBuilder sb = new StringBuilder(60);
        appendIdentifier(sb, prefix, names);
        return sb.toString();
    }

    /**
     * Appends a legal script or class name out of an arbitrary given name to a StringBuilder.
     * 
     * @see {@link #toGalaxyName(String, Object...)}
     * 
     * @sb the StringBuilder that name is appended to.
     * @param prefix The prefix is not allowed to be null and must have at least one character
     * @param names names which should be part of the constructed identifier. They are concatenated with '_' and any invalid characters are
     * replaced with '_'.
     */
    public static void appendIdentifier(StringBuilder sb, String prefix, Object... names) {
        if (Character.isDigit(prefix.charAt(0))) {
            sb.append('_');
        }
        sb.append(replaceNonWordCharacters(prefix));

        if (names != null) {
            for (int i = 0; i < names.length; i++) {
                String name = null;
                if (names[i] != null && (name = names[i].toString().trim()).length() > 0) {
                    sb.append('_');
                    sb.append(replaceNonWordCharacters(name));
                }
            }
        }
    }

    /**
     * Creates a legal script name out of the name of a scope.
     */
    public static String createNamespace(Scope scope) {
        // a '_' is required to avoid a namespace that matches with a script key word
        return '_' + replaceNonWordCharacters(scope.getOriginalName().trim());
    }

    /**
     * Constructs a filename out of an arbitrary model element. The model element must have a valid identifier as a name. This is normally
     * ensured by the process composer for all stand-alone model elements (processes, tasks, triggers, reporting definitions, ...).
     */
    public static String createFilename(ModelElement element, String extension) {
        StringBuilder sb = new StringBuilder(70);
        appendIdentifier(sb, element.getOriginalName(), element.refMofId());
        sb.append('.');
        sb.append(extension);
        return sb.toString();
    }
}
