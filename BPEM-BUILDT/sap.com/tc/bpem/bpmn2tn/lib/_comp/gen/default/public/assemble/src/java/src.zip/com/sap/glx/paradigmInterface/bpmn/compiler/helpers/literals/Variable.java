package com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals;

public class Variable implements Literal<String> {
    private String name;
    
    public Variable(String name) {
        this.name = name;
    }

    public String getValue() {
        return null; // unknown
    }
    
    public String toString() {
        return name;
    }
    


}
