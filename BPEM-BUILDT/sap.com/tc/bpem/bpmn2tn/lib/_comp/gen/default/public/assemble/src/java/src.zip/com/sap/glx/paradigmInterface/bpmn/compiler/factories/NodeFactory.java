package com.sap.glx.paradigmInterface.bpmn.compiler.factories;

import java.util.Locale;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.classes.SimpleTypesEnum;
import com.sap.glx.ide.model.configuration.AttributeSpecification;
import com.sap.glx.ide.model.configuration.TypedConstant;
import com.sap.glx.ide.model.galaxy.core.ModelElement;
import com.sap.glx.ide.model.triggernet.Input;
import com.sap.glx.ide.model.triggernet.Node;
import com.sap.glx.ide.model.triggernet.Output;
import com.sap.glx.ide.model.triggernet.Subnet;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.IdentifierHelper;
import com.sap.glx.paradigmInterface.facades.ITriggernetFacade;
import com.sap.glx.paradigmInterface.facades.TriggernetModelException;

public abstract class NodeFactory extends BaseFactory {

    private int index = 0;
    protected ITriggernetFacade facade;

    protected NodeFactory(ITriggernetFacade facade, Subnet subnet) {
        super(subnet);
        this.facade = facade;
    }

    /**
     * This method is used to name newly created nodes by the methods {@link #prepareNode(Node, ModelElement, String)}.
     * 
     * @return prefix used for naming nodes
     */
    protected abstract String getNodePrefix();

    /**
     * This method is to create the input channels by the methods {@link #prepareNode(Node, ModelElement, String)}.
     * 
     * @return number of input channels for this node type
     */
    protected abstract int getInputCount();

    /**
     * This method is to create the output channels by the methods {@link #prepareNode(Node, ModelElement, String)}.
     * 
     * @return number of output channels for this node type
     */
    protected abstract int getOutputCount();

    private void prepareNode(Node node, String name) {
        subnet.getNode().add(node);
        node.setName(name);
        for (int i = 0; i < getInputCount(); i++) {
            Input input = createElement(Input.class);
            node.getInputChannels().add(input);
        }
        for (int i = 0; i < getOutputCount(); i++) {
            Output output = createElement(Output.class);
            node.getOutputChannels().add(output);
        }
    }

    /**
     * This methods prepare a newly created node. This includes assign it to a trigger network and create input and output channels.
     * Furthermore a unique name is assigned based on the the input parameters.
     * 
     * @param node
     *            the node instance to be prepared
     * @param artifact
     *            the name of the artifact is used to create a unique name
     * @param name
     *            the optional name is also used to create a unique name and maybe {@code null}
     */
    protected void prepareNode(Node node, ModelElement artifact, String name) {
        String nodeName = IdentifierHelper.createIdentifier(getNodePrefix(), artifact.getOriginalName(), name, index++);
        prepareNode(node, nodeName);
    }

    /**
     * @see {@link #prepareNode(Node, String)}
     * 
     * @param node
     *            the node instance to be prepared
     * @param cls
     *            the galaxy class definition is used to create a unique name
     * @param name
     *            the optional name is also used to create a unique name and maybe {@code null}
     */
    protected void prepareNode(Node node, GalaxyClass cls, String name) {
        String nodeName = IdentifierHelper.createIdentifier(getNodePrefix(), cls.getName(), name, index++);
        prepareNode(node, nodeName);
    }

    /**
     * @see {@link #prepareNode(Node, String)}
     * 
     * @param node
     *            the node instance to be prepared
     * @param cls
     *            the galaxy class name is used to create a unique name
     * @param name
     *            the optional name is also used to create a unique name and maybe {@code null}
     */
    protected void prepareNode(Node node, Pair<String, String> cls, String name) {
        String nodeName = IdentifierHelper.createIdentifier(getNodePrefix(), cls.first, cls.second, name, index++);
        prepareNode(node, nodeName);
    }

    protected AttributeSpecification[] parseOperands(String operands) {
        String[] operands_array = operands.split("&"); //$NON-NLS-1$
        AttributeSpecification[] attributes = new AttributeSpecification[operands_array.length];
        for (int i = 0; i < operands_array.length; i++) {
            String[] attribute_array = operands_array[i].trim().split("/"); //$NON-NLS-1$
            attributes[i] = createElement(AttributeSpecification.class);
            attributes[i].setInputChannel(Integer.parseInt(attribute_array[0]));
            attributes[i].setParameterNumber(Integer.parseInt(attribute_array[1]));
            attributes[i].setAttributeId(Integer.parseInt(attribute_array[2]));
        }
        return attributes;
    }

    protected TypedConstant[] parseConstants(String operands) throws BPMNCompilerException {
        String[] operands_array = operands.split("&"); //$NON-NLS-1$
        TypedConstant[] constants = new TypedConstant[operands_array.length];
        try {
            for (int i = 0; i < operands_array.length; i++) {
                int colon = operands_array[i].trim().indexOf(':');
                if (colon != -1) {
                    String[] type_constant = new String[] { operands_array[i].substring(0, colon).trim(),
                            operands_array[i].substring(colon + 1).trim() };
                    // String[] type_constant = operands_array[i].trim().split(":");
                    constants[i] = createElement(TypedConstant.class);
                    constants[i].setValue(type_constant[1].trim());
                    if (type_constant[0].toUpperCase(Locale.ENGLISH).equals("STRING"))//$NON-NLS-1$
                        constants[i].setSimpleType(this.facade.getSimpleType(SimpleTypesEnum.STRING));
                    else if (type_constant[0].toUpperCase(Locale.ENGLISH).equals("INTEGER"))//$NON-NLS-1$
                        constants[i].setSimpleType(this.facade.getSimpleType(SimpleTypesEnum.INTEGER));
                    else if (type_constant[0].toUpperCase(Locale.ENGLISH).equals("LONG"))//$NON-NLS-1$
                        constants[i].setSimpleType(this.facade.getSimpleType(SimpleTypesEnum.LONG));
                    else if (type_constant[0].toUpperCase(Locale.ENGLISH).equals("FLOAT"))//$NON-NLS-1$
                        constants[i].setSimpleType(this.facade.getSimpleType(SimpleTypesEnum.FLOAT));
                    else if (type_constant[0].toUpperCase(Locale.ENGLISH).equals("DOUBLE"))//$NON-NLS-1$
                        constants[i].setSimpleType(this.facade.getSimpleType(SimpleTypesEnum.DOUBLE));
                    else if (type_constant[0].toUpperCase(Locale.ENGLISH).equals("BOOLEAN"))//$NON-NLS-1$
                        constants[i].setSimpleType(this.facade.getSimpleType(SimpleTypesEnum.BOOLEAN));
                    else if (type_constant[0].toUpperCase(Locale.ENGLISH).equals("IDENTITY"))//$NON-NLS-1$
                        constants[i].setSimpleType(this.facade.getSimpleType(SimpleTypesEnum.IDENTITY));
                } else {
                    if (operands_array[i].trim().equalsIgnoreCase("null")) { //$NON-NLS-1$
                        constants[i] = createElement(TypedConstant.class);
                        constants[i].setSimpleType(this.facade.getSimpleType(SimpleTypesEnum.REFERENCE));
                    } else {
                        constants[i] = createElement(TypedConstant.class);
                        constants[i].setValue(operands_array[i].trim());
                        constants[i].setWildcard(operands_array[i].trim().equals("*"));//$NON-NLS-1$
                        constants[i].setSimpleType(this.facade.getSimpleType(SimpleTypesEnum.STRING));
                    }
                }
            }
        } catch (TriggernetModelException e) {
            throw new BPMNCompilerException("Cannot access atomic types in trigger network.", e); //$NON-NLS-1$
        }
        return constants;
    }

    protected Integer[] parseIntegers(String integers) {
        String[] integers_array = integers.split("/"); //$NON-NLS-1$
        Integer[] result = new Integer[integers_array.length];
        for (int i = 0; i < result.length; i++)
            result[i] = new Integer(integers_array[i].trim());
        return result;
    }

    public static void connectNodes(Node source, int output, Node target, int input) {
        Output sourceOutput = (Output) source.getOutputChannels().get(output);
        Input targetInput = (Input) target.getInputChannels().get(input);
        // prevent multiple connections from source output to target input
        if (!sourceOutput.getTargets().contains(targetInput)) {
            sourceOutput.getTargets().add(targetInput);
        }
    }
}
