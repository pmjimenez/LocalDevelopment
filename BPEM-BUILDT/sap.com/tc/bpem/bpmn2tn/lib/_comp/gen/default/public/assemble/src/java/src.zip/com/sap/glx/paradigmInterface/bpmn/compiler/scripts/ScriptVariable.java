package com.sap.glx.paradigmInterface.bpmn.compiler.scripts;

/**
 * Instances of this class represent a variable of a trigger network script.
 * 
 * @author Philipp Sommer
 */
public class ScriptVariable implements Parameter {

    public static final ScriptVariable INSTANCE = new ScriptVariable("instance"); //$NON-NLS-1$
    public static final ScriptVariable TOKEN = new ScriptVariable("token"); //$NON-NLS-1$
    public static final ScriptVariable REQUEST = new ScriptVariable("request"); //$NON-NLS-1$
    public static final ScriptVariable RESPONSE = new ScriptVariable("response"); //$NON-NLS-1$
    public static final ScriptVariable PAYLOAD = new ScriptVariable("payload"); //$NON-NLS-1$
    public static final ScriptVariable INITIATOR = new ScriptVariable("initiator"); //$NON-NLS-1$
    public static final ScriptVariable KICKER = new ScriptVariable("kicker"); //$NON-NLS-1$
    public static final ScriptVariable PARENT = new ScriptVariable("parent"); //$NON-NLS-1$
    public static final ScriptVariable EVENT = new ScriptVariable("event"); //$NON-NLS-1$
    public static final ScriptVariable BRIDGE = new ScriptVariable("bridge"); //$NON-NLS-1$
    public static final ScriptVariable TASK = new ScriptVariable("task"); //$NON-NLS-1$
    public static final ScriptVariable MESSAGE_ID = new ScriptVariable("messageId"); //$NON-NLS-1$
    public static final ScriptVariable SUBSCRIPTION = new ScriptVariable("subscription"); //$NON-NLS-1$
    
    public static final ScriptVariable CONDITIONAL_STARTER = new ScriptVariable("conditionalStarter"); //$NON-NLS-1$
    

    public static final ScriptVariable PULSAR = new ScriptVariable("pulsar"); //$NON-NLS-1$
    public static final ScriptVariable DURATION = new ScriptVariable("duration"); //$NON-NLS-1$
    public static final ScriptVariable VALUE = new ScriptVariable("value"); //$NON-NLS-1$
    public static final ScriptVariable OBJECT = new ScriptVariable("object"); //$NON-NLS-1$
    public static final ScriptVariable EXIT = new ScriptVariable("exit"); //$NON-NLS-1$
    public static final ScriptVariable CONTROLLER = new ScriptVariable("controller"); //$NON-NLS-1$
    public static final ScriptVariable EM_EVENT = new ScriptVariable("em_event"); //$NON-NLS-1$
    
    public static final ScriptVariable EXTRACTOR = new ScriptVariable("extractor"); //$NON-NLS-1$
    public static final ScriptVariable MAPPER = new ScriptVariable("mapper"); //$NON-NLS-1$
    public static final ScriptVariable YVES_IN = new ScriptVariable("yves_in"); //$NON-NLS-1$
    public static final ScriptVariable YVES_OUT = new ScriptVariable("yves_out"); //$NON-NLS-1$
    public static final ScriptVariable DATA = new ScriptVariable("data"); //$NON-NLS-1$
    public static final ScriptVariable SCOPE = new ScriptVariable("scope"); //$NON-NLS-1$
    public static final ScriptVariable COPY = new ScriptVariable("copy"); //$NON-NLS-1$
    public static final ScriptVariable CALLSCOPE = new ScriptVariable("callscope"); //$NON-NLS-1$
    public static final ScriptVariable VIEW_UPDATER = new ScriptVariable("viewUpdater"); //$NON-NLS-1$
    public static final ScriptVariable SERVICE = new ScriptVariable("service"); //$NON-NLS-1$
    public static final ScriptVariable OPERATION = new ScriptVariable("operation"); //$NON-NLS-1$
    public static final ScriptVariable NAME = new ScriptVariable("name"); //$NON-NLS-1$
    public static final ScriptVariable NAMESPACE = new ScriptVariable("namespace"); //$NON-NLS-1$
    public static final ScriptVariable DOCUMENT = new ScriptVariable("document"); //$NON-NLS-1$
    public static final ScriptVariable GENERATOR = new ScriptVariable("generator"); //$NON-NLS-1$
    
    public static final ScriptVariable CALL = new ScriptVariable("call"); //$NON-NLS-1$
    public static final ScriptVariable PP_USERNAME = new ScriptVariable("pp_user"); //$NON-NLS-1$
    public static final ScriptVariable PP_HASH = new ScriptVariable("pp_hash"); //$NON-NLS-1$
    
    private String name;

    public ScriptVariable(String name) {
        this.name = name;
    }

    public String toString() {
        return name;
    }
}
