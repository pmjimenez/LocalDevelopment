package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import com.sap.glx.ide.model.galaxy.workflow.UncontrolledJoinGateway;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;

/**
 * Compiles an XOR merge artifact into the "Multiple Merge" pattern.
 * 
 * @author Sören Balko
 * @author Thilo-Alexander Ginkel
 * 
 * @version $Id: //bpem/bpem.bp/NW731EXT_17_REL/src/SCs/sap.com/BPEM-BUILDT/DCs/sap.com/tc/bpem/bpmn2tn/lib/_comp/src/com/sap/glx/paradigmInterface/bpmn/compiler/rules/XORJoinRule.java#1 $
 */
public class XORJoinRule extends BaseCompilerRule<UncontrolledJoinGateway> implements CompilerRule<UncontrolledJoinGateway> {

    /*
     * @see com.sap.glx.paradigmInterface.bpmn.compiler.rules.CompilerRule#getSupportedArtifact()
     */
    public Class<UncontrolledJoinGateway> getSupportedArtifact() {
        return UncontrolledJoinGateway.class;
    }

    /*
     * @see com.sap.glx.paradigmInterface.bpmn.compiler.rules.CompilerRule#compile(com.sap.glx.ide.model.galaxy.core.ModelElement,
     *      com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext)
     */
    public void compile(UncontrolledJoinGateway xor_merge, CompilerContext ctx) throws BPMNCompilerException {
        ctx.getValidator().validateConnectors(xor_merge, 2, Integer.MAX_VALUE, 1, 1);
        // new semantics: do nothing (automatically taken care of by clever connector labeling)
    }
}
