package com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals;

public class DoubleLiteral extends AbstractLiteral<Double> {

    protected DoubleLiteral(double value) {
        super(value);
    }

}
