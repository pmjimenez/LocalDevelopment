package com.sap.glx.paradigmInterface.bpmn.compiler.scripts;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.sap.glx.ide.model.classes.Attribute;
import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.core.ModelElement;
import com.sap.glx.ide.model.triggernet.GenericOperator;
import com.sap.glx.ide.model.triggernet.Target;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.IdentifierHelper;

/**
 * A Script represents a complete script of a trigger network. It can be used to create a synchronous or asynchronous target node.
 * 
 * @author Philipp Sommer
 */
public class Script {

    CompilerContext ctx;
    ScriptName prefix;
    ModelElement modelElement;
    StringBuilder body = new StringBuilder(200);

    List<Pair<ScriptVariable, Object>> parameters = new ArrayList<Pair<ScriptVariable, Object>>();
    Set<ScriptVariable> variables = new HashSet<ScriptVariable>();

    /**
     * Creates a new script instance
     * 
     * @param ctx compiler context of the current compiler run
     * @param prefix prefix of the script name
     * @param element model element of the process this script belongs to. If null the root scope is used.
     * @throws ScriptException
     */
    public Script(CompilerContext ctx, ScriptName prefix, ModelElement element) throws ScriptException {
        this.ctx = ctx;
        this.prefix = prefix;
        this.modelElement = element;
    }

    /**
     * Adds a parameter to the signature of the script
     * @param variable name of the parameter
     * @param cls type of the parameter, type ANY if null
     * @return variable which represent the parameter
     * @throws ScriptException
     */
    public ScriptVariable addParameter(ScriptVariable variable) throws ScriptException {
        if (variables.contains(variable)) {
            throw new ScriptException("Parameter can not be added, because the name is already in use.");
        }
        parameters.add(new Pair<ScriptVariable, Object>(variable, null));
        variables.add(variable);
        return variable;
    }

    /**
     * Adds a parameter to the signature of the script
     * @param variable name of the parameter
     * @param cls type of the parameter, type ANY if null
     * @return variable which represent the parameter
     * @throws ScriptException
     */
    public ScriptVariable addParameter(ScriptVariable variable, GalaxyClass cls) throws ScriptException {
        if (variables.contains(variable)) {
            throw new ScriptException("Parameter can not be added, because the name is already in use.");
        }
        parameters.add(new Pair<ScriptVariable, Object>(variable, cls));
        variables.add(variable);
        return variable;
    }

    /**
     * Adds a parameter to the signature of the script
     * @param variable name of the parameter
     * @param cls type of the parameter, type ANY if null
     * @return variable which represent the parameter
     * @throws ScriptException
     */
    public ScriptVariable addParameter(ScriptVariable variable, Pair<String, String> cls) throws ScriptException {
        if (variables.contains(variable)) {
            throw new ScriptException("Parameter can not be added, because the name is already in use.");
        }
        parameters.add(new Pair<ScriptVariable, Object>(variable, cls));
        variables.add(variable);
        return variable;
    }

    protected boolean isParameter(ScriptVariable variable) {
        for (Pair<ScriptVariable, Object> parameter : parameters) {
            if (parameter.first == variable) {
                return true;
            }
        }
        return false;
    }

    /**
     * Generates a script command string for method invocation.
     * 
     * @param result Name of the takes the method return value.
     * @param instance is the (GalaxyObject) instance to invoke the method on.
     * @param method is the name of the method.
     * @param parameters is an array of parameters to be passed to the method.
     * @return invocation command (e.g., counter=input:inc(); ).
     * @throws ScriptException
     */
    public ScriptVariable generateInvocationCommand(ScriptVariable result, ScriptVariable instance, String method, Parameter... parameters)
            throws ScriptException {
    	
    	if (result != null) {
            body.append(result);
            body.append("=");
        }
        body.append(instance);
        body.append(":");
        body.append(method);
        body.append("(");
        for (int i = 0; i < parameters.length; i++) {
            Parameter literal = parameters[i];
            if (literal instanceof ScriptVariable && !variables.contains(literal)) {
                throw new ScriptException("Undefined variable name.");
            }
            body.append(literal);
            if (i != parameters.length - 1)
                body.append(", ");
        }
        body.append("); ");

        if (result != null) {
            variables.add(result);
        }
        return result;
    }

    /**
     * Generates a script command for method invocation.
     * 
     * @param instance is the (GalaxyObject) instance to invoke the method on.
     * @param method is the name of the method.
     * @param parameters is an array of parameters to be passed to the method.
     * @return invocation command (e.g., counter=input:inc(); ).
     * @throws ScriptException
     */
    public ScriptVariable generateInvocationCommand(ScriptVariable instance, String method, Parameter... parameters) throws ScriptException {
        return generateInvocationCommand(null, instance, method, parameters);
    }

    /**
     * Generates a script command for GalaxyObject instance deletion.
     * 
     * @param instance is the name of the GalaxyObject instance.
     * @return deletion command (e.g., delete token; ).
     * @throws ScriptException
     */
    public void generateDeleteCommand(ScriptVariable instance) throws ScriptException {
        if (!variables.contains(instance)) {
            throw new ScriptException("Undefined variable name.");
        }
        body.append(CompilerConstants.SCRIPT_COMMAND_DELETE);
        body.append(" ");
        body.append(instance);
        body.append("; ");
        variables.remove(instance);
    }

    /**
     * Adds a script command for GalaxyObject instance deletion.
     * 
     * @param instance is the name of the GalaxyObject instance.
     * @return deletion command (e.g., delete token; ).
     * @throws ScriptException
     */

    public void generateBindCommand(ScriptVariable variable) {
        if (!variables.contains(variable)) {
            throw new ScriptException("Undefined variable name.");
        }
        body.append(CompilerConstants.SCRIPT_COMMAND_BIND);
        body.append(" ");
        body.append(variable);
        body.append("; ");
    }

    /**
     * Generates a script command string for assignment of a local variable.
     * 
     * @param variable is the name of the local variable.
     * @param instance is the name of another local variable.
     * @param attribute is an attribute name of instance_name (optional - only if instance_name refers to a GalaxyObject)
     * @return assignment command (e.g., owner=token:parent; ).
     */
    public ScriptVariable generateAssignCommand(ScriptVariable result, ScriptVariable instance, String attribute) {
        body.append(result);
        body.append("=");
        body.append(instance);
        if (attribute != null) {
            body.append(":");
            body.append(attribute);
        }
        body.append("; ");
        variables.add(result);
        return result;
    }

    /**
     * Generates a script command string which generates a new class instance and assigns the instance to a local variable. With 2nd-stage
     * class versioning.
     * 
     * @param cls is the GalaxyClass.
     * @param attributes is an array of attribute values.
     * @return the creation command (e.g., token=new BPMN:Token(parent,"initial"); ).
     */
    public ScriptVariable generateNewCommand(GalaxyClass cls, Parameter... attributes) {
        return generateNewCommand(null, cls, attributes);
    }

    /**
     * Generates a script command string which generates a new class instance and assigns the instance to a local variable. With 2nd-stage
     * class versioning.
     * 
     * @param result is the name of the local variable (optional).
     * @param cls is the GalaxyClass.
     * @param attributes is an array of attribute values.
     * @return the creation command (e.g., token=new BPMN:Token(parent,"initial"); ).
     */
    public ScriptVariable generateNewCommand(ScriptVariable result, GalaxyClass cls, Parameter... attributes) {
        if (result != null) {
            body.append(result);
            body.append("=");
        }
        body.append(CompilerConstants.SCRIPT_COMMAND_NEW);
        body.append(" ");
        body.append(cls.getAdapter());
        body.append(":");
        body.append(cls.getName());
        body.append("_" + CompilerConstants.SCRIPT_VALUE_VERSION);
        body.append("(");
        for (int i = 0; i < cls.getAttribute().size(); i++) {
            body.append(i < attributes.length ? attributes[i] : CompilerConstants.SCRIPT_VALUE_NULL);
            if (i < cls.getAttribute().size() - 1)
                body.append(", ");
        }
        body.append("); ");
        if (result != null) {
            variables.add(result);
        }
        return result;
    }

    /**
     * Generates a script command string which generates a new class instance and assigns the instance to a local variable. With 2nd-stage
     * class versioning.
     * 
     * @param result is the name of the local variable (optional).
     * @param cls is the GalaxyClass.
     * @param attributes is an array of attribute values.
     * @return the creation command (e.g., token=new BPMN:Token(parent,"initial"); ).
     */
    public ScriptVariable generateNewCommand(ScriptVariable result, Pair<String, String> cls, Parameter... attributes) {
        if (result != null) {
            body.append(result);
            body.append("=");
        }
        body.append(CompilerConstants.SCRIPT_COMMAND_NEW);
        body.append(" ");
        body.append(cls.first);
        body.append(":");
        body.append(cls.second);
        body.append("(");
        for (int i = 0; i < attributes.length; i++) {
            body.append(attributes[i]);
            if (i < attributes.length - 1)
                body.append(", ");
        }
        body.append("); ");
        if (result != null) {
            variables.add(result);
        }
        return result;
    }

    /**
     * Generates a script command string which updates a single attribute of a GalaxyObject instance.
     * 
     * @param instance is the name of the GalaxyObject instance.
     * @param attribute is the name of the attribute.
     * @param value is the new value of the attribute
     */
    public void generateUpdateCommand(ScriptVariable instance, String attribute, Parameter value) {
        body.append(instance);
        body.append(":");
        body.append(attribute);
        body.append("=");
        body.append(value);
        body.append("; ");
    }

    /**
     * Generates a script command string which updates a single attribute of a GalaxyObject instance.
     * 
     * @param instance is the name of the GalaxyObject instance.
     * @param attribute to be updated.
     * @param value is the new value of the attribute
     */
    public void generateUpdateCommand(ScriptVariable instance, Attribute attribute, Parameter value) {
        generateUpdateCommand(instance, attribute.getName(), value);
    }

    public void addGeneratedCommand(String command) {
        body.append(command);
    }

    @SuppressWarnings("unchecked")
    public String getHeader() {
        StringBuilder sb = new StringBuilder(200);

        // generate the name of the script
        sb.append(IdentifierHelper.createNamespace(ctx.getRootScope()));
        sb.append(":");
        if (modelElement != null) {
            IdentifierHelper.appendIdentifier(sb, prefix.toString(), modelElement.getOriginalName());
        } else {
            sb.append(prefix);
        }

        sb.append('(');
        for (Pair<ScriptVariable, Object> parameter : parameters) {
            Object object = parameter.second;
            if (object instanceof GalaxyClass) {
                GalaxyClass cls = (GalaxyClass) object;
                sb.append(cls.getAdapter());
                sb.append(':');
                sb.append(cls.getName());
                sb.append('_' + CompilerConstants.SCRIPT_VALUE_VERSION);
            } else if (object instanceof Pair) {
                Pair<String, String> cls = (Pair<String, String>) object;
                sb.append(cls.first);
                sb.append(':');
                sb.append(cls.second);
            } else {
                sb.append('*');
            }
            sb.append(' ');
            sb.append(parameter.first);
            if ((parameters.indexOf(parameter) + 1) < parameters.size()) {
                sb.append(", ");
            }
        }
        sb.append(") ");
        return sb.toString();
    }

    public String getBody() {
        return body.toString();
    }

    public Target getTarget() {
        return getTarget(CompilerConstants.PRIORITY_NORMAL);
    }

    public Target getTarget(int priority) {
        Target target = ctx.getTargetFactory().generateTarget(modelElement != null ? modelElement : ctx.getRootScope(), prefix.toString());
        ctx.getTargetFactory().setScript(target, this, priority);
        return target;
    }
    
    public Target getTarget(String implementationClass){
        Target target = ctx.getTargetFactory().generateTarget(modelElement != null ? modelElement : ctx.getRootScope(), prefix.toString(), implementationClass);
        ctx.getTargetFactory().setScript(target, this, CompilerConstants.PRIORITY_NORMAL);
        return target;
    }

    public GenericOperator getExecution() {
        GenericOperator execution = ctx.getExecutionFactory().generateExecution(modelElement != null ? modelElement : ctx.getRootScope(),
                prefix.toString());
        ctx.getExecutionFactory().setScript(execution, this);
        return execution;
    }
}
