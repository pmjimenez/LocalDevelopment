package com.sap.glx.paradigmInterface.bpmn.compiler.helpers;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.namespace.QName;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.mapping.MappingPart;
import com.sap.glx.ide.model.galaxy.rule.Expression;
import com.sap.glx.ide.model.galaxy.rule.FunctionInterface;
import com.sap.glx.ide.model.galaxy.rule.FunctionInvocation;
import com.sap.glx.ide.model.galaxy.rule.Literal;
import com.sap.glx.ide.model.galaxy.rule.Reference;
import com.sap.glx.ide.model.galaxy.rule.Step;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.Triple;
import com.sap.glx.paradigmInterface.util.ToolUtils;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;
import com.sap.tc.esmp.mm.xsd1.XsdFeature;

/**
 * Helper class to transform correlation expressions for intermediate events 
 * into a format that can be digested by the compiler. It also offers convenience 
 * methods to validate whether a given expression can be used as a correlation
 * condition.
 * 
 * @author Philipp Sommer
 * 
 */
public class NormalizationHelper {

	public static final String NS_BUILTIN_TEXT = "sap.com/bpem/glx/built-in/text";
    public static final String NS_BUILTIN_FINITE_INTEGER = "sap.com/bpem/glx/built-in/finite-integer";
    public static final String NS_BUILTIN_BOOLEAN = "sap.com/bpem/glx/built-in/boolean";

    private static final String NAME_BUILTIN_TEXT_EQUAL = "string-equal";
    private static final String NAME_BUILTIN_FINITE_INTEGER_EQUAL = "numeric-equal";
    private static final String NAME_BUILTIN_BOOLEAN_EQUAL = "boolean-equal";
    private static final String NAME_BUILTIN_BOOLEAN_AND = "and";
    
    private Set<XsdElementDeclaration> context;
    
    private static enum ReferenceType {
    	MESSAGE, CONTEXT, CONSTANT, MIXED;
    }

    public NormalizationHelper(CompilerContext ctx) {
        // creates xsd_context with the element declarations of all data containers
        Set<Map.Entry<DataContainer, GalaxyClass>> full_context = ctx.getContextHelper().fullContext();
        context = new HashSet<XsdElementDeclaration>();
        for (Map.Entry<DataContainer, GalaxyClass> context_variable : full_context)
        	context.add(context_variable.getKey().getXsdElementDeclaration());
    }

    public List<Triple <String, Expression, Expression>> normalize(Expression expression, XsdElementDeclaration message) {
    	List<Triple <String, Expression, Expression>> result = new ArrayList<Triple <String, Expression, Expression>>();
    	normalize(expression, message, result);
    	return result;
    }
    
    private void normalize(Expression expression, XsdElementDeclaration message, List<Triple <String, Expression, Expression>> result) {
    	
    	ReferenceType type = classifyExpression(expression, message);
    	
    	if (type == ReferenceType.CONSTANT) {
    		// constant expression, no further normalization necessary
    		result.add(new Triple<String, Expression, Expression>(NS_BUILTIN_BOOLEAN, expression, null));
    	} else if (type == ReferenceType.CONTEXT) {
    		// expression solely on the process context, no further normalization necessary
    		result.add(new Triple<String, Expression, Expression>(NS_BUILTIN_BOOLEAN, null, expression));
    	} else if (type == ReferenceType.MESSAGE) {
    		// expression solely on the incoming message, no further normalization necessary
    		result.add(new Triple<String, Expression, Expression>(NS_BUILTIN_BOOLEAN, expression, null));
    	} else {
    		// expression on both process context and message
    		FunctionInterface function = ((FunctionInvocation) expression.getSteps().get(0)).getFunctionInterface();
    		List<MappingPart> parts = ((FunctionInvocation) expression.getSteps().get(0)).getParameterMapping().getMappingParts();
    		if (parts.size() != 2) {
				throw new IllegalArgumentException("Invalid correlation expression");
			}
			
    		if (isConjuctionFunctionInvocation(function)) {
    			// conjunction is further normalized
    			normalize(parts.get(0).getExpression(), message, result);
    			normalize(parts.get(1).getExpression(), message, result);
    			return;
    		} 
			
    		String equalityType = getEqualalityComparison(function);
			if (equalityType != null) {
    			// equality function was found 
				ReferenceType type1 = classifyExpression(parts.get(0).getExpression(), message);
    			ReferenceType type2 = classifyExpression(parts.get(1).getExpression(), message);
    			if (type1 == ReferenceType.MESSAGE && type2 == ReferenceType.CONTEXT) {
    	    		result.add(new Triple<String, Expression, Expression>(equalityType, parts.get(0).getExpression(), parts.get(1).getExpression()));
    	    	} else if (type1 == ReferenceType.CONTEXT && type2 == ReferenceType.MESSAGE) {
    	    		result.add(new Triple<String, Expression, Expression>(equalityType, parts.get(1).getExpression(), parts.get(0).getExpression()));
    	    	} else {
    	    		throw new IllegalArgumentException("Invalid correlation expression");
    	    	}
    	   } else {
    		   	// function is not one of the expected
    			throw new IllegalArgumentException("Invalid correlation expression");
    	   }
    	}
    }
    
    /**
     * Classifies a given expression whether it references 
     * the message, the process context, both or none.
     */
    private ReferenceType classifyExpression(Expression expression, XsdElementDeclaration message) {
        Set<XsdFeature> expression_context = computeTransitiveReferences(expression);

        if (expression_context.contains(message)) {
            // the expression references the message
            for (XsdElementDeclaration context_element : context) {
                if (expression_context.contains(context_element))
                    return ReferenceType.MIXED;
            }
            return ReferenceType.MESSAGE;
        } else {
            // the expression does not reference the message
            for (XsdElementDeclaration context_element : context) {
                if (expression_context.contains(context_element))
                    return ReferenceType.CONTEXT;
            }
            return ReferenceType.CONSTANT;
        }
    }

    private Set<XsdFeature> computeTransitiveReferences(Expression expression) {
        Set<XsdFeature> references = new HashSet<XsdFeature>();
        recursiveTraversal(expression, references);
        return references;
    }

    private void recursiveTraversal(Expression expression, Set<XsdFeature> references) {
        for (Step step : (List<Step>) expression.getSteps()) {
            if (step instanceof Reference) {
                Reference reference = (Reference) step;
                references.add(reference.getXsdFeature());
            } else if (step instanceof FunctionInvocation) {
                FunctionInvocation invocation = (FunctionInvocation) step;
                for (MappingPart part : (List<MappingPart>) invocation.getParameterMapping().getMappingParts())
                    recursiveTraversal(part.getExpression(), references);
            }
        }
    }
    
    public static String getEqualalityComparison(FunctionInterface function) {
        String namespace = function.getNamespace();
        String name = function.getOriginalName();
        if ((NS_BUILTIN_TEXT.equals(namespace) && NAME_BUILTIN_TEXT_EQUAL.equals(name))
                || (NS_BUILTIN_FINITE_INTEGER.equals(namespace) && NAME_BUILTIN_FINITE_INTEGER_EQUAL.equals(name))
                || (NS_BUILTIN_BOOLEAN.equals(namespace) && NAME_BUILTIN_BOOLEAN_EQUAL.equals(name))) {
            return namespace;
        }
        return null;
    }

    public static boolean isTextEqualityComparison(FunctionInterface function) {
        if (NS_BUILTIN_TEXT.equals(getEqualalityComparison(function))) {
            return true;
        }
        return false;
    }

    public static boolean isFiniteIntegerEqualityComparison(FunctionInterface function) {
        if (NS_BUILTIN_FINITE_INTEGER.equals(getEqualalityComparison(function))) {
            return true;
        }
        return false;
    }

    public static boolean isBooleanEqualityComparison(FunctionInterface function) {
        if (NS_BUILTIN_BOOLEAN.equals(getEqualalityComparison(function))) {
            return true;
        }
        return false;
    }

    public static boolean isConjuctionFunctionInvocation(FunctionInterface function) {
        if (NS_BUILTIN_BOOLEAN.equals(function.getNamespace()) && NAME_BUILTIN_BOOLEAN_AND.equals(function.getOriginalName())) {
            return true;
        }
        return false;
    }

    public static Expression createTrueExpression(CompilerContext ctx) {
        Expression e = ctx.getConnection().createElement(Expression.class);
        e.setStringExpression("true");
        Literal l = ctx.getConnection().createElement(Literal.class);
        l.setValue("true");
        QName bool = new QName("http://www.w3.org/2001/XMLSchema", "boolean");
        l.setSimpleDataType(ToolUtils.getInstance().findSimpleTypeDefinition(ctx.getConnection(), bool));
        e.getSteps().add(l);
        return e;
    }
}
