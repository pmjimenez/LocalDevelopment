package com.sap.glx.paradigmInterface.bpmn.compiler.type;

import java.util.Arrays;

import com.sap.glx.paradigmInterface.buildapi.IBuilderHost2;
import com.sap.glx.paradigmInterface.buildapi.ISeedProvider;
import com.sap.glx.paradigmInterface.buildapi.TypeArtifact;

public class TypeSeedProvider implements ISeedProvider<Object,TypeArtifact> {

    public Iterable<TypeArtifact> getSeed(IBuilderHost2 host) {
        return Arrays.asList(new TypeArtifact(host.getLocalDCIdentifier(), true));
    }
}
