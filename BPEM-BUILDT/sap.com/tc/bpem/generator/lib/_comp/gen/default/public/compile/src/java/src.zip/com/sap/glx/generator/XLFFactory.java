package com.sap.glx.generator;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

import com.sap.glx.constants.TextConstants;
import com.sap.glx.ide.model.galaxy.core.ModelElement;
import com.sap.glx.ide.model.galaxy.task.Task;
import com.sap.glx.ide.model.galaxy.text.ModelElementDocumentationText;
import com.sap.glx.ide.model.galaxy.text.ModelElementNameText;
import com.sap.glx.ide.model.galaxy.text.ScopeDescriptionText;
import com.sap.glx.ide.model.galaxy.text.ScopeSubjectText;
import com.sap.glx.ide.model.galaxy.text.VersionedText;
import com.sap.glx.ide.model.galaxy.workflow.Collaboration;
import com.sap.glx.ide.model.galaxy.workflow.Pool;
import com.sap.glx.ide.model.galaxy.workflow.Scope;
import com.sap.glx.paradigmInterface.buildapi.BpemBuildException;
import com.sap.glx.paradigmInterface.buildapi.IArtifact;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost2;
import com.sap.glx.paradigmInterface.buildapi.ICompiler;
import com.sap.glx.paradigmInterface.buildapi.ICompiler2;
import com.sap.glx.paradigmInterface.buildapi.TextArtifact;
import com.sap.glx.paradigmInterface.util.ToolUtils;
import com.sap.s2x.S2XDocument;
import com.sap.s2x.core.types.RestypeValue;
import com.sap.s2x.etc.TranslationUnit;
import com.sap.s2x.validation.ValidationException;
import com.sap.tc.buildplugin.BuildSessionManager;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;
import com.sap.tc.moin.repository.CRI;
import com.sap.tc.moin.repository.Connection;
import com.sap.tc.moin.repository.PRI;
import com.sap.tc.moin.repository.Partitionable;
import com.sap.tc.moin.repository.mmi.reflect.RefObject;
import com.sap.tc.moin.repository.mql.MQLResultSet;
import com.sap.tc.moin.repository.mql.QueryScopeProvider;

/**
 * Compile the artifact (process or task) into XLF file for 7.11 model content. The xlf file is already present (created by the Process
 * Composer) for 7.20 and above model content. In this case the original XLF file and its corresponding translations is packaged into the
 * archive.
 * 
 * @author Philipp Sommer
 */

public class XLFFactory implements ICompiler, ICompiler2<ModelElement, TextArtifact> {

    private static final String XLF_EXTENSION = "xlf"; //$NON-NLS-1$
    private static final String CSV_ENTENSION = "csv"; //$NON-NLS-1$
    private static final String FILE_SEPARATOR = System.getProperty("file.separator"); //$NON-NLS-1$
    private static final String DOT = "."; //$NON-NLS-1$
    private static final Pattern PATTERN = Pattern.compile("\\."); //$NON-NLS-1$

    private static final String MAX_WIDTH_UNLIMITED = "0"; //$NON-NLS-1$
    private static final String TOOL_NAME = "GalaxyXLIFFGenerator"; //$NON-NLS-1$
    private static final String PRODUCT_NAME = "Galaxy XLF generator"; //$NON-NLS-1$
    private static final String DEVEL_CONTACT = ""; //$NON-NLS-1$
    private static final String ORIGINAL = "self"; //$NON-NLS-1$
    private static final String DATA_TYPE = "javaPropertyResourceBundle"; //$NON-NLS-1$
    private static final String TRANSLATE_NO = "no"; //$NON-NLS-1$
    private static final String TRANSLATE_YES = "yes"; //$NON-NLS-1$

    private String originalLocale;

    public XLFFactory() {
        IPluginBuildInfo pbi = (IPluginBuildInfo) BuildSessionManager.getFromBuildSession(IPluginBuildInfo.class.getName());
        originalLocale = pbi.getDCOriginalLocale();
    }

    /**
     * The XLF Factory can compile the Collaboration and the Task objects.
     */
    public boolean canCompile(Object artifact) {
        return ((artifact instanceof Collaboration) || (artifact instanceof Task));
    }

    /**
     * The XLF Factory hasn't got a dependency.
     */
    public Object[] getDependencies(IBuilderHost host, Object artifact) {
        return new Object[0];
    }

    /**
     * Compile the artifact into XLF file. The xlf file is already present (created by the Process Composer) for 7.20 and above model
     * content. In this case the original xlf file and its corresponding translations is packaged into the archive. In case of 7.11 content
     * the xlf file must be created.
     */
    public boolean compile(IBuilderHost host, Object object) throws Exception {
        if (canCompile(object)) {
            ModelElement artifact = (ModelElement) object;
            File artifactFile = constructArtifactSource(artifact);
            HashMap<Locale, File> xlfFiles = getExistingXLFFiles(artifactFile);
            if (xlfFiles.size() == 0) {
                generateXlfFile(host, artifact);
            } else {
                packageXlfFiles(host, artifact, xlfFiles);
            }
            return true;
        } else {
            return false;
        }
    }

    /**
     * Return the MOIN partition file containing the process or task.
     */
    private File constructArtifactSource(ModelElement artifact) {
        IPluginBuildInfo pbi = (IPluginBuildInfo) BuildSessionManager.getFromBuildSession(IPluginBuildInfo.class.getName());
        String relativeName = artifact.get___Mri().getPri().getPartitionName();
        File file = new File(pbi.getRootDir().getPath() + FILE_SEPARATOR + relativeName);
        if (file.exists()) {
            return file;
        } else {
            throw new IllegalStateException("Process or task file '" + file.getAbsoluteFile() + "' can not be found."); //$NON-NLS-1$ //$NON-NLS-2$
        }
    }

    /**
     * Returns a list with all existing XLF files corresponding to a given artifact.
     * 
     * @param artifactFile
     *            of a process or task
     * @return a hash map of from the local name encoded in the file name to the xlf file. The default locale of the DC can be retrieved
     *         with the null key.
     * @throws BpemBuildException
     */
    private HashMap<Locale, File> getExistingXLFFiles(File artifactFile) throws BpemBuildException {
        final String prefix = artifactFile.getName();
        final String suffix = DOT + XLF_EXTENSION;
        final HashMap<Locale, File> xlfFiles = new HashMap<Locale, File>();

        for (File file : artifactFile.getParentFile().listFiles()) {
            String name = file.getName();
            if (prefix.length() + suffix.length() <= name.length()) {
                if (name.substring(0, prefix.length()).equalsIgnoreCase(prefix)
                        && name.substring(name.length() - suffix.length(), name.length()).equalsIgnoreCase(suffix)) {
                    String infix = name.substring(prefix.length(), name.length() - suffix.length());
                    Locale locale = null;
                    if (infix.length() > 0) {
                        locale = getLocale(infix.substring(1));
                    }
                    File previous = xlfFiles.put(locale, file);
                    if (previous != null) {
                        throw new BpemBuildException(String.format("Two XLF files for the same locale '%s' found.", locale));
                    }
                }
            }
        }
        return xlfFiles;
    }

    /**
     * Creates a locale from its string representation.
     */
    private Locale getLocale(String locale) {
        int i1 = locale.indexOf('_');
        if (i1 == -1) {
            return new Locale(locale);
        } else {
            int i2 = locale.indexOf('_', i1 + 1);
            if (i2 == -1) {
                return new Locale(locale.substring(0, i1), locale.substring(i1 + 1));
            } else {
                return new Locale(locale.substring(0, i1), locale.substring(i1 + 1, i2));
            }
        }
    }

    /**
     * Copy the XLF files to the archive. In case the XLF file does not contain the original language of the DC, the locale encoded in the
     * name of the XLF file is checked against its content.
     */
    private void packageXlfFiles(IBuilderHost host, ModelElement artifact, HashMap<Locale, File> xlfFiles) throws Exception {

        boolean existsXLFFileForOriginalLocale = false;

        // The name of the artifact is the name of the file associated to it minus
        // the file extension.
        File artifactFile = constructArtifactSource(artifact);
        String artifactName = artifactFile.getName();
        int artifactFileExtensionStartIndex = artifactName.lastIndexOf(".");
        if (artifactFileExtensionStartIndex > -1) {
            artifactName = artifactName.substring(0, artifactFileExtensionStartIndex);
        }

        Locale dcLocale = originalLocale == null ? null : getLocale(originalLocale);

        for (Locale locale : xlfFiles.keySet()) {
            File xlfFile = xlfFiles.get(locale);
            String name = xlfFile.getAbsoluteFile().toString();
            Log.info(String.format("Packaging XLF file '%s'.", name)); //$NON-NLS-1$

            InputStream in = null;
            OutputStream out = null;
            try {
                in = new FileInputStream(xlfFile);
                out = host.createVersionedTargetFile(TextConstants.generateTextFileName(artifactName, locale), artifact);
                if (locale != null) {
                    S2XDocument doc = new S2XDocument(in);
                    Locale sourceLocale = getLocale(doc.getSourceLanguage());
                    if (!locale.equals(sourceLocale)) {
                        throw new BpemBuildException(String.format("The source locale '%s' of XLF file '%s' does not match its name.", doc
                                .getSourceLanguage(), name));
                    }
                    doc.store(out);
                } else {
                    byte[] buf = new byte[1024];
                    int len;
                    while ((len = in.read(buf)) >= 0) {
                        out.write(buf, 0, len);
                    }
                }
            } finally {
                if (in != null) {
                    in.close();
                }
                if (out != null) {
                    out.close();
                }
            }
            // Checks only the language part of the locales because BI only works with the
            // language, not with the country or the variant parts.
            if (locale != null && dcLocale != null && locale.getLanguage().equals(dcLocale.getLanguage())) {
                existsXLFFileForOriginalLocale = true;
            }
        }

        // If no XLF file exists for the DC locale then a XLF file is generated and has the
        // same content than the XLF file generated automatically with the artifact.
        if (!existsXLFFileForOriginalLocale) {
            File fallbackXLFFile = xlfFiles.get(null);
            if (fallbackXLFFile == null)
                return;
            if (dcLocale == null)
                return;
            //
            InputStream in = null;
            OutputStream out = null;
            try {
                in = new FileInputStream(fallbackXLFFile);
                out = host.createVersionedTargetFile(TextConstants.generateTextFileName(artifactName, dcLocale), artifact);
                byte[] buffer = new byte[1024];
                int len = 0;
                while ((len = in.read(buffer)) >= 0) {
                    out.write(buffer, 0, len);
                }
            } finally {
                try {
                    if (out != null)
                        out.close();
                } finally {
                    if (in != null)
                        in.close();
                }
            }
        }
    }

    /**
     * Create a new XLF file for a given artifact (collaboration or task). This is intended for 7.11 models.
     */
    private void generateXlfFile(IBuilderHost host, ModelElement artifact) throws Exception {
        // get all model element in the partition of the artifacts
        RefObject[] modelElements = getAllModelElements(artifact);

        // If the creation of the S2XDocument is OK then start the filling of it.
        S2XDocument doc = createXLFDocument();
        for (RefObject ro : modelElements) {
            // Every model element is investigated and the name and documentation information will be saved into the XLF, if they exist.
            if (ro instanceof ModelElement) {
                ModelElement me = (ModelElement) ro;

                ModelElementNameText ment = me.getName();
                if ((ment != null) && (ment.getOriginalText() != null) && (ment.getOriginalText().trim().length() > 0)) {
                    addTextToXLF(doc, ment, null);
                }

                ModelElementDocumentationText medt = me.getDocumentation();
                if ((medt != null) && (medt.getOriginalText() != null) && (medt.getOriginalText().trim().length() > 0)) {
                    addTextToXLF(doc, medt, null);
                }

                if ((ro instanceof Task) || (ro instanceof Pool)) {
                    scopeMethod(doc, (Scope) ro);
                }
            }
        }

        String artifactName = artifact.getName().getOriginalText();
        OutputStream stream = host.createVersionedTargetFile(artifactName + DOT + XLF_EXTENSION, artifact);
        // Save the XLF file.
        doc.store(stream);
    }

    /**
     * Return all model elements in the same partition of the given ModelElement.
     */
    private RefObject[] getAllModelElements(ModelElement modelElement) {
        // get the connection and partition
        Connection connection = ((Partitionable) modelElement).get___Connection();
        final PRI[] partition = new PRI[] { ((Partitionable) modelElement).get___Mri().getPri() };
        QueryScopeProvider queryScopeProvider = new QueryScopeProvider() {

            public PRI[] getPartitionScope() {
                return partition;
            }

            public CRI[] getContainerScope() {
                return null;
            }

            public boolean isInclusiveScope() {
                return true;
            }
        };

        // create the query (all model elements in the given partition)
        String query = "select me from Galaxy::Core::ModelElement as me"; //$NON-NLS-1$
        MQLResultSet resultSet = connection.getMQLProcessor().execute(query, queryScopeProvider);
        return resultSet.getRefObjects("me"); //$NON-NLS-1$
    }

    /**
     * Add a new rows to the XLF file for the name and documentation of the root scope. Variable names are replaced with their index before.
     */
    private void scopeMethod(S2XDocument doc, Scope scope) throws ValidationException {
        ScopeSubjectText tst = scope.getSubject();
        ScopeDescriptionText tdt = scope.getDescription();
        List<XsdElementDeclaration> variables = XMLUtil.getTextVariablesOfScope(scope);

        // If the object is null or it hasn't got a text
        // then skip it otherwise create a new row in the XLF file.
        if ((tst != null) && (tst.getOriginalText() != null) && (tst.getOriginalText().trim().length() > 0)) {
            addTextWithVariablesToXLF(doc, tst, variables);
        }
        if ((tdt != null) && (tdt.getOriginalText() != null) && (tdt.getOriginalText().trim().length() > 0)) {
            addTextWithVariablesToXLF(doc, tdt, variables);
        }
    }

    /**
     * Add a new row to the XLF file. Variable names are replaced with their index before.
     */
    private void addTextWithVariablesToXLF(S2XDocument doc, VersionedText text, List<XsdElementDeclaration> variables)
            throws ValidationException {
        String modifiedText = text.getOriginalText();
        for (XsdElementDeclaration variable : variables) {
            modifiedText = modifiedText.replace('{' + variable.getName() + '}', '{' + Integer.toString(variables.indexOf(variable)) + '}');
        }
        addTextToXLF(doc, text, modifiedText);
    }

    /**
     * Add a new row to the XLF file.
     */
    private void addTextToXLF(S2XDocument doc, VersionedText text, String modifiedText) throws ValidationException {
        TranslationUnit tu = new TranslationUnit();
        tu.setRestype(text.getResType());
        tu.setResname(ToolUtils.getInstance().getTextId(text));
        tu.setID(text.getTransUnitId());
        tu.setMaxwidth(MAX_WIDTH_UNLIMITED);
        if (modifiedText != null) {
            tu.setSource(modifiedText);
        } else {
            tu.setSource(text.getOriginalText());
        }
        if (text.isTranslate()) {
            tu.setTranslate(TRANSLATE_YES);
        } else {
            tu.setTranslate(TRANSLATE_NO);
        }

        ensureCorrectTranslationUnit(tu, text);
        doc.addText(tu);
    }

    /**
     * Create a new S2XDocument which contains the rows of the XLF file.
     */
    private S2XDocument createXLFDocument() throws Exception {
        S2XDocument doc = new S2XDocument(false);
        doc.setTool(TOOL_NAME);
        doc.setSourceLanguage(originalLocale);
        doc.setOriginalLocale(originalLocale);
        doc.setDevelContact(DEVEL_CONTACT);
        doc.setOriginal(ORIGINAL);
        doc.setDatatype(DATA_TYPE);
        doc.setProductname(PRODUCT_NAME);
        return doc;
    }

    /**
     * The method ensures that the translation unit tu is good enough to be consumed by the translation frameworks. Normally all texts
     * should be correctly initialized but this method is a fallback.
     */
    private void ensureCorrectTranslationUnit(TranslationUnit tu, VersionedText text) {
        if (tu.getMaxwidth() == null) {
            tu.setMaxwidth(MAX_WIDTH_UNLIMITED);
        }
        if (tu.getResname() == null) {
            tu.setResname(new com.sap.guid.GUID(text.getTransUnitId() + text.getOriginalText()).toHexString());
        }
        if (tu.getRestype() == null) {
            tu.setRestype(RestypeValue.GENERALTEXTLONG);
        }
        if (tu.getID() == null) {
            tu.setID(text.getTransUnitId());
        }
        if (tu.getTranslate() == null) {
            tu.setTranslate(TRANSLATE_NO);
        }
    }

    /**
     * Compile the artifact into XLF file.
     */
    public boolean compile(IBuilderHost2 host, TextArtifact artifact) throws BpemBuildException {
        throw new UnsupportedOperationException();
    }

    /**
     * The XLF Factory hasn't got a dependency.
     */
    public IArtifact<?>[] getDependencies(IBuilderHost2 host, TextArtifact artifact) {
        throw new UnsupportedOperationException();
    }
}
