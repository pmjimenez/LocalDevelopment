package com.sap.glx.paradigmInterface.brms.compiler;

import java.util.Properties;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;
/**
 * @author I047255
 * @since 7.2
 */
public class PropertiesCollector extends DefaultHandler{
	
	Properties props = null;
	
	public PropertiesCollector(Properties props){
		this.props = props;
	}
	
	public void startElement (String uri, String localName, String qName, Attributes attributes){
		if(qName.equals("property")){ //$NON-NLS-1$
			String propName = null;
			String propValue = null;
			int length = attributes.getLength();
			for(int i=0;i<length;i++){
				String attributeName = attributes.getQName(i);
				if(attributeName.equals("name")){ //$NON-NLS-1$
					propName = attributes.getValue(i);
				}else if(attributeName.equals("value")){ //$NON-NLS-1$
					propValue = attributes.getValue(i);
				}
			}
				
			if(propName != null && propValue != null){
				props.put(propName, propValue);
			}
		}
	}
}
