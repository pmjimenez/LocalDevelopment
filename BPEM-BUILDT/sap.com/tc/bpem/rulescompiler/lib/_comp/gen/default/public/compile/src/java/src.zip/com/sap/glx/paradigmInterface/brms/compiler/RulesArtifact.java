package com.sap.glx.paradigmInterface.brms.compiler;

import com.sap.glx.paradigmInterface.buildapi.IArtifact;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;

/**
 * A simple artifact implementation that uses a source path as internal object.
 * @author d023588
 */
public class RulesArtifact implements IArtifact<String> {

	/**
	 * The artifact wraps the source path of a rule source object.
	 */
	private String filename;
	public RulesArtifact(String filename)
	{	
		this.filename = filename;
	}
	
	/**
	 * The identifier must be unique and would be used in distributed DC
	 * scenarios for re-creating an artifact.
	 */
	public String getIdentifier() {
		return this.filename; // TODO: If the path is relative, we should add the DC name here.
	}

	public String getObject() {
		return this.filename;
	}

	public CompilerType handledBy() {
		return CompilerType.RULESCOMPILER;
	}

	/* (non-Javadoc)
	 * @see com.sap.glx.paradigmInterface.buildapi.IArtifact#isLocal(java.lang.Object)
	 */
	public boolean isLocal(Object reference_dc) {
		return true; // Rules artifact are allways local and will be packaged into BPEM
	}
	
}
