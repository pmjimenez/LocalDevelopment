package com.sap.glx.paradigmInterface.brms.compiler;

import java.util.ArrayList;
import java.util.List;
/**
 * Represents pattern to be used when merging two XMLs into one XML.
 * 
 * @author I047255
 * @since 7.2
 */
class XMLMergePattern {
	
		private String _rootElementName = null;
		private List<XMLElementPattern> elements = new ArrayList<XMLElementPattern>();
	
	XMLMergePattern(String rootElementName){
		this._rootElementName = rootElementName;
	}
	
	String getRootElementName(){
		return this._rootElementName;
	}
	
	void addElementCombo(XMLElementPattern elementCombo){
		elements.add(elementCombo);
	}
	
	List<XMLElementPattern> getElementCombos(){
		return elements;
	}
}
