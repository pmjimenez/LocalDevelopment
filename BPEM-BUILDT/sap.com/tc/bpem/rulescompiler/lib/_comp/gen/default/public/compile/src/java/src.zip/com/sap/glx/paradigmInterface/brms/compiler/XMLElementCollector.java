package com.sap.glx.paradigmInterface.brms.compiler;

import java.util.Map;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;
/**
 * 
 * @author I047255
 * @since 7.2
 */
public class XMLElementCollector extends DefaultHandler{
	
	Map<String, String> elementVsNSPrefix = null;
	
	public XMLElementCollector(Map<String, String> elementVsNSPrefix){
		this.elementVsNSPrefix = elementVsNSPrefix;
	}
	
	public void startElement (String uri, String localName, String qName, Attributes attributes){
		if(qName.equals("class")){ //$NON-NLS-1$
			int length = attributes.getLength();
			for(int i=0;i<length;i++){
				String attributeName = attributes.getQName(i);
				if(attributeName.equals("name")){ //$NON-NLS-1$
					String attributeVal = attributes.getValue(i);
					int index1 = attributeVal.indexOf(":"); //$NON-NLS-1$
					if(index1 != -1){
						String nsPrefixElementName = attributeVal.substring(index1+1, attributeVal.length());
						int index2 = nsPrefixElementName.indexOf(":"); //$NON-NLS-1$
						String nsPrefix = nsPrefixElementName.substring(0, index2);
						String elementName = nsPrefixElementName.substring(index2+1, nsPrefixElementName.length());
						int index3 = elementName.indexOf("/"); //$NON-NLS-1$
						if(index3>0){
							elementName = elementName.substring(0, index3);
						}
						
						elementVsNSPrefix.put(elementName, nsPrefix);
					}
					break;
				}
			}
		}
	}
}
