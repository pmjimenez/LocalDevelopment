package com.sap.glx.paradigmInterface.brms.compiler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/**
 * Contains following information about an XML document,
 * 		 	(a) xpath vs list of element content including element tag  
 * 			(b) xpath vs list of element content excluding element tag
 * 			(c) xpath vs start element tag
 * 			(d) XML Declaration 
 * 			
 * @author I047255
 * @since 7.2
 */
class XMLContent {
	
		private Map<String, List<String>> nameVsContentIncludingTags = new HashMap<String, List<String>>();
		private Map<String, List<String>> nameVsContentExcludingTags = new HashMap<String, List<String>>();
		private Map<String, List<String>> nameVsStartTagContent = new HashMap<String, List<String>>();
		
		private String xmlDeclaration = null;
		
	XMLContent(){
		
	}
	
	void setXMLDeclaration(String xmlDeclaration){
		this.xmlDeclaration = xmlDeclaration; 
	}
	
	String getXMLDeclaration(){
		return this.xmlDeclaration;
	}
	
	void addElementContentIncludingTags(String xPath, String elementContent){
		List<String> elementContentList = nameVsContentIncludingTags.get(xPath);
		if(elementContentList == null){
			elementContentList =  new ArrayList<String>();
			nameVsContentIncludingTags.put(xPath, elementContentList);
		}
		elementContentList.add(elementContent);
	}
	
	void addElementContentExcludingTags(String xPath, String elementContent){
		List<String> elementContentList = nameVsContentExcludingTags.get(xPath);
		if(elementContentList == null){
			elementContentList =  new ArrayList<String>();
			nameVsContentExcludingTags.put(xPath, elementContentList);
		}
		elementContentList.add(elementContent);
	}

	void addElementStartTagContent(String xPath, String elementContent){
		List<String> elementContentList = nameVsStartTagContent.get(xPath);
		if(elementContentList == null){
			elementContentList =  new ArrayList<String>();
			nameVsStartTagContent.put(xPath, elementContentList);
		}
		elementContentList.add(elementContent);
	}
	
	List<String> getElementContentIncludingTags(String xPath){
		return nameVsContentIncludingTags.get(xPath);
	}
	
	List<String> getElementContentExcludingTags(String xPath){
		return nameVsContentExcludingTags.get(xPath);
	}
	
	List<String> getElementStartTagContent(String xPath){
		return nameVsStartTagContent.get(xPath);
	}
	
}
