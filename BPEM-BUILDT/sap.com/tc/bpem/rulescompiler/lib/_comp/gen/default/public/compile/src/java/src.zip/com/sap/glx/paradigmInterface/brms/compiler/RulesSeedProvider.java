/**
 * 
 */
package com.sap.glx.paradigmInterface.brms.compiler;

import java.util.ArrayList;
import java.util.Collection;

import com.sap.glx.paradigmInterface.buildapi.IArtifact;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost2;
import com.sap.glx.paradigmInterface.buildapi.ISeedProvider;

/**
 * @author d023588
 *
 */
public class RulesSeedProvider implements ISeedProvider<String, IArtifact<String>> {

	/* (non-Javadoc)
	 * @see com.sap.glx.paradigmInterface.buildapi.ISeedProvider#getSeed(com.sap.glx.paradigmInterface.buildapi.IBuilderHost2, java.lang.Object)
	 */
	public Iterable<IArtifact<String>> getSeed(IBuilderHost2 host) {
		Collection<IArtifact<String>> result = new ArrayList<IArtifact<String>>();
		boolean dummy = false;
		while(dummy) // TODO: Search the project for your source files
		{
			String sourcePath = null; // FIXME: get the correct source path
			RulesArtifact artifact = new RulesArtifact(sourcePath);
			result.add(artifact);
		}
		return result;
	}

}
