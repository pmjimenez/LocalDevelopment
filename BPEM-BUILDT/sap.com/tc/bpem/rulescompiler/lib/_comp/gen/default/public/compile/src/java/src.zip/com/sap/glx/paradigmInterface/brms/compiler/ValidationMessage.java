package com.sap.glx.paradigmInterface.brms.compiler;

public class ValidationMessage {
	
	public enum Type{
		WARNING,
		ERROR
	}
	
	private String resName = null;
	private String entityName = null;
	private String entityType = null;
	private Type type;
	private String message = null;
	
	private String stringRepresentation = null;
	
	public ValidationMessage(String resName, String entityName, String entityType, Type type, String message){
		// null check
		if(resName == null){
			throw new IllegalArgumentException("resName can not be null"); //$NON-NLS-1$
		}
		if(entityName == null){
			throw new IllegalArgumentException("entityName can not be null"); //$NON-NLS-1$
		}
		if(entityType == null){
			throw new IllegalArgumentException("entityType can not be null"); //$NON-NLS-1$
		}
		if(message == null){
			throw new IllegalArgumentException("message can not be null"); //$NON-NLS-1$
		}
		this.resName = resName;
		this.entityName = entityName;
		this.entityType = entityType;
		this.type = type;
		this.message = message;
	}
	
	public String getResourceName(){
		return this.resName;
	}
	
	public String getEntityName(){
		return this.entityName;
	}
	
	public String getEntityType(){
		return this.entityType;
	}
	
	public Type getType(){
		return this.type;
	}
	
	public String getMessage(){
		return this.message;
	}
	
	@Override
	public String toString(){
		if(stringRepresentation == null){
			StringBuffer buffer = new StringBuffer();
			buffer.append("Resource:\'"+resName+"\' "); //$NON-NLS-1$
			buffer.append("Entity:\'"+entityName+"\' "); //$NON-NLS-1$
			buffer.append("Type:\'"+entityType+"\' "); //$NON-NLS-1$
			buffer.append(getTypeAsString(type)+":"+message); //$NON-NLS-1$
			stringRepresentation = buffer.toString();
		}
		return stringRepresentation;
	}
	
	private String getTypeAsString(Type type){
		if(type == Type.ERROR){
			return "ERROR"; //$NON-NLS-1$
		}else if(type == Type.WARNING){
			return "WARNING"; //$NON-NLS-1$
		}
		return ""; //$NON-NLS-1$
		
	}
}
