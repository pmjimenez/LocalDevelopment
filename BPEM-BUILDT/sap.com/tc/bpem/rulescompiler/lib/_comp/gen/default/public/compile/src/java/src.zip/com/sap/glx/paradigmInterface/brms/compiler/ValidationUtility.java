package com.sap.glx.paradigmInterface.brms.compiler;

import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ValidationUtility {

	
	public static ValidationResult loadValidationResult(Document document){
		// null check
		if(document == null){
			throw new IllegalArgumentException("document is null or blank"); //$NON-NLS-1$
		}
		NodeList resElements = document.getElementsByTagName("resource"); //$NON-NLS-1$
		int length = resElements.getLength();
		
		ValidationResult result = new ValidationResult();
		 
		
		for(int i=0;i<length;i++){
			Node node = resElements.item(i);
			
			if(node instanceof Element){
				Element element = (Element)node;
				List<ValidationMessage> messages = getValidationMessages(element);
				for(ValidationMessage message : messages){
					result.addValidationMessage(message);
				}
			}
		}
		
		return result;
	}
	
	private static List<ValidationMessage> getValidationMessages(Element element){
		String resName = element.getAttribute("name"); //$NON-NLS-1$
		NodeList errorElements = element.getElementsByTagName("error"); //$NON-NLS-1$
		NodeList warningElements = element.getElementsByTagName("warning"); //$NON-NLS-1$
		
		List<ValidationMessage> messages = new ArrayList<ValidationMessage>();
		
		for(int i=0;i<errorElements.getLength();i++){
			Node node = errorElements.item(i);
			
			if(node instanceof Element){
				Element errorElement = (Element)node;
				
				String entityName = errorElement.getAttribute("entityName"); //$NON-NLS-1$
				String entityType = errorElement.getAttribute("entityType"); //$NON-NLS-1$
				String messageText = errorElement.getAttribute("message"); //$NON-NLS-1$
				
				ValidationMessage message = new ValidationMessage(resName,entityName,entityType, ValidationMessage.Type.ERROR, messageText);
				messages.add(message);
				
			}
		}
		
		for(int i=0;i<warningElements.getLength();i++){
			Node node = warningElements.item(i);
			
			if(node instanceof Element){
				Element errorElement = (Element)node;
				
				String entityName = errorElement.getAttribute("entityName"); //$NON-NLS-1$
				String entityType = errorElement.getAttribute("entityType"); //$NON-NLS-1$
				String messageText = errorElement.getAttribute("message"); //$NON-NLS-1$
				
				ValidationMessage message = new ValidationMessage(resName,entityName,entityType, ValidationMessage.Type.WARNING, messageText);
				messages.add(message);
				
			}
		}
		
		return messages;
	}
	
}
