package com.sap.glx.paradigmInterface.brms.compiler;

import java.util.Map;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;
/**
 * @author I047255
 * @since 7.2
 */
public class NameSpaceMappingCollector extends DefaultHandler{
	
	Map<String, String> prefixVsNameSpace = null;
	
	public NameSpaceMappingCollector(Map<String,String> prefixVsNameSpace){
		this.prefixVsNameSpace = prefixVsNameSpace;
	}
	
	public void startElement(String uri, String localName, String qName, Attributes attributes){
		if(qName.equals("mapping")){ //$NON-NLS-1$
			String preFix = null;
			String nameSpace = null;
			int length = attributes.getLength();
			for(int i=0;i<length;i++){
				String attrName = attributes.getQName(i);
				if(attrName.equals("prefix")){ //$NON-NLS-1$
					preFix = attributes.getValue(i);
				}else if(attrName.equals("namespace")){ //$NON-NLS-1$
					nameSpace = attributes.getValue(i);
				}
				
				if(preFix!=null && nameSpace!=null){
					prefixVsNameSpace.put(preFix, nameSpace);
				}
			}
		}
	}
}
