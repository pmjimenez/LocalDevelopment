package com.sap.glx.paradigmInterface.postprocessor.ws;

import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URI;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.buildapi.BpemBuildException;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost;
import com.sap.glx.paradigmInterface.buildapi.IPostProcessor;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.glx.paradigmInterface.util.ProvisioningURLUtils;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.esmp.mm.wsdl2.Description;
import com.sap.tc.esmp.mm.wsdl2.Endpoint;
import com.sap.tc.esmp.mm.wsdl2.Interface;
import com.sap.tc.esmp.mm.wsdl2.Operation;
import com.sap.tc.esmp.mm.wsdl2.Service;
import com.sap.tc.esmp.mm.wsdl2.UnknownExtensibilityElement;
import com.sap.tc.esmp.mm.wsdl2.UnknownExtensibilityEntity;
import com.sap.tc.esmp.mm.xsd1.dom.DomElement;
import com.sap.tc.esmp.mm.xsd1.dom.DomNode;
import com.sap.tc.esmp.mm.xsd1.dom.DomText;
import com.sap.tc.esmp.tools.wsdlexport.ServiceDescriptionExtended;
import com.sap.tc.esmp.tools.wsdlexport.Wsdl1Document;
import com.sap.tc.esmp.tools.wsdlexport.Wsdl1Exporter;
import com.sap.tc.esmp.tools.wsdlexport.Wsdl1ExporterExtension;
import com.sap.tc.esmp.tools.wsdlexport.Wsdl1ExporterProvider;
import com.sap.tc.esmp.tools.wsdlexport.WsdlExportException;
import com.sap.tc.esmp.tools.xsdexport.SchemaDocument;

/**
 * The {@link WSProvisioningPostProcessor} is responsible to create an archive in the build result, containing all information required by
 * the web service runtime. These services are used to enable processes to provision web services.
 * 
 * @author I044121
 * @author Philipp Sommer
 */
public class WSProvisioningPostProcessor implements IPostProcessor {

    private static final String ARCHIVE_SUFFIX = ".wsar"; //$NON-NLS-1$
    private static final String DESCRIPTOR_LOCATION = "META-INF/webservices-j2ee-engine-alt.xml"; //$NON-NLS-1$
    private static final String WSDL_LOCATION = "META-INF/wsdl"; //$NON-NLS-1$

    private static final String GALAXY_IMPLEMENTATION_ID = "GalaxyImpl"; //$NON-NLS-1$
    private static final String WS_RT_NS = "http://www.sap.com/webas/710/ws/webservices-j2ee-engine-alt-descriptor"; //$NON-NLS-1$
    private static final String XALAN_NS = "http://xml.apache.org/xalan"; //$NON-NLS-1$
    private static final String XSLT_NS = "http://www.w3.org/1999/XSL/Transform"; //$NON-NLS-1$

    private static final String BINDING_SUFFIX = "Binding"; //$NON-NLS-1$
    private static final String SERVICE_SUFFIX = "Service"; //$NON-NLS-1$
    private static final String SOAP_ACTION = ""; //$NON-NLS-1$
    private static final String PORT_SUFFIX = "Port"; //$NON-NLS-1$

    private IBuilderHost host;
    private String wsarName;
    private Map<String, Interface> generatedEndpoints = new HashMap<String, Interface>();
    private Map<String, Interface> modelledEndpoints = new HashMap<String, Interface>();

    private Map<String, Interface> interfaces = new HashMap<String, Interface>();
    private Map<String, QName> services = new HashMap<String, QName>();
    private Map<String, QName> ports = new HashMap<String, QName>();
    private Map<String, String> absoluteURLs = new HashMap<String, String>();
    private Map<String, String> relativeURLs = new HashMap<String, String>();
    private Map<String, String> rootWSDLFilenames = new HashMap<String, String>();

    final String TRANSPORT_PROTOCOL_XI = "soap_and_xi"; //$NON-NLS-1$
    
    public CompilerType postProcessesWhat() {
        return CompilerType.INTERFACECOMPILER;
    }

    private Writer createArchivedFile(String filename) throws Exception {
        OutputStream stream = host.createOutOfBoundsFile(wsarName, filename);
        return new OutputStreamWriter(stream, "UTF-8");
    }

    public boolean postProcess(IBuilderHost host) throws Exception {
        Map<Object, List<Object>> ppdata = host.getPostProcessorData();
        if (ppdata != null) {
            this.host = host;
            this.wsarName = host.getApplicationName().replace('/', '~') + ARCHIVE_SUFFIX;

            // collect all interfaces from the post processor data
            collectInterfaces(ppdata);

            for (String serviceId : generatedEndpoints.keySet()) {
                Interface serviceInterface = generatedEndpoints.get(serviceId);
                exportServiceDescription(serviceId, serviceInterface, ProvisioningURLUtils.getAbsoluteGeneratedURL(serviceId,
                        serviceInterface), ProvisioningURLUtils.getRelativeGeneratedURL(serviceId, serviceInterface));
            }
            for (String serviceId : modelledEndpoints.keySet()) {
                Interface serviceInterface = modelledEndpoints.get(serviceId);
                exportServiceDescription(serviceId, serviceInterface, ProvisioningURLUtils.getAbsoluteModelledURL(serviceId),
                        ProvisioningURLUtils.getRelativeModelledURL(serviceId));
            }

            Writer writer = createArchivedFile(DESCRIPTOR_LOCATION);
            writer.write(createMetaData());
            writer.close();

            return true;
        }
        return false;
    }

    private void exportServiceDescription(String serviceId, Interface iface, String absoluteURL, String relativeURL)
            throws MalformedURLException, WsdlExportException, Exception {
        absoluteURLs.put(serviceId, absoluteURL);
        relativeURLs.put(serviceId, relativeURL);
        interfaces.put(serviceId, iface);

        Wsdl1Exporter<String> exporter;
        ServiceDescriptionExtended<String> description;
        if (iface.getService().isEmpty()) {
            // This happens if there is no service in the WSDL file, we create on while exporting
            Wsdl1ExporterExtension wee = new PolicyDecorator(iface.getName() + BINDING_SUFFIX, iface.getName() + SERVICE_SUFFIX,
                    SOAP_ACTION, absoluteURL, iface.getName() + PORT_SUFFIX);
            exporter = Wsdl1ExporterProvider.getWsdl1Exporter(wee);
            description = exporter.getExtendedServiceDescription(iface.getDescriptions().iterator().next());
            services.put(serviceId, new QName(iface.getNamespace(), iface.getName() + SERVICE_SUFFIX));
            ports.put(serviceId, new QName(iface.getNamespace(), iface.getName() + PORT_SUFFIX));
        } else {
            // If there are services we pick one and use the first port defined in it
            Wsdl1ExporterExtension wee = new EndPointAddressDecorator(absoluteURL);
            exporter = Wsdl1ExporterProvider.getWsdl1Exporter(wee);
            Service service = iface.getService().iterator().next();
            description = exporter.getExtendedServiceDescription(service.getDescriptions().iterator().next());
            services.put(serviceId, new QName(service.getNamespace(), service.getName()));
            Endpoint port = service.getEndpoints().iterator().next();
            ports.put(serviceId, new QName(service.getNamespace(), port.getName()));
        }

        rootWSDLFilenames.put(serviceId, getWSDLFilename(description.getRootWsdl1Document(), serviceId));
        for (Wsdl1Document<String> wsdldoc : description.getWsdl1Documents()) {
            String wsdlFile = getWSDLFilename(wsdldoc, serviceId);
            Log.info("Writing WSDL location '%s' to file '%s'.", wsdldoc.getLocation(), wsdlFile); //$NON-NLS-1$
            Writer writer = createArchivedFile(wsdlFile);
            writer.write(wsdldoc.getContent());
            writer.close();
        }
        for (SchemaDocument<String> schema : description.getSchemaDocuments()) {
            String schemaFile = getSchemaFilename(schema, serviceId);
            Log.info("Writing Schema location '%s' with target namesapce '%s' to file '%s'.", schema.getSchemaLocation(), schema //$NON-NLS-1$
                    .getTargetNamespace(), schemaFile);
            URI schemaLocation = new URI(schema.getSchemaLocation());
            if (!schemaLocation.isAbsolute()) {
                Writer writer = createArchivedFile(schemaFile);
                writer.write(schema.get());
                writer.close();
            } else {
                Log.info("Schema location '%s' is an absolute URI, therefore schema won't be packaged.", schema.getSchemaLocation()); //$NON-NLS-1$
            }
        }
    }

    @SuppressWarnings("unchecked")
    private void collectInterfaces(Map<Object, List<Object>> ppdata) throws BpemBuildException {
        Log.info("WS Provisioning post processing started for %d artifacts found.", ppdata.keySet().size()); //$NON-NLS-1$

        // collect generated endpoints
        if (ppdata.get(false) != null) {
            for (Object endpoint : ppdata.get(false)) {
                if (endpoint instanceof Pair) {
                    Pair<String, Operation> generatedEndpoint = (Pair<String, Operation>) endpoint;
                    Interface iface = generatedEndpoint.second.getServiceInterface();
                    Log.info("Generated endpoint for post processing found (service '%s', operation '%s', interface '{%s}%s'.", //$NON-NLS-1$
                            generatedEndpoint.first, generatedEndpoint.second.getName(), iface.getNamespace(), iface.getName());
                    if (generatedEndpoints.put(generatedEndpoint.first, iface) != null) {
                        throw new BpemBuildException("BPM.rt_c_post.000000", //$NON-NLS-1$
                                "Collision between generated service identifiers detected '" + generatedEndpoint.first + "'.");//$NON-NLS-1$  //$NON-NLS-2$
                    }
                } else {
                    throw new IllegalArgumentException();
                }
            }
        }

        // collect modelled endpoints
        if (ppdata.get(true) != null) {
            for (Object endpoint : ppdata.get(true)) {
                if (endpoint instanceof Pair) {
                    Pair<String, Operation> modelledEndpoint = (Pair<String, Operation>) endpoint;
                    Interface iface = modelledEndpoint.second.getServiceInterface();
                    Log.info("Modelled endpoint for post processing found (service '%s', operation '%s', interface '{%s}%s'.",
                            modelledEndpoint.first, modelledEndpoint.second.getName(), iface.getNamespace(), iface.getName());
                    if (modelledEndpoints.put(modelledEndpoint.first, iface) != null) {
                        throw new BpemBuildException("BPM.rt_c_post.000001", //$NON-NLS-1$
                                "Collision between modelled service identifiers detected '" + modelledEndpoint.first + "'.");//$NON-NLS-1$  //$NON-NLS-2$
                    }
                } else {
                    throw new IllegalArgumentException();
                }
            }
        }

        Set<String> temp = new HashSet<String>();
        temp.addAll(generatedEndpoints.keySet());
        temp.retainAll(modelledEndpoints.keySet());
        if (temp.size() != 0) {
            throw new BpemBuildException("BPM.rt_c_post.000002", //$NON-NLS-1$
                    "Collision between modelled and generated service identifiers detected '" + temp.iterator().next() + "'."); //$NON-NLS-1$ //$NON-NLS-2$
        }
    }

    private String createMetaData() throws BpemBuildException {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        TransformerFactory tf = TransformerFactory.newInstance();
        StringWriter result = new StringWriter();
        try {
            DocumentBuilder docbuilder = dbf.newDocumentBuilder();
            Document doc = docbuilder.newDocument();
            Element stylesheet_root = doc.createElementNS(XSLT_NS, "stylesheet"); //$NON-NLS-1$
            Element stylesheet_output = doc.createElementNS(XSLT_NS, "output"); //$NON-NLS-1$
            stylesheet_output.setAttribute("method", "xml"); //$NON-NLS-1$	 //$NON-NLS-2$
            stylesheet_output.setAttribute("indent", "yes"); //$NON-NLS-1$	 //$NON-NLS-2$
            stylesheet_output.setAttribute("encoding", "UTF-8"); //$NON-NLS-1$	 //$NON-NLS-2$
            stylesheet_output.setAttributeNS(XALAN_NS, "indent-amount", "2"); //$NON-NLS-1$	 //$NON-NLS-2$
            Element stylesheet_template = doc.createElementNS(XSLT_NS, "template"); //$NON-NLS-1$
            stylesheet_template.setAttribute("match", "/"); //$NON-NLS-1$	 //$NON-NLS-2$
            stylesheet_root.appendChild(stylesheet_output);
            stylesheet_root.appendChild(stylesheet_template);
            stylesheet_template.appendChild(createWebserviceDescription(doc));
            doc.appendChild(stylesheet_root);
            doc.normalizeDocument();

            Transformer t = tf.newTransformer(new DOMSource(doc));
            t.transform(new DOMSource(doc), new StreamResult(result));
        } catch (Exception e) {
            throw new BpemBuildException("BPM.rt_c_post.000003", //$NON-NLS-1$
                    "Error occured while creating content of wsar file.", e); //$NON-NLS-1$
        }
        return result.toString();
    }

    private Element createWebserviceDescription(Document doc) {
        Element root = doc.createElementNS(WS_RT_NS, "webservices"); //$NON-NLS-1$
        for (String serviceId : interfaces.keySet()) {
            Log.info("Creating metadata for service url '%s'.", relativeURLs.get(serviceId)); //$NON-NLS-1$
            Interface iface = interfaces.get(serviceId);
            Element webserviceDescription = doc.createElement("webservice-description"); //$NON-NLS-1$
            Element webserviceName = doc.createElement("webservice-name"); //$NON-NLS-1$
            Text webserviceNameText = doc.createTextNode(iface.getName() + '_' + ProvisioningURLUtils.escapeForFilename(serviceId));
            webserviceName.appendChild(webserviceNameText);
            webserviceDescription.appendChild(webserviceName);

            Element wsdlFile = doc.createElement("wsdl-file"); //$NON-NLS-1$
            Text wsdlFileText = doc.createTextNode(rootWSDLFilenames.get(serviceId));
            wsdlFile.appendChild(wsdlFileText);
            webserviceDescription.appendChild(wsdlFile);

            QName service = services.get(serviceId);
            Element wsdlService = doc.createElement("wsdl-service"); //$NON-NLS-1$
            wsdlService.setAttribute("namespace", service.getNamespaceURI()); //$NON-NLS-1$
            Text wsdlServiceText = doc.createTextNode(service.getLocalPart());
            wsdlService.appendChild(wsdlServiceText);
            webserviceDescription.appendChild(wsdlService);

            Element portComponent = doc.createElement("port-component"); //$NON-NLS-1$

            Element portName = doc.createElement("port-name"); //$NON-NLS-1$
            Text portNameText = doc.createTextNode(iface.getName());
            portName.appendChild(portNameText);
            portComponent.appendChild(portName);

            QName port = ports.get(serviceId);
            Element wsdlPort = doc.createElement("wsdl-port"); //$NON-NLS-1$
            wsdlPort.setAttribute("namespace", port.getNamespaceURI()); //$NON-NLS-1$
            Text wsdlPortText = doc.createTextNode(port.getLocalPart());
            wsdlPort.appendChild(wsdlPortText);
            portComponent.appendChild(wsdlPort);

            Element url = doc.createElement("url"); //$NON-NLS-1$
            Text urlText = doc.createTextNode(relativeURLs.get(serviceId));
            url.appendChild(urlText);
            portComponent.appendChild(url);

            Element implementationLink = doc.createElement("implementation-link"); //$NON-NLS-1$
            Element propertyImplementationId = doc.createElement("property"); //$NON-NLS-1$
            propertyImplementationId.setAttribute("name", "implementation-id"); //$NON-NLS-1$	 //$NON-NLS-2$
            Text implementationIdText = doc.createTextNode(GALAXY_IMPLEMENTATION_ID);
            propertyImplementationId.appendChild(implementationIdText);
            implementationLink.appendChild(propertyImplementationId);
            Element propertyServiceId = doc.createElement("property"); //$NON-NLS-1$
            propertyServiceId.setAttribute("name", "service-identifier"); //$NON-NLS-1$	 //$NON-NLS-2$
            Text propertyServiceIdText = doc.createTextNode(serviceId);
            propertyServiceId.appendChild(propertyServiceIdText);
            implementationLink.appendChild(propertyServiceId);
            portComponent.appendChild(implementationLink);

            Element metaData = doc.createElement("meta-data"); //$NON-NLS-1$
            //PING: Changes to provide additional archive for XI binding in WS descriptor
            if(checkInterfaceCompatibilityForSCP(iface)){
            	Element propertyTransport = doc.createElement("property"); //$NON-NLS-1$
            	propertyTransport.setAttribute("name", "transport"); //$NON-NLS-1$	 //$NON-NLS-2$
            	Text transportText = doc.createTextNode(TRANSPORT_PROTOCOL_XI);
            	propertyTransport.appendChild(transportText);
            	metaData.appendChild(propertyTransport);
            }
            portComponent.appendChild(metaData);

            webserviceDescription.appendChild(portComponent);

            root.appendChild(webserviceDescription);
        }
        return root;
    }

    private String getWSDLFilename(Wsdl1Document<String> wsdldoc, String serviceId) {
        String originalName = wsdldoc.getLocation();
        String subPackageName = ProvisioningURLUtils.escapeForFilename(serviceId);
        return WSDL_LOCATION + '/' + subPackageName + '/' + originalName;
    }

    private String getSchemaFilename(SchemaDocument<String> schema, String serviceId) {
        String originalName = schema.getSchemaLocation();
        String subPackageName = ProvisioningURLUtils.escapeForFilename(serviceId);
        return WSDL_LOCATION + '/' + subPackageName + '/' + originalName;
    }
   
    // 3 comparizations ifw does not exist, exist but not compatible and exist and compatible
    private enum IfwCompatibility{
    	IFW_DOES_NOT_EXIST,
    	INTERFACE_NOT_COMPATIBLE,
    	INTERFACE_COMPATIBLE
    };
    
    //PING: Checks if service interface is XI 30 compatible based on ESR(ifw:properties) properties
    private boolean checkInterfaceCompatibilityForSCP(Interface iface){
    	IfwCompatibility compatible = isIntefaceCompatibleBasedOnIfwProperties(iface);
    	if(IfwCompatibility.IFW_DOES_NOT_EXIST == compatible){
    		return false;
    	}else{
    		return (IfwCompatibility.INTERFACE_COMPATIBLE == compatible);
    	}
    }
    
 
    //Checks three state : ifw:properties does not exist, exist and XI 3.0 compatible and exist and not compatible to XI 3.0
    private IfwCompatibility isIntefaceCompatibleBasedOnIfwProperties(Interface iface){
    	UnknownExtensibilityElement unknownExtensibilityElement = getIfwPropertiesElement(iface);
    	if(unknownExtensibilityElement == null){
    		return IfwCompatibility.IFW_DOES_NOT_EXIST;
    	}else{
    		String interfacePattern = getInterfacePattern(unknownExtensibilityElement);
    		String interfaceCategory = getInterfaceCategory(unknownExtensibilityElement);
    		// From 7.31.SP09 onwards, we are going to support Abstract interfaces for modeling PO scenarios.
    		if(interfacePattern == null && ("inbound".equalsIgnoreCase(interfaceCategory)) ||
    				"abstract".equalsIgnoreCase(interfaceCategory)){
    			return IfwCompatibility.INTERFACE_COMPATIBLE;
    		}else{
    			return IfwCompatibility.INTERFACE_NOT_COMPATIBLE;
    		}
    	}	
    }
    
    //returns element corresponding to ifw:properties. returns null if its not there.
    private UnknownExtensibilityElement getIfwPropertiesElement(Interface iface){
       	Collection<Description> descriptions = iface.getDescriptions();
       	for(Description description: descriptions){
       		java.util.List<UnknownExtensibilityEntity> extensibilities  = description.getExtensibilityEntities();
       		for(UnknownExtensibilityEntity unextensibility: extensibilities){
    			if(unextensibility instanceof UnknownExtensibilityElement){
    				UnknownExtensibilityElement unknownExtensibilityElement = (UnknownExtensibilityElement)unextensibility;
    				String name = unknownExtensibilityElement.getName(); 
    				String namespace = unknownExtensibilityElement.getNamespace();
    				if(name.equalsIgnoreCase("properties")&& namespace.equalsIgnoreCase("urn:com-sap:ifr:v2:wsdl")){
    					return unknownExtensibilityElement;
    				}
        		}
       		}
       	}
        return null;
    }
    // return InterfacePattern profile value. return null if this element does not exist.
    private String getInterfacePattern(UnknownExtensibilityElement unknownExtensibilityElement){
    	List<DomNode> node = unknownExtensibilityElement.getChildren();
		DomElement interfacePatternElement = getChildDomElementWithName(node, "interfacePattern", true);
		if(interfacePatternElement != null){
			return getChildDomElementDataValue(interfacePatternElement);
		}
		return null;
    }
    
   /*
    * Return DomElement with domnodes and return null if nodename and domelement are null.
    * @param domelement
    * @param nodeName
    * @param ignoreCase 
    * @return
    */
    private DomElement getChildDomElementWithName(DomElement domelement,String nodeName,boolean ignoreCase){
    	if(null == nodeName || null == domelement){
    		return null;
    	}
    	List<DomNode> domNodes = domelement.getChildren();
    	return getChildDomElementWithName(domNodes,nodeName,ignoreCase);
    }

    /*
     * loops through and return the child with name ='nodeName' and returns null incase not found.
     * @param domNodes 
     * @param nodeName
     * @param ignoreCase //ignore the String case.
     * @return
     */
    private DomElement getChildDomElementWithName(List<DomNode> domNodes,String nodeName,boolean ignoreCase){
    	if(null == nodeName || null == domNodes){
    		return null;
    	}
    	for (DomNode domNode : domNodes) {
    		if(domNode instanceof DomElement){
    			DomElement child = (DomElement)domNode;
    			String name = child.getName();
    			boolean matchFound = (ignoreCase)?nodeName.equalsIgnoreCase(name):nodeName.equals(name);
    			if(matchFound){
    				return child;
    			}
        	}
		}
    	return null;
    }
    /*
     * Loops through properties Element and retruns the interfaceCategory value.
     * @param property
     * @return
     */
    private String getInterfaceCategory(UnknownExtensibilityElement property){
    	List<DomNode> domnode = property.getChildren();
    	DomElement methodsElement = getChildDomElementWithName(domnode, "methods", true);
    	
    	if(methodsElement != null){
    		DomElement methodElement = getChildDomElementWithName(methodsElement, "method", true);
    		if(methodElement != null){
				DomElement interfaceCategoryElement = getChildDomElementWithName(methodElement, "interfaceCategory", true);
				if(interfaceCategoryElement != null){
					return getChildDomElementDataValue(interfaceCategoryElement);
				}
    		}
    	}
    	return null;
    }
/*
 * Loop throgh the Domelement and Retrunt the value of the element and return null in case no value
 * @param domelement
 * @return
 */
	private String getChildDomElementDataValue(DomElement domelement) {
		List<DomNode>  domnode = domelement.getChildren();
		for(DomNode mydomenode : domnode){
			if(mydomenode instanceof DomText){
				String mydata = ((DomText) mydomenode).getData();
				return mydata;
			}
		}
		return null;
	}
    
}