package com.sap.glx.paradigmInterface.postprocessor.ws;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.sap.glx.paradigmInterface.postprocessor.ws.misc.HTTPSSO2;
import com.sap.glx.paradigmInterface.postprocessor.ws.misc.UsingPolicy;
import com.sap.glx.paradigmInterface.postprocessor.ws.wssx.NestedPolicyType;
import com.sap.glx.paradigmInterface.postprocessor.ws.wssx.QNameAssertionType;
import com.sap.glx.paradigmInterface.postprocessor.ws.wssx.TokenAssertionType;
import com.sap.tc.esmp.tools.wsdlexport.ExporterContext;
import com.sap.tc.esmp.tools.wsdlexport.WsdlExportException;
import com.sap.tc.esmp.tools.wsdlexport.model.policy.OperatorContentType;
import com.sap.tc.esmp.tools.wsdlexport.model.policy.Policy;
import com.sap.tc.esmp.tools.wsdlexport.model.policy.PolicyReference;
import com.sap.tc.esmp.tools.wsdlexport.model.wsdl.TBinding;
import com.sap.tc.esmp.tools.wsdlexport.model.wsdl.TDefinitions;
import com.sap.tc.esmp.tools.wsdlexport.model.wsdl.TPort;
import com.sap.tc.esmp.tools.wsdlexport.model.wsdl.TService;
import com.sap.tc.esmp.tools.wsdlexport.model.wsdl.soap.TAddress;
import commonj.sdo.DataObject;
import commonj.sdo.Property;
import commonj.sdo.Type;
import commonj.sdo.helper.HelperContext;
import commonj.sdo.impl.HelperProvider;

public class WSSecurityPolicyUtils {
    private static final String SDO_NAMESPACE_FOR_XML = "commonj.sdo/xml"; //$NON-NLS-1$
    private static final String WS_2004_09_POLICY = "http://schemas.xmlsoap.org/ws/2004/09/policy"; //$NON-NLS-1$
    private static final String WS_SX_POLICY = "http://docs.oasis-open.org/ws-sx/ws-securitypolicy/200702"; //$NON-NLS-1$
    private static final String SAP_SSO_POLICY = "http://www.sap.com/webas/630/soap/features/security/policy"; //$NON-NLS-1$

    private String endpointAddress;
    private HelperContext helperContext = HelperProvider.getDefaultContext();

    private final Property property_pol = getMixedTextProperty(WS_2004_09_POLICY, "Policy", true); //$NON-NLS-1$
    private final Property property_polref = getMixedTextProperty(WS_2004_09_POLICY, "PolicyReference", true); //$NON-NLS-1$
    private final Property property_usingpol = getMixedTextProperty(WS_2004_09_POLICY, "UsingPolicy", true); //$NON-NLS-1$
    private final Property transportBinding = getMixedTextProperty(WS_SX_POLICY, "TransportBinding", true); //$NON-NLS-1$
    private final Property transportToken = getMixedTextProperty(WS_SX_POLICY, "TransportToken", true); //$NON-NLS-1$
    private final Property prop_httpsToken = getMixedTextProperty(WS_SX_POLICY, "HttpsToken", true); //$NON-NLS-1$
    private final Property algorithmSuite = getMixedTextProperty(WS_SX_POLICY, "AlgorithmSuite", true); //$NON-NLS-1$
    private final Property prop_tripleDesRsa15 = getMixedTextProperty(WS_SX_POLICY, "TripleDesRsa15", true); //$NON-NLS-1$
    private final Property prop_strict = getMixedTextProperty(WS_SX_POLICY, "Strict", true); //$NON-NLS-1$
    private final Property layout = getMixedTextProperty(WS_SX_POLICY, "Layout", true); //$NON-NLS-1$

    public WSSecurityPolicyUtils(String endpointAddress) {
        this.endpointAddress = endpointAddress;
    }

    @SuppressWarnings("unchecked")
    void decorate(ExporterContext context) throws WsdlExportException {
        Collection<TDefinitions> definitions = context.getAllDefinitions();
        Iterator<TDefinitions> iterator = definitions.iterator();
        Policy policy = create(Policy.class);
        OperatorContentType exactly_one = create(OperatorContentType.class);
        OperatorContentType all = create(OperatorContentType.class);
        OperatorContentType wsp_exactly_one = create(OperatorContentType.class);
        all.getExactlyOne().add(wsp_exactly_one);
        exactly_one.getAll().add(all);
        createPolicyEntry(wsp_exactly_one, WS_SX_POLICY, "HttpBasicAuthentication", (DataObject) create(QNameAssertionType.class)); //$NON-NLS-1$
        createPolicyEntry(wsp_exactly_one, SAP_SSO_POLICY, "HTTPSSO2", (DataObject) create(HTTPSSO2.class)); //$NON-NLS-1$
        policy.getExactlyOne().add(exactly_one);
        policy.setId("GLX_POLICY"); //$NON-NLS-1$
        PolicyReference polref = create(PolicyReference.class);
        polref.setUri("#GLX_POLICY"); //$NON-NLS-1$

        while (iterator.hasNext()) {
            TDefinitions definition = iterator.next();
            List<Policy> policies = (((DataObject) definition).getList(property_pol));
            if (policies != null) {
                policies.add((Policy) policy);
            }

            if (((DataObject) definition).getDataObject(property_usingpol) == null) {
                ((DataObject) definition).setDataObject(property_usingpol, (DataObject) create(UsingPolicy.class));
            }
            List<TService> services = definition.getService();
            Iterator<TService> serviceIter = services.iterator();
            while (serviceIter.hasNext()) {
                TPort port = serviceIter.next().getPort().get(0);
                DataObject portDataObject = (DataObject) port;
                List<?> addresses = portDataObject.getList("address"); //$NON-NLS-1$
                if (addresses.size() > 0) {
                    DataObject addressObject = (DataObject) addresses.get(0);
                    TAddress taddress = null;
                    if (addressObject instanceof TAddress) {
                        taddress = (TAddress) addressObject;
                        taddress.setLocation(endpointAddress);
                    }
                }
                break;
            }
            List<TBinding> bindings = definition.getBinding();
            for (TBinding binding : bindings) {
                if (((DataObject) binding).getDataObject(property_polref) == null) {
                    ((DataObject) binding).setDataObject(property_polref, (DataObject) polref);
                }
            }
            break;
        }
    }

    private OperatorContentType createPolicyEntry(OperatorContentType parent, String uri, String name, DataObject auth_policy) {
        OperatorContentType wsp_all = create(OperatorContentType.class);
        parent.getAll().add(wsp_all);
        NestedPolicyType e_transportbinding = create(NestedPolicyType.class);
        ((DataObject) wsp_all).setDataObject(transportBinding, (DataObject) e_transportbinding);
        Policy pol_HTTPBasic = create(Policy.class);
        ((DataObject) e_transportbinding).setDataObject(property_pol, (DataObject) pol_HTTPBasic);

        NestedPolicyType e_transporttoken = create(NestedPolicyType.class);
        ((DataObject) pol_HTTPBasic).setDataObject(transportToken, (DataObject) e_transporttoken);
        Policy httpsToken = create(Policy.class);
        TokenAssertionType e_httpsToken = create(TokenAssertionType.class);
        ((DataObject) e_transporttoken).setDataObject(property_pol, (DataObject) httpsToken);
        ((DataObject) httpsToken).setDataObject(prop_httpsToken, (DataObject) e_httpsToken);
        Policy httpBasicAuthentication = create(Policy.class);
        ((DataObject) e_httpsToken).setDataObject(property_pol, (DataObject) httpBasicAuthentication);

        Property prop_auth = getMixedTextProperty(uri, name, true);
        ((DataObject) httpBasicAuthentication).setDataObject(prop_auth, auth_policy);

        NestedPolicyType e_algorithmsuite = create(NestedPolicyType.class);
        ((DataObject) pol_HTTPBasic).setDataObject(algorithmSuite, (DataObject) e_algorithmsuite);
        Policy tripleDesRsa15 = create(Policy.class);
        QNameAssertionType e_tripleDesRsa15 = create(QNameAssertionType.class);
        ((DataObject) e_algorithmsuite).setDataObject(property_pol, (DataObject) tripleDesRsa15);
        ((DataObject) tripleDesRsa15).setDataObject(prop_tripleDesRsa15, (DataObject) e_tripleDesRsa15);

        NestedPolicyType e_layout = create(NestedPolicyType.class);
        ((DataObject) pol_HTTPBasic).setDataObject(layout, (DataObject) e_layout);
        Policy strict = create(Policy.class);
        ((DataObject) e_layout).setDataObject(property_pol, (DataObject) strict);
        QNameAssertionType e_strict = create(QNameAssertionType.class);
        ((DataObject) strict).setDataObject(prop_strict, (DataObject) e_strict);
        return wsp_all;
    }

    @SuppressWarnings("unchecked")
    private <T> T create(Class<T> clazz) {
        return (T) helperContext.getDataFactory().create(clazz);
    }

    private Property getMixedTextProperty(String uri, String name, boolean many) {
        if (name == null) {
            throw new NullPointerException("name must not be null"); //$NON-NLS-1$
        }
        DataObject propertyDo = helperContext.getDataFactory().create("commonj.sdo", "Property"); //$NON-NLS-1$   //$NON-NLS-2$
        propertyDo.setString("name", name); //$NON-NLS-1$
        Type type = helperContext.getTypeHelper().getType("commonj.sdo", "Text"); //$NON-NLS-1$   //$NON-NLS-2$
        propertyDo.set("type", type); //$NON-NLS-1$
        propertyDo.set("many", many); //$NON-NLS-1$
        propertyDo.set("containment", true); //$NON-NLS-1$
        Property xmlElementProperty = helperContext.getTypeHelper().getOpenContentProperty(SDO_NAMESPACE_FOR_XML, "xmlElement"); //$NON-NLS-1$
        propertyDo.setBoolean(xmlElementProperty, true);

        if (uri != null && !"".equals(uri)) { //$NON-NLS-1$
            Property refProperty = helperContext.getTypeHelper().getOpenContentProperty(SDO_NAMESPACE_FOR_XML, "ref"); //$NON-NLS-1$
            // this simulates a reference to a TopLevelElement and so the
            // namespace is always rendered
            String ref = uri + '#' + name;
            propertyDo.setString(refProperty, ref);
        }
        Property result = helperContext.getTypeHelper().defineOpenContentProperty(null, propertyDo);
        return result;
    }

}
