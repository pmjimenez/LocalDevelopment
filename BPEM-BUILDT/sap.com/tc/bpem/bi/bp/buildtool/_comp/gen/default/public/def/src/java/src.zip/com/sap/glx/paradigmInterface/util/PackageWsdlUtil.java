package com.sap.glx.paradigmInterface.util;

import java.io.File;
import java.io.OutputStream;
import java.net.URI;
import java.util.Collection;

import javax.xml.namespace.QName;

import com.sap.glx.paradigmInterface.buildapi.IBuilderHost;
import com.sap.ide.es.config.mc.model.mc.logicalsystem.Qname;
import com.sap.ide.es.config.mc.model.mc.servicereferences.ServiceReference;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.esmp.mm.wsdl2.Interface;
import com.sap.tc.esmp.tools.wsdlexport.ServiceDescriptionExtended;
import com.sap.tc.esmp.tools.wsdlexport.Wsdl1Document;
import com.sap.tc.esmp.tools.wsdlexport.Wsdl1Exporter;
import com.sap.tc.esmp.tools.wsdlexport.Wsdl1ExporterProvider;
import com.sap.tc.esmp.tools.xsdexport.SchemaDocument;
import com.sap.tc.glx.CompilerRegistry;
import com.sap.tc.moin.repository.CRI;
import com.sap.tc.moin.repository.Connection;

public class PackageWsdlUtil {

	private static final String SRC_WSDL = "src/wsdl/";	 //$NON-NLS-1$
	Connection connection;
	IPluginBuildInfo pbi;
	CRI cri;
	IBuilderHost host;
	
	public PackageWsdlUtil(Connection connection, IPluginBuildInfo pbi, CRI cri, IBuilderHost host) {
		super();
		this.connection = connection;
		this.pbi = pbi;
		this.cri = cri;
		this.host = host;
	}
	
	public void packageWsdls() throws Exception {

		// Collecting all service references
    	Collection<ServiceReference> services = ToolUtils.getInstance().queryByType(connection, 
				ServiceReference.class, new String[] { "mc", "servicereferences", "ServiceReference" }, true, cri);  //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    	
    	for(ServiceReference serv: services){
    		getWsdlContent(serv);
		}
	}
	
	private void getWsdlContent(ServiceReference servRef) throws Exception {
		Qname portType = servRef.getPorttype();
		String nameSpace = portType.getNamespace();
		String localName = portType.getName();
		//Log.info("portType: " + portType.toString());
		QName qName = new QName(nameSpace, localName);
		//Log.info("qName: " + qName.toString());
		Interface i = ToolUtils.getInstance().findServiceInterface(connection, Interface.class, qName);
		
		// if the interface cannot be found, skip this reference
		if (i==null) { return; }
		
		Wsdl1Exporter<String> exporter = Wsdl1ExporterProvider.getWsdl1Exporter(null);
        ServiceDescriptionExtended<String> description = exporter.getExtendedServiceDescription(i.getDescriptions().iterator().next());
        for (Wsdl1Document<String> wsdldoc : description.getWsdl1Documents()) {
            Log.info("WSDL Location:" + wsdldoc.getLocation());  //$NON-NLS-1$
            String dirName = new StringBuilder(CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.WSDL)).append(BuildPluginConstants.FILE_SEPARATOR).append(getContainingDC(servRef)).toString();
            (new File(dirName)).mkdirs();
            writeWsdlFile(dirName, wsdldoc);
        }
        for (SchemaDocument<String> schema : description.getSchemaDocuments()) {
            Log.info("Schema:" + schema.getTargetNamespace()+ "#" + schema.getSchemaLocation());     //$NON-NLS-1$   //$NON-NLS-2$
            URI loc = new URI(schema.getSchemaLocation());
            if (!loc.isAbsolute()) {
                String dirName = new StringBuilder(CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.WSDL)).append(BuildPluginConstants.FILE_SEPARATOR).append(getContainingDC(servRef)).toString();
                (new File(dirName)).mkdirs();
                writeXsdFile(dirName, schema);           	
            } else {
            	Log.info("Schema location " + schema.getSchemaLocation() + " is an absolute URI, therefore schema won't be packaged."); //$NON-NLS-1$   //$NON-NLS-2$
            }
        }
	}

	private String getContainingDC(ServiceReference servRef) {
		CRI servCri = servRef.getLogicalSystem().get___Mri().getCri();
		Log.info(servCri.toString());
		if (!cri.equals(servCri)){
			return tildeName(servCri.getContainerName());
		}
		else
		{
			return (new StringBuilder(pbi.getDCVendor())).append("~").append(tildeName(pbi.getDCName())).toString();
		}
	}

	private void writeXsdFile(String dirName, SchemaDocument<String> schema) throws Exception {
		String filename = getSchemaName(schema);
		File outFile = new File(dirName, filename); 
		OutputStream oStream = host.createVersionedTargetFile(outFile.toString(), filename);
		oStream.write(schema.get().getBytes(BuildPluginConstants.ENCODING_UTF8));
		oStream.close();
	}

	private void writeWsdlFile(String dirName, Wsdl1Document<String> wsdldoc) throws Exception{
		String filename = getWSDLFileName(wsdldoc);
		File outFile = new File(dirName, filename); 
		OutputStream oStream = host.createVersionedTargetFile(outFile.toString(), filename);
		oStream.write(wsdldoc.getContent().getBytes(BuildPluginConstants.ENCODING_UTF8));
		oStream.close();
	}
	
	private String getWSDLFileName(Wsdl1Document<String> wsdldoc) {
        String wsdlPath = wsdldoc.getLocation();
        if (wsdlPath.startsWith(SRC_WSDL)) {
            return wsdlPath.substring(SRC_WSDL.length());
        } else {
            return wsdlPath;
        }
	}

	private String getSchemaName(SchemaDocument<String> schema) {
		String schemaPath = schema.getSchemaLocation();
		if (schemaPath.startsWith(SRC_WSDL)){
			return schemaPath.substring(SRC_WSDL.length());
		}
		else
		{
		return schemaPath;
		}	
	}
 
    private String tildeName(String name) {
        return name.replace('/', '~');
    }

}
