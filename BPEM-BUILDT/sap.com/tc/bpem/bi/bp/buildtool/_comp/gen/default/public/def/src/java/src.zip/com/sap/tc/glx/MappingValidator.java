package com.sap.tc.glx;

import java.text.MessageFormat;
import java.util.Collection;
import java.util.LinkedList;

import com.sap.glx.paradigmInterface.bpmn.compiler.Warnable;
import com.sap.glx.paradigmInterface.bpmn.compiler.mapping.DataMappingValidator;
import com.sap.glx.paradigmInterface.bpmn.compiler.mapping.GlxBuildTimeValidationAdviserFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.mapping.IValidationResultReporter;
import com.sap.mapping.dtmodel.mapping.IValidationItem;
import com.sap.mapping.dtmodel.validation.IValidationAdviser;
import com.sap.tc.moin.repository.CRI;
import com.sap.tc.moin.repository.Connection;
import com.sap.tc.moin.repository.mmi.reflect.RefObject;

/**
 * Utility for performing data mapping validation within a development component build. Upon errors the implementation would throw
 * {@link ValidationErrorsDetectedException}
 * 
 * @author I030720
 */
public class MappingValidator
{
	private final Connection connection;
	private final CRI cri;
	private final Warnable warnable;

	/**
	 * Thrown when validation encountered errors in the modelled mappings and expressions
	 * 
	 * @see MappingValidator#validate()
	 * @author I030720
	 */
	public class ValidationErrorsDetectedException extends RuntimeException
	{
		private static final long serialVersionUID = 7731336432264862171L;

		public ValidationErrorsDetectedException(final String message)
		{
			super(message);
		}
	}

	/**
	 * Constructor
	 * 
	 * @param connection
	 *            a {@link Connection} to be used to query the MOIN model
	 * @param cri
	 *            the resource identifier of the currently built development component
	 * @param warnable
	 *            a {@link Warnable} instance to report warnings and errors in the log
	 */
	public MappingValidator(final Connection connection, final CRI cri, final Warnable warnable)
	{
		this.connection = connection;
		this.cri = cri;
		this.warnable = warnable;
	}

	/**
	 * Performs the validation
	 * 
	 * @throws ValidationErrorsDetectedException
	 *             when the validation encountered errors in the modelled mapping and expressions
	 */
	public void validate() throws ValidationErrorsDetectedException
	{
		final IValidationAdviser validationAdviser = new GlxBuildTimeValidationAdviserFactory().createAdviser();
		final ValidationResultReporter reporter = new ValidationResultReporter();
		new DataMappingValidator(validationAdviser, reporter).validate(connection, cri);
		reporter.interruptOnErrors();
	}

	private class ValidationResultReporter implements IValidationResultReporter
	{
		private static final String MESSAGE_TEMPLATE = "[{0}] {1}"; //$NON-NLS-1$
		private final Collection<IValidationItem<RefObject>> reportedErrors = new LinkedList<IValidationItem<RefObject>>();

		@Override
		public void reportErrors(final Collection<IValidationItem<RefObject>> errors)
		{
			report(errors, Warnable.Severity.ERROR);
			reportedErrors.addAll(errors);
		}

		@Override
		public void reportWarnings(Collection<IValidationItem<RefObject>> warnings)
		{
			report(warnings, Warnable.Severity.WARNING);
		}

		private void report(final Collection<IValidationItem<RefObject>> items, final Warnable.Severity severity)
		{
			for (IValidationItem<RefObject> item : items)
			{
				warnable.addWarning(severity, item.getObject(), MessageFormat.format(MESSAGE_TEMPLATE, severity, item.getMessage()));
			}
		}

		private void interruptOnErrors()
		{
			if (!reportedErrors.isEmpty())
			{
				throw new ValidationErrorsDetectedException(MessageFormat.format("Data mapping validation encountered errors:\n{0}", buildErrorReport())); //$NON-NLS-1$
			}
		}

		private String buildErrorReport()
		{
			final StringBuilder reportBuilder = new StringBuilder();
			for (IValidationItem<RefObject> item : reportedErrors)
			{
				reportBuilder.append(item.getMessage() + "\n"); //$NON-NLS-1$
			}
			return reportBuilder.toString();
		}
	}
}
