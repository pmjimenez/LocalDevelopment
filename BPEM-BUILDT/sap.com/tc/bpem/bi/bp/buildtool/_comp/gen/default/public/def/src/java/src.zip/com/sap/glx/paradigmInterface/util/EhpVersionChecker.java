package com.sap.glx.paradigmInterface.util;

import java.util.HashSet;
import java.util.Iterator;

import com.sap.tc.buildplugin.BuildSessionManager;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.pp.api.IComponentDependencies;
import com.sap.tc.buildplugin.pp.api.IComponentDependency;

public class EhpVersionChecker {

	/*
	 * Returns true if dependencies are OK
	 * IF this method is updated you should also update the method in IdeUtils
	 */
	public static boolean isEhp2Project() {
		// dependencies needed for microbus
		HashSet<String> goodDependencies = new HashSet<String>();
		goodDependencies.add("bie/sca/scdl/gen"); //$NON-NLS-1$
		goodDependencies.add("bie/sca/scdl/gen/mc"); //$NON-NLS-1$
		goodDependencies.add("bie/sca/scdl/contributors/glx"); //$NON-NLS-1$
		goodDependencies.add("bie/sca/scdl/contributors/mc"); //$NON-NLS-1$
		goodDependencies.add("ide/es/config/mc/model/bi"); //$NON-NLS-1$
		goodDependencies.add("bie/sca/scdl/gen/xlf2prop"); //$NON-NLS-1$

		// dependencies not needed anymore (webservice rutime
		HashSet<String> badDependencies = new HashSet<String>();
		badDependencies.add("tc/bi/mctech"); //$NON-NLS-1$
		// note that "ide/es/config/mc/model/bi" is not a bad dependency since
		// it is also needed for microbus
		IPluginBuildInfo pbi = (IPluginBuildInfo) BuildSessionManager.getFromBuildSession(IPluginBuildInfo.class.getName());
		IComponentDependencies dependencies = pbi.getDependencies();

		for (IComponentDependency dep : dependencies) {
			// if a bad dependency is found return false
			if (badDependencies.contains(dep.getComponentName())) {
				return false;
			}

			// check if the dependency is one of the good dependencies
			Iterator<String> depNameIt = goodDependencies.iterator();
			while (depNameIt.hasNext()) {
				String depName = depNameIt.next();
				if (dep.getComponentName().contains(depName)) {
					// remove found dependecy from the searchlist to fasten
					// search
					depNameIt.remove();
				}
			}
		}
		// when searchlist is empty all needed dependencies were found, so
		// return this.
		return goodDependencies.isEmpty();
	}
}
