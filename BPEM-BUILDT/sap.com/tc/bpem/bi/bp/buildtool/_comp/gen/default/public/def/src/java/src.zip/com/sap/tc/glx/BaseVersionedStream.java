package com.sap.tc.glx;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;

import com.sap.glx.util.DigestUtil;

import com.sap.glx.paradigmInterface.util.BuildPluginConstants;

/**
 * This class manages the filewriter method of the compilers.
 * 
 * @author I044123
 * 
 */
public class BaseVersionedStream extends FileOutputStream {

    private final String fileName;
    private final Object artifact;
    protected MessageDigest currentAlgorithm;
    private BuilderHostImpl builderHost = null;
    protected boolean closeInvoked;

    /**
     * This constructor creates a new stream.
     * 
     * @param fileName
     *            - The name of the file.
     * @param fullPath
     *            - The full path of the file.
     * @param artifact
     *            - The artifact which is compiled.
     * @param aImpl
     *            - The parent class.
     * @throws FileNotFoundException
     * @throws NoSuchAlgorithmException
     */
    public BaseVersionedStream(final String fileName, final File fullPath, final Object artifact, final BuilderHostImpl aImpl)
            throws FileNotFoundException, NoSuchAlgorithmException {
        super(fullPath);
        this.builderHost = aImpl;
        this.fileName = fileName;
        this.artifact = artifact;
        this.closeInvoked = false;

        currentAlgorithm = MessageDigest.getInstance("MD5");
        currentAlgorithm.reset();
    }

    protected void createFile(final String typeId) {
        final int compilerIndex = CompilerRegistry.getIndex();
        final CompDirs cd = CompilerRegistry.COMPILERS[compilerIndex];
        final String artifactPath = builderHost.getArtifactPath(artifact);
        final String sourcePath = cd.getTargetDir().getPath() + BuildPluginConstants.FILE_SEPARATOR + artifactPath + fileName;
        String targetPath;
        if (cd.getTargetDir().getPath().equals("")) {
            targetPath = cd.getTargetDir().getPath() + artifactPath + fileName;
        } else {
            targetPath = cd.getTargetDir().getPath() + BuildPluginConstants.FILE_SEPARATOR + artifactPath + fileName;
        }

        // We check whether is a row in the VersionRegistry for this object.
        // If it is then update the row otherwise add a new one.
        boolean newTocEntryRequired = true;
        if (!cd.newTocEntry()) {
            for (int i = 0; i < builderHost.getVersionRegistrySize(); i++) {
                final VersionRegistry vr = builderHost.getVersionRegistryRow(i);
                if ((vr.getArtifact().equals(artifact)) && (vr.getCompilerId() == cd.getCompiler())) {
                    // In case the version id is already in the version registry, only an update is done.
                    vr.setSourcePath(sourcePath);
                    vr.setTargetPath(targetPath);
                    vr.setToPackage(true);
                    builderHost.setVersionRegistryRow(i, vr);
                    newTocEntryRequired = false;
                    break;
                }
            }
        }
        if (newTocEntryRequired) {
            builderHost.addVersionRegistry(new VersionRegistry(artifact, cd.getCompiler(), typeId, sourcePath, targetPath, true));
        }
    }
}
