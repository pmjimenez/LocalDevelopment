/**
 * 
 */
package com.sap.glx.paradigmInterface.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.sap.sdm.ant.api.ComponentIF;
import com.sap.sdm.ant.api.DependencyIF;
import com.sap.sdm.ant.api.JarSAPException;
import com.sap.sdm.ant.api.JarSAPFactory;
import com.sap.sdm.ant.api.JarSAPIF;
import com.sap.tc.buildplugin.BuildSessionManager;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.buildplugin.pp.api.IComponentDependencies;
import com.sap.tc.buildplugin.pp.api.IComponentDependency;
import com.sap.tc.buildplugin.pp.api.IDCAttribute;
import com.sap.tc.buildplugin.pp.api.IDCAttributes;

public class GenerateSDA {

    File ctxDir;
    File tmpDir;
    private static final String logPrefix = BuildPluginLogConstants.CSN_COMPONENT_NAME + " " + GenerateSDA.class.getName();

    public GenerateSDA(File tmpDir) {
        Log.debug(logPrefix + " GenerateSDA(File tmpDir) - entering.");
        this.tmpDir = tmpDir;
        ctxDir = new File(tmpDir, BuildPluginConstants.SDA_TMP_DIR);
        ctxDir.mkdirs();
        Log.debug(logPrefix + " GenerateSDA(File tmpDir) - exiting.");
    }

    public File execute(String name, String vendor, String location, String version, File srcDir) throws IOException, JarSAPException {
        Log.debug(logPrefix + " execute(name, vendor, location, version, srcDir) - entering.");
        Log.info(logPrefix + " execute(name, vendor, location, version, srcDir) -Generating SDA...");

        String tildedName = tildeName(name); // Replace '/' characters to '~'
        String archPatternName = new StringBuilder(256).append(vendor).append("~").append(tildedName).toString();

        File sdaFile = new File(tmpDir, archPatternName + BuildPluginConstants.SDA_EXTENSION);
        File bpemFile = new File(ctxDir, archPatternName + BuildPluginConstants.BPEM_ARCHIVE_EXTENSION);
        // File zipFile = new File( ctxDir, archPatternName+".zip" );
        File manifestFile = new File(ctxDir, BuildPluginConstants.META_INF_DIR);
        manifestFile.mkdirs();

        // Generate BPEM archive
        generateArchive(bpemFile, srcDir);

        // Adding runtime references to application-j2ee-engine.xml
        Map<String, String> keyValuePairs = new HashMap<String, String>(2);
        StringBuilder runtimeXml = new StringBuilder();
        IPluginBuildInfo pbi = (IPluginBuildInfo) BuildSessionManager.getFromBuildSession(IPluginBuildInfo.class.getName());
        IComponentDependencies dependencies = pbi.getDependencies();
        IComponentDependency dep = null;

        if (dependencies != null) {
            for (int i = 0; i < dependencies.size(); i++) {
                dep = (IComponentDependency) dependencies.get(i);
                // include only deploytime and runtime dependencies
                if (dep.isAtRuntime()) {
                    keyValuePairs.put(BuildPluginConstants.REFERENCED_DC_VENDOR_KEY, dep.getVendor());
                    keyValuePairs.put(BuildPluginConstants.REFERENCED_DC_NAME_KEY, dep.getName());
                    runtimeXml.append(substituteParams(BuildPluginConstants.RUNTIME_REFERENCE_XML, keyValuePairs));
                    keyValuePairs.remove(BuildPluginConstants.REFERENCED_DC_NAME_KEY);
                    keyValuePairs.remove(BuildPluginConstants.REFERENCED_DC_VENDOR_KEY);
                }
            }
        }

        keyValuePairs.put(BuildPluginConstants.REFERENCES_KEY, runtimeXml.toString());
        keyValuePairs.put(BuildPluginConstants.BPEM_FILE_KEY, bpemFile.getName());

        // Copying xml files
        // generateJ2eeEngineXml();
    //    copyResourceAsFile(manifestFile, BuildPluginConstants.APPLICATION_XML_FILE, null);
        copyResourceAsFile(manifestFile, BuildPluginConstants.APPLICATION_J2EE_ENGINE_XML_FILE, keyValuePairs);

        // Generate SDA
        generateSDA(name, vendor, location, version, copyResourceAsFile(tmpDir, BuildPluginConstants.SDA_DD_XML_FILE, null), sdaFile,
                ctxDir);

        Log.debug(logPrefix + " execute(name, vendor, location, version, srcDir) - exiting.");
        return sdaFile;
    }

    private File copyResourceAsFile(File parent, String resourceName, Map<String, String> keyValuePairs) throws IOException {
        Log.debug(logPrefix + " copyResourceAsFile(parent, resourceName, keyValuePairs) - entering.");

        InputStream is = getClass().getResourceAsStream(BuildPluginConstants.RESOURCES_FOLDER + resourceName);
        // InputStream is = getClass().getResourceAsStream("resources/" + resourceName);
        if (is == null) {
            Log.error(logPrefix
                    + "  copyResourceAsFile(parent, resourceName, keyValuePairs)  - Exception during bpm's gen folder generation.");
            throw new IOException("Fatal:Cannot generate SDA due to missing resource:" + resourceName);
        }

        File outFile = new File(parent, resourceName);
        BufferedReader bReader = new BufferedReader(new InputStreamReader(is, BuildPluginConstants.ENCODING_UTF8));

        StringBuilder content = new StringBuilder();
        String line;
        while ((line = bReader.readLine()) != null) {
            content.append(line).append(BuildPluginConstants.LINE_SEPARATOR);
        }

        bReader.close();
        is.close();
        CharSequence parsed;
        if (keyValuePairs != null && keyValuePairs.size() > 0) {
            parsed = substituteParams(content, keyValuePairs);
        } else {
            parsed = content;
        }
        FileWriter fWriter = new FileWriter(outFile);
        fWriter.write(parsed.toString());
        fWriter.close();

        Log.debug(logPrefix + " copyResourceAsFile(parent, resourceName, keyValuePairs) - exiting.");
        return outFile;
    }

    private void generateArchive(File outArchive, File srcDir) throws IOException {
        Log.debug(logPrefix + " generateArchive(outArchive, srcDir) - entering.");

        // create a ZipOutputStream to zip the data to
        ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(outArchive));

        // Zip the directory
        zipDir(srcDir, zos, srcDir);

        // close the stream
        zos.close();

        Log.info(logPrefix + " generateArchive(outArchive, srcDir) - " + outArchive + " archive is generated");
        Log.debug(logPrefix + " generateArchive(outArchive, srcDir) - exiting.");
    }

    public void generateOutOfBoundsArchives(Hashtable<String, File> archives) throws IOException {
        Log.debug(logPrefix + " generateOutOfBoundsArchives(archives) - entering.");

        for (String key : archives.keySet()) {
            ctxDir.mkdirs();
            generateArchive(new File(ctxDir, key), archives.get(key));
        }
        Log.debug(logPrefix + " generateOutOfBoundsArchives(archives) - exiting.");
    }

    public void generateContentMetaFile(File metaFile, String location, String keycounter, long buildTime) throws IOException {
        Log.debug(logPrefix + " generateContentMetaFile(metaFile, location, keycounter, buildTime) - entering.");
        String meta = "";
        FileWriter fstream = new FileWriter(metaFile);
        BufferedWriter out = new BufferedWriter(fstream);

        meta = meta + "Location" + "\t" + location + "\n";
        meta = meta + "Keycounter" + "\t" + keycounter + "\n";
        meta = meta + "Buildtime" + "\t" + new Long(buildTime).toString() + "\n";

        out.write(meta);
        out.close();
        Log.debug(logPrefix + " generateContentMetaFile(metaFile, location, keycounter, buildTime) - exiting.");
    }

    private void zipDir(File zipDir, ZipOutputStream zos, File rootDir) throws IOException {
        Log.debug(logPrefix + " zipDir(zipDir, zos, rootDir) - entering.");

        // get a listing of the directory content
        String[] dirList = zipDir.list();
        byte[] readBuffer = new byte[2156];
        int bytesIn = 0;
        String slashedPath;
        // loop through dirList, and zip the files
        for (int i = 0; i < dirList.length; i++) {
            File f = new File(zipDir, dirList[i]);            
            if (f.isDirectory()) {
                // if the File object is a directory, call this
                // function again to add its content recursively
                zipDir(f, zos, rootDir);
                slashedPath = replaceBackslashesToSlashes(f.getPath().substring((int) (rootDir.getPath().length()) + 1));
                ZipEntry anEntry = new ZipEntry(slashedPath + "/");

                // place the zip entry in the ZipOutputStream object
                zos.putNextEntry(anEntry);

                // loop again
                continue;
            }
            // if we reached here, the File object f was not a directory
            // create a FileInputStream on top of f
            FileInputStream fis = new FileInputStream(f);
            // create a new zip entry
            slashedPath = replaceBackslashesToSlashes(f.getPath().substring((int) (rootDir.getPath().length()) + 1));
            ZipEntry anEntry = new ZipEntry(slashedPath);

            // place the zip entry in the ZipOutputStream object
            zos.putNextEntry(anEntry);
            // now write the content of the file to the ZipOutputStream
            while ((bytesIn = fis.read(readBuffer)) != -1) {
                zos.write(readBuffer, 0, bytesIn);
            }
            // close the Stream
            fis.close();
        } // end for for
        Log.debug(logPrefix + "  zipDir(zipDir, zos, rootDir) - exiting.");
    }

    private File generateSDA(String name, String vendor, String location, String counter, File deployFile, File sdaFile, File ctxFiles)
            throws IOException, JarSAPException {
        Log.debug(logPrefix + " generateSDA(name,  vendor, location, counter, deployFile, sdaFile,  ctxFiles) - entering.");

        // Log.info("GenerateSDA.generateSDA");
        IPluginBuildInfo pbi = (IPluginBuildInfo) BuildSessionManager.getFromBuildSession(IPluginBuildInfo.class.getName());

        JarSAPIF jarsap = JarSAPFactory.getInstance().createJarSAP(null);
        ComponentIF componentdef = jarsap.createComponent();
        jarsap.setSoftwaretype("J2EE");
        jarsap.setDeployfile(deployFile.getCanonicalPath());
        
        // Set data in SAP-MANIFEST
        componentdef.setName(name);
        componentdef.setVendor(vendor);
        componentdef.setLocation(location);
        componentdef.setCounter(counter);
        componentdef.setScname(pbi.getSCName());
        componentdef.setScvendor(pbi.getSCVendor());

        // Set CSN component name in SAP-MANIFEST
        IDCAttributes atts = pbi.getDCAttributes();
        for (IDCAttribute att: atts.getAttributes("ACHAssignment", "sap.com")){
        	Log.info("atts: " + att.getValue());
        	jarsap.setCsnComponent(att.getValue());
        }
        
        // Set dependencies in SAP-MANIFEST
        IComponentDependencies dependencies = pbi.getDependencies();
        IComponentDependency dep = null;

        DependencyIF dependency = null;

        if (dependencies != null) {
            for (int i = 0; i < dependencies.size(); i++) {
                dep = (IComponentDependency) dependencies.get(i);
                // include only deploytime and runtime dependencies
                if (dep.isAtDeploy() || dep.isAtRuntime()) {
                    dependency = (DependencyIF) jarsap.createDependency();
                    dependency.setVendor(dep.getVendor());
                    dependency.setName(dep.getName());
                }
            }
        }

        jarsap.setCompress("true");

        // definition of the archivename to be created
        jarsap.setJarfile(sdaFile.getCanonicalPath());

        jarsap.createANTFileSet(ctxFiles.getCanonicalPath());

        // create the file
        jarsap.execute();

        Log.debug(logPrefix + " generateSDA(name,  vendor, location, counter, deployFile, sdaFile,  ctxFiles) - exiting.");
        return sdaFile;
    }

    private CharSequence substituteParams(CharSequence source, Map<String, String> map) {
        Log.debug(logPrefix + " substituteParams(source,  map) - entering.");

        Pattern pattern = Pattern.compile("\\$\\{([a-zA-Z_0-9.]+)\\}");// "\\$\\{(\\w+)\\}"

        Matcher matcher = pattern.matcher(source);
        StringBuffer buffer = new StringBuffer();
        String value;
        while (matcher.find()) {
            value = map.get(matcher.group(1));
            value = value == null ? "" : value;
            value = Matcher.quoteReplacement(value);
            matcher.appendReplacement(buffer, value);
        }
        matcher.appendTail(buffer);

        Log.debug(logPrefix + " substituteParams(source,  map) - exiting.");
        return buffer;
    }

    private String tildeName(String name) {
        return name.replace('/', '~');
    }

    private String replaceBackslashesToSlashes(String path) {
        return path.replace('\\', '/');
    }

    public void copyMcArchive(File publicFolder) throws IOException {
        Log.debug(logPrefix + " copyMcArchive(File publicFolder) - entering.");

        Log.info(logPrefix + " copyMcArchive(File publicFolder) -Including Mass Configuration archive into sda");
        File mcDir = new File(publicFolder, "mcjar/lib");

        // Filtering Mass Configuration archive
        FilenameFilter filter = new FilenameFilter() {

            public boolean accept(File dir, String name) {
                return name.endsWith(BuildPluginConstants.MASS_CONF_EXTENSION);
            };
        };

        File[] inputs = mcDir.listFiles(filter);

        if (inputs != null) {
            copyFile(inputs[0], new File(ctxDir, inputs[0].getName()));
        }

        Log.debug(logPrefix + " copyMcArchive(File publicFolder) - exiting.");
    }

    public void copyScdlFiles(File scdlFolder) throws IOException {
        Log.debug(logPrefix + " copyScdlFiles(File scdlFolder) - entering.");
        Log.info(logPrefix + " copyScdlFiles(File scdlFolder) - Including SCDL files into sda");

        File[] inputs = scdlFolder.listFiles();

        if (inputs != null)
            for (File input : inputs) {
                if (input.isFile()) {
                    copyFile(input, new File(ctxDir, input.getName()));
                } else if (input.isDirectory()) {
                    getSubdirFiles(scdlFolder.toString(), input);
                }
            }
        Log.debug(logPrefix + " copyScdlFiles(File scdlFolder) - exiting.");
    }

    public void copyScdlGlobalizationFiles(File scdlXlfFolder) throws IOException {
        Log.debug(logPrefix + " copyScdlGlobalizationFiles(File scdlXlfFolder) - entering.");
        Log.info(logPrefix + " copyScdlGlobalizationFiles(File scdlXlfFolder) - Including SCDL globalization files into sda");

        File[] inputs = scdlXlfFolder.listFiles();
        File sca_resources = new File(ctxDir, BuildPluginConstants.SCA_RESOURCES);

        if (inputs != null)
            for (File input : inputs) {
                if (input.isFile()) {
                    Log.info(logPrefix + " copyScdlGlobalizationFiles(File scdlXlfFolder) - copyFile: " + ctxDir + "/" + input.getName());
                    copyFile(input, new File(sca_resources, input.getName()));
                } else if (input.isDirectory()) {
                    getSubdirFiles(sca_resources.toString(), input);
                }
            }
        Log.debug(logPrefix + " copyScdlGlobalizationFiles(File scdlXlfFolder) - entering.");
    }

    public void copyFile(File in, File out) throws IOException {
        Log.debug(logPrefix + " copyFile(File in, File out)  - entering.");

        FileInputStream fis = new FileInputStream(in);
        (new File(out.getParent())).mkdirs();
        FileOutputStream fos = new FileOutputStream(out);
        byte[] buf = new byte[1024];
        int i = 0;
        while ((i = fis.read(buf)) != -1) {
            fos.write(buf, 0, i);
        }
        fis.close();
        fos.close();

        Log.debug(logPrefix + " copyFile(File in, File out)  - exiting.");
    }

    private void getSubdirFiles(String parent, File subdir) throws IOException {
        Log.debug(logPrefix + " getSubdirFiles(String parent, File subdir)  - entering.");

        File[] inputs = subdir.listFiles();
        if (inputs != null)
            for (File input : inputs) {
                if (input.isFile()) {
                    Log.info(logPrefix + " getSubdirFiles(String parent, File subdir)  - copyFile: " + ctxDir + "/" + input.getName());
                    copyFile(input, new File(ctxDir + BuildPluginConstants.FILE_SEPARATOR + subdir.getName()
                            + BuildPluginConstants.FILE_SEPARATOR + input.getName()));
                } else if (input.isDirectory()) {
                    getSubdirFiles(parent + subdir.getName() + BuildPluginConstants.FILE_SEPARATOR, input);
                }
            }
        Log.debug(logPrefix + " getSubdirFiles(String parent, File subdir)  - exiting.");
    }

}
