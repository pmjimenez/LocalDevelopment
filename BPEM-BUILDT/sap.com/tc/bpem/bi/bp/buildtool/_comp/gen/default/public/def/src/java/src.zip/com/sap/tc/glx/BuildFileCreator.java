package com.sap.tc.glx;

import java.io.File;
import java.io.IOException;

import com.sap.glx.paradigmInterface.util.BuildPluginConstants;
import com.sap.glx.paradigmInterface.util.BuildPluginUtilities;
import com.sap.glx.paradigmInterface.util.BuildPluginLogConstants;
import com.sap.tc.buildplugin.BuildSessionManager;
import com.sap.tc.buildplugin.api.IBuildContext;
import com.sap.tc.buildplugin.api.IBuildFileCreator;
import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.gen.IGeneratorCall;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.buildplugin.util.BuildPluginException;
import com.sap.tc.buildplugin.util.IAntToolkit;

public class BuildFileCreator implements IBuildFileCreator {

    private String logPrefix = BuildPluginLogConstants.CSN_COMPONENT_NAME + " " + BuildFileCreator.class.getName();

    // utility method to get the current build context.
    protected final IBuildContext getContext() {
        return (IBuildContext) BuildSessionManager.getFromBuildSession(IBuildContext.class.getName());
    }

    public void initialize(IPluginBuildInfo pluginBuildInfo) throws BuildPluginException {}

    public void render(IAntToolkit toolkit) throws BuildPluginException {
        Log.debug(logPrefix + " render(IAntToolkit toolkit) - entering. ");

        IPluginBuildInfo pbi = (IPluginBuildInfo) BuildSessionManager.getFromBuildSession(IPluginBuildInfo.class.getName());
        try {
            // Packaging public parts
            toolkit.startTarget("createPublicParts", "Bpem");
            toolkit.packPublicParts();
            toolkit.endTarget();
            // Building the DC
            toolkit.startTarget("Bpem", "ScdlBase");
            executeTask();

        } catch (Exception e) {
            Log.error(" \"BPM.bp.000010\"  " + logPrefix + "  render(toolkit) - Failed to create build file.", e);
            throw new BuildPluginException("Failed to create build file", e);
        } finally {
            try {
                toolkit.deleteDir(new File(pbi.getGenDirDeploy(), BuildPluginConstants.SDA_TMP_DIR));
                toolkit.deleteFile(new File(pbi.getGenDirDeploy(), BuildPluginConstants.SDA_DD_XML_FILE));
                // toolkit.deleteDir(pbi.getTempDir());
                toolkit.endTarget();
            } catch (IOException e) {
                Log.error(logPrefix + "  render(toolkit) - " + BuildPluginUtilities.convertSatckTraceToString(e));
            }

        }
        Log.debug(logPrefix + "render(IAntToolkit toolkit) - exiting. ");
    }

    public void executeTask() throws BuildPluginException {
        Log.debug(logPrefix + " executeTask() - entering. ");
        
        IGlobalPluginUtil gpu = (IGlobalPluginUtil) BuildSessionManager.getFromBuildSession(IGlobalPluginUtil.class.getName());
        // IBuildContext context = (IBuildContext)
        // BuildSessionManager.getFromBuildSession(IBuildContext.class.getName());
        IGeneratorCall gc = gpu.createGeneratorCall("sap.com~bpem_chain");

        // gc.setInputPath("default", sourceDirs);
        // gc.setOutputPath("default", outputFolder);
        // gc.setUsedPath("default", classpath);

        // gc.setParameter("encoding", "UTF8");
        // gc.setParameter("source-root", context.getAsString("dc_rootDir"));
        // gc.setParameter("fork", context.getAsString("dc_javac_fork_compile"));
        // gc.setParameter("executable", context.getAsString("compiler_executable_path"));
        // gc.setParameter("source", context.getAsString("javac_source"));
        try {
            gc.invoke();
        } catch (Exception e) {
            Log.error(" \"BPM.bp.000011\"  " + logPrefix + "  executeTask() - Failed to invoked sap.com~bpem_chain.", e);
            throw new BuildPluginException("Failed to invoked sap.com~bpem_chain", e);
        }
        Log.debug(logPrefix + " executeTask()) - exiting. ");
    }

    public void destroy() throws BuildPluginException {}

}
