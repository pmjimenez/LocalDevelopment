package com.sap.tc.glx;

import com.sap.glx.paradigmInterface.buildapi.CompilerTypes;

/**
 * This class represents a row in the VersionRegistry.
 * @author I044123
 * 
 */
public class VersionRegistry {

    private Object artifact;
    private CompilerTypes.CompilerType compilerId;
    private String versionId;
    private String sourcePath;
    private String targetPath;
    private boolean toPackage;

    // private static String logPrefix = BuldPluginLogConstant.CSN_COMPONENET_NAME + " " + VersionRegistry.class.getName();

    VersionRegistry(Object pArtifact, CompilerTypes.CompilerType pCompilerId, String pVersionId, String pSourcePath, String pTargetPath,
            boolean pToPackage) {
        artifact = pArtifact;
        compilerId = pCompilerId;
        versionId = pVersionId;
        sourcePath = pSourcePath;
        targetPath = pTargetPath;
        toPackage = pToPackage;
    }

    public Object getArtifact() {
        return artifact;
    }

    public CompilerTypes.CompilerType getCompilerId() {
        return compilerId;
    }

    public String getVersionId() {
        return versionId;
    }

    public String getSourcePath() {
        return sourcePath;
    }

    public String getTargetPath() {
        return targetPath;
    }

    public void setVersionId(String versionId) {
        this.versionId = versionId;
    }

    public void setSourcePath(String sourcePath) {
        this.sourcePath = sourcePath;
    }

    public void setTargetPath(String targetPath) {
        this.targetPath = targetPath;
    }

    public boolean isToPackage() {
        return toPackage;
    }

    public void setToPackage(boolean toPackage) {
        this.toPackage = toPackage;
    }

}
