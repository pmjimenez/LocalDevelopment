package com.sap.glx.paradigmInterface.util;

import java.io.PrintWriter;
import java.io.StringWriter;

public class BuildPluginUtilities {

    /**
     * Convert the stack trace into String in order to use it in SAP engine standard logging mechanism.
     * @param th - Throwable. Can not be null.
     * @return - String. String version of the stack trace.
     */
    public static String convertSatckTraceToString(Throwable th) {
        if (th == null)
            return "";
        StringWriter writer = new StringWriter();
        th.printStackTrace(new PrintWriter(writer));
        return "caused by " + writer.toString();
    }	
}
