package com.sap.tc.glx;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.namespace.QName;

import org.apache.tools.ant.BuildException;

import com.sap.glx.paradigmInterface.bpmn.compiler.type.TypeCompiler;
import com.sap.glx.paradigmInterface.brms.compiler.RulesCompilerUtility;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost;
import com.sap.glx.paradigmInterface.buildapi.ICompiler;
import com.sap.glx.paradigmInterface.buildapi.RulesArtifactWrapper;
import com.sap.glx.paradigmInterface.buildapi.RulesCompilationState;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.glx.paradigmInterface.buildapi.RulesArtifactWrapper.RulesArtifactType;
import com.sap.glx.paradigmInterface.util.BuildPluginConstants;
import com.sap.glx.paradigmInterface.util.BuildPluginLogConstants;
import com.sap.glx.paradigmInterface.util.ToolUtils;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.esmp.mm.xsd1.XsdComplexTypeDefinition;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;
import com.sap.tc.esmp.mm.xsd1.XsdNamedComponent;
import com.sap.tc.moin.repository.Connection;

/**
 * 
 * @author I047246
 * 
 */
public class RulesArtifactsCompilationManager {

    private IPluginBuildInfo pbi;
    private IBuilderHost builder;
    private HashMap<CompilerType, List<Object>> compedObjects;

    private Connection conn;
    private BpemTask bpemTask;
    private static String logPrefix = BuildPluginLogConstants.CSN_COMPONENT_NAME + " " + RulesArtifactsCompilationManager.class.getName();

    public RulesArtifactsCompilationManager(IPluginBuildInfo pbi, IBuilderHost builder, HashMap<CompilerType, List<Object>> compObjects,
            Connection conn, BpemTask bpemTask) {
        this.pbi = pbi;
        this.builder = builder;
        this.compedObjects = compObjects;
        this.conn = conn;
        this.bpemTask = bpemTask;
    }

    public void manageCompilation() throws Exception {
        Log.debug(logPrefix + " manageCompilation() - entering.");

        // Collect rules artifacts
        Iterable<RulesArtifactWrapper> rulesArtifacts = collectRulesArtifactsForCompilation(pbi);

        // Get the CompDirs corresponding to RULESCOMPILER
        CompDirs[] compDirs = CompilerRegistry.COMPILERS;
        CompDirs rulesCompDir = null;

        for (int i = 0; i < compDirs.length; i++) {
            CompDirs compDir = compDirs[i];
            CompilerType compType = compDir.getCompiler();
            if (compType.equals(CompilerType.RULESCOMPILER)) {
                rulesCompDir = compDir;
                break;
            }
        }
        // Compile the rules artifacts
        //There is a static map been created for every project compiled.
        //So we need to clear map just before the compilation.  
        RulesCompilerUtility.clearRulesetGuidVsNameMap();
        for (RulesArtifactWrapper refobj : rulesArtifacts) {
            CompilerRegistry.resetIndex();
            processRulesCompilation(refobj, rulesCompDir);
        }

        Log.debug(logPrefix + " manageCompilation() - exiting.");
    }

    private Iterable<RulesArtifactWrapper> collectRulesArtifactsForCompilation(IPluginBuildInfo pbi) {
        List<RulesArtifactWrapper> result = new ArrayList<RulesArtifactWrapper>(0);

        Log.debug(logPrefix + " collectRulesArtifactsForCompilation(IPluginBuildInfo pbi) - entering.");

        List<File> srcFiles = pbi.getSourceDirsAsFiles();

        for (File file : srcFiles) {
            String filename = file.getName();
            Log.debug(logPrefix + " collectRulesArtifactsForCompilation(pbi) - filename :" + filename);

            // Get src folder
            if (filename.equals("src")) { //$NON-NLS-1$
                String sourcePath = file.getAbsolutePath() + File.separator + "brms"; //$NON-NLS-1$
                File brmsFile = new File(sourcePath);

                if (!brmsFile.exists()) {
                    return result;
                }

                // Filter files corresponding to rules artifacts
                File[] artifactsFile = brmsFile.listFiles(new FileFilter() {

                    public boolean accept(File file) {
                        String fName = file.getName();
                        if (fName.endsWith(BuildPluginConstants.PROJECT_EXT) || fName.endsWith(BuildPluginConstants.RULESET_EXT)
                                || fName.endsWith(BuildPluginConstants.ALIASSET_EXT) || fName.endsWith(BuildPluginConstants.SHAREDRES_EXT)
                                || fName.equals(BuildPluginConstants.VALIDATION_MSGS_FILE_NAME)) {
                            return true;
                        }
                        return false;
                    }
                });

                if (artifactsFile.length == 0) {
                    // No rules artifacts to compile.
                    return result;
                }

                // return rules artifacts in the order (1) validation messages (2) shared resource (3)shared resource aliasset
                // (4) project (5)project aliasset (6) aliassets of rulesets (7) rulesets (8) csdl

                // Rules artifacts
                RulesArtifactWrapper validationMsgs = null;
                RulesArtifactWrapper project = null;
                RulesArtifactWrapper projectAset = null;
                RulesArtifactWrapper sharedRes = null;
                RulesArtifactWrapper sharedResAset = null;

                List<RulesArtifactWrapper> rulesetAliasSets = new ArrayList<RulesArtifactWrapper>();
                List<RulesArtifactWrapper> rulesets = new ArrayList<RulesArtifactWrapper>();

                RulesCompilationState compilationState = new RulesCompilationState();

                for (File artifactFile : artifactsFile) {
                    String filepath = artifactFile.getPath();
                    if (filepath.endsWith(BuildPluginConstants.PROJECT_EXT)) {
                        project = new RulesArtifactWrapper(filepath, RulesArtifactType.PROJECT, compilationState);
                    } else if (filepath.endsWith(BuildPluginConstants.SHAREDRES_EXT)) {
                        sharedRes = new RulesArtifactWrapper(filepath, RulesArtifactType.SHAREDRESOURCE, compilationState);
                    } else if (filepath.endsWith(BuildPluginConstants.VALIDATION_MSGS_FILE_NAME)) {
                        validationMsgs = new RulesArtifactWrapper(filepath, RulesArtifactType.VALIDATION_MSGS, compilationState);
                    }
                }

                String projectPath = project.getArtifactPath();
                Log.debug(logPrefix + " collectRulesArtifactsForCompilation(pbi) - projectPath:" + projectPath);

                int index1 = projectPath.lastIndexOf(File.separator);
                String temp = projectPath.substring(index1 + 1, projectPath.length());
                int index2 = temp.indexOf(BuildPluginConstants.PROJECT_EXT);

                String projectName = temp.substring(0, index2);
                compilationState.setProjectName(projectName);

                for (File artifactFile : artifactsFile) {
                    String filepath = artifactFile.getPath();
                    if (filepath.endsWith(projectName + BuildPluginConstants.ALIASSET_EXT)) {
                        projectAset = new RulesArtifactWrapper(filepath, RulesArtifactType.PROJECT_ALIASSET, compilationState);
                    } else if (filepath.endsWith(projectName + BuildPluginConstants.SHAREDRES_ALIASSET_SUFFIX
                            + BuildPluginConstants.ALIASSET_EXT)) {
                        sharedResAset = new RulesArtifactWrapper(filepath, RulesArtifactType.SHAREDRESOURCE_ALIASSET, compilationState);
                    } else if (filepath.endsWith(BuildPluginConstants.ALIASSET_EXT)) {
                        rulesetAliasSets.add(new RulesArtifactWrapper(filepath, RulesArtifactType.RULESET_ALIASSET, compilationState));
                    } else if (filepath.endsWith(BuildPluginConstants.RULESET_EXT)) {
                        rulesets.add(new RulesArtifactWrapper(filepath, RulesArtifactType.RULESET, compilationState));
                    }
                }

                if (validationMsgs != null) {
                    result.add(validationMsgs);
                }

                if (sharedRes != null && sharedResAset != null) {
                    result.add(sharedRes);
                    result.add(sharedResAset);
                }

                result.add(project);
                result.add(projectAset);
                result.addAll(rulesetAliasSets);
                result.addAll(rulesets);

                // CSDL artifacts
                String wsPath = sourcePath + File.separator + "ws"; //$NON-NLS-1$
                File wsFile = new File(wsPath);

                if (wsFile.exists()) {
                    File[] csdlFiles = wsFile.listFiles(new FileFilter() {

                        public boolean accept(File file) {
                            String fName = file.getName();
                            if (fName.endsWith(BuildPluginConstants.CSDL_EXT)) {
                                return true;
                            }
                            return false;
                        }
                    });

                    for (File csdlFile : csdlFiles) {
                        String csdlFilePath = csdlFile.getPath();
                        RulesArtifactWrapper csdlArtifact = new RulesArtifactWrapper(csdlFilePath, RulesArtifactType.CSDL, compilationState);
                        result.add(csdlArtifact);
                    }
                }

                // Set lastRulesArtifact flag on the last rules artifact
                RulesArtifactWrapper lastRulesArtifact = result.get(result.size() - 1);
                lastRulesArtifact.setLastRulesArtifacr(true);

                return result;
            }
        }
        Log.debug(logPrefix + " collectRulesArtifactsForCompilation(IPluginBuildInfo pbi) - exiting.");
        return result;
    }

    @SuppressWarnings("unchecked")
	private void processRulesCompilation(RulesArtifactWrapper rulestArtifact, CompDirs compDir) throws Exception {
        Log.debug(logPrefix + " processRulesCompilation(RulesArtifactWrapper rulestArtifact, CompDirs compDir) - entering.");

        Log.debug(logPrefix + " processRulesCompilation(rulestArtifact, compDir) - Compiling rules object : " + rulestArtifact.toString()); //$NON-NLS-1$
        RulesCompilationState compilationState = rulestArtifact.getRulesCompilationState();
        ICompiler currentCompiler = (ICompiler) Class.forName(compDir.getClassString()).newInstance();

        // if the object was already compiled with this Compiler, skip it
        CompilerType cType = compDir.getCompiler();
        if (compedObjects.get(cType) != null && compedObjects.get(cType).contains(rulestArtifact))
            return;

        if (currentCompiler.canCompile(rulestArtifact)) {
            Object[] refs = currentCompiler.getDependencies(builder, rulestArtifact);
            for (Object ref : refs)
                Log.debug(logPrefix + " processRulesCompilation(rulestArtifact, compDir) - ref: " + ref); //$NON-NLS-1$

            if (refs.length == 2 && (refs[0] instanceof Map) && (refs[1] instanceof Map)) {
                generateType((Map<String, String>) refs[0], (Map<String, Map<String, String>>) refs[1], compilationState);
            }

            int index = getIndexOfCompiler(cType);
            CompilerRegistry.setIndex(index);

            Log
                    .debug(logPrefix
                            + " processRulesCompilation(rulestArtifact, compDir) - Obj: " + rulestArtifact + ", compiler: " + compDir.getCompiler()); //$NON-NLS-1$
            currentCompiler.compile(builder, rulestArtifact);

            // Update list of compiled objects after compile is finished
            updateCompedObjects(compDir.getCompiler(), rulestArtifact);
        }
        Log.debug(logPrefix + " processRulesCompilation(RulesArtifactWrapper rulestArtifact, CompDirs compDir) - exiting.");
    }

    /*
     * This is code duplication Same method also exists in BpemTask
     */
    private int getIndexOfCompiler(CompilerType c) throws BuildException {
        int i = 0;
        for (CompDirs compD : CompilerRegistry.COMPILERS) {
            if (compD.getCompiler() == c)
                return i;
            i++;
        }
        Log.error(" \"BPM.bp.000015\"  " + logPrefix + "   getIndexOfCompiler(CompilerType c) - compiler is not listed in the Registry(Index).");
        throw new BuildException(c.toString() + " compiler is not listed in the Registry."); //$NON-NLS-1$
    }

    /*
     * This is code duplication Same method also exists in BpemTask
     */
    private void updateCompedObjects(CompilerType comp, Object obj) {
        List<Object> list = compedObjects.get(comp);
        if (list == null) {
            list = new ArrayList<Object>();
        }
        list.add(obj); // update list
        compedObjects.put(comp, list); // update HashMap of artifacts with their lists
    }

    private void generateType(Map<String, String> prefixVsNamespace, Map<String, Map<String, String>> entityNameVsElementNameVsPrefix,
            RulesCompilationState compilationState) throws Exception {
        Log.debug(logPrefix + " generateType(prefixVsNamespace, entityNameVsElementNameVsPrefix, compilationState) - entering.");
        
        Set<Map.Entry<String, Map<String, String>>> elementVsNSPrefixEntry = entityNameVsElementNameVsPrefix.entrySet();
        Iterator<Map.Entry<String, Map<String, String>>> elementVsNSPrefixIt = elementVsNSPrefixEntry.iterator();
        List<QName> processedElementDeclarations = new ArrayList<QName>();
        Collection<XsdElementDeclaration> dependentTypes = new ArrayList<XsdElementDeclaration>();
        
        while (elementVsNSPrefixIt.hasNext()) {
            Map.Entry<String, Map<String, String>> entry = elementVsNSPrefixIt.next();
            Map<String, String> elementNameVsPrefix = entry.getValue();

            Set<Map.Entry<String, String>> elementNameVsPrefixSet = elementNameVsPrefix.entrySet();
            Iterator<Map.Entry<String, String>> elementNameVsPrefixIt = elementNameVsPrefixSet.iterator();

            while (elementNameVsPrefixIt.hasNext()) {
                Map.Entry<String, String> entry2 = elementNameVsPrefixIt.next();
                String elementName = entry2.getKey();
                String prefix = entry2.getValue();
                String nameSpace = prefixVsNamespace.get(prefix);
                QName qName = new QName(nameSpace, elementName);
                
                // Check if QName is already processed
                if (!processedElementDeclarations.contains(qName)) {
                	// Returns collection of XsdElementDeclarations with specified qname          	
                    Collection<XsdElementDeclaration> result = ToolUtils.getInstance().findXsdElementDeclarations(conn, new QName(nameSpace, elementName));
                    
                    // Get global XsdElementDeclaration from result.
                    if(result != null && !result.isEmpty()){
                    	Collection<XsdElementDeclaration> globalXsdElemDeclarations = new ArrayList<XsdElementDeclaration>();
                    	Iterator<XsdElementDeclaration> resultIt = result.iterator();
                    	while(resultIt.hasNext()){
                    		XsdElementDeclaration xsdElemDecl = resultIt.next();
                    		// container is null for global XsdElementDeclaration
                    		if(xsdElemDecl.getContainer()==null){
                    			if(globalXsdElemDeclarations.size() == 0){
                    				globalXsdElemDeclarations.add(xsdElemDecl);
                    			}else{
                    				if(nameSpace != null){
	                    				// More than one global XsdElementDeclaration
	                    				Log.warn("More than one global XsdElementDeclaration found for \'"+qName+"\'.");	
	                    				//throw new BuildException("More than one global XsdElementDeclaration found for \'"+qName+"\'.");
                    				}else{
                    					globalXsdElemDeclarations.add(xsdElemDecl);
                    				}
                    			}
                    		}
                    	}
                    	
                    	if(nameSpace == null && globalXsdElemDeclarations.size() > 1){
                    		int size = globalXsdElemDeclarations.size();
                    		Log.warn("No NameSpace information for \'"+qName+"\' and \'"+size+"\' global XsdElementDeclarations found.");
                    	}
                    	if(globalXsdElemDeclarations.size() > 0){
                    		dependentTypes.addAll(globalXsdElemDeclarations);
                    		processedElementDeclarations.add(qName);
                    	}
                    }else{
                    	// Moin query results in null when there is no corresponding data in moin repo for the given XML element
                    	// and happens when there are old XML aliases which have not been cleaned properly.
                    	Log.warn("No XsdElementDeclaration found for \'"+qName+"\'.");
                    }
                }
            }
        }

        try {
            int typeCompilerIndex = getIndexOfTypeCompiler();
            if (typeCompilerIndex < 0) {
                Log.error(" \"BPM.bp.000016\"  " + logPrefix + "   generateType(prefixVsNamespace, entityNameVsElementNameVsPrefix, compilationState) -  compiler is not listed in the Registry(genType).");
                throw new BuildException("TypeCompiler is not listed in the registry"); //$NON-NLS-1$
            } else {
                CompilerRegistry.setIndex(typeCompilerIndex);
                if (dependentTypes.size() > 0) {
                	Map<String, Collection<XsdComplexTypeDefinition>> complexTypesAndSubTypesMap = XsdUtil.collectTypesAndSubTypes(dependentTypes);
                	Collection<XsdComplexTypeDefinition> complexSubTypes = complexTypesAndSubTypesMap.get(XsdUtil.COMPLEX_SUB_TYPES_KEY);
                	String typeHash = null;
                	if(complexSubTypes.size()==0){
                		// No sub-types.
	                    bpemTask.processCompiler(dependentTypes, CompilerRegistry.COMPILERS[typeCompilerIndex]);
	                    typeHash = builder.getVersionId(dependentTypes);
                	}else{
                		// sub-types. Call special method in type compiler to handle sub-types.
                		TypeCompiler typeCompiler = new TypeCompiler();
                		Collection<XsdNamedComponent> elementsCollection = new ArrayList<XsdNamedComponent>();
                		elementsCollection.addAll(dependentTypes);
                		
                		Collection<XsdNamedComponent> subTypesCollection = new ArrayList<XsdNamedComponent>();
                		subTypesCollection.addAll(complexSubTypes);
                		
                		Map<String, Collection<XsdNamedComponent>> elementsAndSubTypesMap = new HashMap<String, Collection<XsdNamedComponent>>();
                		elementsAndSubTypesMap.put("elements",elementsCollection);
                		elementsAndSubTypesMap.put("subtypes",subTypesCollection);
                		typeCompiler.compileWithSubTypes(builder, elementsAndSubTypesMap);
                		Collection<XsdNamedComponent> elementsAndSubTypes = new ArrayList<XsdNamedComponent>();
                		elementsAndSubTypes.addAll(dependentTypes);
                		elementsAndSubTypes.addAll(complexSubTypes);
                		typeHash = builder.getVersionId(elementsAndSubTypesMap);
                	}
                	compilationState.setMofId(typeHash);
                }
            }
        } finally {
            CompilerRegistry.resetIndex();
        }
        Log.debug(logPrefix + " generateType(prefixVsNamespace, entityNameVsElementNameVsPrefix, compilationState) - exiting.");
    }

    private int getIndexOfTypeCompiler() {
        int typeCompilerIndex = -1;

        for (int i = 0; i < CompilerRegistry.COMPILERS.length; i++) {
            CompDirs compDir = CompilerRegistry.COMPILERS[i];
            if (compDir.getCompiler() == CompilerTypes.CompilerType.TYPECOMPILER) {
                typeCompilerIndex = i;
                break;
            }
        }

        return typeCompilerIndex;
    }

}
