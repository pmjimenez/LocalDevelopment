package com.sap.tc.glx;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.sap.glx.paradigmInterface.util.BuildPluginConstants;
import com.sap.glx.paradigmInterface.util.BuildPluginLogConstants;
import com.sap.tc.buildplugin.api.IDataContext;
import com.sap.tc.buildplugin.gen.GeneratorException;
import com.sap.tc.buildplugin.gen.IGenerator;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.buildplugin.util.IAntToolkit;
import com.sap.tc.buildplugin.util.IAntToolkit.Element;

public class BpemTaskGenerator implements IGenerator {

    private String logPrefix = BuildPluginLogConstants.CSN_COMPONENT_NAME + " " + BpemTaskGenerator.class.getName();

    public void execute(IAntToolkit toolkit, IDataContext arg1, Map<String, List> arg2, Map<String, Object> arg3, Map<String, List> arg4,
            Map<String, Object> arg5) throws GeneratorException, IOException {

        Log.debug(logPrefix + " execute() - entering. ");

        Element elem = toolkit.createElement(BuildPluginConstants.BPEM_TASK);
        elem.render();

        Log.debug(logPrefix + " execute() - entering. ");
    }

}
