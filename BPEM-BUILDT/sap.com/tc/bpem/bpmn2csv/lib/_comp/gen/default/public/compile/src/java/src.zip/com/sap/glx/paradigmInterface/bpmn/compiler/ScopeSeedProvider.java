package com.sap.glx.paradigmInterface.bpmn.compiler;

import java.util.ArrayList;
import java.util.Collection;

import com.sap.glx.ide.model.galaxy.task.Task;
import com.sap.glx.ide.model.galaxy.workflow.Collaboration;
import com.sap.glx.ide.model.galaxy.workflow.Scope;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost2;
import com.sap.glx.paradigmInterface.buildapi.ISeedProvider;
import com.sap.glx.paradigmInterface.buildapi.ScopeArtifact;
import com.sap.glx.paradigmInterface.util.ToolUtils;

public class ScopeSeedProvider implements ISeedProvider<Scope,ScopeArtifact> {

    public Iterable<ScopeArtifact> getSeed(IBuilderHost2 host) {
        ArrayList<ScopeArtifact> ret = new ArrayList<ScopeArtifact>();
        
        // Querying for tasks
        Collection<Task> resultSet2 = ToolUtils.getInstance().queryByType(host.getConnection(), 
                Task.class, new String[] { "Galaxy", "Task", "Task" }, true, host.getLocalDCIdentifier()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
        for (Task task : resultSet2) {
            ScopeArtifact item = new ScopeArtifact((Scope)task, host);
            ret.add(item);
        }
        
        // Querying for workflows
        Collection<Collaboration> resultSet = ToolUtils.getInstance().queryByType(host.getConnection(), 
                Collaboration.class, new String[] { "Galaxy", "Workflow", "Collaboration" }, true, host.getLocalDCIdentifier()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
        for (Collaboration collab : resultSet) {
            ScopeArtifact item = new ScopeArtifact((Scope)collab, host);
            ret.add(item);
        }
        
        
        return ret;
    }
}
