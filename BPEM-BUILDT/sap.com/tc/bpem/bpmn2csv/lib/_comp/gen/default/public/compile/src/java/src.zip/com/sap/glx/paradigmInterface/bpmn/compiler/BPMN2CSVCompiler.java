package com.sap.glx.paradigmInterface.bpmn.compiler;

import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import com.sap.glx.ide.model.galaxy.core.ModelElement;
import com.sap.glx.ide.model.galaxy.task.Task;
import com.sap.glx.ide.model.galaxy.workflow.Collaboration;
import com.sap.glx.ide.model.galaxy.workflow.Scope;
import com.sap.glx.ide.model.triggernet.Subnet;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.DependencyHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.WorkflowHelper;
import com.sap.glx.paradigmInterface.bpmn.preprocessor.ArtificialLoopPreProcessor;
import com.sap.glx.paradigmInterface.bpmn.preprocessor.IBPMNPreProcessor;
import com.sap.glx.paradigmInterface.buildapi.BpemBuildException;
import com.sap.glx.paradigmInterface.buildapi.IArtifact;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost2;
import com.sap.glx.paradigmInterface.buildapi.ICompiler;
import com.sap.glx.paradigmInterface.buildapi.ICompiler2;
import com.sap.glx.paradigmInterface.buildapi.ModelElementArtifact;
import com.sap.glx.paradigmInterface.facades.ITriggernetFacade;
import com.sap.glx.paradigmInterface.facades.TriggernetTransaction;
import com.sap.glx.paradigmInterface.facades.impl.TriggernetFacade;
import com.sap.glx.paradigmInterface.triggernet.assembler.GalaxyAssembler;
import com.sap.tc.moin.repository.Connection;
import com.sap.tc.moin.repository.Partitionable;

/**
 * A BPMN2CSV compiler for the BPEM Build Plugin.
 * 
 * @author Thilo-Alexander Ginkel
 * @author Philipp Sommer
 * 
 * @version $Id:
 * //bpem/bpem.bp/NWCorr_stream/src/SCs/sap.com/BPEM-BUILDT/DCs/sap.com/tc/bpem/bpmn2csv/lib/_comp/src/com/sap/glx/paradigmInterface
 * /bpmn/compiler/BPMN2CSVCompiler.java#2 $
 */
public class BPMN2CSVCompiler implements ICompiler, ICompiler2<ModelElement, ModelElementArtifact> {

    private DependencyHelper dependencies = null;
    private List<IBPMNPreProcessor> preProcessors = null;

    public boolean canCompile(Object artifact) {
        return (artifact instanceof Task || artifact instanceof Collaboration);
    }

    public BPMN2CSVCompiler() {
        preProcessors = new ArrayList<IBPMNPreProcessor>(1);
        preProcessors.add(new ArtificialLoopPreProcessor());
    }

    public boolean compile(final IBuilderHost host, final Object artifact) throws BpemBuildException, Exception {
        if (canCompile(artifact)) {
            final Scope scope;
            final String wfName;

            if (artifact instanceof Collaboration) {
                Collaboration workflow = (Collaboration) artifact;
                scope = WorkflowHelper.getActivePool(workflow);
                wfName = workflow.getName().getOriginalText();
                host.calculateVersionId(workflow);
            } else if (artifact instanceof Task) {
                scope = (Task) artifact;
                wfName = scope.getName().getOriginalText();
                host.calculateVersionId(scope);
            } else {
                throw new IllegalStateException("Cannot compile the given artifact."); //$NON-NLS-1$
            }

            final Connection conn = ((Partitionable) scope).get___Connection();

            // run the preprocessors
            if (preProcessors != null) {
                conn.enableMemoryChangeOnly();
                for (IBPMNPreProcessor processor : preProcessors) {
                    processor.process(scope);
                }
            }

            TriggernetTransaction tx = new TriggernetTransaction(conn, false) {

                @Override
                protected Subnet compileSubnet() throws Exception {

                    host.getWarnable().addWarning(Warnable.Severity.INFORMATION, null,
                            "Compiling process '%s' ...", scope.getOriginalName()); //$NON-NLS-1$
                    ITriggernetFacade triggernetFacade = new TriggernetFacade(this);

                    CompilerRun compiler = new CompilerRun();
                    Pair<Subnet, String> result = compiler.generateTriggerNetwork(scope, triggernetFacade, getDependencyHelper(), host);

                    // explicitly tell the build plugin the version id from the first compiler pass
                    host.setVersionId(artifact, result.second);
                    return result.first;
                }

                @Override
                protected Object useSubnet(Subnet subnet) throws Exception {
                    host.getWarnable().addWarning(Warnable.Severity.INFORMATION, null, "Transforming Trigger Network into CSV...");//$NON-NLS-1$
                    OutputStream out = host.createVersionedTargetFile(wfName + ".csv", artifact);
                    PrintWriter writer = new PrintWriter(new OutputStreamWriter(out, "UTF-8")); //$NON-NLS-1$
                    new GalaxyAssembler(host).generateCSV(subnet, writer);
                    return true;
                }
            };
            tx.process();

            // revert the changes of the preprocessors
            conn.revert();
            return true;
        } else {
            return false;
        }
    }

    private DependencyHelper getDependencyHelper() {
        if (dependencies == null)
            dependencies = new DependencyHelper();
        return dependencies;
    }

    public Object[] getDependencies(IBuilderHost host, Object artifact) {
        DependencyHelper dependencyHelper = getDependencyHelper();
        if (artifact instanceof Collaboration) {
            return dependencyHelper.getAllDependencies((Collaboration) artifact);
        } else if (artifact instanceof Task) {
            return dependencyHelper.getAllDependencies((Task) artifact);
        }

        // if the artifact is neither a collaboration nor a task, we just have no dependencies
        return new Object[0];
    }

    public boolean compile(IBuilderHost2 host, ModelElementArtifact artifact) throws BpemBuildException {
        throw new UnsupportedOperationException();
    }

    public IArtifact<?>[] getDependencies(IBuilderHost2 host, ModelElementArtifact artifact) {
        throw new UnsupportedOperationException();
    }

}
