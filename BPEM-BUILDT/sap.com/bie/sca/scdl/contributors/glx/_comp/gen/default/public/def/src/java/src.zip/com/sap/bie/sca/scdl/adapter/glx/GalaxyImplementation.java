package com.sap.bie.sca.scdl.adapter.glx;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.impl.CustomScdlElement;
import com.sap.bie.sca.scdl.adapter.impl.Implementation;

public class GalaxyImplementation extends Implementation {
	private static final String IMPLEMENTATION_BPM = "implementation.bpm"; //$NON-NLS-1$
	private static final String IMPLEMENTATION_BPM_NAMESPACE_VALUE = "http://www.sap.com/webas/2007/03/esoa/implementation/bpm";
	private static final String IMPLEMENTATION_BPM_NAMESPACE_NAME = "sapimplbpm";

	public GalaxyImplementation() {
		super(new QName(IMPLEMENTATION_BPM_NAMESPACE_VALUE, IMPLEMENTATION_BPM, IMPLEMENTATION_BPM_NAMESPACE_NAME));
		
		CustomScdlElement glxImpl = new CustomScdlElement(getName());
		
		addCustomElement(glxImpl);
	}


}
