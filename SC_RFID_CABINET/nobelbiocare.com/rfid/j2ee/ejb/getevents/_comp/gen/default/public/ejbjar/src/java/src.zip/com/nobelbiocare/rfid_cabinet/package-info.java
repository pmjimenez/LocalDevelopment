@javax.xml.bind.annotation.XmlSchema(namespace = "http://nobelbiocare.com/rfid_cabinet")
package com.nobelbiocare.rfid_cabinet;
